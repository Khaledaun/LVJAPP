
import { NextResponse } from "next/server";
import { getPrisma } from "@/lib/db";
import { getCurrentUser, requireAdmin } from "@/lib/rbac";
import { logUserManagement } from "@/lib/audit-log";
import { Role } from "@prisma/client";
import bcrypt from "bcryptjs";

export const dynamic = "force-dynamic";

// GET - List all users (ADMIN only)
export async function GET(req: Request) {
  try {
    const user = await getCurrentUser();
    requireAdmin(user);

    const { searchParams } = new URL(req.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const role = searchParams.get('role') as Role | null;
    
    const skip = (page - 1) * limit;
    
    const prisma = await getPrisma();
    
    const whereClause: any = {};
    if (role && Object.values(Role).includes(role)) {
      whereClause.role = role;
    }

    const [users, totalCount] = await Promise.all([
      prisma.user.findMany({
        where: whereClause,
        select: {
          id: true,
          email: true,
          name: true,
          firstName: true,
          lastName: true,
          phone: true,
          role: true,
          isActive: true,
          preferredLanguage: true,
          lastLoginAt: true,
          createdAt: true,
          updatedAt: true,
          _count: {
            select: {
              casesAsClient: true,
              casesAsManager: true,
              casesAsLawyer: true,
            }
          }
        },
        skip,
        take: limit,
        orderBy: {
          createdAt: 'desc',
        },
      }),
      prisma.user.count({ where: whereClause }),
    ]);

    return NextResponse.json({
      users,
      pagination: {
        page,
        limit,
        totalCount,
        totalPages: Math.ceil(totalCount / limit),
      },
    });
  } catch (error: any) {
    console.error("Failed to fetch users:", error);
    return NextResponse.json(
      { error: error?.message || "Internal Server Error" },
      { status: error?.status || 500 }
    );
  }
}

// POST - Create a new user (ADMIN only)
export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    requireAdmin(user);

    const body = await req.json();
    const { email, name, firstName, lastName, phone, role, password } = body;

    // Validation
    if (!email || !name || !role || !password) {
      return NextResponse.json(
        { error: 'Email, name, role, and password are required' },
        { status: 400 }
      );
    }

    if (!Object.values(Role).includes(role)) {
      return NextResponse.json(
        { error: 'Invalid role specified' },
        { status: 400 }
      );
    }

    const prisma = await getPrisma();

    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email },
    });

    if (existingUser) {
      return NextResponse.json(
        { error: 'User with this email already exists' },
        { status: 409 }
      );
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create user
    const newUser = await prisma.user.create({
      data: {
        email,
        name,
        firstName,
        lastName,
        phone,
        role,
        password: hashedPassword,
        isActive: true,
      },
      select: {
        id: true,
        email: true,
        name: true,
        firstName: true,
        lastName: true,
        phone: true,
        role: true,
        isActive: true,
        createdAt: true,
      },
    });

    // Log the user creation
    await logUserManagement(user.id, newUser.id, 'CREATE', {
      email: newUser.email,
      role: newUser.role,
    });

    return NextResponse.json({ user: newUser }, { status: 201 });
  } catch (error: any) {
    console.error("Failed to create user:", error);
    return NextResponse.json(
      { error: error?.message || "Internal Server Error" },
      { status: error?.status || 500 }
    );
  }
}

// PUT - Update user (ADMIN only)
export async function PUT(req: Request) {
  try {
    const user = await getCurrentUser();
    requireAdmin(user);

    const body = await req.json();
    const { userId, updates } = body;

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      );
    }

    const prisma = await getPrisma();

    // Get current user data for audit logging
    const currentUser = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        name: true,
        firstName: true,
        lastName: true,
        phone: true,
        role: true,
        isActive: true,
      },
    });

    if (!currentUser) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // Validate role if provided
    if (updates.role && !Object.values(Role).includes(updates.role)) {
      return NextResponse.json(
        { error: 'Invalid role specified' },
        { status: 400 }
      );
    }

    // Hash password if provided
    if (updates.password) {
      updates.password = await bcrypt.hash(updates.password, 10);
    }

    // Update user
    const updatedUser = await prisma.user.update({
      where: { id: userId },
      data: updates,
      select: {
        id: true,
        email: true,
        name: true,
        firstName: true,
        lastName: true,
        phone: true,
        role: true,
        isActive: true,
        updatedAt: true,
      },
    });

    // Log the update
    await logUserManagement(user.id, userId, 'UPDATE', {
      before: currentUser,
      after: updatedUser,
    });

    return NextResponse.json({ user: updatedUser });
  } catch (error: any) {
    console.error("Failed to update user:", error);
    return NextResponse.json(
      { error: error?.message || "Internal Server Error" },
      { status: error?.status || 500 }
    );
  }
}
