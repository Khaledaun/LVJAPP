
import { getPrisma } from "@/lib/db";

export interface AuditLogData {
  action: string;
  caseId?: string;
  userId?: string;
  diff?: string;
  metadata?: Record<string, any>;
}

/**
 * Create an audit log entry
 */
export async function createAuditLog(data: AuditLogData): Promise<void> {
  try {
    const prisma = await getPrisma();
    
    await prisma.auditLog.create({
      data: {
        action: data.action,
        caseId: data.caseId,
        userId: data.userId,
        diff: data.diff ? JSON.stringify(data.diff) : undefined,
        at: new Date(),
      },
    });
  } catch (error) {
    console.error('Failed to create audit log:', error);
    // Don't throw - audit logging should not break the main flow
  }
}

/**
 * Log case access events
 */
export async function logCaseAccess(caseId: string, userId: string, action: 'VIEW' | 'UPDATE' | 'DELETE'): Promise<void> {
  await createAuditLog({
    action: `CASE_${action}`,
    caseId,
    userId,
  });
}

/**
 * Log user management events
 */
export async function logUserManagement(adminUserId: string, targetUserId: string, action: 'CREATE' | 'UPDATE' | 'DELETE', diff?: any): Promise<void> {
  await createAuditLog({
    action: `USER_${action}`,
    userId: adminUserId,
    diff: diff ? JSON.stringify(diff) : undefined,
    metadata: { targetUserId },
  });
}

/**
 * Log authentication events
 */
export async function logAuthEvent(userId: string, action: 'LOGIN' | 'LOGOUT' | 'LOGIN_FAILED'): Promise<void> {
  await createAuditLog({
    action: `AUTH_${action}`,
    userId,
  });
}
