'use client';

// Simple chart placeholder components to avoid type conflicts
export default function ChartComponents() {
  return (
    <div className="h-[350px] flex items-center justify-center bg-gray-50 rounded-lg">
      <div className="text-center">
        <div className="text-lg font-semibold text-gray-600">Chart Visualization</div>
        <div className="text-sm text-gray-500 mt-2">Analytics charts will be displayed here</div>
      </div>
    </div>
  );
}

// Export individual chart components as placeholders
export const AreaChartComponent = ChartComponents;
export const BarChartComponent = ChartComponents;
export const LineChartComponent = ChartComponents;
export const PieChartComponent = ChartComponents;
