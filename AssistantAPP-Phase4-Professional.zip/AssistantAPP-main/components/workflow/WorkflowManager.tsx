
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { 
  Play, Pause, CheckCircle, AlertCircle, 
  Clock, Users, ArrowRight, Settings,
  Plus, Edit, Trash2, Download
} from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

interface WorkflowTemplate {
  id: string;
  name: string;
  description?: string;
  caseType: string;
  isActive: boolean;
  version: number;
  stages: any[];
  createdAt: string;
  createdBy: {
    name: string;
  };
  _count: {
    workflowRuns: number;
  };
}

interface WorkflowRun {
  id: string;
  status: string;
  progress: number;
  currentStage?: string;
  startedAt: string;
  completedAt?: string;
  case: {
    caseNumber: string;
    title: string;
    client: {
      name: string;
    };
  };
}

interface WorkflowManagerProps {
  className?: string;
}

export default function WorkflowManager({ className }: WorkflowManagerProps) {
  const [templates, setTemplates] = useState<WorkflowTemplate[]>([]);
  const [runs, setRuns] = useState<WorkflowRun[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedView, setSelectedView] = useState('templates');

  useEffect(() => {
    loadWorkflowData();
  }, []);

  const loadWorkflowData = async () => {
    try {
      setLoading(true);
      
      const [templatesResponse, runsResponse] = await Promise.all([
        fetch('/api/workflows'),
        fetch('/api/workflows?type=runs')
      ]);

      if (templatesResponse.ok) {
        const templatesData = await templatesResponse.json();
        if (templatesData.success) {
          setTemplates(templatesData.data || []);
        }
      }

      // For runs, we'll simulate data for now since we don't have the runs endpoint yet
      // In a real implementation, you'd fetch from /api/workflows/runs
      setRuns([]);
      
    } catch (error) {
      console.error('Error loading workflow data:', error);
    } finally {
      setLoading(false);
    }
  };

  const initializeDefaults = async () => {
    try {
      const response = await fetch('/api/workflows', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'initialize_defaults' })
      });

      if (response.ok) {
        const result = await response.json();
        if (result.success) {
          loadWorkflowData();
        }
      }
    } catch (error) {
      console.error('Error initializing defaults:', error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-blue-100 text-blue-800';
      case 'completed': return 'bg-green-100 text-green-800';
      case 'paused': return 'bg-yellow-100 text-yellow-800';
      case 'cancelled': return 'bg-gray-100 text-gray-800';
      case 'error': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <Play className="h-3 w-3" />;
      case 'completed': return <CheckCircle className="h-3 w-3" />;
      case 'paused': return <Pause className="h-3 w-3" />;
      case 'error': return <AlertCircle className="h-3 w-3" />;
      default: return <Clock className="h-3 w-3" />;
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-64" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-5 w-32" />
                <Skeleton className="h-4 w-24" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-20" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Workflow Management</h1>
          <p className="text-gray-600">Manage automation workflows and case processing</p>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" onClick={loadWorkflowData}>
            <Download className="h-4 w-4 mr-1" />
            Refresh
          </Button>
          <Button onClick={initializeDefaults}>
            <Plus className="h-4 w-4 mr-1" />
            Initialize Templates
          </Button>
        </div>
      </div>

      {/* Workflow Tabs */}
      <Tabs value={selectedView} onValueChange={setSelectedView} className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="active">Active Workflows</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        {/* Templates Tab */}
        <TabsContent value="templates" className="space-y-4">
          {templates.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center">
                <div className="text-gray-500 mb-4">
                  <Settings className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p className="text-lg font-medium mb-2">No Workflow Templates</p>
                  <p className="text-sm mb-4">Initialize default templates to get started with automated workflows.</p>
                  <Button onClick={initializeDefaults}>
                    <Plus className="h-4 w-4 mr-2" />
                    Initialize Default Templates
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {templates.map((template) => (
                <Card key={template.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{template.name}</CardTitle>
                        <CardDescription className="mt-1">
                          {template.caseType} • v{template.version}
                        </CardDescription>
                      </div>
                      <Badge variant={template.isActive ? "default" : "secondary"}>
                        {template.isActive ? "Active" : "Inactive"}
                      </Badge>
                    </div>
                    {template.description && (
                      <p className="text-sm text-gray-600">{template.description}</p>
                    )}
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Stages:</span>
                      <span className="font-medium">{template.stages?.length || 0}</span>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Usage:</span>
                      <span className="font-medium">{template._count.workflowRuns} cases</span>
                    </div>
                    
                    <div className="flex items-center text-xs text-gray-500">
                      <Users className="h-3 w-3 mr-1" />
                      Created by {template.createdBy.name}
                    </div>
                    
                    <div className="flex gap-2 pt-2">
                      <Button variant="outline" size="sm" className="flex-1">
                        <Edit className="h-3 w-3 mr-1" />
                        Edit
                      </Button>
                      <Button variant="outline" size="sm">
                        <Settings className="h-3 w-3" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Active Workflows Tab */}
        <TabsContent value="active" className="space-y-4">
          {runs.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center">
                <div className="text-gray-500">
                  <Play className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p className="text-lg font-medium mb-2">No Active Workflows</p>
                  <p className="text-sm">Workflows will appear here when cases are assigned to workflow templates.</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {runs.map((run) => (
                <Card key={run.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">
                          Case {run.case.caseNumber}
                        </CardTitle>
                        <CardDescription>
                          {run.case.title} • Client: {run.case.client.name}
                        </CardDescription>
                      </div>
                      <Badge className={getStatusColor(run.status)}>
                        {getStatusIcon(run.status)}
                        <span className="ml-1 capitalize">{run.status}</span>
                      </Badge>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm text-gray-600">Progress</span>
                        <span className="text-sm font-medium">{run.progress}%</span>
                      </div>
                      <Progress value={run.progress} className="w-full" />
                    </div>
                    
                    {run.currentStage && (
                      <div className="flex items-center text-sm">
                        <span className="text-gray-600 mr-2">Current Stage:</span>
                        <Badge variant="outline">{run.currentStage}</Badge>
                      </div>
                    )}
                    
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span>Started {new Date(run.startedAt).toLocaleDateString()}</span>
                      {run.completedAt && (
                        <span>Completed {new Date(run.completedAt).toLocaleDateString()}</span>
                      )}
                    </div>
                    
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        View Details
                      </Button>
                      {run.status === 'active' && (
                        <Button variant="outline" size="sm">
                          <ArrowRight className="h-3 w-3 mr-1" />
                          Advance Stage
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Total Templates
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{templates.length}</div>
                <p className="text-xs text-gray-600">
                  {templates.filter(t => t.isActive).length} active
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Active Workflows
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{runs.length}</div>
                <p className="text-xs text-gray-600">Currently running</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Avg Completion
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">78%</div>
                <p className="text-xs text-gray-600">Efficiency rate</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Total Usage
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {templates.reduce((sum, t) => sum + t._count.workflowRuns, 0)}
                </div>
                <p className="text-xs text-gray-600">Cases processed</p>
              </CardContent>
            </Card>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Workflow Performance</CardTitle>
              <CardDescription>
                Template usage and efficiency metrics
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {templates.map((template) => (
                  <div key={template.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div>
                      <h4 className="font-medium">{template.name}</h4>
                      <p className="text-sm text-gray-600">{template.caseType}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">{template._count.workflowRuns} runs</p>
                      <p className="text-sm text-gray-600">92% success rate</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
