
'use client';

import { useState, useEffect, useRef } from 'react';
import { useSession } from 'next-auth/react';
import { usePathname } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  LayoutDashboard, FileText, Users, MessageSquare, 
  CheckSquare, BarChart3, Settings, Workflow, 
  DollarSign, Bell, Calendar, Archive,
  ChevronLeft, ChevronRight, Menu, X,
  Plus, Search, User, LogOut, Sun, Moon,
  Zap
} from 'lucide-react';
import { signOut } from 'next-auth/react';
import { useTheme } from 'next-themes';

interface AppLayoutProps {
  children: React.ReactNode;
}

export default function AppLayout({ children }: AppLayoutProps) {
  const { data: session, status } = useSession();
  const pathname = usePathname();
  const { theme, setTheme } = useTheme();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [notificationCount, setNotificationCount] = useState(0);
  const [mounted, setMounted] = useState(false);

  // Fix hydration by ensuring component is mounted
  useEffect(() => {
    setMounted(true);
  }, []);

  // Load notification count
  useEffect(() => {
    if (!session?.user?.id) return;
    
    const loadNotificationCount = async () => {
      try {
        const response = await fetch('/api/notifications/counts');
        if (response?.ok) {
          const result = await response.json();
          if (result?.success) {
            setNotificationCount(result?.data?.unread || 0);
          }
        }
      } catch (error) {
        console.error('Error loading notification count:', error);
      }
    };

    loadNotificationCount();
    const interval = setInterval(loadNotificationCount, 30000);
    return () => clearInterval(interval);
  }, [session?.user?.id]);

  const navigationItems = [
    {
      name: 'Dashboard',
      href: '/dashboard',
      icon: LayoutDashboard,
      badge: null,
      roles: ['CLIENT', 'STAFF', 'ADMIN'],
      description: 'Overview & insights'
    },
    {
      name: 'Cases',
      href: '/cases',
      icon: FileText,
      badge: null,
      roles: ['CLIENT', 'STAFF', 'ADMIN'],
      description: 'Immigration cases'
    },
    {
      name: 'Tasks',
      href: '/tasks',
      icon: CheckSquare,
      badge: null,
      roles: ['CLIENT', 'STAFF', 'ADMIN'],
      description: 'Action items'
    },
    {
      name: 'Messages',
      href: '/messages',
      icon: MessageSquare,
      badge: null,
      roles: ['CLIENT', 'STAFF', 'ADMIN'],
      description: 'Communications'
    },
    {
      name: 'Notifications',
      href: '/notifications',
      icon: Bell,
      badge: notificationCount > 0 ? notificationCount : null,
      roles: ['CLIENT', 'STAFF', 'ADMIN'],
      description: 'Alerts & updates'
    },
    // Staff and Admin sections
    {
      name: 'Analytics',
      href: '/analytics',
      icon: BarChart3,
      badge: null,
      roles: ['STAFF', 'ADMIN'],
      description: 'Performance metrics'
    },
    {
      name: 'Workflows',
      href: '/workflows',
      icon: Workflow,
      badge: null,
      roles: ['STAFF', 'ADMIN'],
      description: 'Process automation'
    },
    {
      name: 'Billing',
      href: '/billing',
      icon: DollarSign,
      badge: null,
      roles: ['STAFF', 'ADMIN'],
      description: 'Financial management'
    },
    // Admin only sections
    {
      name: 'Settings',
      href: '/settings',
      icon: Settings,
      badge: null,
      roles: ['ADMIN'],
      description: 'System configuration'
    }
  ];

  const filteredNavigation = navigationItems.filter(item => 
    !session?.user?.role || item.roles.includes(session.user.role)
  );

  const getUserInitials = (name?: string | null) => {
    if (!name) return 'U';
    return name.split(' ').map(n => n?.[0]).join('').toUpperCase().slice(0, 2);
  };

  const handleSignOut = () => {
    signOut({ callbackUrl: '/signin' });
  };

  const isStaffOrAdmin = session?.user?.role === 'STAFF' || session?.user?.role === 'ADMIN';

  if (!mounted) return null;

  // Don't show layout on auth pages
  if (pathname?.includes('/signin') || pathname?.includes('/signup') || pathname === '/') {
    return <>{children}</>;
  }

  if (status === 'loading') {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <motion.div 
          className="professional-card p-8 rounded-lg shadow-professional-lg"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          <div className="flex items-center space-x-4">
            <div className="w-8 h-8 gradient-professional rounded-lg flex items-center justify-center">
              <Zap className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="text-lg font-semibold text-foreground">LVJ Case Assistant</div>
              <div className="text-sm text-muted-foreground">Loading your workspace...</div>
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  if (!session) {
    return <>{children}</>;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile Sidebar */}
      <Sheet open={mobileSidebarOpen} onOpenChange={setMobileSidebarOpen}>
        <SheetContent side="left" className="p-0 w-80 professional-card border-r">
          <MobileSidebar
            navigationItems={filteredNavigation}
            pathname={pathname}
            onClose={() => setMobileSidebarOpen(false)}
            userRole={session?.user?.role}
          />
        </SheetContent>
      </Sheet>

      {/* Desktop Sidebar */}
      <motion.aside 
        className={cn(
          "fixed left-0 top-0 z-40 hidden lg:block h-screen professional-card border-r transition-all duration-200",
          sidebarCollapsed ? "w-20" : "w-80"
        )}
        initial={{ x: -320 }}
        animate={{ x: 0 }}
        transition={{ duration: 0.3, ease: "easeOut" }}
      >
        <DesktopSidebar
          navigationItems={filteredNavigation}
          pathname={pathname}
          collapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
          userRole={session?.user?.role}
        />
      </motion.aside>

      {/* Main Content Area */}
      <div className={cn(
        "transition-all duration-200",
        "lg:pl-80",
        sidebarCollapsed && "lg:pl-20"
      )}>
        {/* Professional Header */}
        <motion.header 
          className="sticky top-0 z-30 professional-card border-b shadow-professional"
          initial={{ y: -64 }}
          animate={{ y: 0 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
        >
          <div className="flex items-center justify-between px-4 lg:px-8 h-16">
            {/* Mobile menu & Logo */}
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                className="lg:hidden"
                onClick={() => setMobileSidebarOpen(true)}
              >
                <Menu className="h-5 w-5" />
              </Button>
              
              <Link href="/dashboard" className="flex items-center space-x-3">
                <div className="w-10 h-10 gradient-professional rounded-lg flex items-center justify-center shadow-professional">
                  <Zap className="w-5 h-5 text-white" />
                </div>
                <div className="hidden sm:block">
                  <div className="text-lg font-bold text-primary">
                    LVJ Assistant
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Immigration Case Management
                  </div>
                </div>
              </Link>
            </div>

            {/* Search Bar - Hidden on small screens */}
            <div className="hidden md:block flex-1 max-w-lg mx-8">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <input
                  type="text"
                  placeholder="Search cases, clients, tasks..."
                  className="w-full pl-10 pr-4 py-2.5 bg-muted/50 border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200 hover:bg-muted/70"
                />
              </div>
            </div>

            {/* Right Side Actions */}
            <div className="flex items-center space-x-3">
              {/* Quick Actions */}
              {isStaffOrAdmin && (
                <div className="hidden xl:block">
                  <Link href="/cases/new">
                    <Button size="sm" className="btn-professional text-white hover-professional">
                      <Plus className="h-4 w-4 mr-2" />
                      New Case
                    </Button>
                  </Link>
                </div>
              )}

              {/* Theme Toggle */}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="w-9 h-9 p-0"
              >
                <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
                <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
              </Button>

              {/* Notifications */}
              <Button variant="ghost" size="sm" className="relative w-9 h-9 p-0" asChild>
                <Link href="/notifications">
                  <Bell className="h-5 w-5" />
                  {notificationCount > 0 && (
                    <div className="absolute -top-1 -right-1 h-5 w-5 bg-destructive rounded-full flex items-center justify-center">
                      <span className="text-[10px] font-medium text-white">
                        {notificationCount > 99 ? '99+' : notificationCount}
                      </span>
                    </div>
                  )}
                </Link>
              </Button>

              {/* User Menu */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative p-1 hover-professional">
                    <div className="flex items-center space-x-3">
                      <Avatar className="h-9 w-9 shadow-professional">
                        <AvatarImage src={session?.user?.image || ''} alt={session?.user?.name || ''} />
                        <AvatarFallback className="gradient-professional text-white font-medium">
                          {getUserInitials(session?.user?.name)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="hidden lg:block text-left">
                        <div className="text-sm font-semibold text-foreground">
                          {session?.user?.name || 'User'}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {session?.user?.role?.toLowerCase() || 'client'}
                        </div>
                      </div>
                    </div>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56 professional-card shadow-professional-lg">
                  <DropdownMenuLabel>
                    <div>
                      <div className="font-semibold">{session?.user?.name}</div>
                      <div className="text-xs text-muted-foreground font-normal">
                        {session?.user?.email}
                      </div>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  
                  <Link href="/profile">
                    <DropdownMenuItem>
                      <User className="mr-3 h-4 w-4" />
                      Profile
                    </DropdownMenuItem>
                  </Link>
                  
                  <Link href="/settings">
                    <DropdownMenuItem>
                      <Settings className="mr-3 h-4 w-4" />
                      Settings
                    </DropdownMenuItem>
                  </Link>
                  
                  <DropdownMenuSeparator />
                  
                  <DropdownMenuItem onClick={handleSignOut}>
                    <LogOut className="mr-3 h-4 w-4" />
                    Sign out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </motion.header>

        {/* Main Content with Professional Styling */}
        <motion.main 
          className="min-h-[calc(100vh-4rem)] p-4 lg:p-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          {children}
        </motion.main>
      </div>
    </div>
  );
}

// Desktop Sidebar Component
function DesktopSidebar({ 
  navigationItems, 
  pathname, 
  collapsed, 
  onToggleCollapse, 
  userRole 
}: {
  navigationItems: any[];
  pathname: string;
  collapsed: boolean;
  onToggleCollapse: () => void;
  userRole?: string;
}) {
  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-6 border-b border-border/50">
        <div className="flex items-center justify-between">
          {!collapsed && (
            <div>
              <div className="text-xl font-bold text-primary">
                LVJ Assistant
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                Immigration Case Management
              </div>
            </div>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggleCollapse}
            className="w-8 h-8 p-0 hover-professional"
          >
            {collapsed ? (
              <ChevronRight className="h-4 w-4" />
            ) : (
              <ChevronLeft className="h-4 w-4" />
            )}
          </Button>
        </div>
      </div>

      {/* Navigation Items */}
      <div className="flex-1 px-4 py-6 space-y-2">
        {navigationItems.map((item, index) => {
          const isActive = pathname === item.href || pathname?.startsWith(`${item.href}/`);
          return (
            <div key={item.name} className="animate-fade-in">
              <Link
                href={item.href}
                className={cn(
                  "group flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 nav-professional",
                  isActive
                    ? "gradient-professional text-white shadow-professional"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted/50 hover-professional"
                )}
              >
                <item.icon
                  className={cn(
                    "flex-shrink-0 h-5 w-5",
                    collapsed ? "mr-0" : "mr-4",
                    isActive ? "text-white" : "text-muted-foreground group-hover:text-foreground"
                  )}
                />
                <AnimatePresence mode="wait">
                  {!collapsed && (
                    <motion.div
                      className="flex items-center justify-between flex-1"
                      initial={{ opacity: 0, width: 0 }}
                      animate={{ opacity: 1, width: "auto" }}
                      exit={{ opacity: 0, width: 0 }}
                      transition={{ duration: 0.2 }}
                    >
                      <div>
                        <div className="font-medium">{item.name}</div>
                        <div className="text-xs opacity-70">{item.description}</div>
                      </div>
                      {item.badge && (
                        <Badge 
                          className="ml-auto bg-destructive text-destructive-foreground text-xs px-2 py-0.5"
                        >
                          {item.badge > 99 ? '99+' : item.badge}
                        </Badge>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </Link>
            </div>
          );
        })}
      </div>

      {/* User Role Badge */}
      {!collapsed && userRole && (
        <div className="p-6 border-t border-border/50">
          <Badge 
            className={cn(
              "w-full justify-center py-2 text-xs font-medium status-professional",
              userRole === 'ADMIN' ? "bg-purple-100 text-purple-800 border-purple-200" :
              userRole === 'STAFF' ? "bg-blue-100 text-blue-800 border-blue-200" :
              "bg-green-100 text-green-800 border-green-200"
            )}
          >
            {userRole.toLowerCase()} access
          </Badge>
        </div>
      )}
    </div>
  );
}

// Mobile Sidebar Component
function MobileSidebar({ 
  navigationItems, 
  pathname, 
  onClose, 
  userRole 
}: {
  navigationItems: any[];
  pathname: string;
  onClose: () => void;
  userRole?: string;
}) {
  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-6 border-b border-border/50">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-xl font-bold text-primary">
              LVJ Assistant
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              Immigration Case Management
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="w-8 h-8 p-0"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Navigation Items */}
      <div className="flex-1 px-4 py-6 space-y-2">
        {navigationItems.map((item, index) => {
          const isActive = pathname === item.href || pathname?.startsWith(`${item.href}/`);
          return (
            <div key={item.name} className="animate-fade-in">
              <Link
                href={item.href}
                onClick={onClose}
                className={cn(
                  "group flex items-center px-4 py-4 text-sm font-medium rounded-lg transition-all duration-200 nav-professional",
                  isActive
                    ? "gradient-professional text-white shadow-professional"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted/50 hover-professional"
                )}
              >
                <item.icon className="flex-shrink-0 h-5 w-5 mr-4" />
                <div className="flex items-center justify-between flex-1">
                  <div>
                    <div className="font-medium">{item.name}</div>
                    <div className="text-xs opacity-70">{item.description}</div>
                  </div>
                  {item.badge && (
                    <Badge className="ml-auto bg-destructive text-destructive-foreground text-xs">
                      {item.badge > 99 ? '99+' : item.badge}
                    </Badge>
                  )}
                </div>
              </Link>
            </div>
          );
        })}
      </div>

      {/* User Role Badge */}
      {userRole && (
        <div className="p-6 border-t border-border/50">
          <Badge 
            className={cn(
              "w-full justify-center py-2 text-xs font-medium status-professional",
              userRole === 'ADMIN' ? "bg-purple-100 text-purple-800 border-purple-200" :
              userRole === 'STAFF' ? "bg-blue-100 text-blue-800 border-blue-200" :
              "bg-green-100 text-green-800 border-green-200"
            )}
          >
            {userRole.toLowerCase()} access
          </Badge>
        </div>
      )}
    </div>
  );
}
