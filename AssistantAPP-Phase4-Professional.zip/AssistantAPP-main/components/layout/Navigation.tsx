
'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  LayoutDashboard, FileText, Users, MessageSquare, 
  CheckSquare, BarChart3, Settings, Workflow, 
  DollarSign, Bell, Calendar, Archive,
  ChevronLeft, ChevronRight
} from 'lucide-react';
import { useState, useEffect } from 'react';

interface NavigationProps {
  userRole?: string;
  className?: string;
}

export default function Navigation({ userRole, className }: NavigationProps) {
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);
  const [notificationCount, setNotificationCount] = useState(0);

  // Load notification count
  useEffect(() => {
    const loadNotificationCount = async () => {
      try {
        const response = await fetch('/api/notifications/counts');
        if (response.ok) {
          const result = await response.json();
          if (result.success) {
            setNotificationCount(result.data.unread || 0);
          }
        }
      } catch (error) {
        console.error('Error loading notification count:', error);
      }
    };

    loadNotificationCount();
    // Refresh every 30 seconds
    const interval = setInterval(loadNotificationCount, 30000);
    return () => clearInterval(interval);
  }, []);

  const navigation = [
    {
      name: 'Dashboard',
      href: '/dashboard',
      icon: LayoutDashboard,
      badge: null,
      roles: ['CLIENT', 'STAFF', 'ADMIN']
    },
    {
      name: 'Cases',
      href: '/cases',
      icon: FileText,
      badge: null,
      roles: ['CLIENT', 'STAFF', 'ADMIN']
    },
    {
      name: 'Tasks',
      href: '/tasks',
      icon: CheckSquare,
      badge: null,
      roles: ['CLIENT', 'STAFF', 'ADMIN']
    },
    {
      name: 'Messages',
      href: '/messages',
      icon: MessageSquare,
      badge: null,
      roles: ['CLIENT', 'STAFF', 'ADMIN']
    },
    {
      name: 'Notifications',
      href: '/notifications',
      icon: Bell,
      badge: notificationCount > 0 ? notificationCount : null,
      roles: ['CLIENT', 'STAFF', 'ADMIN']
    },
    // Staff and Admin only sections
    {
      name: 'Analytics',
      href: '/analytics',
      icon: BarChart3,
      badge: null,
      roles: ['STAFF', 'ADMIN']
    },
    {
      name: 'Workflows',
      href: '/workflows',
      icon: Workflow,
      badge: null,
      roles: ['STAFF', 'ADMIN']
    },
    {
      name: 'Billing',
      href: '/billing',
      icon: DollarSign,
      badge: null,
      roles: ['STAFF', 'ADMIN']
    },
    // Admin only sections
    {
      name: 'Users',
      href: '/settings',
      icon: Users,
      badge: null,
      roles: ['ADMIN']
    }
  ];

  const filteredNavigation = navigation.filter(item => 
    !userRole || item.roles.includes(userRole)
  );

  return (
    <nav className={cn(
      "bg-white border-r border-gray-200 transition-all duration-300",
      collapsed ? "w-16" : "w-64",
      className
    )}>
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between">
            {!collapsed && (
              <div>
                <h1 className="text-lg font-semibold text-gray-900">LVJ Assistant</h1>
                <p className="text-xs text-gray-500">Immigration Case Management</p>
              </div>
            )}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setCollapsed(!collapsed)}
              className="h-8 w-8 p-0"
            >
              {collapsed ? (
                <ChevronRight className="h-4 w-4" />
              ) : (
                <ChevronLeft className="h-4 w-4" />
              )}
            </Button>
          </div>
        </div>

        {/* Navigation Items */}
        <div className="flex-1 px-3 py-4 space-y-1">
          {filteredNavigation.map((item) => {
            const isActive = pathname === item.href || pathname.startsWith(`${item.href}/`);
            return (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  "group flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors duration-200",
                  isActive
                    ? "bg-blue-50 text-blue-700 border-r-2 border-blue-700"
                    : "text-gray-700 hover:bg-gray-50 hover:text-gray-900"
                )}
              >
                <item.icon
                  className={cn(
                    "flex-shrink-0 h-5 w-5",
                    collapsed ? "mr-0" : "mr-3",
                    isActive ? "text-blue-700" : "text-gray-400 group-hover:text-gray-500"
                  )}
                />
                {!collapsed && (
                  <span className="flex-1">{item.name}</span>
                )}
                {!collapsed && item.badge && (
                  <Badge 
                    variant="secondary" 
                    className="ml-auto bg-red-100 text-red-800 text-xs px-1.5 py-0.5"
                  >
                    {item.badge > 99 ? '99+' : item.badge}
                  </Badge>
                )}
              </Link>
            );
          })}
        </div>

        {/* User Role Badge */}
        {!collapsed && userRole && (
          <div className="p-4 border-t border-gray-200">
            <div className="flex items-center">
              <div className="flex-1">
                <Badge 
                  variant="outline" 
                  className={cn(
                    "text-xs",
                    userRole === 'ADMIN' ? "border-purple-200 text-purple-800" :
                    userRole === 'STAFF' ? "border-blue-200 text-blue-800" :
                    "border-green-200 text-green-800"
                  )}
                >
                  {userRole.toLowerCase()}
                </Badge>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
