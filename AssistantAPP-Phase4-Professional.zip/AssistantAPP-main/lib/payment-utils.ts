
import { PrismaClient, PaymentRecordStatus, PaymentMethod } from '@prisma/client';
import { Decimal } from '@prisma/client/runtime/library';

const prisma = new PrismaClient();

export interface PaymentProcessingResult {
  success: boolean;
  transactionId?: string;
  error?: string;
  metadata?: any;
}

export interface PaymentData {
  amount: Decimal;
  currency?: string;
  paymentMethod: PaymentMethod;
  metadata?: any;
}

export interface PaymentSummary {
  totalReceived: Decimal;
  totalPending: Decimal;
  totalFailed: Decimal;
  paymentCount: number;
  averagePaymentAmount: Decimal;
  paymentsByMethod: Array<{
    method: PaymentMethod;
    count: number;
    total: Decimal;
  }>;
}

export class PaymentUtils {
  /**
   * Process a payment for an invoice
   */
  static async processPayment(
    invoiceId: string,
    paymentData: PaymentData
  ): Promise<PaymentProcessingResult> {
    try {
      // Get invoice details
      const invoice = await prisma.invoice.findUnique({
        where: { id: invoiceId },
        include: { client: true }
      });

      if (!invoice) {
        return { success: false, error: 'Invoice not found' };
      }

      if (invoice.status === 'paid') {
        return { success: false, error: 'Invoice is already paid' };
      }

      // Create payment record
      const paymentRecord = await prisma.paymentRecord.create({
        data: {
          amount: paymentData.amount,
          currency: paymentData.currency || 'USD',
          paymentMethod: paymentData.paymentMethod,
          status: 'pending',
          invoiceId,
          metadata: paymentData.metadata
        }
      });

      // Process payment based on method
      let processingResult: PaymentProcessingResult;

      switch (paymentData.paymentMethod) {
        case 'online':
          processingResult = await this.processOnlinePayment(paymentRecord, invoice);
          break;
        case 'bank_transfer':
          processingResult = await this.processBankTransfer(paymentRecord, invoice);
          break;
        case 'cash':
          processingResult = await this.processCashPayment(paymentRecord, invoice);
          break;
        case 'check':
          processingResult = await this.processCheckPayment(paymentRecord, invoice);
          break;
        case 'credit_card':
          processingResult = await this.processCreditCardPayment(paymentRecord, invoice);
          break;
        default:
          processingResult = { success: false, error: 'Unsupported payment method' };
      }

      // Update payment record with result
      const updatedPayment = await prisma.paymentRecord.update({
        where: { id: paymentRecord.id },
        data: {
          status: processingResult.success ? 'completed' : 'failed',
          transactionId: processingResult.transactionId,
          processorResponse: processingResult.metadata,
          paidAt: processingResult.success ? new Date() : null
        }
      });

      // Update invoice status if payment successful
      if (processingResult.success) {
        const totalPaid = await this.calculateTotalPaid(invoiceId);
        const isFullyPaid = totalPaid.gte(invoice.totalAmount);

        await prisma.invoice.update({
          where: { id: invoiceId },
          data: {
            status: isFullyPaid ? 'paid' : 'sent',
            paidAt: isFullyPaid ? new Date() : null
          }
        });
      }

      return {
        success: processingResult.success,
        transactionId: updatedPayment.transactionId || undefined,
        error: processingResult.error,
        metadata: { paymentRecordId: updatedPayment.id }
      };
    } catch (error) {
      console.error('Payment processing error:', error);
      return { success: false, error: 'Payment processing failed' };
    }
  }

  /**
   * Calculate total paid amount for an invoice
   */
  private static async calculateTotalPaid(invoiceId: string): Promise<Decimal> {
    const payments = await prisma.paymentRecord.findMany({
      where: {
        invoiceId,
        status: 'completed'
      }
    });

    return payments.reduce((total: Decimal, payment: any) => total.add(payment.amount), new Decimal(0));
  }

  /**
   * Process online payment (e.g., Stripe, PayPal)
   */
  private static async processOnlinePayment(
    paymentRecord: any,
    invoice: any
  ): Promise<PaymentProcessingResult> {
    // TODO: Integrate with actual payment processor
    // For now, simulate successful payment
    
    const transactionId = `online_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    return {
      success: true,
      transactionId,
      metadata: {
        processor: 'stripe',
        processingFee: paymentRecord.amount.mul(0.029).add(0.30), // 2.9% + $0.30
        processedAt: new Date().toISOString()
      }
    };
  }

  /**
   * Process bank transfer
   */
  private static async processBankTransfer(
    paymentRecord: any,
    invoice: any
  ): Promise<PaymentProcessingResult> {
    // Bank transfers typically require manual verification
    const transactionId = `bank_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    return {
      success: true,
      transactionId,
      metadata: {
        requiresVerification: true,
        verificationStatus: 'pending',
        expectedClearanceDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000) // 3 days
      }
    };
  }

  /**
   * Process cash payment
   */
  private static async processCashPayment(
    paymentRecord: any,
    invoice: any
  ): Promise<PaymentProcessingResult> {
    const transactionId = `cash_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    return {
      success: true,
      transactionId,
      metadata: {
        receivedBy: 'office_staff', // TODO: Get actual user
        receivedAt: new Date().toISOString(),
        receiptNumber: `CASH-${Date.now()}`
      }
    };
  }

  /**
   * Process check payment
   */
  private static async processCheckPayment(
    paymentRecord: any,
    invoice: any
  ): Promise<PaymentProcessingResult> {
    const transactionId = `check_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    return {
      success: true,
      transactionId,
      metadata: {
        checkNumber: paymentRecord.metadata?.checkNumber || 'N/A',
        bankName: paymentRecord.metadata?.bankName || 'N/A',
        depositDate: new Date().toISOString(),
        clearanceExpected: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000) // 5 days
      }
    };
  }

  /**
   * Process credit card payment
   */
  private static async processCreditCardPayment(
    paymentRecord: any,
    invoice: any
  ): Promise<PaymentProcessingResult> {
    // TODO: Integrate with actual credit card processor
    const transactionId = `cc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    return {
      success: true,
      transactionId,
      metadata: {
        processor: 'stripe',
        cardLast4: paymentRecord.metadata?.cardLast4 || '****',
        cardBrand: paymentRecord.metadata?.cardBrand || 'visa',
        processingFee: paymentRecord.amount.mul(0.029).add(0.30) // 2.9% + $0.30
      }
    };
  }

  /**
   * Get payment summary for a period
   */
  static async getPaymentSummary(
    startDate: Date,
    endDate: Date,
    clientId?: string
  ): Promise<PaymentSummary> {
    const where: any = {
      createdAt: {
        gte: startDate,
        lte: endDate
      }
    };

    if (clientId) {
      where.invoice = { clientId };
    }

    const payments = await prisma.paymentRecord.findMany({
      where,
      include: { invoice: true }
    });

    const totalReceived = payments
      .filter((p: any) => p.status === 'completed')
      .reduce((sum: Decimal, p: any) => sum.add(p.amount), new Decimal(0));

    const totalPending = payments
      .filter((p: any) => p.status === 'pending')
      .reduce((sum: Decimal, p: any) => sum.add(p.amount), new Decimal(0));

    const totalFailed = payments
      .filter((p: any) => p.status === 'failed')
      .reduce((sum: Decimal, p: any) => sum.add(p.amount), new Decimal(0));

    const paymentsByMethod = payments.reduce((acc: any, payment: any) => {
      const method = payment.paymentMethod;
      if (!acc[method]) {
        acc[method] = { count: 0, total: new Decimal(0) };
      }
      acc[method].count++;
      acc[method].total = acc[method].total.add(payment.amount);
      return acc;
    }, {});

    const paymentsByMethodArray = Object.entries(paymentsByMethod).map(([method, data]: [string, any]) => ({
      method: method as PaymentMethod,
      count: data.count,
      total: data.total
    }));

    return {
      totalReceived,
      totalPending,
      totalFailed,
      paymentCount: payments.length,
      averagePaymentAmount: payments.length > 0 
        ? totalReceived.add(totalPending).add(totalFailed).div(payments.length)
        : new Decimal(0),
      paymentsByMethod: paymentsByMethodArray
    };
  }

  /**
   * Get payment history for an invoice
   */
  static async getPaymentHistory(invoiceId: string) {
    return prisma.paymentRecord.findMany({
      where: { invoiceId },
      orderBy: { createdAt: 'desc' }
    });
  }

  /**
   * Refund a payment
   */
  static async refundPayment(
    paymentRecordId: string,
    refundAmount?: Decimal,
    reason?: string
  ): Promise<PaymentProcessingResult> {
    try {
      const payment = await prisma.paymentRecord.findUnique({
        where: { id: paymentRecordId },
        include: { invoice: true }
      });

      if (!payment) {
        return { success: false, error: 'Payment record not found' };
      }

      if (payment.status !== 'completed') {
        return { success: false, error: 'Can only refund completed payments' };
      }

      const refundAmountFinal = refundAmount || payment.amount;

      if (refundAmountFinal.gt(payment.amount)) {
        return { success: false, error: 'Refund amount cannot exceed payment amount' };
      }

      // Create refund record
      const refund = await prisma.paymentRecord.create({
        data: {
          amount: refundAmountFinal.neg(), // Negative amount for refund
          currency: payment.currency,
          paymentMethod: payment.paymentMethod,
          status: 'completed',
          invoiceId: payment.invoiceId,
          transactionId: `refund_${payment.transactionId}`,
          metadata: {
            originalPaymentId: payment.id,
            refundReason: reason,
            refundedAt: new Date().toISOString()
          },
          paidAt: new Date()
        }
      });

      // Update original payment status if fully refunded
      if (refundAmountFinal.eq(payment.amount)) {
        await prisma.paymentRecord.update({
          where: { id: paymentRecordId },
          data: { status: 'refunded' }
        });
      }

      // Update invoice status
      const totalPaid = await this.calculateTotalPaid(payment.invoiceId);
      const invoice = payment.invoice;
      const isFullyPaid = totalPaid.gte(invoice.totalAmount);

      await prisma.invoice.update({
        where: { id: payment.invoiceId },
        data: {
          status: isFullyPaid ? 'paid' : totalPaid.gt(0) ? 'sent' : 'draft',
          paidAt: isFullyPaid ? invoice.paidAt : null
        }
      });

      return {
        success: true,
        transactionId: refund.transactionId || undefined,
        metadata: { refundRecordId: refund.id }
      };
    } catch (error) {
      console.error('Refund processing error:', error);
      return { success: false, error: 'Refund processing failed' };
    }
  }

  /**
   * Get overdue payments
   */
  static async getOverduePayments(daysOverdue: number = 30) {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysOverdue);

    return prisma.invoice.findMany({
      where: {
        status: { in: ['sent', 'overdue'] },
        dueDate: { lt: cutoffDate }
      },
      include: {
        client: { select: { name: true, email: true } },
        case: { select: { caseNumber: true, title: true } },
        paymentRecords: true
      },
      orderBy: { dueDate: 'asc' }
    });
  }

  /**
   * Generate payment link for online payments
   */
  static async generatePaymentLink(invoiceId: string): Promise<string> {
    // TODO: Integrate with actual payment processor to generate secure payment link
    // For now, return a placeholder link
    return `${process.env.NEXTAUTH_URL}/payments/pay/${invoiceId}`;
  }
}
