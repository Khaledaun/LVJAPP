
import { PrismaClient, ServiceRate } from '@prisma/client';
import { Decimal } from '@prisma/client/runtime/library';

const prisma = new PrismaClient();

export interface BillingCalculation {
  subtotal: Decimal;
  taxAmount: Decimal;
  totalAmount: Decimal;
  items: BillingItem[];
}

export interface BillingItem {
  description: string;
  quantity: Decimal;
  unitPrice: Decimal;
  totalPrice: Decimal;
  category?: string;
  serviceRateId?: string;
}

export interface TimeEntryBilling {
  timeEntryId: string;
  description: string;
  duration: number; // in minutes
  rate: Decimal;
  amount: Decimal;
}

export class BillingEngine {
  /**
   * Calculate billing for time entries
   */
  static async calculateTimeEntryBilling(
    timeEntryIds: string[],
    taxRate: number = 0
  ): Promise<BillingCalculation> {
    const timeEntries = await prisma.timeEntry.findMany({
      where: {
        id: { in: timeEntryIds },
        isBillable: true,
        invoiceId: null // Only unbilled entries
      },
      include: {
        user: true,
        case: true,
        task: true
      }
    });

    const items: BillingItem[] = [];
    let subtotal = new Decimal(0);

    for (const entry of timeEntries) {
      const hourlyRate = entry.billableRate || new Decimal(150); // Default rate
      const hours = new Decimal(entry.duration).div(60); // Convert minutes to hours
      const amount = hourlyRate.mul(hours);

      items.push({
        description: `${entry.description} (${hours.toFixed(2)} hours)`,
        quantity: hours,
        unitPrice: hourlyRate,
        totalPrice: amount,
        category: entry.category || 'Legal Services'
      });

      subtotal = subtotal.add(amount);
    }

    const taxAmount = subtotal.mul(taxRate);
    const totalAmount = subtotal.add(taxAmount);

    return {
      subtotal,
      taxAmount,
      totalAmount,
      items
    };
  }

  /**
   * Calculate billing for service rates
   */
  static async calculateServiceBilling(
    services: Array<{
      serviceRateId: string;
      quantity: number;
      description?: string;
    }>,
    taxRate: number = 0
  ): Promise<BillingCalculation> {
    const serviceRateIds = services.map(s => s.serviceRateId);
    const serviceRates = await prisma.serviceRate.findMany({
      where: {
        id: { in: serviceRateIds },
        isActive: true
      }
    });

    const items: BillingItem[] = [];
    let subtotal = new Decimal(0);

    for (const service of services) {
      const rate = serviceRates.find(r => r.id === service.serviceRateId);
      if (!rate) continue;

      const quantity = new Decimal(service.quantity);
      const amount = rate.baseRate.mul(quantity);

      items.push({
        description: service.description || rate.description || rate.name,
        quantity,
        unitPrice: rate.baseRate,
        totalPrice: amount,
        category: rate.category,
        serviceRateId: rate.id
      });

      subtotal = subtotal.add(amount);
    }

    const taxAmount = subtotal.mul(taxRate);
    const totalAmount = subtotal.add(taxAmount);

    return {
      subtotal,
      taxAmount,
      totalAmount,
      items
    };
  }

  /**
   * Get applicable service rates for a user/case
   */
  static async getApplicableServiceRates(
    userId?: string,
    caseType?: string
  ): Promise<ServiceRate[]> {
    const where: any = {
      isActive: true
    };

    // Filter by applicable users if specified
    if (userId) {
      where.OR = [
        { applicableTo: { equals: null } }, // Available to all
        { applicableTo: { path: '$', array_contains: userId } } // Specific to user
      ];
    }

    return prisma.serviceRate.findMany({
      where,
      orderBy: { name: 'asc' }
    });
  }

  /**
   * Generate invoice from billing calculation
   */
  static async generateInvoice(
    calculation: BillingCalculation,
    data: {
      clientId: string;
      caseId?: string;
      title: string;
      description?: string;
      dueDate?: Date;
      generatedById: string;
      timeEntryIds?: string[];
    }
  ) {
    const invoiceNumber = await this.generateInvoiceNumber();

    const invoice = await prisma.invoice.create({
      data: {
        invoiceNumber,
        title: data.title,
        description: data.description,
        subtotal: calculation.subtotal,
        taxAmount: calculation.taxAmount,
        totalAmount: calculation.totalAmount,
        clientId: data.clientId,
        caseId: data.caseId,
        generatedById: data.generatedById,
        dueDate: data.dueDate,
        items: {
          create: calculation.items.map(item => ({
            description: item.description,
            quantity: item.quantity,
            unitPrice: item.unitPrice,
            totalPrice: item.totalPrice,
            category: item.category,
            serviceRateId: item.serviceRateId
          }))
        }
      },
      include: {
        items: true,
        client: true,
        case: true
      }
    });

    // Link time entries to invoice if provided
    if (data.timeEntryIds?.length) {
      await prisma.timeEntry.updateMany({
        where: { id: { in: data.timeEntryIds } },
        data: { invoiceId: invoice.id }
      });
    }

    return invoice;
  }

  /**
   * Generate unique invoice number
   */
  private static async generateInvoiceNumber(): Promise<string> {
    const year = new Date().getFullYear();
    const prefix = `INV-${year}-`;

    const lastInvoice = await prisma.invoice.findFirst({
      where: {
        invoiceNumber: { startsWith: prefix }
      },
      orderBy: { createdAt: 'desc' }
    });

    let nextNumber = 1;
    if (lastInvoice) {
      const lastNumber = parseInt(lastInvoice.invoiceNumber.replace(prefix, ''));
      nextNumber = lastNumber + 1;
    }

    return `${prefix}${nextNumber.toString().padStart(4, '0')}`;
  }

  /**
   * Calculate payment status and aging
   */
  static calculateInvoiceAging(invoice: { issuedAt: Date | null; dueDate: Date | null; status: string }) {
    if (!invoice.issuedAt || invoice.status === 'paid') {
      return { aging: 0, status: 'current' };
    }

    const now = new Date();
    const dueDate = invoice.dueDate || invoice.issuedAt;
    const daysPastDue = Math.floor((now.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24));

    let status = 'current';
    if (daysPastDue > 90) status = 'over_90';
    else if (daysPastDue > 60) status = '61_90';
    else if (daysPastDue > 30) status = '31_60';
    else if (daysPastDue > 0) status = '1_30';

    return { aging: Math.max(0, daysPastDue), status };
  }

  /**
   * Get billing summary for a period
   */
  static async getBillingSummary(
    startDate: Date,
    endDate: Date,
    clientId?: string
  ) {
    const where: any = {
      createdAt: {
        gte: startDate,
        lte: endDate
      }
    };

    if (clientId) {
      where.clientId = clientId;
    }

    const [invoices, timeEntries] = await Promise.all([
      prisma.invoice.findMany({
        where,
        include: {
          items: true,
          paymentRecords: true
        }
      }),
      prisma.timeEntry.findMany({
        where: {
          startedAt: {
            gte: startDate,
            lte: endDate
          },
          isBillable: true,
          ...(clientId && {
            case: { clientId }
          })
        }
      })
    ]);

    const totalInvoiced = invoices.reduce((sum, inv) => sum.add(inv.totalAmount), new Decimal(0));
    const totalPaid = invoices.reduce((sum, inv) => {
      const paid = inv.paymentRecords
        .filter(p => p.status === 'completed')
        .reduce((pSum, p) => pSum.add(p.amount), new Decimal(0));
      return sum.add(paid);
    }, new Decimal(0));

    const totalBillableHours = timeEntries.reduce((sum, entry) => sum + entry.duration, 0) / 60;
    const totalUnbilledHours = timeEntries
      .filter(entry => !entry.invoiceId)
      .reduce((sum, entry) => sum + entry.duration, 0) / 60;

    return {
      totalInvoiced,
      totalPaid,
      totalOutstanding: totalInvoiced.sub(totalPaid),
      totalBillableHours,
      totalUnbilledHours,
      invoiceCount: invoices.length,
      averageInvoiceAmount: invoices.length > 0 ? totalInvoiced.div(invoices.length) : new Decimal(0)
    };
  }
}
