
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export interface JourneyStep {
  id: string;
  name: string;
  description?: string;
  order: number;
  isCompleted: boolean;
  completedAt?: Date;
  dueDate?: Date;
  assignedTo?: string;
  metadata?: any;
}

export interface ClientJourney {
  caseId: string;
  currentStep: number;
  totalSteps: number;
  completionPercentage: number;
  steps: JourneyStep[];
  estimatedCompletionDate?: Date;
}

export class JourneyUtils {
  /**
   * Get client journey for a case
   */
  static async getClientJourney(caseId: string): Promise<ClientJourney | null> {
    const caseRecord = await prisma.case.findUnique({
      where: { id: caseId },
      include: {
        workflowRun: {
          include: {
            template: true,
            stageStates: {
              include: {
                assignedTo: { select: { name: true } }
              },
              orderBy: { createdAt: 'asc' }
            }
          }
        },
        tasks: {
          where: { status: { not: 'cancelled' } },
          orderBy: { createdAt: 'asc' }
        }
      }
    });

    if (!caseRecord) return null;

    let steps: JourneyStep[] = [];
    let currentStep = 0;
    let completionPercentage = 0;

    if (caseRecord.workflowRun) {
      // Use workflow stages as journey steps
      const template = caseRecord.workflowRun.template;
      const stageStates = caseRecord.workflowRun.stageStates;
      const templateStages = (template.stages as any[]) || [];

      steps = templateStages.map((stage: any, index: number) => {
        const stageState = stageStates.find((s: any) => s.stageKey === stage.key);
        const isCompleted = stageState?.status === 'completed';
        
        if (isCompleted && index >= currentStep) {
          currentStep = index + 1;
        }

        return {
          id: stage.key,
          name: stage.name,
          description: stage.description,
          order: index + 1,
          isCompleted,
          completedAt: stageState?.completedAt || undefined,
          dueDate: stageState?.dueDate || undefined,
          assignedTo: stageState?.assignedTo?.name || undefined,
          metadata: stageState?.metadata
        };
      });
    } else {
      // Fallback to tasks as journey steps
      steps = caseRecord.tasks.map((task: any, index: number) => {
        const isCompleted = task.status === 'completed';
        
        if (isCompleted && index >= currentStep) {
          currentStep = index + 1;
        }

        return {
          id: task.id,
          name: task.title,
          description: task.description,
          order: index + 1,
          isCompleted,
          completedAt: task.completedAt || undefined,
          dueDate: task.dueDate || undefined,
          assignedTo: task.assignedTo?.name || undefined,
          metadata: { priority: task.priority, category: task.category }
        };
      });
    }

    const totalSteps = steps.length;
    const completedSteps = steps.filter((s: any) => s.isCompleted).length;
    completionPercentage = totalSteps > 0 ? Math.round((completedSteps / totalSteps) * 100) : 0;

    // Estimate completion date based on average step completion time
    let estimatedCompletionDate: Date | undefined;
    const completedStepsWithDates = steps.filter((s: any) => s.isCompleted && s.completedAt);
    
    if (completedStepsWithDates.length > 1) {
      const avgDaysPerStep = this.calculateAverageStepDuration(completedStepsWithDates);
      const remainingSteps = totalSteps - completedSteps;
      
      if (remainingSteps > 0) {
        estimatedCompletionDate = new Date();
        estimatedCompletionDate.setDate(estimatedCompletionDate.getDate() + (avgDaysPerStep * remainingSteps));
      }
    }

    return {
      caseId,
      currentStep,
      totalSteps,
      completionPercentage,
      steps,
      estimatedCompletionDate
    };
  }

  /**
   * Calculate average duration between step completions
   */
  private static calculateAverageStepDuration(completedSteps: JourneyStep[]): number {
    if (completedSteps.length < 2) return 7; // Default 7 days

    const durations: number[] = [];
    
    for (let i = 1; i < completedSteps.length; i++) {
      const prevStep = completedSteps[i - 1];
      const currentStep = completedSteps[i];
      
      if (prevStep.completedAt && currentStep.completedAt) {
        const duration = (currentStep.completedAt.getTime() - prevStep.completedAt.getTime()) / (1000 * 60 * 60 * 24);
        durations.push(duration);
      }
    }

    if (durations.length === 0) return 7;

    const avgDuration = durations.reduce((sum: number, d: number) => sum + d, 0) / durations.length;
    return Math.max(1, Math.round(avgDuration)); // At least 1 day
  }

  /**
   * Update journey step status
   */
  static async updateStepStatus(
    caseId: string,
    stepId: string,
    status: 'completed' | 'in_progress' | 'blocked',
    notes?: string
  ): Promise<boolean> {
    try {
      const caseRecord = await prisma.case.findUnique({
        where: { id: caseId },
        include: { workflowRun: true }
      });

      if (!caseRecord) return false;

      if (caseRecord.workflowRun) {
        // Update workflow stage state
        const stageState = await prisma.workflowStageState.findFirst({
          where: {
            workflowRunId: caseRecord.workflowRun.id,
            stageKey: stepId
          }
        });

        if (stageState) {
          await prisma.workflowStageState.update({
            where: { id: stageState.id },
            data: {
              status: status === 'completed' ? 'completed' : 
                     status === 'in_progress' ? 'in_progress' : 'blocked',
              completedAt: status === 'completed' ? new Date() : null,
              notes
            }
          });
        }
      } else {
        // Update task status
        await prisma.task.updateMany({
          where: {
            id: stepId,
            caseId
          },
          data: {
            status: status === 'completed' ? 'completed' : 
                   status === 'in_progress' ? 'in_progress' : 'blocked',
            completedAt: status === 'completed' ? new Date() : null,
            notes
          }
        });
      }

      // Update case completion percentage
      const journey = await this.getClientJourney(caseId);
      if (journey) {
        await prisma.case.update({
          where: { id: caseId },
          data: {
            completionPercentage: journey.completionPercentage,
            estimatedCompletionDate: journey.estimatedCompletionDate
          }
        });
      }

      return true;
    } catch (error) {
      console.error('Error updating step status:', error);
      return false;
    }
  }

  /**
   * Get journey analytics for multiple cases
   */
  static async getJourneyAnalytics(caseIds: string[]) {
    const journeys = await Promise.all(
      caseIds.map(id => this.getClientJourney(id))
    );

    const validJourneys = journeys.filter(j => j !== null) as ClientJourney[];

    if (validJourneys.length === 0) {
      return {
        averageCompletionPercentage: 0,
        averageStepsCompleted: 0,
        totalCases: 0,
        completedCases: 0,
        averageDaysToComplete: 0
      };
    }

    const totalCompletion = validJourneys.reduce((sum, j) => sum + j.completionPercentage, 0);
    const totalStepsCompleted = validJourneys.reduce((sum, j) => sum + j.currentStep, 0);
    const completedCases = validJourneys.filter(j => j.completionPercentage === 100).length;

    return {
      averageCompletionPercentage: Math.round(totalCompletion / validJourneys.length),
      averageStepsCompleted: Math.round(totalStepsCompleted / validJourneys.length),
      totalCases: validJourneys.length,
      completedCases,
      averageDaysToComplete: 0 // TODO: Calculate based on completed cases
    };
  }
}
