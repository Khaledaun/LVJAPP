
import { PrismaClient } from '@prisma/client';
import { revalidatePath } from 'next/cache';

const prisma = new PrismaClient();

// Automation Action Definitions
export interface AutomationAction {
  type: 'notify_user' | 'create_task' | 'advance_stage' | 'send_email' | 'update_case_status' | 'request_documents';
  parameters: Record<string, any>;
}

export interface AutomationCondition {
  field: string;
  operator: 'equals' | 'not_equals' | 'contains' | 'greater_than' | 'less_than' | 'in' | 'not_in';
  value: any;
}

export interface AutomationRuleDefinition {
  name: string;
  description?: string;
  trigger: string; // AutomationTrigger enum value
  conditions: AutomationCondition[];
  actions: AutomationAction[];
  priority?: number;
}

// Predefined automation rules
export const DEFAULT_AUTOMATION_RULES: AutomationRuleDefinition[] = [
  {
    name: 'Document Approval Notification',
    description: 'Notify client when document is approved',
    trigger: 'document_approved',
    conditions: [],
    actions: [
      {
        type: 'notify_user',
        parameters: {
          recipient: 'case_client',
          title: 'Document Approved',
          message: 'Your document has been approved and is ready for submission.',
          type: 'success'
        }
      }
    ],
    priority: 7
  },
  {
    name: 'Document Rejection Follow-up',
    description: 'Create follow-up task when document is rejected',
    trigger: 'document_rejected',
    conditions: [],
    actions: [
      {
        type: 'create_task',
        parameters: {
          title: 'Follow up on rejected document',
          description: 'Contact client about document rejection and next steps',
          assignTo: 'case_manager',
          priority: 'high',
          dueInDays: 1
        }
      },
      {
        type: 'notify_user',
        parameters: {
          recipient: 'case_client',
          title: 'Document Needs Revision',
          message: 'Your document requires revisions. Please check your case for details.',
          type: 'warning'
        }
      }
    ],
    priority: 8
  },
  {
    name: 'Case Stage Advancement',
    description: 'Auto-advance case stage when conditions are met',
    trigger: 'task_completed',
    conditions: [
      {
        field: 'case.stage',
        operator: 'equals',
        value: 'Document Collection'
      }
    ],
    actions: [
      {
        type: 'advance_stage',
        parameters: {
          autoAdvance: true,
          notes: 'Automatically advanced due to task completion'
        }
      }
    ],
    priority: 6
  },
  {
    name: 'Overdue Task Alert',
    description: 'Alert case manager about overdue tasks',
    trigger: 'task_overdue',
    conditions: [],
    actions: [
      {
        type: 'notify_user',
        parameters: {
          recipient: 'case_manager',
          title: 'Task Overdue',
          message: 'A task in this case is overdue and requires attention.',
          type: 'alert',
          priority: 'urgent'
        }
      }
    ],
    priority: 9
  },
  {
    name: 'Welcome New Case',
    description: 'Send welcome message and create initial tasks for new cases',
    trigger: 'case_created',
    conditions: [],
    actions: [
      {
        type: 'notify_user',
        parameters: {
          recipient: 'case_client',
          title: 'Welcome to LVJ Case Assistant',
          message: 'Your case has been created. We will guide you through each step of the process.',
          type: 'info'
        }
      },
      {
        type: 'create_task',
        parameters: {
          title: 'Initial client onboarding',
          description: 'Complete client onboarding process and document checklist',
          assignTo: 'case_manager',
          priority: 'high',
          dueInDays: 2
        }
      }
    ],
    priority: 5
  },
  {
    name: 'Deadline Reminder',
    description: 'Remind about approaching deadlines',
    trigger: 'deadline_approaching',
    conditions: [
      {
        field: 'daysUntilDeadline',
        operator: 'less_than',
        value: 7
      }
    ],
    actions: [
      {
        type: 'notify_user',
        parameters: {
          recipient: 'case_manager',
          title: 'Deadline Approaching',
          message: 'A case deadline is approaching within 7 days.',
          type: 'warning',
          priority: 'high'
        }
      }
    ],
    priority: 8
  }
];

export class AutomationEngine {
  
  // Create automation rule
  static async createRule(
    definition: AutomationRuleDefinition,
    createdById: string
  ) {
    try {
      const rule = await prisma.automationRule.create({
        data: {
          name: definition.name,
          description: definition.description,
          trigger: definition.trigger as any,
          conditions: definition.conditions as any,
          actions: definition.actions as any,
          priority: definition.priority || 5,
          createdById
        }
      });
      
      return { success: true, data: rule };
    } catch (error) {
      console.error('Error creating automation rule:', error);
      return { success: false, error: 'Failed to create automation rule' };
    }
  }

  // Trigger automation rules
  static async triggerRules(
    trigger: string,
    context: {
      caseId?: string;
      documentId?: string;
      taskId?: string;
      userId?: string;
      data?: Record<string, any>;
    }
  ) {
    try {
      const rules = await prisma.automationRule.findMany({
        where: {
          trigger: trigger as any,
          isActive: true
        },
        orderBy: { priority: 'desc' }
      });

      const executionPromises = rules.map(rule => 
        this.executeRule(rule, context)
      );

      const results = await Promise.allSettled(executionPromises);
      
      const successful = results.filter(r => r.status === 'fulfilled').length;
      const failed = results.filter(r => r.status === 'rejected').length;

      return { 
        success: true, 
        data: { 
          triggered: rules.length,
          successful,
          failed
        }
      };
    } catch (error) {
      console.error('Error triggering automation rules:', error);
      return { success: false, error: 'Failed to trigger automation rules' };
    }
  }

  // Execute individual automation rule
  private static async executeRule(
    rule: any,
    context: Record<string, any>
  ) {
    try {
      // Create automation run record
      const automationRun = await prisma.automationRun.create({
        data: {
          ruleId: rule.id,
          caseId: context.caseId,
          documentId: context.documentId,
          taskId: context.taskId,
          workflowRunId: context.workflowRunId,
          status: 'running'
        }
      });

      // Check conditions
      const conditionsMet = await this.checkConditions(
        rule.conditions,
        context
      );

      if (!conditionsMet) {
        await prisma.automationRun.update({
          where: { id: automationRun.id },
          data: {
            status: 'completed',
            result: { conditionsMet: false },
            completedAt: new Date()
          }
        });
        return;
      }

      // Execute actions
      const actionResults = await Promise.all(
        rule.actions.map((action: AutomationAction) => 
          this.executeAction(action, context)
        )
      );

      // Update automation run
      await prisma.automationRun.update({
        where: { id: automationRun.id },
        data: {
          status: 'completed',
          result: {
            conditionsMet: true,
            actionResults
          },
          completedAt: new Date()
        }
      });

    } catch (error) {
      console.error(`Error executing rule ${rule.name}:`, error);
      
      // Update automation run with error
      await prisma.automationRun.updateMany({
        where: { ruleId: rule.id, status: 'running' },
        data: {
          status: 'failed',
          error: error instanceof Error ? error.message : 'Unknown error',
          completedAt: new Date()
        }
      });
    }
  }

  // Check automation conditions
  private static async checkConditions(
    conditions: AutomationCondition[],
    context: Record<string, any>
  ): Promise<boolean> {
    if (conditions.length === 0) return true;

    try {
      for (const condition of conditions) {
        const fieldValue = this.getFieldValue(condition.field, context);
        const conditionMet = this.evaluateCondition(
          fieldValue,
          condition.operator,
          condition.value
        );

        if (!conditionMet) return false;
      }

      return true;
    } catch (error) {
      console.error('Error checking conditions:', error);
      return false;
    }
  }

  // Get field value from context
  private static getFieldValue(field: string, context: Record<string, any>): any {
    const parts = field.split('.');
    let value = context;

    for (const part of parts) {
      value = value?.[part];
    }

    return value;
  }

  // Evaluate single condition
  private static evaluateCondition(
    fieldValue: any,
    operator: string,
    expectedValue: any
  ): boolean {
    switch (operator) {
      case 'equals':
        return fieldValue === expectedValue;
      case 'not_equals':
        return fieldValue !== expectedValue;
      case 'contains':
        return String(fieldValue).includes(String(expectedValue));
      case 'greater_than':
        return Number(fieldValue) > Number(expectedValue);
      case 'less_than':
        return Number(fieldValue) < Number(expectedValue);
      case 'in':
        return Array.isArray(expectedValue) && expectedValue.includes(fieldValue);
      case 'not_in':
        return Array.isArray(expectedValue) && !expectedValue.includes(fieldValue);
      default:
        return false;
    }
  }

  // Execute automation action
  private static async executeAction(
    action: AutomationAction,
    context: Record<string, any>
  ) {
    try {
      switch (action.type) {
        case 'notify_user':
          return await this.actionNotifyUser(action.parameters, context);
        case 'create_task':
          return await this.actionCreateTask(action.parameters, context);
        case 'advance_stage':
          return await this.actionAdvanceStage(action.parameters, context);
        case 'update_case_status':
          return await this.actionUpdateCaseStatus(action.parameters, context);
        default:
          throw new Error(`Unknown action type: ${action.type}`);
      }
    } catch (error) {
      console.error(`Error executing action ${action.type}:`, error);
      return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  // Action: Notify User
  private static async actionNotifyUser(
    parameters: Record<string, any>,
    context: Record<string, any>
  ) {
    try {
      let recipientId = parameters.recipient;

      // Resolve recipient from context
      if (parameters.recipient === 'case_client' && context.caseId) {
        const caseData = await prisma.case.findUnique({
          where: { id: context.caseId },
          select: { clientId: true }
        });
        recipientId = caseData?.clientId;
      } else if (parameters.recipient === 'case_manager' && context.caseId) {
        const caseData = await prisma.case.findUnique({
          where: { id: context.caseId },
          select: { caseManagerId: true }
        });
        recipientId = caseData?.caseManagerId;
      }

      if (!recipientId) {
        return { success: false, error: 'No recipient found' };
      }

      await prisma.notification.create({
        data: {
          title: parameters.title,
          message: parameters.message,
          type: parameters.type || 'info',
          priority: parameters.priority || 'normal',
          recipientId,
          caseId: context.caseId,
          taskId: context.taskId,
          documentId: context.documentId,
          actionUrl: parameters.actionUrl
        }
      });

      return { success: true };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  // Action: Create Task
  private static async actionCreateTask(
    parameters: Record<string, any>,
    context: Record<string, any>
  ) {
    try {
      let assignedToId = parameters.assignTo;

      // Resolve assignee from context
      if (parameters.assignTo === 'case_manager' && context.caseId) {
        const caseData = await prisma.case.findUnique({
          where: { id: context.caseId },
          select: { caseManagerId: true }
        });
        assignedToId = caseData?.caseManagerId;
      }

      const dueDate = parameters.dueInDays ? 
        new Date(Date.now() + parameters.dueInDays * 24 * 60 * 60 * 1000) : 
        undefined;

      await prisma.task.create({
        data: {
          title: parameters.title,
          description: parameters.description,
          priority: parameters.priority || 'normal',
          assignedToId,
          createdById: context.userId || assignedToId,
          caseId: context.caseId,
          dueDate
        }
      });

      return { success: true };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  // Action: Advance Stage
  private static async actionAdvanceStage(
    parameters: Record<string, any>,
    context: Record<string, any>
  ) {
    try {
      if (!context.caseId) {
        return { success: false, error: 'No case ID provided' };
      }

      const { WorkflowEngine } = await import('./workflow-engine');
      
      const workflowRun = await prisma.workflowRun.findUnique({
        where: { caseId: context.caseId }
      });

      if (!workflowRun?.currentStage) {
        return { success: false, error: 'No active workflow found' };
      }

      const result = await WorkflowEngine.advanceStage(
        workflowRun.id,
        workflowRun.currentStage,
        context.userId || 'system',
        parameters.notes
      );

      return result;
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  // Action: Update Case Status
  private static async actionUpdateCaseStatus(
    parameters: Record<string, any>,
    context: Record<string, any>
  ) {
    try {
      if (!context.caseId) {
        return { success: false, error: 'No case ID provided' };
      }

      await prisma.case.update({
        where: { id: context.caseId },
        data: {
          overallStatus: parameters.status,
          notes: parameters.notes
        }
      });

      return { success: true };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }
}

// Initialize default automation rules
export async function initializeDefaultAutomationRules(userId: string) {
  try {
    for (const ruleDefinition of DEFAULT_AUTOMATION_RULES) {
      const existing = await prisma.automationRule.findFirst({
        where: {
          name: ruleDefinition.name,
          trigger: ruleDefinition.trigger as any
        }
      });

      if (!existing) {
        await AutomationEngine.createRule(ruleDefinition, userId);
      }
    }
    
    return { success: true };
  } catch (error) {
    console.error('Error initializing default automation rules:', error);
    return { success: false, error: 'Failed to initialize automation rules' };
  }
}
