import type { Metadata } from 'next'
import { Suspense } from 'react'
import Providers from './providers'
import { ErrorBoundary } from '@/components/Boundary'
import { ThemeProvider } from '@/components/providers/theme-provider'
import AppLayout from '@/components/layout/AppLayout'
import './globals.css'

export const metadata: Metadata = {
  title: 'LVJ Case Assistant - Premium Immigration Management',
  description: 'Professional immigration case management system with advanced workflow automation, analytics, and client communication tools.',
  keywords: 'immigration, case management, legal, workflow, automation',
  authors: [{ name: 'LVJ Law Firm' }],
  viewport: 'width=device-width, initial-scale=1, maximum-scale=1',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="antialiased">
        <ErrorBoundary fallback={
          <div className="min-h-screen flex items-center justify-center bg-background">
            <div className="professional-card p-8 rounded-lg shadow-professional-lg text-center max-w-md">
              <div className="text-destructive text-lg font-semibold mb-2">Application Error</div>
              <div className="text-muted-foreground text-sm">
                Something went wrong. Please refresh the page or contact support if the problem persists.
              </div>
            </div>
          </div>
        }>
          <ThemeProvider
            attribute="class"
            defaultTheme="system"
            enableSystem
            disableTransitionOnChange
          >
            <Providers>
              <Suspense fallback={
                <div className="min-h-screen bg-background flex items-center justify-center">
                  <div className="professional-card p-8 rounded-lg shadow-professional-lg">
                    <div className="animate-pulse flex items-center space-x-4">
                      <div className="w-8 h-8 gradient-professional rounded-lg"></div>
                      <div>
                        <div className="h-4 bg-muted rounded w-32 mb-2"></div>
                        <div className="h-3 bg-muted rounded w-48"></div>
                      </div>
                    </div>
                  </div>
                </div>
              }>
                <AppLayout>
                  {children}
                </AppLayout>
              </Suspense>
            </Providers>
          </ThemeProvider>
        </ErrorBoundary>
      </body>
    </html>
  )
}