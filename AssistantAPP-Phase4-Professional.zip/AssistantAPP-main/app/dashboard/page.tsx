'use client'

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Plus, 
  Users, 
  FileText, 
  DollarSign, 
  Clock, 
  CheckCircle, 
  AlertTriangle,
  Calendar,
  MessageSquare,
  TrendingUp,
  Activity,
  Zap,
  ArrowUpRight,
  Sparkles,
  Target,
  Award,
  BarChart3
} from 'lucide-react';
import Link from 'next/link';
import { Skeleton } from '@/components/ui/skeleton';

interface DashboardStats {
  cases: {
    total: number
    active: number
    completed: number
    overdue: number
  }
  tasks: {
    total: number
    pending: number
    inProgress: number
    completed: number
    overdue: number
    completionRate: number
  }
  documents: {
    total: number
    uploaded: number
    approved: number
    pending: number
  }
  messages: {
    total: number
    unread: number
    urgent: number
  }
}

interface RecentItem {
  id: string
  type: 'case' | 'task' | 'document' | 'message'
  title: string
  subtitle?: string
  status?: string
  priority?: string
  dueDate?: string
  updatedAt: string
}

export default function DashboardPage() {
  const { data: session, status } = useSession();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentItems, setRecentItems] = useState<RecentItem[]>([]);
  const [upcomingTasks, setUpcomingTasks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (status === 'loading') return;
    if (!session) return;

    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        
        // Fetch stats from various endpoints
        const [casesRes, tasksRes, messagesRes] = await Promise.all([
          fetch('/api/cases?page=1&limit=100'),
          fetch('/api/tasks/stats'),
          fetch('/api/messages?page=1&limit=10'),
        ]);

        const dashboardStats: DashboardStats = {
          cases: { total: 0, active: 0, completed: 0, overdue: 0 },
          tasks: { total: 0, pending: 0, inProgress: 0, completed: 0, overdue: 0, completionRate: 0 },
          documents: { total: 0, uploaded: 0, approved: 0, pending: 0 },
          messages: { total: 0, unread: 0, urgent: 0 },
        };

        // Process cases data
        if (casesRes.ok) {
          const casesData = await casesRes.json();
          const cases = casesData.cases || [];
          dashboardStats.cases.total = cases.length;
          dashboardStats.cases.active = cases.filter((c: any) => 
            !['approved', 'denied'].includes(c.overallStatus)
          ).length;
          dashboardStats.cases.completed = cases.filter((c: any) => 
            ['approved', 'denied'].includes(c.overallStatus)
          ).length;
        }

        // Process tasks data
        if (tasksRes.ok) {
          const tasksData = await tasksRes.json();
          if (tasksData.stats?.overview) {
            dashboardStats.tasks = tasksData.stats.overview;
          }
        }

        // Process recent messages
        if (messagesRes.ok) {
          const messagesData = await messagesRes.json();
          const messages = messagesData.messages || [];
          dashboardStats.messages.total = messages.length;
          dashboardStats.messages.unread = messages.filter((m: any) => 
            m.status === 'unread'
          ).length;
          dashboardStats.messages.urgent = messages.filter((m: any) => 
            m.isUrgent
          ).length;
        }

        setStats(dashboardStats);

        // Fetch recent activities (simplified)
        const recent: RecentItem[] = [];
        if (casesRes.ok) {
          const casesData = await casesRes.json();
          const recentCases = (casesData.cases || []).slice(0, 3);
          recent.push(...recentCases.map((c: any) => ({
            id: c.id,
            type: 'case' as const,
            title: c.title || `Case ${c.caseNumber}`,
            subtitle: c.applicantName,
            status: c.overallStatus,
            updatedAt: c.updatedAt,
          })));
        }

        setRecentItems(recent);
      } catch (error) {
        console.error('Failed to fetch dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, [session, status]);

  const getStatusColor = (status: string, type: string = 'case') => {
    if (type === 'case') {
      switch (status) {
        case 'approved':
          return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
        case 'in_review':
          return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
        case 'new':
        case 'documents_pending':
          return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
        case 'denied':
          return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
        default:
          return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
      }
    }
    return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString();
  };

  if (status === 'loading' || loading) {
    return <DashboardSkeleton />;
  }

  if (!session) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Welcome to LVJ Case Assistant</h2>
          <p className="text-muted-foreground mb-6">Please sign in to access your dashboard.</p>
          <Button asChild>
            <Link href="/signin">Sign In</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Premium Header */}
      <motion.div 
        className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <motion.div 
              className="w-12 h-12 bg-gradient-primary rounded-xl flex items-center justify-center shadow-premium"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Zap className="w-6 h-6 text-white" />
            </motion.div>
            <div>
              <motion.h1 
                className="text-4xl lg:text-5xl font-bold bg-gradient-to-r from-foreground via-primary to-accent bg-clip-text text-transparent"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
              >
                Welcome back!
              </motion.h1>
              <motion.p 
                className="text-lg text-muted-foreground"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
              >
                Here's what's happening with your cases and tasks today.
              </motion.p>
            </div>
          </div>
        </div>
        
        <motion.div 
          className="flex flex-col sm:flex-row gap-3"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Link href="/cases/new">
            <Button size="lg" className="btn-premium text-white px-6 py-3">
              <Plus className="mr-2 h-5 w-5" />
              New Case
            </Button>
          </Link>
          <Link href="/analytics">
            <Button variant="outline" size="lg" className="px-6 py-3 hover-lift glass-card">
              <BarChart3 className="mr-2 h-5 w-5" />
              Analytics
            </Button>
          </Link>
        </motion.div>
      </motion.div>

      {/* Premium Stats Overview */}
      <div className="responsive-grid">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="glass-card border-0 shadow-premium hover-lift overflow-hidden">
            <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-bl from-primary/20 to-transparent rounded-bl-full"></div>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-sm font-semibold text-muted-foreground">Total Cases</CardTitle>
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-premium">
                <FileText className="h-5 w-5 text-white" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold bg-gradient-to-r from-foreground to-primary bg-clip-text text-transparent">
                {stats?.cases.total ?? 0}
              </div>
              <div className="flex items-center gap-2 mt-2">
                <Badge className="status-success text-[10px] px-2 py-0.5">
                  {stats?.cases.active ?? 0} active
                </Badge>
                <Badge className="status-info text-[10px] px-2 py-0.5">
                  {stats?.cases.completed ?? 0} done
                </Badge>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="glass-card border-0 shadow-premium hover-lift overflow-hidden">
            <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-bl from-success/20 to-transparent rounded-bl-full"></div>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-sm font-semibold text-muted-foreground">Tasks</CardTitle>
              <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center shadow-premium">
                <CheckCircle className="h-5 w-5 text-white" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold bg-gradient-to-r from-foreground to-success bg-clip-text text-transparent">
                {stats?.tasks.total ?? 0}
              </div>
              <div className="flex items-center gap-2 mt-2">
                <div className="flex items-center text-xs text-muted-foreground">
                  <Target className="w-3 h-3 mr-1" />
                  {stats?.tasks.completionRate ?? 0}% completion
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="glass-card border-0 shadow-premium hover-lift overflow-hidden">
            <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-bl from-destructive/20 to-transparent rounded-bl-full"></div>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-sm font-semibold text-muted-foreground">Overdue Items</CardTitle>
              <div className="w-10 h-10 bg-gradient-to-br from-red-500 to-red-600 rounded-xl flex items-center justify-center shadow-premium">
                <AlertTriangle className="h-5 w-5 text-white" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold bg-gradient-to-r from-destructive to-red-600 bg-clip-text text-transparent">
                {(stats?.tasks.overdue ?? 0) + (stats?.cases.overdue ?? 0)}
              </div>
              <div className="flex items-center gap-2 mt-2">
                <Badge className="status-warning text-[10px] px-2 py-0.5">
                  {stats?.tasks.overdue ?? 0} tasks
                </Badge>
                <Badge className="status-warning text-[10px] px-2 py-0.5">
                  {stats?.cases.overdue ?? 0} cases
                </Badge>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="glass-card border-0 shadow-premium hover-lift overflow-hidden">
            <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-bl from-accent/20 to-transparent rounded-bl-full"></div>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-sm font-semibold text-muted-foreground">Messages</CardTitle>
              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center shadow-premium">
                <MessageSquare className="h-5 w-5 text-white" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold bg-gradient-to-r from-foreground to-accent bg-clip-text text-transparent">
                {stats?.messages.unread ?? 0}
              </div>
              <div className="flex items-center gap-2 mt-2">
                <div className="flex items-center text-xs text-muted-foreground">
                  <Sparkles className="w-3 h-3 mr-1" />
                  Unread messages
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Premium Main Content Tabs */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <Tabs defaultValue="overview" className="space-y-6">
          <div className="glass-card p-1 rounded-2xl shadow-premium w-fit mx-auto">
            <TabsList className="grid grid-cols-4 bg-transparent gap-1">
              <TabsTrigger 
                value="overview" 
                className="data-[state=active]:bg-gradient-primary data-[state=active]:text-white data-[state=active]:shadow-premium rounded-xl px-6 py-3 font-medium"
              >
                <Target className="w-4 h-4 mr-2" />
                Overview
              </TabsTrigger>
              <TabsTrigger 
                value="tasks" 
                className="data-[state=active]:bg-gradient-primary data-[state=active]:text-white data-[state=active]:shadow-premium rounded-xl px-6 py-3 font-medium"
              >
                <CheckCircle className="w-4 h-4 mr-2" />
                Tasks
              </TabsTrigger>
              <TabsTrigger 
                value="cases" 
                className="data-[state=active]:bg-gradient-primary data-[state=active]:text-white data-[state=active]:shadow-premium rounded-xl px-6 py-3 font-medium"
              >
                <FileText className="w-4 h-4 mr-2" />
                Cases
              </TabsTrigger>
              <TabsTrigger 
                value="activity" 
                className="data-[state=active]:bg-gradient-primary data-[state=active]:text-white data-[state=active]:shadow-premium rounded-xl px-6 py-3 font-medium"
              >
                <Activity className="w-4 h-4 mr-2" />
                Activity
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid gap-8 lg:grid-cols-3">
              {/* Recent Activity */}
              <motion.div 
                className="lg:col-span-2"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.6 }}
              >
                <Card className="glass-card border-0 shadow-premium-lg">
                  <CardHeader className="pb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-info to-blue-600 rounded-xl flex items-center justify-center shadow-premium">
                        <Activity className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <CardTitle className="text-xl font-semibold">Recent Activity</CardTitle>
                        <CardDescription className="text-muted-foreground">
                          Latest updates across your cases and tasks
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {recentItems.length === 0 ? (
                        <motion.div 
                          className="text-center py-12"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          transition={{ delay: 0.8 }}
                        >
                          <div className="w-16 h-16 bg-gradient-to-br from-muted to-secondary rounded-2xl flex items-center justify-center mx-auto mb-4">
                            <Activity className="h-8 w-8 text-muted-foreground" />
                          </div>
                          <p className="text-muted-foreground font-medium">No recent activity</p>
                          <p className="text-sm text-muted-foreground mt-1">Activity will appear here as you work with cases and tasks</p>
                        </motion.div>
                      ) : (
                        recentItems.map((item, index) => (
                          <motion.div 
                            key={`${item.type}-${item.id}`} 
                            className="glass-card p-4 rounded-xl border-0 shadow-premium hover-lift"
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.7 + (index * 0.1) }}
                            whileHover={{ scale: 1.02 }}
                          >
                            <div className="flex items-center justify-between">
                              <div className="space-y-2">
                                <p className="font-semibold text-foreground">{item.title}</p>
                                {item.subtitle && (
                                  <p className="text-sm text-muted-foreground">{item.subtitle}</p>
                                )}
                                <p className="text-xs text-muted-foreground flex items-center gap-1">
                                  <Clock className="w-3 h-3" />
                                  {formatDate(item.updatedAt)}
                                </p>
                              </div>
                              <div className="text-right space-y-1">
                                {item.status && (
                                  <Badge className={`${getStatusColor(item.status, item.type)} shadow-sm`}>
                                    {item.status.replace('_', ' ')}
                                  </Badge>
                                )}
                                <ArrowUpRight className="w-4 h-4 text-muted-foreground ml-auto" />
                              </div>
                            </div>
                          </motion.div>
                        ))
                      )}
                    </div>
                    <motion.div 
                      className="mt-6 flex gap-3"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.9 }}
                    >
                      <Link href="/cases" className="flex-1">
                        <Button variant="outline" className="w-full hover-lift glass-card">
                          <FileText className="mr-2 h-4 w-4" />
                          View All Cases
                        </Button>
                      </Link>
                      <Link href="/tasks" className="flex-1">
                        <Button variant="outline" className="w-full hover-lift glass-card">
                          <CheckCircle className="mr-2 h-4 w-4" />
                          View All Tasks
                        </Button>
                      </Link>
                    </motion.div>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Premium Quick Actions */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.7 }}
              >
                <Card className="glass-card border-0 shadow-premium-lg">
                  <CardHeader className="pb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-accent to-purple-600 rounded-xl flex items-center justify-center shadow-premium">
                        <Zap className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <CardTitle className="text-xl font-semibold">Quick Actions</CardTitle>
                        <CardDescription className="text-muted-foreground">
                          Common tasks and shortcuts
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <motion.div
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <Link href="/cases/new">
                        <Button className="w-full justify-start btn-premium text-white h-12">
                          <Plus className="mr-3 h-5 w-5" />
                          <div className="text-left">
                            <div className="font-medium">New Case</div>
                            <div className="text-xs opacity-80">Create immigration case</div>
                          </div>
                        </Button>
                      </Link>
                    </motion.div>

                    <motion.div
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <Link href="/tasks">
                        <Button variant="outline" className="w-full justify-start glass-card hover-lift h-12">
                          <Calendar className="mr-3 h-5 w-5" />
                          <div className="text-left">
                            <div className="font-medium">View Tasks</div>
                            <div className="text-xs text-muted-foreground">Manage assignments</div>
                          </div>
                        </Button>
                      </Link>
                    </motion.div>

                    <motion.div
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <Link href="/messages">
                        <Button variant="outline" className="w-full justify-start glass-card hover-lift h-12">
                          <MessageSquare className="mr-3 h-5 w-5" />
                          <div className="text-left flex-1">
                            <div className="font-medium">Messages</div>
                            <div className="text-xs text-muted-foreground">Client communications</div>
                          </div>
                          {stats?.messages.unread && stats.messages.unread > 0 && (
                            <Badge className="ml-auto bg-gradient-to-r from-destructive to-red-500 text-white">
                              {stats.messages.unread}
                            </Badge>
                          )}
                        </Button>
                      </Link>
                    </motion.div>

                    <motion.div
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <Link href="/analytics">
                        <Button variant="outline" className="w-full justify-start glass-card hover-lift h-12">
                          <TrendingUp className="mr-3 h-5 w-5" />
                          <div className="text-left">
                            <div className="font-medium">Analytics</div>
                            <div className="text-xs text-muted-foreground">Performance insights</div>
                          </div>
                        </Button>
                      </Link>
                    </motion.div>

                    {/* Performance Indicator */}
                    <motion.div 
                      className="mt-6 p-4 glass-card rounded-xl border-0"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 1.0 }}
                    >
                      <div className="flex items-center gap-3 mb-2">
                        <Award className="w-5 h-5 text-accent" />
                        <span className="font-medium text-sm">Performance</span>
                      </div>
                      <div className="text-2xl font-bold bg-gradient-to-r from-success to-green-600 bg-clip-text text-transparent">
                        Excellent
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        Your case management is on track
                      </p>
                    </motion.div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </TabsContent>

          <TabsContent value="tasks" className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
            >
              <Card className="glass-card border-0 shadow-premium-lg">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-success to-green-600 rounded-xl flex items-center justify-center shadow-premium">
                      <CheckCircle className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-xl font-semibold">Task Management</CardTitle>
                      <CardDescription>Overview of your tasks and assignments</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-6 md:grid-cols-3">
                    <div className="glass-card p-6 rounded-xl border-0 text-center">
                      <div className="text-3xl font-bold bg-gradient-to-r from-warning to-yellow-600 bg-clip-text text-transparent">
                        {stats?.tasks.pending ?? 0}
                      </div>
                      <h4 className="font-semibold mt-2">Pending Tasks</h4>
                      <p className="text-xs text-muted-foreground mt-1">Awaiting action</p>
                    </div>
                    <div className="glass-card p-6 rounded-xl border-0 text-center">
                      <div className="text-3xl font-bold bg-gradient-to-r from-info to-blue-600 bg-clip-text text-transparent">
                        {stats?.tasks.inProgress ?? 0}
                      </div>
                      <h4 className="font-semibold mt-2">In Progress</h4>
                      <p className="text-xs text-muted-foreground mt-1">Currently working</p>
                    </div>
                    <div className="glass-card p-6 rounded-xl border-0 text-center">
                      <div className="text-3xl font-bold bg-gradient-to-r from-success to-green-600 bg-clip-text text-transparent">
                        {stats?.tasks.completed ?? 0}
                      </div>
                      <h4 className="font-semibold mt-2">Completed</h4>
                      <p className="text-xs text-muted-foreground mt-1">Successfully done</p>
                    </div>
                  </div>
                  <div className="mt-6">
                    <Link href="/tasks">
                      <Button className="w-full btn-premium text-white h-12">
                        <CheckCircle className="mr-2 h-5 w-5" />
                        Manage All Tasks
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          <TabsContent value="cases" className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
            >
              <Card className="glass-card border-0 shadow-premium-lg">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-primary to-blue-600 rounded-xl flex items-center justify-center shadow-premium">
                      <FileText className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-xl font-semibold">Case Management</CardTitle>
                      <CardDescription>Overview of your immigration cases</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-6 md:grid-cols-3">
                    <div className="glass-card p-6 rounded-xl border-0 text-center">
                      <div className="text-3xl font-bold bg-gradient-to-r from-success to-green-600 bg-clip-text text-transparent">
                        {stats?.cases.active ?? 0}
                      </div>
                      <h4 className="font-semibold mt-2">Active Cases</h4>
                      <p className="text-xs text-muted-foreground mt-1">In progress</p>
                    </div>
                    <div className="glass-card p-6 rounded-xl border-0 text-center">
                      <div className="text-3xl font-bold bg-gradient-to-r from-info to-blue-600 bg-clip-text text-transparent">
                        {stats?.cases.completed ?? 0}
                      </div>
                      <h4 className="font-semibold mt-2">Completed</h4>
                      <p className="text-xs text-muted-foreground mt-1">Successfully closed</p>
                    </div>
                    <div className="glass-card p-6 rounded-xl border-0 text-center">
                      <div className="text-3xl font-bold bg-gradient-to-r from-accent to-purple-600 bg-clip-text text-transparent">
                        {stats?.cases.total ?? 0}
                      </div>
                      <h4 className="font-semibold mt-2">Total Cases</h4>
                      <p className="text-xs text-muted-foreground mt-1">All time</p>
                    </div>
                  </div>
                  <div className="mt-6">
                    <Link href="/cases">
                      <Button className="w-full btn-premium text-white h-12">
                        <FileText className="mr-2 h-5 w-5" />
                        View All Cases
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          <TabsContent value="activity" className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
            >
              <Card className="glass-card border-0 shadow-premium-lg">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-accent to-purple-600 rounded-xl flex items-center justify-center shadow-premium">
                      <Activity className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-xl font-semibold">Recent Activity</CardTitle>
                      <CardDescription>All recent activities across your workspace</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {recentItems.length === 0 ? (
                    <motion.div 
                      className="text-center py-16"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.8 }}
                    >
                      <div className="w-20 h-20 bg-gradient-to-br from-muted to-secondary rounded-3xl flex items-center justify-center mx-auto mb-6">
                        <Activity className="h-10 w-10 text-muted-foreground" />
                      </div>
                      <h3 className="text-xl font-semibold mb-2">No recent activity</h3>
                      <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                        Start by creating a case or task to see activity here.
                      </p>
                      <div className="flex gap-3 justify-center">
                        <Link href="/cases/new">
                          <Button className="btn-premium text-white">
                            <Plus className="mr-2 h-4 w-4" />
                            New Case
                          </Button>
                        </Link>
                        <Link href="/tasks">
                          <Button variant="outline" className="hover-lift glass-card">
                            <Calendar className="mr-2 h-4 w-4" />
                            View Tasks
                          </Button>
                        </Link>
                      </div>
                    </motion.div>
                  ) : (
                    <div className="space-y-4">
                      {recentItems.map((item, index) => (
                        <motion.div 
                          key={`${item.type}-${item.id}`} 
                          className="glass-card p-4 rounded-xl border-0 shadow-premium hover-lift"
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.7 + (index * 0.1) }}
                          whileHover={{ scale: 1.01 }}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <p className="font-semibold text-foreground">{item.title}</p>
                              {item.subtitle && (
                                <p className="text-sm text-muted-foreground">{item.subtitle}</p>
                              )}
                              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                                <Clock className="w-3 h-3" />
                                {formatDate(item.updatedAt)}
                              </p>
                            </div>
                            <div className="flex items-center gap-2">
                              {item.status && (
                                <Badge className={`${getStatusColor(item.status, item.type)} shadow-sm`}>
                                  {item.status.replace('_', ' ')}
                                </Badge>
                              )}
                              <ArrowUpRight className="w-4 h-4 text-muted-foreground" />
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>
        </Tabs>
      </motion.div>
    </div>
  );
}

function DashboardSkeleton() {
  return (
    <div className="flex-1 space-y-6 p-4 md:p-8 pt-6">
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-4 w-96" />
        </div>
        <Skeleton className="h-10 w-32" />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardHeader className="pb-2">
              <Skeleton className="h-4 w-24" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-8 w-12 mb-1" />
              <Skeleton className="h-3 w-20" />
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <Skeleton className="h-6 w-32" />
            <Skeleton className="h-4 w-48" />
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-48" />
                    <Skeleton className="h-3 w-32" />
                  </div>
                  <Skeleton className="h-6 w-20" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        <Card className="col-span-3">
          <CardHeader>
            <Skeleton className="h-6 w-32" />
            <Skeleton className="h-4 w-40" />
          </CardHeader>
          <CardContent className="space-y-3">
            {[...Array(4)].map((_, i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
