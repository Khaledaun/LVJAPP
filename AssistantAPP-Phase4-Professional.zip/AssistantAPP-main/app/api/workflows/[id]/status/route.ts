
export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth/options';
import { getCurrentUser, assertCaseAccess } from '@/lib/rbac';
import { WorkflowEngine } from '@/lib/workflow-engine';

// GET /api/workflows/[id]/status - Get workflow status for a case
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    const caseId = params.id; // This is actually the case ID for status endpoint

    const result = await WorkflowEngine.getWorkflowStatus(caseId);
    return NextResponse.json(result);
  } catch (error: any) {
    console.error('Error getting workflow status:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to get workflow status' },
      { status: error.status || 500 }
    );
  }
}
