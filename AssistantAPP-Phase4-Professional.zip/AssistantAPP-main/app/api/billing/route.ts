

export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth/options';
import { requireStaffOrAdmin, getCurrentUser } from '@/lib/rbac';
import { BillingEngine } from '@/lib/billing-engine';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// GET /api/billing - Get billing analytics and summary
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    const user = await getCurrentUser();
    requireStaffOrAdmin(user);

    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type') || 'summary';
    const startDate = searchParams.get('startDate') ? new Date(searchParams.get('startDate')!) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const endDate = searchParams.get('endDate') ? new Date(searchParams.get('endDate')!) : new Date();
    const clientId = searchParams.get('clientId') || undefined;
    const caseId = searchParams.get('caseId') || undefined;

    let data;

    switch (type) {
      case 'analytics':
        data = await BillingEngine.getBillingSummary(startDate, endDate, clientId);
        break;
      case 'case_summary':
        data = await BillingEngine.getBillingSummary(startDate, endDate, clientId);
        break;
      default:
        data = await BillingEngine.getBillingSummary(startDate, endDate, clientId);
    }

    return NextResponse.json({
      success: true,
      data
    });
  } catch (error: any) {
    console.error('Error getting billing data:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to get billing data' },
      { status: error.status || 500 }
    );
  }
}

// POST /api/billing - Create billing entries or perform billing operations
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    const user = await getCurrentUser();
    requireStaffOrAdmin(user);

    const body = await request.json();
    const { action, ...data } = body;

    let result;

    switch (action) {
      case 'generate_invoice':
        if (data.timeEntryIds?.length) {
          const calculation = await BillingEngine.calculateTimeEntryBilling(data.timeEntryIds, data.taxRate || 0);
          result = await BillingEngine.generateInvoice(calculation, {
            clientId: data.clientId,
            caseId: data.caseId,
            title: data.title,
            description: data.description,
            dueDate: data.dueDate ? new Date(data.dueDate) : undefined,
            generatedById: user.id,
            timeEntryIds: data.timeEntryIds
          });
        } else if (data.services?.length) {
          const calculation = await BillingEngine.calculateServiceBilling(data.services, data.taxRate || 0);
          result = await BillingEngine.generateInvoice(calculation, {
            clientId: data.clientId,
            caseId: data.caseId,
            title: data.title,
            description: data.description,
            dueDate: data.dueDate ? new Date(data.dueDate) : undefined,
            generatedById: user.id
          });
        } else {
          return NextResponse.json({ success: false, error: 'No billing items provided' }, { status: 400 });
        }
        break;

      case 'calculate_time_billing':
        result = await BillingEngine.calculateTimeEntryBilling(data.timeEntryIds, data.taxRate || 0);
        break;

      case 'calculate_service_billing':
        result = await BillingEngine.calculateServiceBilling(data.services, data.taxRate || 0);
        break;

      case 'get_service_rates':
        result = await BillingEngine.getApplicableServiceRates(data.userId, data.caseType);
        break;

      default:
        return NextResponse.json({ success: false, error: 'Invalid action' }, { status: 400 });
    }

    return NextResponse.json({
      success: true,
      data: result
    });
  } catch (error: any) {
    console.error('Error processing billing operation:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to process billing operation' },
      { status: error.status || 500 }
    );
  }
}
