

export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth/options';
import { NotificationEngine } from '@/lib/notification-engine';

// GET /api/notifications/counts - Get notification counts for current user
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    const userId = session.user.id;
    const unreadCount = await NotificationEngine.getUnreadCount(userId);

    // Get counts by type
    const notifications = await NotificationEngine.getUserNotifications(userId, { 
      status: 'unread',
      limit: 100 
    });

    const countsByType = notifications.reduce((acc: any, notification: any) => {
      const type = notification.type;
      acc[type] = (acc[type] || 0) + 1;
      return acc;
    }, {});

    const countsByPriority = notifications.reduce((acc: any, notification: any) => {
      const priority = notification.priority;
      acc[priority] = (acc[priority] || 0) + 1;
      return acc;
    }, {});

    return NextResponse.json({
      success: true,
      data: {
        total: unreadCount,
        byType: countsByType,
        byPriority: countsByPriority
      }
    });
  } catch (error: any) {
    console.error('Error getting notification counts:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to get notification counts' },
      { status: error.status || 500 }
    );
  }
}
