

export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth/options';
import { requireStaffOrAdmin, getCurrentUser } from '@/lib/rbac';
import { NotificationEngine } from '@/lib/notification-engine';
import { NotificationType } from '@prisma/client';

// GET /api/notifications - Get notifications for current user
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const status = searchParams.get('status') as 'unread' | 'read' | 'dismissed' | undefined;
    const typeParam = searchParams.get('type');
    const type = typeParam as NotificationType | undefined;

    const notifications = await NotificationEngine.getUserNotifications(session.user.id, {
      status,
      type,
      limit,
      offset: (page - 1) * limit
    });

    return NextResponse.json({
      success: true,
      data: notifications,
      pagination: {
        page,
        limit,
        total: notifications.length
      }
    });
  } catch (error: any) {
    console.error('Error getting notifications:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to get notifications' },
      { status: error.status || 500 }
    );
  }
}

// POST /api/notifications - Create or send notifications
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    const user = await getCurrentUser();
    requireStaffOrAdmin(user);

    const body = await request.json();
    const { action, ...data } = body;

    let result;

    switch (action) {
      case 'send_bulk':
        result = await NotificationEngine.sendBulkNotifications(data.recipientIds, {
          title: data.title,
          message: data.message,
          type: data.type,
          priority: data.priority,
          senderId: user.id,
          caseId: data.caseId,
          taskId: data.taskId,
          documentId: data.documentId,
          actionUrl: data.actionUrl,
          expiresAt: data.expiresAt ? new Date(data.expiresAt) : undefined
        });
        break;

      case 'send_template':
        result = await NotificationEngine.sendTemplateNotification(
          data.templateId,
          data.recipientId,
          data.variables,
          {
            senderId: user.id,
            caseId: data.caseId,
            taskId: data.taskId,
            documentId: data.documentId,
            actionUrl: data.actionUrl,
            priority: data.priority,
            expiresAt: data.expiresAt ? new Date(data.expiresAt) : undefined
          }
        );
        break;

      case 'send_single':
        result = await NotificationEngine.sendNotification({
          title: data.title,
          message: data.message,
          type: data.type,
          priority: data.priority,
          recipientId: data.recipientId,
          senderId: user.id,
          caseId: data.caseId,
          taskId: data.taskId,
          documentId: data.documentId,
          actionUrl: data.actionUrl,
          expiresAt: data.expiresAt ? new Date(data.expiresAt) : undefined
        });
        break;

      default:
        return NextResponse.json({ success: false, error: 'Invalid action' }, { status: 400 });
    }

    return NextResponse.json({
      success: true,
      data: result
    });
  } catch (error: any) {
    console.error('Error processing notification:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to process notification' },
      { status: error.status || 500 }
    );
  }
}
