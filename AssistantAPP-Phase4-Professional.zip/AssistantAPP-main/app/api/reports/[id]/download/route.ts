

export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth/options';
import { requireStaffOrAdmin, getCurrentUser } from '@/lib/rbac';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// GET /api/reports/[id]/download - Download generated report
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    const user = await getCurrentUser();
    requireStaffOrAdmin(user);

    const report = await prisma.generatedReport.findUnique({
      where: { id: params.id },
      include: {
        template: { select: { name: true, type: true } },
        generatedBy: { select: { name: true } }
      }
    });

    if (!report) {
      return NextResponse.json({ success: false, error: 'Report not found' }, { status: 404 });
    }

    if (report.status !== 'completed') {
      return NextResponse.json({ success: false, error: 'Report is not ready for download' }, { status: 400 });
    }

    if (!report.fileUrl) {
      return NextResponse.json({ success: false, error: 'Report file not available' }, { status: 404 });
    }

    // Check if report has expired
    if (report.expiresAt && new Date() > report.expiresAt) {
      return NextResponse.json({ success: false, error: 'Report has expired' }, { status: 410 });
    }

    // Update download count
    await prisma.generatedReport.update({
      where: { id: params.id },
      data: { downloadCount: { increment: 1 } }
    });

    // Handle report data if it's stored in metadata
    let reportData = null;
    if (report.metadata && typeof report.metadata === 'object') {
      const metadata = report.metadata as any;
      if (metadata.reportData) {
        reportData = metadata.reportData;
      }
    }

    return NextResponse.json({
      success: true,
      data: {
        ...report,
        reportData
      }
    });
  } catch (error: any) {
    console.error('Error downloading report:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to download report' },
      { status: error.status || 500 }
    );
  }
}
