

export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth/options';
import { requireStaffOrAdmin, getCurrentUser } from '@/lib/rbac';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// GET /api/reports - Get all generated reports
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    const user = await getCurrentUser();
    requireStaffOrAdmin(user);

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const status = searchParams.get('status');
    const type = searchParams.get('type');

    const where: any = {};
    
    if (status) {
      where.status = status;
    }
    
    if (type) {
      where.template = { type };
    }

    const [reports, total] = await Promise.all([
      prisma.generatedReport.findMany({
        where,
        include: {
          template: { select: { name: true, type: true } },
          generatedBy: { select: { name: true } }
        },
        orderBy: { generatedAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit
      }),
      prisma.generatedReport.count({ where })
    ]);

    return NextResponse.json({
      success: true,
      data: reports,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error: any) {
    console.error('Error getting reports:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to get reports' },
      { status: error.status || 500 }
    );
  }
}
