
import { NextRequest, NextResponse } from "next/server";
import { getPrisma } from "@/lib/db";
import { getCurrentUser } from "@/lib/rbac";
import { Role } from "@prisma/client";

export const dynamic = "force-dynamic";

// GET - Get document comments
export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 });
    }

    const { id: documentId } = params;
    const prisma = await getPrisma();

    // First check if user has access to the document
    const document = await prisma.document.findUnique({
      where: { id: documentId },
      include: {
        case: true
      },
    });

    if (!document) {
      return NextResponse.json({ error: 'Document not found' }, { status: 404 });
    }

    // Check access permissions
    let hasAccess = false;
    if (user.role === Role.ADMIN) {
      hasAccess = true;
    } else if (user.role === Role.STAFF) {
      hasAccess = document.case.caseManagerId === user.id || document.case.lawyerId === user.id;
    } else if (user.role === Role.CLIENT) {
      hasAccess = document.case.clientId === user.id || 
                 document.uploadedBy === user.id ||
                 document.isShared ||
                 (document.sharedWith && JSON.parse(document.sharedWith as string || '[]').includes(user.id));
    }

    if (!hasAccess) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 });
    }

    const comments = await prisma.documentComment.findMany({
      where: { documentId },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            email: true,
            firstName: true,
            lastName: true,
            avatar: true,
            role: true,
          }
        }
      },
      orderBy: { createdAt: 'asc' },
    });

    return NextResponse.json({ comments });
  } catch (error: any) {
    console.error("Failed to fetch document comments:", error);
    return NextResponse.json(
      { error: error?.message || "Internal Server Error" },
      { status: error?.status || 500 }
    );
  }
}

// POST - Add a comment to a document
export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 });
    }

    const { id: documentId } = params;
    const body = await req.json();
    const { content } = body;

    if (!content || content.trim() === '') {
      return NextResponse.json(
        { error: 'Comment content is required' },
        { status: 400 }
      );
    }

    const prisma = await getPrisma();

    // Check if user has access to the document (same logic as GET)
    const document = await prisma.document.findUnique({
      where: { id: documentId },
      include: {
        case: true
      },
    });

    if (!document) {
      return NextResponse.json({ error: 'Document not found' }, { status: 404 });
    }

    // Check access permissions
    let hasAccess = false;
    if (user.role === Role.ADMIN) {
      hasAccess = true;
    } else if (user.role === Role.STAFF) {
      hasAccess = document.case.caseManagerId === user.id || document.case.lawyerId === user.id;
    } else if (user.role === Role.CLIENT) {
      hasAccess = document.case.clientId === user.id || 
                 document.uploadedBy === user.id ||
                 document.isShared ||
                 (document.sharedWith && JSON.parse(document.sharedWith as string || '[]').includes(user.id));
    }

    if (!hasAccess) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 });
    }

    const comment = await prisma.documentComment.create({
      data: {
        content: content.trim(),
        authorId: user.id,
        documentId,
      },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            email: true,
            firstName: true,
            lastName: true,
            avatar: true,
            role: true,
          }
        }
      },
    });

    return NextResponse.json({ comment }, { status: 201 });
  } catch (error: any) {
    console.error('Failed to create document comment:', error);
    return NextResponse.json(
      { error: error?.message || 'Internal Server Error' },
      { status: error?.status || 500 }
    );
  }
}
