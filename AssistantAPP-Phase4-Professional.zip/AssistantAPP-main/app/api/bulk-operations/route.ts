
export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth/options';
import { requireStaffOrAdmin, getCurrentUser } from '@/lib/rbac';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// GET /api/bulk-operations - Get bulk operations history
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    requireStaffOrAdmin(user);

    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');
    const type = searchParams.get('type');
    const status = searchParams.get('status');

    const where: any = {};
    if (type) where.type = type;
    if (status) where.status = status;

    const operations = await prisma.bulkOperation.findMany({
      where,
      include: {
        executedBy: { select: { name: true } }
      },
      orderBy: { startedAt: 'desc' },
      take: limit,
      skip: offset
    });

    return NextResponse.json({
      success: true,
      data: operations
    });
  } catch (error: any) {
    console.error('Error getting bulk operations:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to get bulk operations' },
      { status: error.status || 500 }
    );
  }
}

// POST /api/bulk-operations - Execute bulk operation
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    requireStaffOrAdmin(user);

    const body = await request.json();
    const { type, description, parameters } = body;

    // Create bulk operation record
    const operation = await prisma.bulkOperation.create({
      data: {
        type: type as any,
        description,
        parameters,
        executedById: user.id,
        status: 'processing'
      }
    });

    // Execute the bulk operation based on type
    let result;
    try {
      switch (type) {
        case 'case_status_update':
          result = await executeCaseStatusUpdate(operation.id, parameters);
          break;
        
        case 'document_approval':
          result = await executeDocumentApproval(operation.id, parameters);
          break;
        
        case 'task_assignment':
          result = await executeTaskAssignment(operation.id, parameters);
          break;
        
        case 'notification_send':
          result = await executeNotificationSend(operation.id, parameters);
          break;
        
        default:
          throw new Error(`Unknown bulk operation type: ${type}`);
      }

      // Update operation with results
      const updatedOperation = await prisma.bulkOperation.update({
        where: { id: operation.id },
        data: {
          status: 'completed',
          completedAt: new Date(),
          ...result
        }
      });

      return NextResponse.json({
        success: true,
        data: updatedOperation
      });

    } catch (error: any) {
      // Mark operation as failed
      await prisma.bulkOperation.update({
        where: { id: operation.id },
        data: {
          status: 'failed',
          error: error.message,
          completedAt: new Date()
        }
      });

      throw error;
    }
  } catch (error: any) {
    console.error('Error executing bulk operation:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to execute bulk operation' },
      { status: 500 }
    );
  }
}

// Bulk operation implementations
async function executeCaseStatusUpdate(operationId: string, parameters: any) {
  const { caseIds, newStatus } = parameters;
  
  const result = await prisma.case.updateMany({
    where: { id: { in: caseIds } },
    data: { overallStatus: newStatus }
  });

  return {
    totalItems: caseIds.length,
    processedItems: result.count,
    successItems: result.count,
    failedItems: caseIds.length - result.count
  };
}

async function executeDocumentApproval(operationId: string, parameters: any) {
  const { documentIds, action } = parameters; // action: 'approve' or 'reject'
  
  const newState = action === 'approve' ? 'approved' : 'rejected';
  
  const result = await prisma.document.updateMany({
    where: { id: { in: documentIds } },
    data: { 
      state: newState,
      reviewedAt: new Date()
    }
  });

  return {
    totalItems: documentIds.length,
    processedItems: result.count,
    successItems: result.count,
    failedItems: documentIds.length - result.count
  };
}

async function executeTaskAssignment(operationId: string, parameters: any) {
  const { taskIds, assigneeId } = parameters;
  
  const result = await prisma.task.updateMany({
    where: { id: { in: taskIds } },
    data: { assignedToId: assigneeId }
  });

  return {
    totalItems: taskIds.length,
    processedItems: result.count,
    successItems: result.count,
    failedItems: taskIds.length - result.count
  };
}

async function executeNotificationSend(operationId: string, parameters: any) {
  const { recipientIds, template } = parameters;
  
  let successCount = 0;
  let failedCount = 0;

  for (const recipientId of recipientIds) {
    try {
      await prisma.notification.create({
        data: {
          title: template.title,
          message: template.message,
          type: template.type || 'info',
          priority: template.priority || 'normal',
          recipientId
        }
      });
      successCount++;
    } catch {
      failedCount++;
    }
  }

  return {
    totalItems: recipientIds.length,
    processedItems: recipientIds.length,
    successItems: successCount,
    failedItems: failedCount
  };
}
