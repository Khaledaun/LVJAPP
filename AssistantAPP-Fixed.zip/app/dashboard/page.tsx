import { Suspense } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Plus, Users, FileText, DollarSign, Clock } from 'lucide-react';
import Link from 'next/link';

// Mock data for development - replace with real data fetching
const mockStats = {
  totalCases: 24,
  activeCases: 18,
  completedCases: 6,
  totalRevenue: 125000,
  pendingPayments: 15000,
};

const mockRecentCases = [
  {
    id: '1',
    caseNumber: 'LVJ-2024-001',
    applicantName: 'John Doe',
    status: 'IN_PROGRESS',
    stage: 'Document Review',
    updatedAt: '2024-09-01',
  },
  {
    id: '2',
    caseNumber: 'LVJ-2024-002',
    applicantName: 'Jane Smith',
    status: 'PENDING',
    stage: 'Initial Consultation',
    updatedAt: '2024-08-30',
  },
  {
    id: '3',
    caseNumber: 'LVJ-2024-003',
    applicantName: 'Mike Johnson',
    status: 'COMPLETED',
    stage: 'Case Closed',
    updatedAt: '2024-08-28',
  },
];

function DashboardStats() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Cases</CardTitle>
          <FileText className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{mockStats.totalCases}</div>
          <p className="text-xs text-muted-foreground">
            {mockStats.activeCases} active, {mockStats.completedCases} completed
          </p>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Active Cases</CardTitle>
          <Clock className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{mockStats.activeCases}</div>
          <p className="text-xs text-muted-foreground">
            Cases in progress
          </p>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
          <DollarSign className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">${mockStats.totalRevenue.toLocaleString()}</div>
          <p className="text-xs text-muted-foreground">
            ${mockStats.pendingPayments.toLocaleString()} pending
          </p>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Clients</CardTitle>
          <Users className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{mockStats.totalCases}</div>
          <p className="text-xs text-muted-foreground">
            Active clients
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

function RecentCases() {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return 'bg-green-100 text-green-800';
      case 'IN_PROGRESS':
        return 'bg-blue-100 text-blue-800';
      case 'PENDING':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Cases</CardTitle>
        <CardDescription>
          Latest case updates and activities
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {mockRecentCases.map((case_) => (
            <div key={case_.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div className="space-y-1">
                <p className="font-medium">{case_.caseNumber}</p>
                <p className="text-sm text-muted-foreground">{case_.applicantName}</p>
                <p className="text-xs text-muted-foreground">{case_.stage}</p>
              </div>
              <div className="text-right space-y-1">
                <Badge className={getStatusColor(case_.status)}>
                  {case_.status.replace('_', ' ')}
                </Badge>
                <p className="text-xs text-muted-foreground">{case_.updatedAt}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-4">
          <Button asChild className="w-full">
            <Link href="/cases">View All Cases</Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function QuickActions() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
        <CardDescription>
          Common tasks and shortcuts
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-2">
        <Button asChild className="w-full justify-start">
          <Link href="/cases/new">
            <Plus className="mr-2 h-4 w-4" />
            New Case
          </Link>
        </Button>
        <Button variant="outline" asChild className="w-full justify-start">
          <Link href="/cases">
            <FileText className="mr-2 h-4 w-4" />
            View All Cases
          </Link>
        </Button>
        <Button variant="outline" asChild className="w-full justify-start">
          <Link href="/profile">
            <Users className="mr-2 h-4 w-4" />
            Manage Profile
          </Link>
        </Button>
      </CardContent>
    </Card>
  );
}

export default function DashboardPage() {
  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        <div className="flex items-center space-x-2">
          <Button asChild>
            <Link href="/cases/new">
              <Plus className="mr-2 h-4 w-4" />
              New Case
            </Link>
          </Button>
        </div>
      </div>
      
      <Suspense fallback={<div>Loading stats...</div>}>
        <DashboardStats />
      </Suspense>
      
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <div className="col-span-4">
          <Suspense fallback={<div>Loading recent cases...</div>}>
            <RecentCases />
          </Suspense>
        </div>
        <div className="col-span-3">
          <QuickActions />
        </div>
      </div>
    </div>
  );
}
