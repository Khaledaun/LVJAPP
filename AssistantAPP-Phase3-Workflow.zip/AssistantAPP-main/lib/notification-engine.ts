
import { PrismaClient, NotificationType, Priority } from '@prisma/client';

const prisma = new PrismaClient();

export interface NotificationData {
  title: string;
  message: string;
  type?: NotificationType;
  priority?: Priority;
  recipientId: string;
  senderId?: string;
  caseId?: string;
  taskId?: string;
  documentId?: string;
  workflowRunId?: string;
  actionUrl?: string;
  metadata?: any;
  expiresAt?: Date;
}

export interface NotificationTemplate {
  id: string;
  name: string;
  title: string;
  message: string;
  type: NotificationType;
  variables: string[];
}

export class NotificationEngine {
  private static templates: NotificationTemplate[] = [
    {
      id: 'case_created',
      name: 'Case Created',
      title: 'New case assigned: {{caseNumber}}',
      message: 'A new case "{{caseTitle}}" has been assigned to you.',
      type: 'info',
      variables: ['caseNumber', 'caseTitle']
    },
    {
      id: 'document_uploaded',
      name: 'Document Uploaded',
      title: 'Document uploaded: {{documentName}}',
      message: 'A new document "{{documentName}}" has been uploaded for case {{caseNumber}}.',
      type: 'info',
      variables: ['documentName', 'caseNumber']
    },
    {
      id: 'task_assigned',
      name: 'Task Assigned',
      title: 'New task assigned: {{taskTitle}}',
      message: 'You have been assigned a new task "{{taskTitle}}" for case {{caseNumber}}.',
      type: 'info',
      variables: ['taskTitle', 'caseNumber']
    },
    {
      id: 'task_overdue',
      name: 'Task Overdue',
      title: 'Task overdue: {{taskTitle}}',
      message: 'Task "{{taskTitle}}" is overdue. Please complete it as soon as possible.',
      type: 'warning',
      variables: ['taskTitle', 'dueDate']
    },
    {
      id: 'deadline_approaching',
      name: 'Deadline Approaching',
      title: 'Deadline approaching: {{itemName}}',
      message: 'The deadline for "{{itemName}}" is approaching ({{dueDate}}).',
      type: 'warning',
      variables: ['itemName', 'dueDate']
    },
    {
      id: 'workflow_completed',
      name: 'Workflow Completed',
      title: 'Workflow completed: {{workflowName}}',
      message: 'The workflow "{{workflowName}}" for case {{caseNumber}} has been completed.',
      type: 'success',
      variables: ['workflowName', 'caseNumber']
    },
    {
      id: 'payment_received',
      name: 'Payment Received',
      title: 'Payment received: {{amount}}',
      message: 'A payment of {{amount}} has been received for invoice {{invoiceNumber}}.',
      type: 'success',
      variables: ['amount', 'invoiceNumber']
    },
    {
      id: 'system_alert',
      name: 'System Alert',
      title: 'System Alert: {{alertTitle}}',
      message: '{{alertMessage}}',
      type: 'alert',
      variables: ['alertTitle', 'alertMessage']
    }
  ];

  /**
   * Send a notification
   */
  static async sendNotification(data: NotificationData) {
    const notification = await prisma.notification.create({
      data: {
        title: data.title,
        message: data.message,
        type: data.type || 'info',
        priority: data.priority || 'normal',
        recipientId: data.recipientId,
        senderId: data.senderId,
        caseId: data.caseId,
        taskId: data.taskId,
        documentId: data.documentId,
        workflowRunId: data.workflowRunId,
        actionUrl: data.actionUrl,
        metadata: data.metadata,
        expiresAt: data.expiresAt
      },
      include: {
        recipient: { select: { name: true, email: true } },
        sender: { select: { name: true } },
        case: { select: { caseNumber: true, title: true } }
      }
    });

    // TODO: Implement real-time notification delivery (WebSocket, push notifications, email)
    await this.deliverNotification(notification);

    return notification;
  }

  /**
   * Send notification using template
   */
  static async sendTemplateNotification(
    templateId: string,
    recipientId: string,
    variables: Record<string, string>,
    options: {
      senderId?: string;
      caseId?: string;
      taskId?: string;
      documentId?: string;
      workflowRunId?: string;
      actionUrl?: string;
      priority?: Priority;
      expiresAt?: Date;
    } = {}
  ) {
    const template = this.templates.find(t => t.id === templateId);
    if (!template) {
      throw new Error(`Notification template not found: ${templateId}`);
    }

    const title = this.replaceVariables(template.title, variables);
    const message = this.replaceVariables(template.message, variables);

    return this.sendNotification({
      title,
      message,
      type: template.type,
      recipientId,
      ...options
    });
  }

  /**
   * Send bulk notifications
   */
  static async sendBulkNotifications(
    recipientIds: string[],
    data: Omit<NotificationData, 'recipientId'>
  ) {
    const notifications = recipientIds.map(recipientId => ({
      ...data,
      recipientId,
      type: data.type || 'info',
      priority: data.priority || 'normal'
    }));

    const created = await prisma.notification.createMany({
      data: notifications
    });

    // Get created notifications for delivery
    const createdNotifications = await prisma.notification.findMany({
      where: {
        recipientId: { in: recipientIds },
        createdAt: { gte: new Date(Date.now() - 1000) } // Last second
      },
      include: {
        recipient: { select: { name: true, email: true } },
        sender: { select: { name: true } },
        case: { select: { caseNumber: true, title: true } }
      }
    });

    // Deliver notifications
    await Promise.all(
      createdNotifications.map(notification => this.deliverNotification(notification))
    );

    return created;
  }

  /**
   * Get notifications for a user
   */
  static async getUserNotifications(
    userId: string,
    options: {
      status?: 'unread' | 'read' | 'dismissed';
      type?: NotificationType;
      limit?: number;
      offset?: number;
      includeExpired?: boolean;
    } = {}
  ) {
    const where: any = { recipientId: userId };

    if (options.status) {
      where.status = options.status;
    }

    if (options.type) {
      where.type = options.type;
    }

    if (!options.includeExpired) {
      where.OR = [
        { expiresAt: null },
        { expiresAt: { gt: new Date() } }
      ];
    }

    const notifications = await prisma.notification.findMany({
      where,
      include: {
        sender: { select: { name: true } },
        case: { select: { caseNumber: true, title: true } },
        task: { select: { title: true } },
        document: { select: { name: true } }
      },
      orderBy: { createdAt: 'desc' },
      take: options.limit || 50,
      skip: options.offset || 0
    });

    return notifications;
  }

  /**
   * Mark notification as read
   */
  static async markAsRead(notificationId: string, userId: string) {
    const notification = await prisma.notification.findFirst({
      where: {
        id: notificationId,
        recipientId: userId
      }
    });

    if (!notification) return false;

    await prisma.notification.update({
      where: { id: notificationId },
      data: {
        status: 'read',
        readAt: new Date()
      }
    });

    return true;
  }

  /**
   * Mark all notifications as read for a user
   */
  static async markAllAsRead(userId: string) {
    await prisma.notification.updateMany({
      where: {
        recipientId: userId,
        status: 'unread'
      },
      data: {
        status: 'read',
        readAt: new Date()
      }
    });
  }

  /**
   * Dismiss notification
   */
  static async dismissNotification(notificationId: string, userId: string) {
    const notification = await prisma.notification.findFirst({
      where: {
        id: notificationId,
        recipientId: userId
      }
    });

    if (!notification) return false;

    await prisma.notification.update({
      where: { id: notificationId },
      data: { status: 'dismissed' }
    });

    return true;
  }

  /**
   * Get unread notification count
   */
  static async getUnreadCount(userId: string) {
    return prisma.notification.count({
      where: {
        recipientId: userId,
        status: 'unread',
        OR: [
          { expiresAt: null },
          { expiresAt: { gt: new Date() } }
        ]
      }
    });
  }

  /**
   * Clean up expired notifications
   */
  static async cleanupExpiredNotifications() {
    const result = await prisma.notification.deleteMany({
      where: {
        expiresAt: { lt: new Date() }
      }
    });

    return result.count;
  }

  /**
   * Get notification analytics
   */
  static async getNotificationAnalytics(
    startDate: Date,
    endDate: Date,
    userId?: string
  ) {
    const where: any = {
      createdAt: {
        gte: startDate,
        lte: endDate
      }
    };

    if (userId) {
      where.recipientId = userId;
    }

    const [total, unread, byType, byPriority] = await Promise.all([
      prisma.notification.count({ where }),
      prisma.notification.count({ where: { ...where, status: 'unread' } }),
      prisma.notification.groupBy({
        by: ['type'],
        where,
        _count: { id: true }
      }),
      prisma.notification.groupBy({
        by: ['priority'],
        where,
        _count: { id: true }
      })
    ]);

    return {
      total,
      unread,
      readRate: total > 0 ? ((total - unread) / total) * 100 : 0,
      byType: byType.map((item: any) => ({
        type: item.type,
        count: item._count.id
      })),
      byPriority: byPriority.map((item: any) => ({
        priority: item.priority,
        count: item._count.id
      }))
    };
  }

  /**
   * Replace variables in template strings
   */
  private static replaceVariables(template: string, variables: Record<string, string>): string {
    return template.replace(/\{\{(\w+)\}\}/g, (match, key) => {
      return variables[key] || match;
    });
  }

  /**
   * Deliver notification through various channels
   */
  private static async deliverNotification(notification: any) {
    // TODO: Implement actual delivery mechanisms
    
    // 1. Real-time WebSocket notification
    // await this.sendWebSocketNotification(notification);
    
    // 2. Email notification for high priority
    if (notification.priority === 'urgent' || notification.priority === 'critical') {
      // await this.sendEmailNotification(notification);
    }
    
    // 3. Push notification for mobile apps
    // await this.sendPushNotification(notification);
    
    // For now, just log the notification
    console.log('Notification delivered:', {
      id: notification.id,
      title: notification.title,
      recipient: notification.recipient?.name || notification.recipientId,
      type: notification.type,
      priority: notification.priority
    });
  }

  /**
   * Get available notification templates
   */
  static getTemplates(): NotificationTemplate[] {
    return this.templates;
  }

  /**
   * Register custom notification template
   */
  static registerTemplate(template: NotificationTemplate) {
    const existingIndex = this.templates.findIndex(t => t.id === template.id);
    if (existingIndex >= 0) {
      this.templates[existingIndex] = template;
    } else {
      this.templates.push(template);
    }
  }
}
