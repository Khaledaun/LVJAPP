
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export interface AnalyticsFilter {
  startDate?: Date;
  endDate?: Date;
  caseTypes?: string[];
  userIds?: string[];
  departments?: string[];
  statuses?: string[];
}

export interface MetricResult {
  key: string;
  value: number;
  dimension?: string;
  metadata?: Record<string, any>;
  periodStart: Date;
  periodEnd: Date;
}

export class AnalyticsEngine {
  
  // Calculate and cache analytics metrics
  static async calculateMetrics(
    metrics: string[],
    filters: AnalyticsFilter = {},
    cachePeriod: 'daily' | 'weekly' | 'monthly' = 'daily'
  ) {
    try {
      const now = new Date();
      const { periodStart, periodEnd } = this.getPeriodDates(cachePeriod, now);
      
      const results: MetricResult[] = [];

      for (const metric of metrics) {
        const result = await this.calculateSingleMetric(
          metric,
          filters,
          periodStart,
          periodEnd
        );
        
        if (result) {
          results.push(result);
          
          // Cache the metric
          await this.cacheMetric(result);
        }
      }

      return { success: true, data: results };
    } catch (error) {
      console.error('Error calculating metrics:', error);
      return { success: false, error: 'Failed to calculate metrics' };
    }
  }

  // Calculate single metric
  private static async calculateSingleMetric(
    metricKey: string,
    filters: AnalyticsFilter,
    periodStart: Date,
    periodEnd: Date
  ): Promise<MetricResult | null> {
    try {
      switch (metricKey) {
        case 'case_completion_rate':
          return await this.calculateCaseCompletionRate(filters, periodStart, periodEnd);
        
        case 'average_case_duration':
          return await this.calculateAverageCaseDuration(filters, periodStart, periodEnd);
        
        case 'document_approval_rate':
          return await this.calculateDocumentApprovalRate(filters, periodStart, periodEnd);
        
        case 'task_completion_rate':
          return await this.calculateTaskCompletionRate(filters, periodStart, periodEnd);
        
        case 'staff_productivity':
          return await this.calculateStaffProductivity(filters, periodStart, periodEnd);
        
        case 'revenue_metrics':
          return await this.calculateRevenueMetrics(filters, periodStart, periodEnd);
        
        case 'client_satisfaction':
          return await this.calculateClientSatisfactionMetrics(filters, periodStart, periodEnd);
        
        case 'workflow_efficiency':
          return await this.calculateWorkflowEfficiency(filters, periodStart, periodEnd);
        
        default:
          console.warn(`Unknown metric: ${metricKey}`);
          return null;
      }
    } catch (error) {
      console.error(`Error calculating metric ${metricKey}:`, error);
      return null;
    }
  }

  // Case completion rate metric
  private static async calculateCaseCompletionRate(
    filters: AnalyticsFilter,
    periodStart: Date,
    periodEnd: Date
  ): Promise<MetricResult> {
    const dateFilter = {
      createdAt: { gte: periodStart, lte: periodEnd }
    };

    const [totalCases, completedCases] = await Promise.all([
      prisma.case.count({
        where: {
          ...dateFilter,
          ...(filters.caseTypes && { caseType: { in: filters.caseTypes } })
        }
      }),
      prisma.case.count({
        where: {
          ...dateFilter,
          overallStatus: 'approved',
          ...(filters.caseTypes && { caseType: { in: filters.caseTypes } })
        }
      })
    ]);

    const rate = totalCases > 0 ? (completedCases / totalCases) * 100 : 0;

    return {
      key: 'case_completion_rate',
      value: Math.round(rate * 100) / 100,
      periodStart,
      periodEnd,
      metadata: {
        totalCases,
        completedCases
      }
    };
  }

  // Average case duration metric
  private static async calculateAverageCaseDuration(
    filters: AnalyticsFilter,
    periodStart: Date,
    periodEnd: Date
  ): Promise<MetricResult> {
    const completedCases = await prisma.case.findMany({
      where: {
        createdAt: { gte: periodStart, lte: periodEnd },
        overallStatus: 'approved',
        actualCompletionDate: { not: null },
        ...(filters.caseTypes && { caseType: { in: filters.caseTypes } })
      },
      select: {
        createdAt: true,
        actualCompletionDate: true
      }
    });

    if (completedCases.length === 0) {
      return {
        key: 'average_case_duration',
        value: 0,
        periodStart,
        periodEnd,
        metadata: { totalCases: 0 }
      };
    }

    const totalDuration = completedCases.reduce((sum, caseItem) => {
      const duration = caseItem.actualCompletionDate!.getTime() - caseItem.createdAt.getTime();
      return sum + duration;
    }, 0);

    const averageDays = totalDuration / (completedCases.length * 24 * 60 * 60 * 1000);

    return {
      key: 'average_case_duration',
      value: Math.round(averageDays * 10) / 10,
      periodStart,
      periodEnd,
      metadata: {
        totalCases: completedCases.length,
        unit: 'days'
      }
    };
  }

  // Document approval rate metric
  private static async calculateDocumentApprovalRate(
    filters: AnalyticsFilter,
    periodStart: Date,
    periodEnd: Date
  ): Promise<MetricResult> {
    const [totalDocs, approvedDocs] = await Promise.all([
      prisma.document.count({
        where: {
          createdAt: { gte: periodStart, lte: periodEnd },
          state: { not: 'requested' }
        }
      }),
      prisma.document.count({
        where: {
          createdAt: { gte: periodStart, lte: periodEnd },
          state: 'approved'
        }
      })
    ]);

    const rate = totalDocs > 0 ? (approvedDocs / totalDocs) * 100 : 0;

    return {
      key: 'document_approval_rate',
      value: Math.round(rate * 100) / 100,
      periodStart,
      periodEnd,
      metadata: {
        totalDocuments: totalDocs,
        approvedDocuments: approvedDocs
      }
    };
  }

  // Task completion rate metric
  private static async calculateTaskCompletionRate(
    filters: AnalyticsFilter,
    periodStart: Date,
    periodEnd: Date
  ): Promise<MetricResult> {
    const [totalTasks, completedTasks] = await Promise.all([
      prisma.task.count({
        where: {
          createdAt: { gte: periodStart, lte: periodEnd },
          ...(filters.userIds && { assignedToId: { in: filters.userIds } })
        }
      }),
      prisma.task.count({
        where: {
          createdAt: { gte: periodStart, lte: periodEnd },
          status: 'completed',
          ...(filters.userIds && { assignedToId: { in: filters.userIds } })
        }
      })
    ]);

    const rate = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

    return {
      key: 'task_completion_rate',
      value: Math.round(rate * 100) / 100,
      periodStart,
      periodEnd,
      metadata: {
        totalTasks,
        completedTasks
      }
    };
  }

  // Staff productivity metric
  private static async calculateStaffProductivity(
    filters: AnalyticsFilter,
    periodStart: Date,
    periodEnd: Date
  ): Promise<MetricResult> {
    const timeEntries = await prisma.timeEntry.findMany({
      where: {
        startedAt: { gte: periodStart, lte: periodEnd },
        ...(filters.userIds && { userId: { in: filters.userIds } })
      },
      include: {
        user: { select: { role: true, department: true } }
      }
    });

    const totalHours = timeEntries.reduce((sum, entry) => sum + entry.duration, 0) / 60;
    const billableHours = timeEntries
      .filter(entry => entry.isBillable)
      .reduce((sum, entry) => sum + entry.duration, 0) / 60;

    const utilizationRate = totalHours > 0 ? (billableHours / totalHours) * 100 : 0;

    return {
      key: 'staff_productivity',
      value: Math.round(utilizationRate * 100) / 100,
      periodStart,
      periodEnd,
      metadata: {
        totalHours: Math.round(totalHours * 10) / 10,
        billableHours: Math.round(billableHours * 10) / 10,
        totalStaff: new Set(timeEntries.map(e => e.userId)).size
      }
    };
  }

  // Revenue metrics
  private static async calculateRevenueMetrics(
    filters: AnalyticsFilter,
    periodStart: Date,
    periodEnd: Date
  ): Promise<MetricResult> {
    const [invoices, payments] = await Promise.all([
      prisma.invoice.findMany({
        where: {
          createdAt: { gte: periodStart, lte: periodEnd }
        },
        select: { totalAmount: true }
      }),
      prisma.paymentRecord.findMany({
        where: {
          createdAt: { gte: periodStart, lte: periodEnd },
          status: 'completed'
        },
        select: { amount: true }
      })
    ]);

    const totalInvoiced = invoices.reduce((sum, inv) => sum + Number(inv.totalAmount), 0);
    const totalRevenue = payments.reduce((sum, pay) => sum + Number(pay.amount), 0);
    const collectionRate = totalInvoiced > 0 ? (totalRevenue / totalInvoiced) * 100 : 0;

    return {
      key: 'revenue_metrics',
      value: totalRevenue,
      periodStart,
      periodEnd,
      metadata: {
        totalInvoiced,
        collectionRate: Math.round(collectionRate * 100) / 100,
        invoiceCount: invoices.length
      }
    };
  }

  // Client satisfaction metrics (placeholder - would need surveys/feedback system)
  private static async calculateClientSatisfactionMetrics(
    filters: AnalyticsFilter,
    periodStart: Date,
    periodEnd: Date
  ): Promise<MetricResult> {
    // This is a placeholder implementation
    // In a real system, you would pull from client feedback/survey data
    const completedCases = await prisma.case.count({
      where: {
        createdAt: { gte: periodStart, lte: periodEnd },
        overallStatus: 'approved'
      }
    });

    // Mock satisfaction score based on case completion
    const mockScore = completedCases > 0 ? 4.2 : 0; // Out of 5

    return {
      key: 'client_satisfaction',
      value: mockScore,
      periodStart,
      periodEnd,
      metadata: {
        completedCases,
        scale: '5-point scale',
        note: 'Mock data - requires feedback system implementation'
      }
    };
  }

  // Workflow efficiency metric
  private static async calculateWorkflowEfficiency(
    filters: AnalyticsFilter,
    periodStart: Date,
    periodEnd: Date
  ): Promise<MetricResult> {
    const workflowRuns = await prisma.workflowRun.findMany({
      where: {
        startedAt: { gte: periodStart, lte: periodEnd },
        status: 'completed',
        completedAt: { not: null }
      },
      include: {
        template: true,
        case: { select: { caseType: true } }
      }
    });

    if (workflowRuns.length === 0) {
      return {
        key: 'workflow_efficiency',
        value: 0,
        periodStart,
        periodEnd,
        metadata: { totalWorkflows: 0 }
      };
    }

    // Calculate average completion time vs estimated time
    const efficiencyScores = workflowRuns.map(run => {
      const actualDuration = run.completedAt!.getTime() - run.startedAt.getTime();
      const actualDays = actualDuration / (24 * 60 * 60 * 1000);
      
      // Estimate based on workflow stages (simplified)
      const stages = (run.template.stages as any[]) || [];
      const estimatedDays = stages.reduce((sum, stage) => sum + (stage.estimatedDuration || 7), 0);
      
      return estimatedDays > 0 ? Math.min((estimatedDays / actualDays) * 100, 200) : 100;
    });

    const averageEfficiency = efficiencyScores.reduce((sum, score) => sum + score, 0) / efficiencyScores.length;

    return {
      key: 'workflow_efficiency',
      value: Math.round(averageEfficiency * 100) / 100,
      periodStart,
      periodEnd,
      metadata: {
        totalWorkflows: workflowRuns.length,
        unit: 'percentage',
        note: 'Higher values indicate faster completion vs estimates'
      }
    };
  }

  // Cache metric result
  private static async cacheMetric(metric: MetricResult) {
    try {
      await prisma.analyticsMetric.upsert({
        where: {
          key_dimension_periodStart_periodEnd: {
            key: metric.key,
            dimension: metric.dimension || '',
            periodStart: metric.periodStart,
            periodEnd: metric.periodEnd
          }
        },
        update: {
          value: metric.value,
          metadata: metric.metadata,
          calculatedAt: new Date()
        },
        create: {
          key: metric.key,
          value: metric.value,
          dimension: metric.dimension || '',
          periodStart: metric.periodStart,
          periodEnd: metric.periodEnd,
          metadata: metric.metadata
        }
      });
    } catch (error) {
      console.error('Error caching metric:', error);
    }
  }

  // Get cached metrics
  static async getCachedMetrics(
    metrics: string[],
    cachePeriod: 'daily' | 'weekly' | 'monthly' = 'daily',
    maxAge?: number // in hours
  ) {
    try {
      const now = new Date();
      const { periodStart, periodEnd } = this.getPeriodDates(cachePeriod, now);
      
      const where: any = {
        key: { in: metrics },
        periodStart,
        periodEnd
      };

      if (maxAge) {
        const cutoff = new Date(now.getTime() - maxAge * 60 * 60 * 1000);
        where.calculatedAt = { gte: cutoff };
      }

      const cachedMetrics = await prisma.analyticsMetric.findMany({
        where,
        orderBy: { calculatedAt: 'desc' }
      });

      return { success: true, data: cachedMetrics };
    } catch (error) {
      console.error('Error getting cached metrics:', error);
      return { success: false, error: 'Failed to get cached metrics' };
    }
  }

  // Get dashboard summary metrics
  static async getDashboardMetrics(filters: AnalyticsFilter = {}) {
    try {
      const now = new Date();
      const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      
      const metrics = await this.calculateMetrics(
        [
          'case_completion_rate',
          'average_case_duration',
          'document_approval_rate',
          'task_completion_rate',
          'staff_productivity',
          'revenue_metrics'
        ],
        { ...filters, startDate: thirtyDaysAgo, endDate: now },
        'monthly'
      );

      if (!metrics.success) {
        throw new Error(metrics.error);
      }

      // Get additional dashboard stats
      const [
        totalCases,
        activeCases,
        totalTasks,
        overdueTasks,
        pendingDocuments,
        totalRevenue
      ] = await Promise.all([
        prisma.case.count(),
        prisma.case.count({
          where: { overallStatus: { in: ['new', 'documents_pending', 'in_review', 'submitted'] } }
        }),
        prisma.task.count(),
        prisma.task.count({
          where: {
            dueDate: { lt: now },
            status: { notIn: ['completed', 'cancelled'] }
          }
        }),
        prisma.document.count({
          where: { state: { in: ['requested', 'uploaded'] } }
        }),
        prisma.paymentRecord.aggregate({
          where: { status: 'completed' },
          _sum: { amount: true }
        })
      ]);

      const dashboardData = {
        metrics: metrics.data?.reduce((acc, metric) => {
          acc[metric.key] = metric;
          return acc;
        }, {} as Record<string, MetricResult>) || {},
        counts: {
          totalCases,
          activeCases,
          totalTasks,
          overdueTasks,
          pendingDocuments,
          totalRevenue: Number(totalRevenue._sum.amount || 0)
        },
        trends: {
          // These would be calculated from historical data
          casesGrowth: 0,
          revenueGrowth: 0,
          efficiencyImprovement: 0
        }
      };

      return { success: true, data: dashboardData };
    } catch (error) {
      console.error('Error getting dashboard metrics:', error);
      return { success: false, error: 'Failed to get dashboard metrics' };
    }
  }

  // Helper method to get period dates
  private static getPeriodDates(period: 'daily' | 'weekly' | 'monthly', date: Date) {
    const now = new Date(date);
    
    switch (period) {
      case 'daily':
        const dayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const dayEnd = new Date(dayStart.getTime() + 24 * 60 * 60 * 1000 - 1);
        return { periodStart: dayStart, periodEnd: dayEnd };
      
      case 'weekly':
        const weekStart = new Date(now);
        weekStart.setDate(now.getDate() - now.getDay());
        weekStart.setHours(0, 0, 0, 0);
        const weekEnd = new Date(weekStart.getTime() + 7 * 24 * 60 * 60 * 1000 - 1);
        return { periodStart: weekStart, periodEnd: weekEnd };
      
      case 'monthly':
        const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
        const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
        return { periodStart: monthStart, periodEnd: monthEnd };
      
      default:
        throw new Error(`Unknown period: ${period}`);
    }
  }

  // Generate trend analysis
  static async generateTrendAnalysis(
    metricKey: string,
    periods: number = 6,
    period: 'daily' | 'weekly' | 'monthly' = 'monthly'
  ) {
    try {
      const now = new Date();
      const results = [];

      for (let i = periods - 1; i >= 0; i--) {
        const periodDate = new Date(now);
        
        switch (period) {
          case 'daily':
            periodDate.setDate(now.getDate() - i);
            break;
          case 'weekly':
            periodDate.setDate(now.getDate() - (i * 7));
            break;
          case 'monthly':
            periodDate.setMonth(now.getMonth() - i);
            break;
        }

        const { periodStart, periodEnd } = this.getPeriodDates(period, periodDate);
        
        const metric = await this.calculateSingleMetric(
          metricKey,
          {},
          periodStart,
          periodEnd
        );

        if (metric) {
          results.push(metric);
        }
      }

      // Calculate trend direction
      let trend = 'stable';
      if (results.length >= 2) {
        const recent = results[results.length - 1].value;
        const previous = results[results.length - 2].value;
        const change = ((recent - previous) / previous) * 100;
        
        if (change > 5) trend = 'increasing';
        else if (change < -5) trend = 'decreasing';
      }

      return {
        success: true,
        data: {
          metrics: results,
          trend,
          periodType: period,
          totalPeriods: periods
        }
      };
    } catch (error) {
      console.error('Error generating trend analysis:', error);
      return { success: false, error: 'Failed to generate trend analysis' };
    }
  }
}
