
import { PrismaClient } from '@prisma/client';
import { revalidatePath } from 'next/cache';

const prisma = new PrismaClient();

// Workflow Template Definitions
export interface WorkflowStageDefinition {
  key: string;
  name: string;
  description?: string;
  order: number;
  requiredDocuments?: string[];
  requiredTasks?: string[];
  checklist?: string[];
  estimatedDuration?: number; // in days
  assignedRole?: 'STAFF' | 'ADMIN' | 'CLIENT';
  autoAdvanceConditions?: {
    documentsApproved?: boolean;
    tasksCompleted?: boolean;
    customConditions?: string[];
  };
}

export interface WorkflowTemplateDefinition {
  name: string;
  description?: string;
  caseType: string;
  stages: WorkflowStageDefinition[];
}

// Predefined Immigration Workflow Templates
export const IMMIGRATION_TEMPLATES: Record<string, WorkflowTemplateDefinition> = {
  H1B: {
    name: 'H1B Visa Process',
    description: 'Standard H1B visa application workflow',
    caseType: 'H1B',
    stages: [
      {
        key: 'intake',
        name: 'Initial Intake',
        description: 'Client consultation and case assessment',
        order: 1,
        checklist: [
          'Initial consultation completed',
          'Fee agreement signed',
          'Client intake form completed'
        ],
        estimatedDuration: 3,
        assignedRole: 'STAFF'
      },
      {
        key: 'document_collection',
        name: 'Document Collection',
        description: 'Collect required documents from client',
        order: 2,
        requiredDocuments: ['passport', 'diploma', 'resume', 'job_offer'],
        checklist: [
          'All required documents received',
          'Document quality verified',
          'Translations obtained if needed'
        ],
        estimatedDuration: 14,
        assignedRole: 'STAFF'
      },
      {
        key: 'preparation',
        name: 'Application Preparation',
        description: 'Prepare and review petition forms',
        order: 3,
        requiredTasks: ['form_preparation', 'legal_review'],
        checklist: [
          'Form I-129 completed',
          'Supporting documentation compiled',
          'Legal review completed'
        ],
        estimatedDuration: 7,
        assignedRole: 'STAFF',
        autoAdvanceConditions: {
          tasksCompleted: true,
          documentsApproved: true
        }
      },
      {
        key: 'submission',
        name: 'USCIS Submission',
        description: 'Submit petition to USCIS',
        order: 4,
        checklist: [
          'Final review completed',
          'Filing fee paid',
          'Petition submitted to USCIS'
        ],
        estimatedDuration: 2,
        assignedRole: 'ADMIN'
      },
      {
        key: 'processing',
        name: 'USCIS Processing',
        description: 'Monitor USCIS processing and respond to RFEs',
        order: 5,
        checklist: [
          'Receipt notice received',
          'Case status monitored',
          'RFEs responded to (if applicable)'
        ],
        estimatedDuration: 90,
        assignedRole: 'STAFF'
      },
      {
        key: 'approval',
        name: 'Case Completion',
        description: 'Handle approval notice and next steps',
        order: 6,
        checklist: [
          'Approval notice received',
          'Client notified',
          'Next steps communicated'
        ],
        estimatedDuration: 1,
        assignedRole: 'STAFF'
      }
    ]
  },
  GREEN_CARD: {
    name: 'Green Card Application',
    description: 'Employment-based green card process',
    caseType: 'GREEN_CARD',
    stages: [
      {
        key: 'labor_certification',
        name: 'Labor Certification (PERM)',
        description: 'Department of Labor certification process',
        order: 1,
        estimatedDuration: 180,
        assignedRole: 'STAFF'
      },
      {
        key: 'i140_filing',
        name: 'I-140 Petition',
        description: 'File immigrant petition',
        order: 2,
        estimatedDuration: 120,
        assignedRole: 'STAFF'
      },
      {
        key: 'i485_filing',
        name: 'Adjustment of Status',
        description: 'File I-485 application',
        order: 3,
        estimatedDuration: 240,
        assignedRole: 'STAFF'
      }
    ]
  }
};

export class WorkflowEngine {
  
  // Create workflow template from definition
  static async createTemplate(
    definition: WorkflowTemplateDefinition,
    createdById: string
  ) {
    try {
      const template = await prisma.workflowTemplate.create({
        data: {
          name: definition.name,
          description: definition.description,
          caseType: definition.caseType,
          stages: definition.stages as any,
          createdById
        }
      });
      
      return { success: true, data: template };
    } catch (error) {
      console.error('Error creating workflow template:', error);
      return { success: false, error: 'Failed to create workflow template' };
    }
  }

  // Initialize workflow for a case
  static async initializeWorkflow(
    caseId: string,
    templateId: string
  ) {
    try {
      const template = await prisma.workflowTemplate.findUnique({
        where: { id: templateId }
      });

      if (!template) {
        return { success: false, error: 'Template not found' };
      }

      const stages = template.stages as any as WorkflowStageDefinition[];
      
      // Create workflow run
      const workflowRun = await prisma.workflowRun.create({
        data: {
          templateId,
          caseId,
          currentStage: stages[0]?.key,
          progress: 0
        }
      });

      // Create stage states for all stages
      const stageStates = await Promise.all(
        stages.map(stage => 
          prisma.workflowStageState.create({
            data: {
              workflowRunId: workflowRun.id,
              stageKey: stage.key,
              status: stage.key === stages[0]?.key ? 'in_progress' : 'pending',
              dueDate: stage.estimatedDuration ? 
                new Date(Date.now() + stage.estimatedDuration * 24 * 60 * 60 * 1000) : 
                undefined,
              checklist: stage.checklist || [],
              metadata: {
                stageName: stage.name,
                description: stage.description,
                order: stage.order,
                estimatedDuration: stage.estimatedDuration,
                assignedRole: stage.assignedRole
              }
            }
          })
        )
      );

      // Update case stage and status
      await prisma.case.update({
        where: { id: caseId },
        data: {
          stage: stages[0]?.name || 'Initial Stage',
          overallStatus: 'documents_pending'
        }
      });

      return { 
        success: true, 
        data: { workflowRun, stageStates }
      };
    } catch (error) {
      console.error('Error initializing workflow:', error);
      return { success: false, error: 'Failed to initialize workflow' };
    }
  }

  // Advance workflow to next stage
  static async advanceStage(
    workflowRunId: string,
    currentStageKey: string,
    userId: string,
    notes?: string
  ) {
    try {
      const workflowRun = await prisma.workflowRun.findUnique({
        where: { id: workflowRunId },
        include: {
          template: true,
          stageStates: true,
          case: true
        }
      });

      if (!workflowRun) {
        return { success: false, error: 'Workflow not found' };
      }

      const stages = workflowRun.template.stages as any as WorkflowStageDefinition[];
      const currentStageIndex = stages.findIndex(s => s.key === currentStageKey);
      const nextStageIndex = currentStageIndex + 1;

      if (nextStageIndex >= stages.length) {
        // Workflow complete
        await this.completeWorkflow(workflowRunId);
        return { success: true, data: { completed: true } };
      }

      const nextStage = stages[nextStageIndex];

      // Update current stage to completed
      await prisma.workflowStageState.updateMany({
        where: {
          workflowRunId,
          stageKey: currentStageKey
        },
        data: {
          status: 'completed',
          completedAt: new Date(),
          notes
        }
      });

      // Update next stage to in_progress
      await prisma.workflowStageState.updateMany({
        where: {
          workflowRunId,
          stageKey: nextStage.key
        },
        data: {
          status: 'in_progress',
          startedAt: new Date()
        }
      });

      // Calculate progress
      const progress = Math.round(((nextStageIndex) / stages.length) * 100);

      // Update workflow run
      await prisma.workflowRun.update({
        where: { id: workflowRunId },
        data: {
          currentStage: nextStage.key,
          progress
        }
      });

      // Update case
      await prisma.case.update({
        where: { id: workflowRun.caseId },
        data: {
          stage: nextStage.name,
          completionPercentage: progress
        }
      });

      // Create notification for stage transition
      await this.createStageNotification(
        workflowRunId,
        nextStage,
        'stage_advanced',
        userId
      );

      revalidatePath('/dashboard');
      revalidatePath(`/cases/${workflowRun.caseId}`);

      return { 
        success: true, 
        data: { 
          nextStage: nextStage.key,
          progress
        }
      };
    } catch (error) {
      console.error('Error advancing workflow stage:', error);
      return { success: false, error: 'Failed to advance workflow stage' };
    }
  }

  // Complete entire workflow
  static async completeWorkflow(workflowRunId: string) {
    try {
      const workflowRun = await prisma.workflowRun.update({
        where: { id: workflowRunId },
        data: {
          status: 'completed',
          progress: 100,
          completedAt: new Date()
        },
        include: { case: true }
      });

      // Update case to completed
      await prisma.case.update({
        where: { id: workflowRun.caseId },
        data: {
          overallStatus: 'approved',
          completionPercentage: 100,
          actualCompletionDate: new Date()
        }
      });

      return { success: true, data: workflowRun };
    } catch (error) {
      console.error('Error completing workflow:', error);
      return { success: false, error: 'Failed to complete workflow' };
    }
  }

  // Check if stage can auto-advance
  static async checkAutoAdvance(
    workflowRunId: string,
    stageKey: string
  ) {
    try {
      const workflowRun = await prisma.workflowRun.findUnique({
        where: { id: workflowRunId },
        include: {
          template: true,
          case: {
            include: {
              documents: true,
              tasks: true
            }
          }
        }
      });

      if (!workflowRun) return false;

      const stages = workflowRun.template.stages as any as WorkflowStageDefinition[];
      const stage = stages.find(s => s.key === stageKey);
      
      if (!stage?.autoAdvanceConditions) return false;

      const { documentsApproved, tasksCompleted } = stage.autoAdvanceConditions;

      // Check documents condition
      if (documentsApproved) {
        const pendingDocs = workflowRun.case.documents.filter(
          doc => doc.state !== 'approved'
        );
        if (pendingDocs.length > 0) return false;
      }

      // Check tasks condition
      if (tasksCompleted) {
        const pendingTasks = workflowRun.case.tasks.filter(
          task => task.status !== 'completed'
        );
        if (pendingTasks.length > 0) return false;
      }

      return true;
    } catch (error) {
      console.error('Error checking auto-advance:', error);
      return false;
    }
  }

  // Create stage notification
  private static async createStageNotification(
    workflowRunId: string,
    stage: WorkflowStageDefinition,
    type: string,
    userId: string
  ) {
    try {
      const workflowRun = await prisma.workflowRun.findUnique({
        where: { id: workflowRunId },
        include: {
          case: {
            include: {
              client: true,
              caseManager: true,
              lawyer: true
            }
          }
        }
      });

      if (!workflowRun) return;

      const recipients = [];
      if (workflowRun.case.clientId) recipients.push(workflowRun.case.clientId);
      if (workflowRun.case.caseManagerId) recipients.push(workflowRun.case.caseManagerId);
      if (workflowRun.case.lawyerId) recipients.push(workflowRun.case.lawyerId);

      // Create notifications for all recipients
      await Promise.all(
        recipients.map(recipientId =>
          prisma.notification.create({
            data: {
              title: `Stage Update: ${stage.name}`,
              message: `Case ${workflowRun.case.caseNumber} has advanced to ${stage.name}`,
              type: 'info',
              recipientId,
              senderId: userId,
              caseId: workflowRun.caseId,
              workflowRunId,
              actionUrl: `/cases/${workflowRun.caseId}`
            }
          })
        )
      );
    } catch (error) {
      console.error('Error creating stage notification:', error);
    }
  }

  // Get workflow status for a case
  static async getWorkflowStatus(caseId: string) {
    try {
      const workflowRun = await prisma.workflowRun.findUnique({
        where: { caseId },
        include: {
          template: true,
          stageStates: {
            orderBy: { createdAt: 'asc' }
          }
        }
      });

      if (!workflowRun) {
        return { success: false, error: 'No workflow found for this case' };
      }

      const stages = workflowRun.template.stages as any as WorkflowStageDefinition[];
      const stageStates = workflowRun.stageStates;

      const workflowStatus = {
        workflowRun,
        stages: stages.map(stage => ({
          ...stage,
          state: stageStates.find(state => state.stageKey === stage.key)
        })),
        progress: workflowRun.progress,
        currentStage: workflowRun.currentStage,
        status: workflowRun.status
      };

      return { success: true, data: workflowStatus };
    } catch (error) {
      console.error('Error getting workflow status:', error);
      return { success: false, error: 'Failed to get workflow status' };
    }
  }
}

// Initialize default workflow templates
export async function initializeDefaultTemplates(userId: string) {
  try {
    for (const [key, template] of Object.entries(IMMIGRATION_TEMPLATES)) {
      const existing = await prisma.workflowTemplate.findFirst({
        where: {
          caseType: template.caseType,
          name: template.name
        }
      });

      if (!existing) {
        await WorkflowEngine.createTemplate(template, userId);
      }
    }
    
    return { success: true };
  } catch (error) {
    console.error('Error initializing default templates:', error);
    return { success: false, error: 'Failed to initialize templates' };
  }
}
