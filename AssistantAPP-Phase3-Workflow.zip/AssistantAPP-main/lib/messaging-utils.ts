
import { PrismaClient, MessageType, Priority, NotificationType } from '@prisma/client';

const prisma = new PrismaClient();

export interface MessageData {
  body: string;
  messageType?: MessageType;
  priority?: Priority;
  isUrgent?: boolean;
  isInternal?: boolean;
  attachments?: string[];
  recipientIds?: string[];
  parentMessageId?: string;
}

export interface MessageThread {
  id: string;
  subject: string;
  participants: string[];
  messageCount: number;
  lastMessage: Date;
  isRead: boolean;
}

export class MessagingUtils {
  /**
   * Send a message
   */
  static async sendMessage(
    caseId: string,
    senderId: string,
    messageData: MessageData
  ) {
    const message = await prisma.message.create({
      data: {
        body: messageData.body,
        messageType: messageData.messageType || 'note',
        priority: messageData.priority || 'normal',
        isUrgent: messageData.isUrgent || false,
        isInternal: messageData.isInternal ?? true,
        attachments: messageData.attachments || [],
        recipientIds: messageData.recipientIds || [],
        parentMessageId: messageData.parentMessageId,
        senderId,
        caseId,
        status: 'unread'
      },
      include: {
        sender: { select: { name: true, email: true } },
        case: { select: { caseNumber: true, title: true } }
      }
    });

    // Create notifications for recipients
    if (messageData.recipientIds?.length) {
      await this.createMessageNotifications(message, messageData.recipientIds);
    }

    return message;
  }

  /**
   * Get messages for a case
   */
  static async getCaseMessages(
    caseId: string,
    options: {
      isInternal?: boolean;
      messageType?: MessageType;
      limit?: number;
      offset?: number;
      threadId?: string;
    } = {}
  ) {
    const where: any = { caseId };

    if (options.isInternal !== undefined) {
      where.isInternal = options.isInternal;
    }

    if (options.messageType) {
      where.messageType = options.messageType;
    }

    if (options.threadId) {
      where.threadId = options.threadId;
    }

    const messages = await prisma.message.findMany({
      where,
      include: {
        sender: { select: { name: true, email: true, avatar: true } },
        replies: {
          include: {
            sender: { select: { name: true, email: true, avatar: true } }
          },
          orderBy: { createdAt: 'asc' }
        }
      },
      orderBy: { createdAt: 'desc' },
      take: options.limit || 50,
      skip: options.offset || 0
    });

    return messages;
  }

  /**
   * Get message threads for a case
   */
  static async getMessageThreads(caseId: string): Promise<MessageThread[]> {
    const messages = await prisma.message.findMany({
      where: {
        caseId,
        parentMessageId: null // Only root messages
      },
      include: {
        replies: true,
        sender: { select: { name: true } }
      },
      orderBy: { createdAt: 'desc' }
    });

    return messages.map((message: any) => {
      const allMessages = [message, ...message.replies];
      const participants = [...new Set(allMessages.map((m: any) => m.senderId))];
      const lastMessage = allMessages.reduce((latest: any, current: any) => 
        current.createdAt > latest.createdAt ? current : latest
      );

      return {
        id: message.id,
        subject: message.body.substring(0, 50) + (message.body.length > 50 ? '...' : ''),
        participants,
        messageCount: allMessages.length,
        lastMessage: lastMessage.createdAt,
        isRead: message.status === 'read'
      };
    });
  }

  /**
   * Mark message as read
   */
  static async markAsRead(messageId: string, userId: string) {
    const message = await prisma.message.findUnique({
      where: { id: messageId }
    });

    if (!message) return false;

    // Update read status
    const readBy = (message.readBy as any) || {};
    readBy[userId] = new Date().toISOString();

    await prisma.message.update({
      where: { id: messageId },
      data: {
        status: 'read',
        readBy
      }
    });

    return true;
  }

  /**
   * Get unread message count for a user
   */
  static async getUnreadCount(userId: string, caseId?: string) {
    const where: any = {
      OR: [
        { recipientIds: { path: '$', array_contains: userId } },
        { isInternal: false } // All external messages are visible to staff
      ],
      status: 'unread'
    };

    if (caseId) {
      where.caseId = caseId;
    }

    return prisma.message.count({ where });
  }

  /**
   * Create notifications for message recipients
   */
  private static async createMessageNotifications(message: any, recipientIds: string[]) {
    const notifications = recipientIds.map((recipientId: string) => ({
      title: `New message from ${message.sender.name}`,
      message: message.body.substring(0, 100) + (message.body.length > 100 ? '...' : ''),
      type: (message.isUrgent ? 'alert' : 'info') as NotificationType,
      priority: message.priority,
      recipientId,
      senderId: message.senderId,
      caseId: message.caseId,
      actionUrl: `/cases/${message.caseId}/messages/${message.id}`
    }));

    await prisma.notification.createMany({
      data: notifications
    });
  }

  /**
   * Search messages
   */
  static async searchMessages(
    query: string,
    options: {
      caseId?: string;
      userId?: string;
      messageType?: MessageType;
      isInternal?: boolean;
      limit?: number;
    } = {}
  ) {
    const where: any = {
      body: { contains: query, mode: 'insensitive' }
    };

    if (options.caseId) {
      where.caseId = options.caseId;
    }

    if (options.userId) {
      where.OR = [
        { senderId: options.userId },
        { recipientIds: { path: '$', array_contains: options.userId } }
      ];
    }

    if (options.messageType) {
      where.messageType = options.messageType;
    }

    if (options.isInternal !== undefined) {
      where.isInternal = options.isInternal;
    }

    return prisma.message.findMany({
      where,
      include: {
        sender: { select: { name: true, email: true } },
        case: { select: { caseNumber: true, title: true } }
      },
      orderBy: { createdAt: 'desc' },
      take: options.limit || 20
    });
  }

  /**
   * Get message analytics
   */
  static async getMessageAnalytics(
    startDate: Date,
    endDate: Date,
    caseId?: string
  ) {
    const where: any = {
      createdAt: {
        gte: startDate,
        lte: endDate
      }
    };

    if (caseId) {
      where.caseId = caseId;
    }

    const [totalMessages, internalMessages, externalMessages, urgentMessages] = await Promise.all([
      prisma.message.count({ where }),
      prisma.message.count({ where: { ...where, isInternal: true } }),
      prisma.message.count({ where: { ...where, isInternal: false } }),
      prisma.message.count({ where: { ...where, isUrgent: true } })
    ]);

    const messagesByType = await prisma.message.groupBy({
      by: ['messageType'],
      where,
      _count: { id: true }
    });

    const messagesByDay = await prisma.message.groupBy({
      by: ['createdAt'],
      where,
      _count: { id: true },
      orderBy: { createdAt: 'asc' }
    });

    // Group by day for chart data
    const dailyData = messagesByDay.reduce((acc: any, item: any) => {
      const date = new Date(item.createdAt).toISOString().split('T')[0];
      acc[date] = (acc[date] || 0) + item._count.id;
      return acc;
    }, {});

    return {
      totalMessages,
      internalMessages,
      externalMessages,
      urgentMessages,
      messagesByType: messagesByType.map((item: any) => ({
        type: item.messageType,
        count: item._count.id
      })),
      dailyData: Object.entries(dailyData).map(([date, count]) => ({
        date,
        count
      }))
    };
  }
}
