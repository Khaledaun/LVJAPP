
import { PrismaClient, ReportType, ReportFormat } from '@prisma/client';

const prisma = new PrismaClient();

export interface ReportData {
  title: string;
  description?: string;
  generatedAt: Date;
  parameters: any;
  data: any[];
  summary?: any;
  charts?: any[];
  [key: string]: any;
}

export interface ReportParameters {
  startDate?: Date;
  endDate?: Date;
  caseId?: string;
  clientId?: string;
  userId?: string;
  status?: string;
  caseType?: string;
  filters?: Record<string, any>;
  groupBy?: string;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  limit?: number;
}

export class ReportEngine {
  /**
   * Generate case analytics report
   */
  static async generateCaseAnalyticsReport(parameters: ReportParameters): Promise<ReportData> {
    const { startDate, endDate, caseType, status } = parameters;
    
    const where: any = {};
    
    if (startDate && endDate) {
      where.createdAt = { gte: startDate, lte: endDate };
    }
    
    if (caseType) {
      where.caseType = caseType;
    }
    
    if (status) {
      where.overallStatus = status;
    }

    const cases = await prisma.case.findMany({
      where,
      include: {
        client: { select: { name: true, email: true } },
        caseManager: { select: { name: true } },
        lawyer: { select: { name: true } },
        tasks: true,
        documents: true,
        timeEntries: true
      },
      orderBy: { createdAt: 'desc' }
    });

    // Calculate summary statistics
    const totalCases = cases.length;
    const completedCases = cases.filter(c => c.overallStatus === 'approved').length;
    const activeCases = cases.filter(c => ['new', 'documents_pending', 'in_review', 'submitted'].includes(c.overallStatus)).length;
    const averageCompletionTime = this.calculateAverageCompletionTime(cases.filter(c => c.actualCompletionDate));

    // Group by case type
    const casesByType = cases.reduce((acc: any, caseItem) => {
      const type = caseItem.caseType || 'Unknown';
      if (!acc[type]) acc[type] = 0;
      acc[type]++;
      return acc;
    }, {});

    // Group by status
    const casesByStatus = cases.reduce((acc: any, caseItem) => {
      const status = caseItem.overallStatus;
      if (!acc[status]) acc[status] = 0;
      acc[status]++;
      return acc;
    }, {});

    const reportData: ReportData = {
      title: 'Case Analytics Report',
      description: 'Comprehensive analysis of case performance and metrics',
      generatedAt: new Date(),
      parameters,
      data: cases.map(c => ({
        id: c.id,
        caseNumber: c.caseNumber,
        title: c.title,
        caseType: c.caseType,
        status: c.overallStatus,
        clientName: c.client?.name,
        caseManager: c.caseManager?.name,
        lawyer: c.lawyer?.name,
        createdAt: c.createdAt,
        completionPercentage: c.completionPercentage,
        totalFee: c.totalFee,
        taskCount: c.tasks?.length || 0,
        documentCount: c.documents?.length || 0,
        timeEntries: c.timeEntries?.length || 0
      })),
      summary: {
        totalCases,
        completedCases,
        activeCases,
        completionRate: totalCases > 0 ? (completedCases / totalCases) * 100 : 0,
        averageCompletionTime,
        casesByType,
        casesByStatus
      },
      charts: [
        {
          type: 'pie',
          title: 'Cases by Type',
          data: Object.entries(casesByType).map(([type, count]) => ({ name: type, value: count }))
        },
        {
          type: 'bar',
          title: 'Cases by Status',
          data: Object.entries(casesByStatus).map(([status, count]) => ({ name: status, value: count }))
        }
      ]
    };

    return reportData;
  }

  /**
   * Generate productivity report
   */
  static async generateProductivityReport(parameters: ReportParameters): Promise<ReportData> {
    const { startDate, endDate, userId } = parameters;
    
    const where: any = {};
    
    if (startDate && endDate) {
      where.startedAt = { gte: startDate, lte: endDate };
    }
    
    if (userId) {
      where.userId = userId;
    }

    const timeEntries = await prisma.timeEntry.findMany({
      where,
      include: {
        user: { select: { name: true, role: true } },
        case: { select: { caseNumber: true, title: true } },
        task: { select: { title: true } }
      },
      orderBy: { startedAt: 'desc' }
    });

    // Calculate productivity metrics
    const totalHours = timeEntries.reduce((sum, entry) => sum + entry.duration, 0) / 60;
    const billableHours = timeEntries.filter(e => e.isBillable).reduce((sum, entry) => sum + entry.duration, 0) / 60;
    const billableRate = totalHours > 0 ? (billableHours / totalHours) * 100 : 0;

    // Group by user
    const productivityByUser = timeEntries.reduce((acc: any, entry) => {
      const userId = entry.userId;
      const userName = entry.user?.name || 'Unknown';
      
      if (!acc[userId]) {
        acc[userId] = {
          name: userName,
          totalHours: 0,
          billableHours: 0,
          entries: 0
        };
      }
      
      acc[userId].totalHours += entry.duration / 60;
      if (entry.isBillable) {
        acc[userId].billableHours += entry.duration / 60;
      }
      acc[userId].entries++;
      
      return acc;
    }, {});

    // Group by category
    const hoursByCategory = timeEntries.reduce((acc: any, entry) => {
      const category = entry.category || 'General';
      if (!acc[category]) acc[category] = 0;
      acc[category] += entry.duration / 60;
      return acc;
    }, {});

    const reportData: ReportData = {
      title: 'Productivity Report',
      description: 'Analysis of time tracking and productivity metrics',
      generatedAt: new Date(),
      parameters,
      data: timeEntries.map(entry => ({
        id: entry.id,
        description: entry.description,
        duration: entry.duration / 60, // Convert to hours
        isBillable: entry.isBillable,
        category: entry.category,
        userName: entry.user?.name,
        caseNumber: entry.case?.caseNumber,
        taskTitle: entry.task?.title,
        startedAt: entry.startedAt,
        endedAt: entry.endedAt
      })),
      summary: {
        totalHours: Math.round(totalHours * 100) / 100,
        billableHours: Math.round(billableHours * 100) / 100,
        nonBillableHours: Math.round((totalHours - billableHours) * 100) / 100,
        billableRate: Math.round(billableRate * 100) / 100,
        totalEntries: timeEntries.length,
        productivityByUser: Object.values(productivityByUser),
        hoursByCategory
      },
      charts: [
        {
          type: 'pie',
          title: 'Billable vs Non-Billable Hours',
          data: [
            { name: 'Billable', value: Math.round(billableHours * 100) / 100 },
            { name: 'Non-Billable', value: Math.round((totalHours - billableHours) * 100) / 100 }
          ]
        },
        {
          type: 'bar',
          title: 'Hours by Category',
          data: Object.entries(hoursByCategory).map(([category, hours]) => ({ 
            name: category, 
            value: Math.round((hours as number) * 100) / 100 
          }))
        }
      ]
    };

    return reportData;
  }

  /**
   * Generate billing report
   */
  static async generateBillingReport(parameters: ReportParameters): Promise<ReportData> {
    const { startDate, endDate, clientId } = parameters;
    
    const where: any = {};
    
    if (startDate && endDate) {
      where.createdAt = { gte: startDate, lte: endDate };
    }
    
    if (clientId) {
      where.clientId = clientId;
    }

    const invoices = await prisma.invoice.findMany({
      where,
      include: {
        client: { select: { name: true, email: true } },
        case: { select: { caseNumber: true, title: true } },
        items: true,
        paymentRecords: true
      },
      orderBy: { createdAt: 'desc' }
    });

    // Calculate billing metrics
    const totalInvoiced = invoices.reduce((sum, inv) => sum + Number(inv.totalAmount), 0);
    const totalPaid = invoices.reduce((sum, inv) => {
      const paid = inv.paymentRecords
        .filter(p => p.status === 'completed')
        .reduce((pSum, p) => pSum + Number(p.amount), 0);
      return sum + paid;
    }, 0);
    const totalOutstanding = totalInvoiced - totalPaid;

    // Group by status
    const invoicesByStatus = invoices.reduce((acc: any, inv) => {
      const status = inv.status;
      if (!acc[status]) acc[status] = { count: 0, amount: 0 };
      acc[status].count++;
      acc[status].amount += Number(inv.totalAmount);
      return acc;
    }, {});

    // Monthly revenue
    const monthlyRevenue = invoices.reduce((acc: any, inv) => {
      const month = inv.createdAt.toISOString().substring(0, 7); // YYYY-MM
      if (!acc[month]) acc[month] = 0;
      acc[month] += Number(inv.totalAmount);
      return acc;
    }, {});

    const reportData: ReportData = {
      title: 'Billing Report',
      description: 'Financial performance and billing analysis',
      generatedAt: new Date(),
      parameters,
      data: invoices.map(inv => ({
        id: inv.id,
        invoiceNumber: inv.invoiceNumber,
        title: inv.title,
        clientName: inv.client?.name,
        caseNumber: inv.case?.caseNumber,
        subtotal: Number(inv.subtotal),
        taxAmount: Number(inv.taxAmount),
        totalAmount: Number(inv.totalAmount),
        status: inv.status,
        issuedAt: inv.issuedAt,
        dueDate: inv.dueDate,
        paidAt: inv.paidAt,
        itemCount: inv.items?.length || 0,
        paymentCount: inv.paymentRecords?.length || 0
      })),
      summary: {
        totalInvoiced: Math.round(totalInvoiced * 100) / 100,
        totalPaid: Math.round(totalPaid * 100) / 100,
        totalOutstanding: Math.round(totalOutstanding * 100) / 100,
        collectionRate: totalInvoiced > 0 ? (totalPaid / totalInvoiced) * 100 : 0,
        invoiceCount: invoices.length,
        averageInvoiceAmount: invoices.length > 0 ? totalInvoiced / invoices.length : 0,
        invoicesByStatus,
        monthlyRevenue
      },
      charts: [
        {
          type: 'pie',
          title: 'Revenue by Invoice Status',
          data: Object.entries(invoicesByStatus).map(([status, data]: [string, any]) => ({ 
            name: status, 
            value: Math.round(data.amount * 100) / 100 
          }))
        },
        {
          type: 'line',
          title: 'Monthly Revenue Trend',
          data: Object.entries(monthlyRevenue).map(([month, amount]) => ({ 
            name: month, 
            value: Math.round((amount as number) * 100) / 100 
          }))
        }
      ]
    };

    return reportData;
  }

  /**
   * Generate and save report
   */
  static async generateReport(
    templateId: string,
    parameters: ReportParameters,
    generatedById: string,
    format: ReportFormat = 'pdf'
  ) {
    const template = await prisma.reportTemplate.findUnique({
      where: { id: templateId }
    });

    if (!template) {
      throw new Error('Report template not found');
    }

    let reportData: ReportData;

    // Generate report based on type
    switch (template.type) {
      case 'case_analytics':
        reportData = await this.generateCaseAnalyticsReport(parameters);
        break;
      case 'productivity':
        reportData = await this.generateProductivityReport(parameters);
        break;
      case 'billing':
        reportData = await this.generateBillingReport(parameters);
        break;
      default:
        throw new Error(`Unsupported report type: ${template.type}`);
    }

    // Create generated report record
    const generatedReport = await prisma.generatedReport.create({
      data: {
        templateId,
        title: reportData.title,
        description: reportData.description,
        status: 'generating',
        format,
        parameters: parameters as any,
        generatedById,
        metadata: {
          reportData: reportData as any
        }
      }
    });

    // TODO: Generate actual file (PDF, Excel, etc.)
    // For now, just mark as completed
    const updatedReport = await prisma.generatedReport.update({
      where: { id: generatedReport.id },
      data: {
        status: 'completed',
        completedAt: new Date(),
        fileUrl: `/reports/${generatedReport.id}.${format}`,
        fileSize: JSON.stringify(reportData).length // Approximate size
      }
    });

    return updatedReport;
  }

  /**
   * Calculate average completion time for cases
   */
  private static calculateAverageCompletionTime(completedCases: any[]): number {
    if (completedCases.length === 0) return 0;

    const totalDays = completedCases.reduce((sum, caseItem) => {
      const start = new Date(caseItem.createdAt);
      const end = new Date(caseItem.actualCompletionDate);
      const days = (end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24);
      return sum + days;
    }, 0);

    return Math.round(totalDays / completedCases.length);
  }

  /**
   * Get available report templates
   */
  static async getReportTemplates(isPublic?: boolean) {
    const where: any = {};
    
    if (isPublic !== undefined) {
      where.isPublic = isPublic;
    }

    return prisma.reportTemplate.findMany({
      where,
      include: {
        createdBy: { select: { name: true } },
        _count: { select: { reports: true } }
      },
      orderBy: { name: 'asc' }
    });
  }

  /**
   * Export report data to different formats
   */
  static async exportReport(reportId: string, format: ReportFormat) {
    const report = await prisma.generatedReport.findUnique({
      where: { id: reportId },
      include: { template: true }
    });

    if (!report) {
      throw new Error('Report not found');
    }

    const reportData = (report.metadata as any)?.reportData;
    if (!reportData) {
      throw new Error('Report data not available');
    }

    switch (format) {
      case 'json':
        return JSON.stringify(reportData, null, 2);
      case 'csv':
        return this.convertToCSV(reportData.data);
      case 'excel':
        // TODO: Implement Excel export
        throw new Error('Excel export not implemented yet');
      case 'pdf':
        // TODO: Implement PDF export
        throw new Error('PDF export not implemented yet');
      default:
        throw new Error(`Unsupported export format: ${format}`);
    }
  }

  /**
   * Convert data to CSV format
   */
  private static convertToCSV(data: any[]): string {
    if (!data || data.length === 0) return '';

    const headers = Object.keys(data[0]);
    const csvRows = [headers.join(',')];

    for (const row of data) {
      const values = headers.map(header => {
        const value = row[header];
        return typeof value === 'string' ? `"${value.replace(/"/g, '""')}"` : value;
      });
      csvRows.push(values.join(','));
    }

    return csvRows.join('\n');
  }
}
