
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Bell, BellRing, CheckCircle, AlertTriangle, 
  Info, AlertCircle, Trash2, Check,
  Filter, RefreshCw, Archive
} from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'error' | 'success' | 'reminder' | 'alert' | 'system';
  priority: 'low' | 'normal' | 'high' | 'urgent' | 'critical';
  status: 'unread' | 'read' | 'dismissed' | 'expired';
  createdAt: string;
  readAt?: string;
  actionUrl?: string;
  sender?: {
    name: string;
  };
  case?: {
    caseNumber: string;
    title: string;
  };
  task?: {
    title: string;
  };
  document?: {
    name: string;
  };
}

interface NotificationCounts {
  unread: number;
  urgent: number;
  total: number;
}

interface NotificationCenterProps {
  className?: string;
  compact?: boolean;
}

export default function NotificationCenter({ className, compact = false }: NotificationCenterProps) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [counts, setCounts] = useState<NotificationCounts>({ unread: 0, urgent: 0, total: 0 });
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');

  useEffect(() => {
    loadNotifications();
    loadCounts();
  }, [filter, typeFilter]);

  const loadNotifications = async () => {
    try {
      setLoading(true);
      
      const params = new URLSearchParams();
      if (filter !== 'all') params.append('status', filter);
      if (typeFilter !== 'all') params.append('type', typeFilter);
      params.append('limit', compact ? '5' : '50');

      const response = await fetch(`/api/notifications?${params.toString()}`);
      if (response.ok) {
        const result = await response.json();
        if (result.success) {
          setNotifications(result.data?.notifications || []);
        }
      }
    } catch (error) {
      console.error('Error loading notifications:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadCounts = async () => {
    try {
      const response = await fetch('/api/notifications/counts');
      if (response.ok) {
        const result = await response.json();
        if (result.success) {
          setCounts(result.data);
        }
      }
    } catch (error) {
      console.error('Error loading notification counts:', error);
    }
  };

  const markAsRead = async (notificationId: string) => {
    try {
      const response = await fetch(`/api/notifications/${notificationId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' }
      });

      if (response.ok) {
        setNotifications(prev => 
          prev.map(n => n.id === notificationId ? { ...n, status: 'read', readAt: new Date().toISOString() } : n)
        );
        loadCounts(); // Refresh counts
      }
    } catch (error) {
      console.error('Error marking notification as read:', error);
    }
  };

  const markAllAsRead = async () => {
    try {
      const response = await fetch('/api/notifications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'mark_all_read' })
      });

      if (response.ok) {
        loadNotifications();
        loadCounts();
      }
    } catch (error) {
      console.error('Error marking all as read:', error);
    }
  };

  const getNotificationIcon = (type: string, priority: string) => {
    const urgentColor = priority === 'urgent' || priority === 'critical' ? 'text-red-500' : '';
    
    switch (type) {
      case 'success':
        return <CheckCircle className={`h-4 w-4 text-green-500 ${urgentColor}`} />;
      case 'warning':
        return <AlertTriangle className={`h-4 w-4 text-yellow-500 ${urgentColor}`} />;
      case 'error':
      case 'alert':
        return <AlertCircle className={`h-4 w-4 text-red-500 ${urgentColor}`} />;
      case 'reminder':
        return <Bell className={`h-4 w-4 text-blue-500 ${urgentColor}`} />;
      default:
        return <Info className={`h-4 w-4 text-blue-500 ${urgentColor}`} />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-200';
      case 'urgent': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'high': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'normal': return 'bg-blue-100 text-blue-800 border-blue-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const handleNotificationClick = (notification: Notification) => {
    if (notification.status === 'unread') {
      markAsRead(notification.id);
    }
    
    if (notification.actionUrl) {
      window.location.href = notification.actionUrl;
    }
  };

  if (compact) {
    return (
      <Card className={className}>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">Notifications</CardTitle>
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="text-xs">
                {counts.unread} new
              </Badge>
              <Button variant="ghost" size="sm" onClick={loadNotifications}>
                <RefreshCw className="h-3 w-3" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <ScrollArea className="h-64">
            {loading ? (
              <div className="space-y-2 p-4">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="flex items-start space-x-3">
                    <Skeleton className="h-4 w-4 rounded-full" />
                    <div className="space-y-1 flex-1">
                      <Skeleton className="h-3 w-32" />
                      <Skeleton className="h-2 w-full" />
                    </div>
                  </div>
                ))}
              </div>
            ) : notifications.length === 0 ? (
              <div className="p-4 text-center text-gray-500">
                <Bell className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">No notifications</p>
              </div>
            ) : (
              <div className="space-y-1">
                {notifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={`p-3 hover:bg-gray-50 cursor-pointer border-l-2 ${
                      notification.status === 'unread' 
                        ? 'bg-blue-50 border-l-blue-500' 
                        : 'border-l-transparent'
                    }`}
                    onClick={() => handleNotificationClick(notification)}
                  >
                    <div className="flex items-start space-x-2">
                      {getNotificationIcon(notification.type, notification.priority)}
                      <div className="flex-1 min-w-0">
                        <p className={`text-sm font-medium truncate ${
                          notification.status === 'unread' ? 'text-gray-900' : 'text-gray-600'
                        }`}>
                          {notification.title}
                        </p>
                        <p className="text-xs text-gray-500 line-clamp-2">
                          {notification.message}
                        </p>
                        <p className="text-xs text-gray-400 mt-1">
                          {new Date(notification.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <BellRing className="h-6 w-6" />
            Notifications
          </h1>
          <p className="text-gray-600">
            {counts.unread} unread • {counts.urgent} urgent • {counts.total} total
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" onClick={loadNotifications}>
            <RefreshCw className="h-4 w-4 mr-1" />
            Refresh
          </Button>
          <Button variant="outline" onClick={markAllAsRead} disabled={counts.unread === 0}>
            <CheckCircle className="h-4 w-4 mr-1" />
            Mark All Read
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-gray-500" />
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="unread">Unread</SelectItem>
              <SelectItem value="read">Read</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="info">Info</SelectItem>
            <SelectItem value="warning">Warning</SelectItem>
            <SelectItem value="error">Error</SelectItem>
            <SelectItem value="success">Success</SelectItem>
            <SelectItem value="reminder">Reminder</SelectItem>
            <SelectItem value="alert">Alert</SelectItem>
            <SelectItem value="system">System</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Notifications List */}
      {loading ? (
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-4">
                <div className="flex items-start space-x-4">
                  <Skeleton className="h-4 w-4 rounded-full" />
                  <div className="space-y-2 flex-1">
                    <Skeleton className="h-4 w-48" />
                    <Skeleton className="h-3 w-full" />
                    <Skeleton className="h-3 w-32" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : notifications.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Bell className="h-16 w-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No notifications</h3>
            <p className="text-gray-500">You're all caught up! Check back later for updates.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {notifications.map((notification) => (
            <Card 
              key={notification.id} 
              className={`transition-all duration-200 hover:shadow-md cursor-pointer ${
                notification.status === 'unread' ? 'ring-1 ring-blue-200 bg-blue-50/50' : ''
              }`}
              onClick={() => handleNotificationClick(notification)}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between space-x-4">
                  <div className="flex items-start space-x-3 flex-1">
                    {getNotificationIcon(notification.type, notification.priority)}
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className={`font-medium ${
                          notification.status === 'unread' ? 'text-gray-900' : 'text-gray-700'
                        }`}>
                          {notification.title}
                        </h4>
                        
                        <Badge 
                          className={`${getPriorityColor(notification.priority)} text-xs`}
                        >
                          {notification.priority}
                        </Badge>
                        
                        {notification.status === 'unread' && (
                          <div className="h-2 w-2 bg-blue-500 rounded-full"></div>
                        )}
                      </div>
                      
                      <p className="text-sm text-gray-600 mb-2">{notification.message}</p>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4 text-xs text-gray-500">
                          <span>{new Date(notification.createdAt).toLocaleDateString()}</span>
                          
                          {notification.sender && (
                            <span>From: {notification.sender.name}</span>
                          )}
                          
                          {notification.case && (
                            <span>Case: {notification.case.caseNumber}</span>
                          )}
                          
                          {notification.task && (
                            <span>Task: {notification.task.title}</span>
                          )}
                          
                          {notification.document && (
                            <span>Doc: {notification.document.name}</span>
                          )}
                        </div>
                        
                        {notification.readAt && (
                          <span className="text-xs text-gray-400">
                            Read {new Date(notification.readAt).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-1">
                    {notification.status === 'unread' && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          markAsRead(notification.id);
                        }}
                      >
                        <Check className="h-3 w-3" />
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
