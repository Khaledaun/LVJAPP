'use client'

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Plus, 
  Users, 
  FileText, 
  DollarSign, 
  Clock, 
  CheckCircle, 
  AlertTriangle,
  Calendar,
  MessageSquare,
  TrendingUp,
  Activity,
} from 'lucide-react';
import Link from 'next/link';
import { Skeleton } from '@/components/ui/skeleton';

interface DashboardStats {
  cases: {
    total: number
    active: number
    completed: number
    overdue: number
  }
  tasks: {
    total: number
    pending: number
    inProgress: number
    completed: number
    overdue: number
    completionRate: number
  }
  documents: {
    total: number
    uploaded: number
    approved: number
    pending: number
  }
  messages: {
    total: number
    unread: number
    urgent: number
  }
}

interface RecentItem {
  id: string
  type: 'case' | 'task' | 'document' | 'message'
  title: string
  subtitle?: string
  status?: string
  priority?: string
  dueDate?: string
  updatedAt: string
}

export default function DashboardPage() {
  const { data: session, status } = useSession();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentItems, setRecentItems] = useState<RecentItem[]>([]);
  const [upcomingTasks, setUpcomingTasks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (status === 'loading') return;
    if (!session) return;

    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        
        // Fetch stats from various endpoints
        const [casesRes, tasksRes, messagesRes] = await Promise.all([
          fetch('/api/cases?page=1&limit=100'),
          fetch('/api/tasks/stats'),
          fetch('/api/messages?page=1&limit=10'),
        ]);

        const dashboardStats: DashboardStats = {
          cases: { total: 0, active: 0, completed: 0, overdue: 0 },
          tasks: { total: 0, pending: 0, inProgress: 0, completed: 0, overdue: 0, completionRate: 0 },
          documents: { total: 0, uploaded: 0, approved: 0, pending: 0 },
          messages: { total: 0, unread: 0, urgent: 0 },
        };

        // Process cases data
        if (casesRes.ok) {
          const casesData = await casesRes.json();
          const cases = casesData.cases || [];
          dashboardStats.cases.total = cases.length;
          dashboardStats.cases.active = cases.filter((c: any) => 
            !['approved', 'denied'].includes(c.overallStatus)
          ).length;
          dashboardStats.cases.completed = cases.filter((c: any) => 
            ['approved', 'denied'].includes(c.overallStatus)
          ).length;
        }

        // Process tasks data
        if (tasksRes.ok) {
          const tasksData = await tasksRes.json();
          if (tasksData.stats?.overview) {
            dashboardStats.tasks = tasksData.stats.overview;
          }
        }

        // Process recent messages
        if (messagesRes.ok) {
          const messagesData = await messagesRes.json();
          const messages = messagesData.messages || [];
          dashboardStats.messages.total = messages.length;
          dashboardStats.messages.unread = messages.filter((m: any) => 
            m.status === 'unread'
          ).length;
          dashboardStats.messages.urgent = messages.filter((m: any) => 
            m.isUrgent
          ).length;
        }

        setStats(dashboardStats);

        // Fetch recent activities (simplified)
        const recent: RecentItem[] = [];
        if (casesRes.ok) {
          const casesData = await casesRes.json();
          const recentCases = (casesData.cases || []).slice(0, 3);
          recent.push(...recentCases.map((c: any) => ({
            id: c.id,
            type: 'case' as const,
            title: c.title || `Case ${c.caseNumber}`,
            subtitle: c.applicantName,
            status: c.overallStatus,
            updatedAt: c.updatedAt,
          })));
        }

        setRecentItems(recent);
      } catch (error) {
        console.error('Failed to fetch dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, [session, status]);

  const getStatusColor = (status: string, type: string = 'case') => {
    if (type === 'case') {
      switch (status) {
        case 'approved':
          return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
        case 'in_review':
          return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
        case 'new':
        case 'documents_pending':
          return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
        case 'denied':
          return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
        default:
          return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
      }
    }
    return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString();
  };

  if (status === 'loading' || loading) {
    return <DashboardSkeleton />;
  }

  if (!session) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Welcome to LVJ Case Assistant</h2>
          <p className="text-muted-foreground mb-6">Please sign in to access your dashboard.</p>
          <Button asChild>
            <Link href="/signin">Sign In</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 space-y-6 p-4 md:p-8 pt-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Welcome back!</h2>
          <p className="text-muted-foreground">
            Here's what's happening with your cases and tasks today.
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Button asChild>
            <Link href="/cases/new">
              <Plus className="mr-2 h-4 w-4" />
              New Case
            </Link>
          </Button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Cases</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.cases.total ?? 0}</div>
            <p className="text-xs text-muted-foreground">
              {stats?.cases.active ?? 0} active, {stats?.cases.completed ?? 0} completed
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tasks</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.tasks.total ?? 0}</div>
            <p className="text-xs text-muted-foreground">
              {stats?.tasks.completionRate ?? 0}% completion rate
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overdue Items</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {(stats?.tasks.overdue ?? 0) + (stats?.cases.overdue ?? 0)}
            </div>
            <p className="text-xs text-muted-foreground">
              {stats?.tasks.overdue ?? 0} tasks, {stats?.cases.overdue ?? 0} cases
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Messages</CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.messages.unread ?? 0}</div>
            <p className="text-xs text-muted-foreground">
              Unread messages
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="tasks">Tasks</TabsTrigger>
          <TabsTrigger value="cases">Cases</TabsTrigger>
          <TabsTrigger value="activity">Activity</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
            {/* Recent Activity */}
            <Card className="col-span-4">
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>
                  Latest updates across your cases and tasks
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentItems.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Activity className="mx-auto h-8 w-8 mb-2 opacity-50" />
                      <p>No recent activity</p>
                    </div>
                  ) : (
                    recentItems.map((item) => (
                      <div key={`${item.type}-${item.id}`} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="space-y-1">
                          <p className="font-medium">{item.title}</p>
                          {item.subtitle && (
                            <p className="text-sm text-muted-foreground">{item.subtitle}</p>
                          )}
                          <p className="text-xs text-muted-foreground">
                            {formatDate(item.updatedAt)}
                          </p>
                        </div>
                        <div className="text-right space-y-1">
                          {item.status && (
                            <Badge className={getStatusColor(item.status, item.type)}>
                              {item.status.replace('_', ' ')}
                            </Badge>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
                <div className="mt-4 flex space-x-2">
                  <Button variant="outline" asChild className="flex-1">
                    <Link href="/cases">View All Cases</Link>
                  </Button>
                  <Button variant="outline" asChild className="flex-1">
                    <Link href="/tasks">View All Tasks</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="col-span-3">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>
                  Common tasks and shortcuts
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button asChild className="w-full justify-start">
                  <Link href="/cases/new">
                    <Plus className="mr-2 h-4 w-4" />
                    New Case
                  </Link>
                </Button>
                <Button variant="outline" asChild className="w-full justify-start">
                  <Link href="/tasks">
                    <Calendar className="mr-2 h-4 w-4" />
                    View Tasks
                  </Link>
                </Button>
                <Button variant="outline" asChild className="w-full justify-start">
                  <Link href="/messages">
                    <MessageSquare className="mr-2 h-4 w-4" />
                    Messages
                    {stats?.messages.unread && stats.messages.unread > 0 && (
                      <Badge className="ml-auto" variant="destructive">
                        {stats.messages.unread}
                      </Badge>
                    )}
                  </Link>
                </Button>
                <Button variant="outline" asChild className="w-full justify-start">
                  <Link href="/reports">
                    <TrendingUp className="mr-2 h-4 w-4" />
                    Reports
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="tasks" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Task Management</CardTitle>
              <CardDescription>
                Overview of your tasks and assignments
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <h4 className="font-medium">Pending Tasks</h4>
                  <div className="text-2xl font-bold">{stats?.tasks.pending ?? 0}</div>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium">In Progress</h4>
                  <div className="text-2xl font-bold">{stats?.tasks.inProgress ?? 0}</div>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium">Completed</h4>
                  <div className="text-2xl font-bold">{stats?.tasks.completed ?? 0}</div>
                </div>
              </div>
              <div className="mt-4">
                <Button asChild className="w-full">
                  <Link href="/tasks">Manage All Tasks</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="cases" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Case Management</CardTitle>
              <CardDescription>
                Overview of your immigration cases
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <h4 className="font-medium">Active Cases</h4>
                  <div className="text-2xl font-bold">{stats?.cases.active ?? 0}</div>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium">Completed</h4>
                  <div className="text-2xl font-bold">{stats?.cases.completed ?? 0}</div>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium">Total Cases</h4>
                  <div className="text-2xl font-bold">{stats?.cases.total ?? 0}</div>
                </div>
              </div>
              <div className="mt-4">
                <Button asChild className="w-full">
                  <Link href="/cases">View All Cases</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="activity" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>
                All recent activities across your workspace
              </CardDescription>
            </CardHeader>
            <CardContent>
              {recentItems.length === 0 ? (
                <div className="text-center py-12">
                  <Activity className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">No recent activity</h3>
                  <p className="text-muted-foreground">
                    Start by creating a case or task to see activity here.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {recentItems.map((item) => (
                    <div key={`${item.type}-${item.id}`} className="flex items-center p-3 border rounded-lg">
                      <div className="flex-1">
                        <p className="font-medium">{item.title}</p>
                        {item.subtitle && (
                          <p className="text-sm text-muted-foreground">{item.subtitle}</p>
                        )}
                        <p className="text-xs text-muted-foreground">
                          {formatDate(item.updatedAt)}
                        </p>
                      </div>
                      {item.status && (
                        <Badge className={getStatusColor(item.status, item.type)}>
                          {item.status.replace('_', ' ')}
                        </Badge>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function DashboardSkeleton() {
  return (
    <div className="flex-1 space-y-6 p-4 md:p-8 pt-6">
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-4 w-96" />
        </div>
        <Skeleton className="h-10 w-32" />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardHeader className="pb-2">
              <Skeleton className="h-4 w-24" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-8 w-12 mb-1" />
              <Skeleton className="h-3 w-20" />
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <Skeleton className="h-6 w-32" />
            <Skeleton className="h-4 w-48" />
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-48" />
                    <Skeleton className="h-3 w-32" />
                  </div>
                  <Skeleton className="h-6 w-20" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        <Card className="col-span-3">
          <CardHeader>
            <Skeleton className="h-6 w-32" />
            <Skeleton className="h-4 w-40" />
          </CardHeader>
          <CardContent className="space-y-3">
            {[...Array(4)].map((_, i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
