

export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth/options';
import { requireAdmin, getCurrentUser } from '@/lib/rbac';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// POST /api/system/initialize - Initialize system data
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    const user = await getCurrentUser();
    requireAdmin(user);

    const body = await request.json();

    // Initialize system data based on request
    const results: any[] = [];

    if (body.createDefaultWorkflows) {
      // Create default workflow templates
      const defaultWorkflow = await prisma.workflowTemplate.create({
        data: {
          name: 'Standard Immigration Case',
          description: 'Default workflow for immigration cases',
          caseType: 'immigration',
          stages: [
            { key: 'intake', name: 'Initial Intake', order: 1 },
            { key: 'document_collection', name: 'Document Collection', order: 2 },
            { key: 'review', name: 'Legal Review', order: 3 },
            { key: 'submission', name: 'Application Submission', order: 4 },
            { key: 'follow_up', name: 'Follow-up', order: 5 }
          ],
          createdById: user.id
        }
      });
      results.push({ type: 'workflow_template', data: defaultWorkflow });
    }

    if (body.createDefaultAutomationRules) {
      // Create default automation rules
      const defaultRule = await prisma.automationRule.create({
        data: {
          name: 'Document Upload Notification',
          description: 'Send notification when document is uploaded',
          trigger: 'document_uploaded',
          conditions: {},
          actions: [
            { type: 'send_notification', target: 'case_manager' }
          ],
          createdById: user.id
        }
      });
      results.push({ type: 'automation_rule', data: defaultRule });
    }

    if (body.createDefaultServiceRates) {
      // Create default service rates
      const defaultRate = await prisma.serviceRate.create({
        data: {
          name: 'Legal Consultation',
          description: 'Standard legal consultation rate',
          category: 'Legal',
          baseRate: 250.00,
          currency: 'USD'
        }
      });
      results.push({ type: 'service_rate', data: defaultRate });
    }

    // Handle any additional initialization based on the result type
    for (const result of results) {
      if (typeof result === 'object' && result !== null) {
        // Process the result object
        console.log('Initialized:', result.type);
      }
    }

    return NextResponse.json({
      success: true,
      message: 'System initialized successfully',
      data: results
    });
  } catch (error: any) {
    console.error('Error initializing system:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to initialize system' },
      { status: error.status || 500 }
    );
  }
}
