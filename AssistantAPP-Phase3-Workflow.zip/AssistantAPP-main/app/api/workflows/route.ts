

export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth/options';
import { requireStaffOrAdmin, getCurrentUser } from '@/lib/rbac';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// GET /api/workflows - Get all workflow runs
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    const user = await getCurrentUser();
    requireStaffOrAdmin(user);

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const status = searchParams.get('status');
    const caseId = searchParams.get('caseId');

    const where: any = {};
    
    if (status) {
      where.status = status;
    }
    
    if (caseId) {
      where.caseId = caseId;
    }

    const [workflows, total] = await Promise.all([
      prisma.workflowRun.findMany({
        where,
        include: {
          template: { select: { name: true } },
          case: { select: { caseNumber: true, title: true } },
          _count: { select: { stageStates: true } }
        },
        orderBy: { startedAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit
      }),
      prisma.workflowRun.count({ where })
    ]);

    return NextResponse.json({
      success: true,
      data: workflows,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error: any) {
    console.error('Error getting workflows:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to get workflows' },
      { status: error.status || 500 }
    );
  }
}

// POST /api/workflows - Start new workflow run
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    const user = await getCurrentUser();
    requireStaffOrAdmin(user);

    const body = await request.json();

    const workflow = await prisma.workflowRun.create({
      data: {
        templateId: body.templateId,
        caseId: body.caseId,
        currentStage: body.currentStage,
        metadata: body.metadata
      }
    });

    return NextResponse.json({
      success: true,
      data: workflow
    }, { status: 201 });
  } catch (error: any) {
    console.error('Error creating workflow:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to create workflow' },
      { status: error.status || 500 }
    );
  }
}
