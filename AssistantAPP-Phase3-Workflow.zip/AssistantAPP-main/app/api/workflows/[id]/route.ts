

export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth/options';
import { requireStaffOrAdmin, getCurrentUser } from '@/lib/rbac';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// GET /api/workflows/[id] - Get workflow run details
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    const user = await getCurrentUser();
    requireStaffOrAdmin(user);

    const workflow = await prisma.workflowRun.findUnique({
      where: { id: params.id },
      include: {
        template: { select: { name: true, description: true, stages: true } },
        case: { select: { caseNumber: true, title: true } },
        stageStates: {
          include: {
            assignedTo: { select: { name: true } }
          },
          orderBy: { createdAt: 'asc' }
        },
        automationRuns: {
          include: {
            rule: { select: { name: true } }
          },
          orderBy: { executedAt: 'desc' },
          take: 10
        },
        notifications: {
          orderBy: { createdAt: 'desc' },
          take: 10
        }
      }
    });

    if (!workflow) {
      return NextResponse.json({ success: false, error: 'Workflow not found' }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      data: workflow
    });
  } catch (error: any) {
    console.error('Error getting workflow:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to get workflow' },
      { status: error.status || 500 }
    );
  }
}

// PUT /api/workflows/[id] - Update workflow run
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    const user = await getCurrentUser();
    requireStaffOrAdmin(user);

    const body = await request.json();

    const workflow = await prisma.workflowRun.update({
      where: { id: params.id },
      data: {
        currentStage: body.currentStage,
        status: body.status,
        progress: body.progress,
        completedAt: body.status === 'completed' ? new Date() : null,
        metadata: body.metadata
      }
    });

    return NextResponse.json({
      success: true,
      data: workflow
    });
  } catch (error: any) {
    console.error('Error updating workflow:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to update workflow' },
      { status: error.status || 500 }
    );
  }
}

// DELETE /api/workflows/[id] - Cancel workflow run
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    const user = await getCurrentUser();
    requireStaffOrAdmin(user);

    const workflow = await prisma.workflowRun.update({
      where: { id: params.id },
      data: {
        status: 'cancelled',
        completedAt: new Date()
      }
    });

    return NextResponse.json({
      success: true,
      data: workflow,
      message: 'Workflow cancelled successfully'
    });
  } catch (error: any) {
    console.error('Error cancelling workflow:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to cancel workflow' },
      { status: error.status || 500 }
    );
  }
}
