

export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth/options';
import { requireStaffOrAdmin, getCurrentUser } from '@/lib/rbac';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// GET /api/billing/invoices/[id] - Get invoice details
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    requireStaffOrAdmin(user);

    const invoice = await prisma.invoice.findUnique({
      where: { id: params.id },
      include: {
        client: { select: { name: true, email: true } },
        case: { select: { caseNumber: true, title: true } },
        generatedBy: { select: { name: true } },
        items: {
          include: {
            serviceRate: { select: { name: true, category: true } }
          }
        },
        timeEntries: {
          include: {
            user: { select: { name: true } },
            task: { select: { title: true } }
          }
        },
        paymentRecords: {
          orderBy: { createdAt: 'desc' }
        }
      }
    });

    if (!invoice) {
      return NextResponse.json({ success: false, error: 'Invoice not found' }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      data: invoice
    });
  } catch (error: any) {
    console.error('Error getting invoice:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to get invoice' },
      { status: error.status || 500 }
    );
  }
}

// PUT /api/billing/invoices/[id] - Update invoice
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    requireStaffOrAdmin(user);

    const body = await request.json();

    const invoice = await prisma.invoice.update({
      where: { id: params.id },
      data: {
        title: body.title,
        description: body.description,
        dueDate: body.dueDate ? new Date(body.dueDate) : null,
        status: body.status,
        metadata: body.metadata
      }
    });

    return NextResponse.json({
      success: true,
      data: invoice
    });
  } catch (error: any) {
    console.error('Error updating invoice:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to update invoice' },
      { status: error.status || 500 }
    );
  }
}

// DELETE /api/billing/invoices/[id] - Delete invoice
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    requireStaffOrAdmin(user);

    await prisma.invoice.delete({
      where: { id: params.id }
    });

    return NextResponse.json({
      success: true,
      message: 'Invoice deleted successfully'
    });
  } catch (error: any) {
    console.error('Error deleting invoice:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to delete invoice' },
      { status: error.status || 500 }
    );
  }
}
