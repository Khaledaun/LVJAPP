

export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth/options';
import { requireStaffOrAdmin, getCurrentUser } from '@/lib/rbac';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// GET /api/reports/templates - Get all report templates
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    const user = await getCurrentUser();
    requireStaffOrAdmin(user);

    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type');
    const isPublic = searchParams.get('isPublic');

    const where: any = {};
    
    if (type) {
      where.type = type;
    }
    
    if (isPublic !== null) {
      where.isPublic = isPublic === 'true';
    }

    const templates = await prisma.reportTemplate.findMany({
      where,
      include: {
        createdBy: { select: { name: true } },
        _count: { select: { reports: true } }
      },
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json({
      success: true,
      data: templates
    });
  } catch (error: any) {
    console.error('Error getting report templates:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to get report templates' },
      { status: error.status || 500 }
    );
  }
}

// POST /api/reports/templates - Create new report template
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    const user = await getCurrentUser();
    requireStaffOrAdmin(user);

    const body = await request.json();

    const template = await prisma.reportTemplate.create({
      data: {
        name: body.name,
        description: body.description,
        type: body.type,
        parameters: body.parameters,
        filters: body.filters,
        columns: body.columns,
        isPublic: body.isPublic ?? false,
        createdById: user.id
      }
    });

    return NextResponse.json({
      success: true,
      data: template
    }, { status: 201 });
  } catch (error: any) {
    console.error('Error creating report template:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to create report template' },
      { status: error.status || 500 }
    );
  }
}
