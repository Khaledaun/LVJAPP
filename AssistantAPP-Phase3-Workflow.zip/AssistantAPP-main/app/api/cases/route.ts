import { getServerSession } from "next-auth/next";
import { getAuthOptions } from "@/lib/auth";
import { NextResponse } from "next/server";
import { getPrisma } from "@/lib/db"; // Use the async getter
import { Role, CaseStatus } from "@prisma/client";
import { getCurrentUser, requireStaffOrAdmin } from "@/lib/rbac";
import { createAuditLog } from "@/lib/audit-log";

export const dynamic = "force-dynamic";

// GET Handler to list cases
export async function GET(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const status = searchParams.get('status');
    const urgency = searchParams.get('urgency');
    
    const skip = (page - 1) * limit;

    const prisma = await getPrisma();
    
    let whereClause: any = {};

    // Role-based filtering
    if (user.role === Role.CLIENT) {
      whereClause.clientId = user.id;
    } else if (user.role === Role.STAFF) {
      whereClause.OR = [
        { caseManagerId: user.id },
        { lawyerId: user.id },
      ];
    }
    // ADMIN sees all cases (no additional filtering)

    // Additional filters
    if (status && Object.values(CaseStatus).includes(status as CaseStatus)) {
      whereClause.overallStatus = status;
    }
    if (urgency) {
      whereClause.urgencyLevel = urgency;
    }

    const [cases, totalCount] = await Promise.all([
      prisma.case.findMany({
        where: whereClause,
        include: {
          client: { 
            select: { 
              id: true, 
              name: true, 
              email: true, 
              firstName: true, 
              lastName: true 
            } 
          },
          caseManager: { 
            select: { 
              id: true, 
              name: true, 
              email: true, 
              firstName: true, 
              lastName: true 
            } 
          },
          lawyer: { 
            select: { 
              id: true, 
              name: true, 
              email: true, 
              firstName: true, 
              lastName: true 
            } 
          },
          _count: {
            select: {
              documents: true,
              payments: true,
              timelineEvents: true,
            }
          }
        },
        orderBy: {
          createdAt: 'desc',
        },
        skip,
        take: limit,
      }),
      prisma.case.count({ where: whereClause }),
    ]);

    return NextResponse.json({ 
      cases,
      pagination: {
        page,
        limit,
        totalCount,
        totalPages: Math.ceil(totalCount / limit),
      },
    });
  } catch (error: any) {
    console.error("Failed to fetch cases:", error);
    return NextResponse.json(
      { error: error?.message || "Internal Server Error" }, 
      { status: error?.status || 500 }
    );
  }
}

// POST Handler to create a new case
export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    requireStaffOrAdmin(user);

    const body = await req.json();
    const { 
      title, 
      applicantName, 
      applicantEmail, 
      totalFee = 0, 
      currency = 'USD',
      urgencyLevel = 'STANDARD',
      stage = 'Intake',
      clientId,
      lawyerId 
    } = body;

    // Validation
    if (!title || !applicantName || !applicantEmail) {
      return NextResponse.json(
        { error: 'Title, applicant name, and email are required' },
        { status: 400 }
      );
    }

    const prisma = await getPrisma();

    // Validate client ID if provided
    if (clientId) {
      const client = await prisma.user.findUnique({
        where: { id: clientId, role: Role.CLIENT },
      });
      if (!client) {
        return NextResponse.json(
          { error: 'Invalid client ID' },
          { status: 400 }
        );
      }
    }

    // Validate lawyer ID if provided
    if (lawyerId) {
      const lawyer = await prisma.user.findUnique({
        where: { id: lawyerId, role: { in: [Role.STAFF, Role.ADMIN] } },
      });
      if (!lawyer) {
        return NextResponse.json(
          { error: 'Invalid lawyer ID' },
          { status: 400 }
        );
      }
    }

    // Generate unique case number
    const timestamp = Date.now();
    const caseNumber = `LVJ-${timestamp}`;

    const newCase = await prisma.case.create({
      data: {
        title,
        applicantName,
        applicantEmail,
        caseManagerId: user.id,
        caseNumber,
        totalFee: totalFee || 0,
        currency: currency || 'USD',
        overallStatus: CaseStatus.new,
        stage: stage || 'Intake',
        urgencyLevel: urgencyLevel || 'STANDARD',
        completionPercentage: 5,
        clientId: clientId || null,
        lawyerId: lawyerId || null,
      },
      include: {
        client: { 
          select: { 
            id: true, 
            name: true, 
            email: true, 
            firstName: true, 
            lastName: true 
          } 
        },
        caseManager: { 
          select: { 
            id: true, 
            name: true, 
            email: true, 
            firstName: true, 
            lastName: true 
          } 
        },
        lawyer: { 
          select: { 
            id: true, 
            name: true, 
            email: true, 
            firstName: true, 
            lastName: true 
          } 
        },
      },
    });

    // Log case creation
    await createAuditLog({
      action: 'CASE_CREATE',
      caseId: newCase.id,
      userId: user.id,
      diff: JSON.stringify({
        title: newCase.title,
        applicantName: newCase.applicantName,
        applicantEmail: newCase.applicantEmail,
        caseNumber: newCase.caseNumber,
      }),
    });

    return NextResponse.json({ case: newCase }, { status: 201 });
  } catch (error: any) {
    if (error?.code === 'P2002') {
      return NextResponse.json({ error: 'A case with this number already exists.' }, { status: 409 });
    }
    console.error('Failed to create case:', error);
    return NextResponse.json(
      { error: error?.message || 'Internal Server Error' }, 
      { status: error?.status || 500 }
    );
  }
}
