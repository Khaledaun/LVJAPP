import { getServerSession } from "next-auth/next";
import { getAuthOptions } from "@/lib/auth";
import { NextResponse } from "next/server";
import { getPrisma } from "@/lib/db";
import { Role, CaseStatus } from "@prisma/client";
import { assertCaseAccess, getCurrentUser, requireStaffOrAdmin } from "@/lib/rbac";
import { logCaseAccess } from "@/lib/audit-log";

export const dynamic = "force-dynamic";

export async function GET(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    const caseId = params.id;
    if (!caseId) {
      return NextResponse.json({ error: "Case ID is required" }, { status: 400 });
    }

    // Use the enhanced RBAC function for access control
    const { user, case: caseRecord } = await assertCaseAccess(caseId);
    
    // At this point, user is guaranteed to be non-null due to assertCaseAccess
    if (!user) {
      throw new Error('User authentication failed');
    }
    
    const prisma = await getPrisma();

    // Get detailed case information with relations
    const detailedCase = await prisma.case.findUnique({
      where: { id: caseId },
      include: {
        client: { 
          select: { 
            id: true, 
            name: true, 
            email: true, 
            firstName: true, 
            lastName: true 
          } 
        },
        caseManager: { 
          select: { 
            id: true, 
            name: true, 
            email: true, 
            firstName: true, 
            lastName: true 
          } 
        },
        lawyer: { 
          select: { 
            id: true, 
            name: true, 
            email: true, 
            firstName: true, 
            lastName: true 
          } 
        },
        documents: {
          select: {
            id: true,
            name: true,
            state: true,
            createdAt: true,
            updatedAt: true,
          },
          orderBy: {
            createdAt: 'desc',
          },
        },
        payments: {
          select: {
            id: true,
            amount: true,
            currency: true,
            status: true,
            description: true,
            invoiceNumber: true,
            issuedAt: true,
            paidAt: true,
          },
          orderBy: {
            createdAt: 'desc',
          },
        },
        timelineEvents: {
          select: {
            id: true,
            details: true,
            createdAt: true,
          },
          orderBy: {
            createdAt: 'desc',
          },
        },
      },
    });

    // Log the case access
    await logCaseAccess(caseId, user.id, 'VIEW');

    return NextResponse.json({ case: detailedCase });
  } catch (error: any) {
    console.error("Failed to fetch case:", error);
    return NextResponse.json(
      { error: error?.message || "Internal Server Error" },
      { status: error?.status || 500 }
    );
  }
}

// PUT - Full case update (STAFF and ADMIN only)
export async function PUT(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    const caseId = params.id;
    if (!caseId) {
      return NextResponse.json({ error: "Case ID is required" }, { status: 400 });
    }

    // Check user permissions
    const user = await getCurrentUser();
    requireStaffOrAdmin(user);

    // Verify case access
    const { case: existingCase } = await assertCaseAccess(caseId);

    const body = await req.json();
    const {
      title,
      applicantName,
      applicantEmail,
      totalFee,
      currency,
      overallStatus,
      stage,
      urgencyLevel,
      completionPercentage,
      clientId,
      caseManagerId,
      lawyerId,
    } = body;

    // Validate required fields
    if (!title || !applicantName || !applicantEmail) {
      return NextResponse.json(
        { error: 'Title, applicant name, and email are required' },
        { status: 400 }
      );
    }

    // Validate status if provided
    if (overallStatus && !Object.values(CaseStatus).includes(overallStatus)) {
      return NextResponse.json(
        { error: 'Invalid case status' },
        { status: 400 }
      );
    }

    const prisma = await getPrisma();

    // Validate user references if provided
    if (clientId) {
      const client = await prisma.user.findUnique({
        where: { id: clientId, role: Role.CLIENT },
      });
      if (!client) {
        return NextResponse.json(
          { error: 'Invalid client ID' },
          { status: 400 }
        );
      }
    }

    if (caseManagerId) {
      const manager = await prisma.user.findUnique({
        where: { id: caseManagerId, role: { in: [Role.STAFF, Role.ADMIN] } },
      });
      if (!manager) {
        return NextResponse.json(
          { error: 'Invalid case manager ID' },
          { status: 400 }
        );
      }
    }

    if (lawyerId) {
      const lawyer = await prisma.user.findUnique({
        where: { id: lawyerId, role: { in: [Role.STAFF, Role.ADMIN] } },
      });
      if (!lawyer) {
        return NextResponse.json(
          { error: 'Invalid lawyer ID' },
          { status: 400 }
        );
      }
    }

    // Update the case
    const updatedCase = await prisma.case.update({
      where: { id: caseId },
      data: {
        title,
        applicantName,
        applicantEmail,
        totalFee: totalFee !== undefined ? totalFee : undefined,
        currency: currency || undefined,
        overallStatus: overallStatus || undefined,
        stage: stage || undefined,
        urgencyLevel: urgencyLevel || undefined,
        completionPercentage: completionPercentage !== undefined ? completionPercentage : undefined,
        clientId: clientId !== undefined ? clientId : undefined,
        caseManagerId: caseManagerId !== undefined ? caseManagerId : undefined,
        lawyerId: lawyerId !== undefined ? lawyerId : undefined,
      },
      include: {
        client: { select: { id: true, name: true, email: true } },
        caseManager: { select: { id: true, name: true, email: true } },
        lawyer: { select: { id: true, name: true, email: true } },
      },
    });

    // Log the case update
    await logCaseAccess(caseId, user.id, 'UPDATE');

    return NextResponse.json({ case: updatedCase });
  } catch (error: any) {
    console.error("Failed to update case:", error);
    return NextResponse.json(
      { error: error?.message || "Internal Server Error" },
      { status: error?.status || 500 }
    );
  }
}

// PATCH - Partial case update (STAFF and ADMIN only)
export async function PATCH(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    const caseId = params.id;
    if (!caseId) {
      return NextResponse.json({ error: "Case ID is required" }, { status: 400 });
    }

    // Check user permissions
    const user = await getCurrentUser();
    requireStaffOrAdmin(user);

    // Verify case access
    const { case: existingCase } = await assertCaseAccess(caseId);

    const body = await req.json();
    const updates: any = {};

    // Only update fields that are provided
    if (body.title !== undefined) updates.title = body.title;
    if (body.applicantName !== undefined) updates.applicantName = body.applicantName;
    if (body.applicantEmail !== undefined) updates.applicantEmail = body.applicantEmail;
    if (body.totalFee !== undefined) updates.totalFee = body.totalFee;
    if (body.currency !== undefined) updates.currency = body.currency;
    if (body.overallStatus !== undefined) {
      if (!Object.values(CaseStatus).includes(body.overallStatus)) {
        return NextResponse.json(
          { error: 'Invalid case status' },
          { status: 400 }
        );
      }
      updates.overallStatus = body.overallStatus;
    }
    if (body.stage !== undefined) updates.stage = body.stage;
    if (body.urgencyLevel !== undefined) updates.urgencyLevel = body.urgencyLevel;
    if (body.completionPercentage !== undefined) updates.completionPercentage = body.completionPercentage;
    if (body.clientId !== undefined) updates.clientId = body.clientId;
    if (body.caseManagerId !== undefined) updates.caseManagerId = body.caseManagerId;
    if (body.lawyerId !== undefined) updates.lawyerId = body.lawyerId;

    // If no updates provided
    if (Object.keys(updates).length === 0) {
      return NextResponse.json(
        { error: 'No valid fields to update' },
        { status: 400 }
      );
    }

    const prisma = await getPrisma();

    // Validate user references if provided
    if (updates.clientId) {
      const client = await prisma.user.findUnique({
        where: { id: updates.clientId, role: Role.CLIENT },
      });
      if (!client) {
        return NextResponse.json(
          { error: 'Invalid client ID' },
          { status: 400 }
        );
      }
    }

    if (updates.caseManagerId) {
      const manager = await prisma.user.findUnique({
        where: { id: updates.caseManagerId, role: { in: [Role.STAFF, Role.ADMIN] } },
      });
      if (!manager) {
        return NextResponse.json(
          { error: 'Invalid case manager ID' },
          { status: 400 }
        );
      }
    }

    if (updates.lawyerId) {
      const lawyer = await prisma.user.findUnique({
        where: { id: updates.lawyerId, role: { in: [Role.STAFF, Role.ADMIN] } },
      });
      if (!lawyer) {
        return NextResponse.json(
          { error: 'Invalid lawyer ID' },
          { status: 400 }
        );
      }
    }

    // Update the case
    const updatedCase = await prisma.case.update({
      where: { id: caseId },
      data: updates,
      include: {
        client: { select: { id: true, name: true, email: true } },
        caseManager: { select: { id: true, name: true, email: true } },
        lawyer: { select: { id: true, name: true, email: true } },
      },
    });

    // Log the case update
    await logCaseAccess(caseId, user.id, 'UPDATE');

    return NextResponse.json({ case: updatedCase });
  } catch (error: any) {
    console.error("Failed to patch case:", error);
    return NextResponse.json(
      { error: error?.message || "Internal Server Error" },
      { status: error?.status || 500 }
    );
  }
}

// DELETE - Delete case (ADMIN only)
export async function DELETE(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    const caseId = params.id;
    if (!caseId) {
      return NextResponse.json({ error: "Case ID is required" }, { status: 400 });
    }

    // Only ADMIN can delete cases
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json(
        { error: "Authentication required" },
        { status: 401 }
      );
    }

    if (user.role !== Role.ADMIN) {
      return NextResponse.json(
        { error: "Admin access required" },
        { status: 403 }
      );
    }

    // Verify case exists
    const { case: existingCase } = await assertCaseAccess(caseId);

    const prisma = await getPrisma();

    // Delete related records first (due to foreign key constraints)
    await prisma.$transaction([
      prisma.document.deleteMany({ where: { caseId } }),
      prisma.payment.deleteMany({ where: { caseId } }),
      prisma.timelineEvent.deleteMany({ where: { caseId } }),
      prisma.message.deleteMany({ where: { caseId } }),
      prisma.externalCommunication.deleteMany({ where: { caseId } }),
      prisma.externalPartner.deleteMany({ where: { caseId } }),
      prisma.case.delete({ where: { id: caseId } }),
    ]);

    // Log the case deletion
    await logCaseAccess(caseId, user.id, 'DELETE');

    return NextResponse.json({ message: 'Case deleted successfully' });
  } catch (error: any) {
    console.error("Failed to delete case:", error);
    return NextResponse.json(
      { error: error?.message || "Internal Server Error" },
      { status: error?.status || 500 }
    );
  }
}
