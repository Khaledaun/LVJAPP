
import { NextRequest, NextResponse } from "next/server";
import { getPrisma } from "@/lib/db";
import { getCurrentUser } from "@/lib/rbac";
import { TaskStatus, Priority, Role } from "@prisma/client";

export const dynamic = "force-dynamic";

// GET - Get task statistics and metrics
export async function GET(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const caseId = searchParams.get('caseId');
    const userId = searchParams.get('userId');
    
    const prisma = await getPrisma();
    
    let whereClause: any = {};

    // Role-based filtering
    if (user.role === Role.CLIENT) {
      // Clients can only see tasks for cases they own
      whereClause.case = {
        clientId: user.id
      };
    } else if (user.role === Role.STAFF) {
      // Staff can see tasks assigned to them or cases they manage
      whereClause.OR = [
        { assignedToId: user.id },
        { case: { caseManagerId: user.id } },
        { case: { lawyerId: user.id } },
      ];
    }
    // ADMIN sees all tasks (no additional filtering)

    // Additional filters
    if (caseId) {
      whereClause.caseId = caseId;
    }
    if (userId) {
      whereClause.assignedToId = userId;
    }

    // Get basic counts
    const [
      totalTasks,
      pendingTasks,
      inProgressTasks,
      completedTasks,
      overdueTasks,
      highPriorityTasks,
      criticalTasks
    ] = await Promise.all([
      prisma.task.count({ where: whereClause }),
      prisma.task.count({ where: { ...whereClause, status: TaskStatus.pending } }),
      prisma.task.count({ where: { ...whereClause, status: TaskStatus.in_progress } }),
      prisma.task.count({ where: { ...whereClause, status: TaskStatus.completed } }),
      prisma.task.count({ 
        where: { 
          ...whereClause, 
          dueDate: { lt: new Date() },
          status: { not: TaskStatus.completed }
        } 
      }),
      prisma.task.count({ where: { ...whereClause, priority: Priority.high } }),
      prisma.task.count({ where: { ...whereClause, priority: Priority.critical } }),
    ]);

    // Get tasks by status
    const tasksByStatus = await prisma.task.groupBy({
      by: ['status'],
      where: whereClause,
      _count: { status: true },
    });

    // Get tasks by priority
    const tasksByPriority = await prisma.task.groupBy({
      by: ['priority'],
      where: whereClause,
      _count: { priority: true },
    });

    // Get tasks by category
    const tasksByCategory = await prisma.task.groupBy({
      by: ['category'],
      where: { ...whereClause, category: { not: null } },
      _count: { category: true },
    });

    // Get recent completed tasks
    const recentCompletedTasks = await prisma.task.findMany({
      where: { 
        ...whereClause, 
        status: TaskStatus.completed,
        completedAt: { not: null }
      },
      select: {
        id: true,
        title: true,
        completedAt: true,
        assignedTo: {
          select: {
            name: true,
            firstName: true,
            lastName: true,
          }
        }
      },
      orderBy: { completedAt: 'desc' },
      take: 10,
    });

    // Get upcoming due tasks
    const upcomingTasks = await prisma.task.findMany({
      where: {
        ...whereClause,
        dueDate: {
          gte: new Date(),
          lte: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // Next 7 days
        },
        status: { notIn: [TaskStatus.completed, TaskStatus.cancelled] }
      },
      select: {
        id: true,
        title: true,
        dueDate: true,
        priority: true,
        assignedTo: {
          select: {
            name: true,
            firstName: true,
            lastName: true,
          }
        },
        case: {
          select: {
            title: true,
            caseNumber: true,
          }
        }
      },
      orderBy: { dueDate: 'asc' },
      take: 10,
    });

    const stats = {
      overview: {
        total: totalTasks,
        pending: pendingTasks,
        inProgress: inProgressTasks,
        completed: completedTasks,
        overdue: overdueTasks,
        highPriority: highPriorityTasks,
        critical: criticalTasks,
        completionRate: totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0,
      },
      breakdown: {
        byStatus: tasksByStatus.reduce((acc, item) => {
          acc[item.status] = item._count.status;
          return acc;
        }, {} as Record<string, number>),
        byPriority: tasksByPriority.reduce((acc, item) => {
          acc[item.priority] = item._count.priority;
          return acc;
        }, {} as Record<string, number>),
        byCategory: tasksByCategory.reduce((acc, item) => {
          acc[item.category!] = item._count.category;
          return acc;
        }, {} as Record<string, number>),
      },
      recent: {
        completed: recentCompletedTasks,
        upcoming: upcomingTasks,
      },
    };

    return NextResponse.json({ stats });
  } catch (error: any) {
    console.error("Failed to fetch task stats:", error);
    return NextResponse.json(
      { error: error?.message || "Internal Server Error" },
      { status: error?.status || 500 }
    );
  }
}
