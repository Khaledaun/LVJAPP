
import { NextRequest, NextResponse } from "next/server";
import { getPrisma } from "@/lib/db";
import { getCurrentUser, requireStaffOrAdmin } from "@/lib/rbac";
import { createAuditLog } from "@/lib/audit-log";
import { TaskStatus, Priority, Role } from "@prisma/client";

export const dynamic = "force-dynamic";

// GET - List tasks with filtering and pagination
export async function GET(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const status = searchParams.get('status') as TaskStatus | null;
    const priority = searchParams.get('priority') as Priority | null;
    const assignedToId = searchParams.get('assignedTo');
    const caseId = searchParams.get('caseId');
    const category = searchParams.get('category');
    const search = searchParams.get('search');
    const overdue = searchParams.get('overdue') === 'true';
    
    const skip = (page - 1) * limit;
    const prisma = await getPrisma();
    
    let whereClause: any = {};

    // Role-based filtering
    if (user.role === Role.CLIENT) {
      // Clients can only see tasks for cases they own
      whereClause.case = {
        clientId: user.id
      };
    } else if (user.role === Role.STAFF) {
      // Staff can see tasks assigned to them or cases they manage
      whereClause.OR = [
        { assignedToId: user.id },
        { case: { caseManagerId: user.id } },
        { case: { lawyerId: user.id } },
      ];
    }
    // ADMIN sees all tasks (no additional filtering)

    // Additional filters
    if (status && Object.values(TaskStatus).includes(status)) {
      whereClause.status = status;
    }
    if (priority && Object.values(Priority).includes(priority)) {
      whereClause.priority = priority;
    }
    if (assignedToId) {
      whereClause.assignedToId = assignedToId;
    }
    if (caseId) {
      whereClause.caseId = caseId;
    }
    if (category) {
      whereClause.category = category;
    }
    if (search) {
      whereClause.OR = [
        { title: { contains: search } },
        { description: { contains: search } },
      ];
    }
    if (overdue) {
      whereClause.dueDate = { lt: new Date() };
      whereClause.status = { not: TaskStatus.completed };
    }

    const [tasks, totalCount] = await Promise.all([
      prisma.task.findMany({
        where: whereClause,
        include: {
          assignedTo: {
            select: {
              id: true,
              name: true,
              email: true,
              firstName: true,
              lastName: true,
            }
          },
          createdBy: {
            select: {
              id: true,
              name: true,
              email: true,
              firstName: true,
              lastName: true,
            }
          },
          case: {
            select: {
              id: true,
              title: true,
              caseNumber: true,
              overallStatus: true,
            }
          },
          _count: {
            select: {
              comments: true,
              activities: true,
            }
          }
        },
        orderBy: [
          { priority: 'desc' },
          { dueDate: 'asc' },
          { createdAt: 'desc' },
        ],
        skip,
        take: limit,
      }),
      prisma.task.count({ where: whereClause }),
    ]);

    return NextResponse.json({
      tasks,
      pagination: {
        page,
        limit,
        totalCount,
        totalPages: Math.ceil(totalCount / limit),
      },
    });
  } catch (error: any) {
    console.error("Failed to fetch tasks:", error);
    return NextResponse.json(
      { error: error?.message || "Internal Server Error" },
      { status: error?.status || 500 }
    );
  }
}

// POST - Create a new task
export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    requireStaffOrAdmin(user);

    const body = await req.json();
    const {
      title,
      description,
      priority = Priority.normal,
      category,
      dueDate,
      estimatedHours,
      tags,
      assignedToId,
      caseId,
      dependsOn,
      attachments,
    } = body;

    // Validation
    if (!title) {
      return NextResponse.json(
        { error: 'Task title is required' },
        { status: 400 }
      );
    }

    const prisma = await getPrisma();

    // Validate assignedTo user if provided
    if (assignedToId) {
      const assignedUser = await prisma.user.findUnique({
        where: { id: assignedToId, isActive: true },
      });
      if (!assignedUser) {
        return NextResponse.json(
          { error: 'Invalid assigned user ID' },
          { status: 400 }
        );
      }
    }

    // Validate case if provided
    if (caseId) {
      const caseRecord = await prisma.case.findUnique({
        where: { id: caseId },
      });
      if (!caseRecord) {
        return NextResponse.json(
          { error: 'Invalid case ID' },
          { status: 400 }
        );
      }
    }

    // Validate priority
    if (priority && !Object.values(Priority).includes(priority)) {
      return NextResponse.json(
        { error: 'Invalid priority level' },
        { status: 400 }
      );
    }

    const newTask = await prisma.task.create({
      data: {
        title,
        description,
        priority: priority || Priority.normal,
        category,
        dueDate: dueDate ? new Date(dueDate) : null,
        estimatedHours,
        tags: tags ? JSON.stringify(tags) : undefined,
        assignedToId,
        createdById: user.id,
        caseId,
        dependsOn: dependsOn ? JSON.stringify(dependsOn) : undefined,
        attachments: attachments ? JSON.stringify(attachments) : undefined,
        status: TaskStatus.pending,
      },
      include: {
        assignedTo: {
          select: {
            id: true,
            name: true,
            email: true,
            firstName: true,
            lastName: true,
          }
        },
        createdBy: {
          select: {
            id: true,
            name: true,
            email: true,
            firstName: true,
            lastName: true,
          }
        },
        case: {
          select: {
            id: true,
            title: true,
            caseNumber: true,
          }
        },
      },
    });

    // Create activity log
    await prisma.taskActivity.create({
      data: {
        action: 'created',
        description: `Task "${title}" created`,
        userId: user.id,
        taskId: newTask.id,
      },
    });

    // Log task creation
    await createAuditLog({
      action: 'TASK_CREATE',
      caseId: caseId || null,
      userId: user.id,
      diff: JSON.stringify({
        taskId: newTask.id,
        title: newTask.title,
        assignedToId: newTask.assignedToId,
        priority: newTask.priority,
      }),
    });

    return NextResponse.json({ task: newTask }, { status: 201 });
  } catch (error: any) {
    console.error('Failed to create task:', error);
    return NextResponse.json(
      { error: error?.message || 'Internal Server Error' },
      { status: error?.status || 500 }
    );
  }
}
