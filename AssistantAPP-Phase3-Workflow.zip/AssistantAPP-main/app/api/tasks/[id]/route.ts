
import { NextRequest, NextResponse } from "next/server";
import { getPrisma } from "@/lib/db";
import { getCurrentUser, requireStaffOrAdmin } from "@/lib/rbac";
import { createAuditLog } from "@/lib/audit-log";
import { TaskStatus, Priority, Role } from "@prisma/client";

export const dynamic = "force-dynamic";

// GET - Get task by ID with full details
export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 });
    }

    const { id } = params;
    const prisma = await getPrisma();

    const task = await prisma.task.findUnique({
      where: { id },
      include: {
        assignedTo: {
          select: {
            id: true,
            name: true,
            email: true,
            firstName: true,
            lastName: true,
            avatar: true,
          }
        },
        createdBy: {
          select: {
            id: true,
            name: true,
            email: true,
            firstName: true,
            lastName: true,
            avatar: true,
          }
        },
        case: {
          select: {
            id: true,
            title: true,
            caseNumber: true,
            overallStatus: true,
            client: {
              select: {
                id: true,
                name: true,
                email: true,
              }
            }
          }
        },
        comments: {
          include: {
            author: {
              select: {
                id: true,
                name: true,
                email: true,
                firstName: true,
                lastName: true,
                avatar: true,
              }
            }
          },
          orderBy: { createdAt: 'desc' },
        },
        activities: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                email: true,
                firstName: true,
                lastName: true,
              }
            }
          },
          orderBy: { createdAt: 'desc' },
          take: 20,
        },
      },
    });

    if (!task) {
      return NextResponse.json({ error: 'Task not found' }, { status: 404 });
    }

    // Check access permissions
    let hasAccess = false;
    if (user.role === Role.ADMIN) {
      hasAccess = true;
    } else if (user.role === Role.STAFF) {
      hasAccess = task.assignedToId === user.id || 
                 task.createdById === user.id;
    } else if (user.role === Role.CLIENT) {
      hasAccess = task.case?.client?.id === user.id;
    }

    if (!hasAccess) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 });
    }

    // Parse JSON fields
    const taskWithParsedFields = {
      ...task,
      tags: task.tags ? JSON.parse(task.tags as string) : [],
      dependsOn: task.dependsOn ? JSON.parse(task.dependsOn as string) : [],
      blockedBy: task.blockedBy ? JSON.parse(task.blockedBy as string) : [],
      attachments: task.attachments ? JSON.parse(task.attachments as string) : [],
    };

    return NextResponse.json({ task: taskWithParsedFields });
  } catch (error: any) {
    console.error("Failed to fetch task:", error);
    return NextResponse.json(
      { error: error?.message || "Internal Server Error" },
      { status: error?.status || 500 }
    );
  }
}

// PUT - Update task
export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await getCurrentUser();
    requireStaffOrAdmin(user);

    const { id } = params;
    const body = await req.json();
    const {
      title,
      description,
      status,
      priority,
      category,
      dueDate,
      completedAt,
      estimatedHours,
      actualHours,
      tags,
      notes,
      assignedToId,
      dependsOn,
      blockedBy,
      attachments,
    } = body;

    const prisma = await getPrisma();

    // Get current task
    const currentTask = await prisma.task.findUnique({
      where: { id },
      include: {
        case: true,
      },
    });

    if (!currentTask) {
      return NextResponse.json({ error: 'Task not found' }, { status: 404 });
    }

    // Check permissions (similar to GET)
    let hasAccess = false;
    if (user.role === Role.ADMIN) {
      hasAccess = true;
    } else if (user.role === Role.STAFF) {
      hasAccess = currentTask.assignedToId === user.id || 
                 currentTask.createdById === user.id;
    }

    if (!hasAccess) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 });
    }

    // Validate status
    if (status && !Object.values(TaskStatus).includes(status)) {
      return NextResponse.json(
        { error: 'Invalid status' },
        { status: 400 }
      );
    }

    // Validate priority
    if (priority && !Object.values(Priority).includes(priority)) {
      return NextResponse.json(
        { error: 'Invalid priority' },
        { status: 400 }
      );
    }

    // Validate assignedTo user if provided
    if (assignedToId && assignedToId !== currentTask.assignedToId) {
      const assignedUser = await prisma.user.findUnique({
        where: { id: assignedToId, isActive: true },
      });
      if (!assignedUser) {
        return NextResponse.json(
          { error: 'Invalid assigned user ID' },
          { status: 400 }
        );
      }
    }

    // Prepare update data
    const updateData: any = {};
    if (title !== undefined) updateData.title = title;
    if (description !== undefined) updateData.description = description;
    if (status !== undefined) {
      updateData.status = status;
      if (status === TaskStatus.completed && !completedAt) {
        updateData.completedAt = new Date();
      }
    }
    if (priority !== undefined) updateData.priority = priority;
    if (category !== undefined) updateData.category = category;
    if (dueDate !== undefined) updateData.dueDate = dueDate ? new Date(dueDate) : undefined;
    if (completedAt !== undefined) updateData.completedAt = completedAt ? new Date(completedAt) : undefined;
    if (estimatedHours !== undefined) updateData.estimatedHours = estimatedHours;
    if (actualHours !== undefined) updateData.actualHours = actualHours;
    if (tags !== undefined) updateData.tags = JSON.stringify(tags);
    if (notes !== undefined) updateData.notes = notes;
    if (assignedToId !== undefined) updateData.assignedToId = assignedToId;
    if (dependsOn !== undefined) updateData.dependsOn = JSON.stringify(dependsOn);
    if (blockedBy !== undefined) updateData.blockedBy = JSON.stringify(blockedBy);
    if (attachments !== undefined) updateData.attachments = JSON.stringify(attachments);

    const updatedTask = await prisma.task.update({
      where: { id },
      data: updateData,
      include: {
        assignedTo: {
          select: {
            id: true,
            name: true,
            email: true,
            firstName: true,
            lastName: true,
          }
        },
        createdBy: {
          select: {
            id: true,
            name: true,
            email: true,
            firstName: true,
            lastName: true,
          }
        },
        case: {
          select: {
            id: true,
            title: true,
            caseNumber: true,
          }
        },
      },
    });

    // Create activity logs for changes
    const activities = [];
    if (status && status !== currentTask.status) {
      activities.push({
        action: 'status_changed',
        description: `Status changed from ${currentTask.status} to ${status}`,
        oldValue: currentTask.status || undefined,
        newValue: status || undefined,
        userId: user.id,
        taskId: id,
      });
    }
    if (assignedToId && assignedToId !== currentTask.assignedToId) {
      activities.push({
        action: 'assigned',
        description: `Task reassigned`,
        oldValue: currentTask.assignedToId || undefined,
        newValue: assignedToId,
        userId: user.id,
        taskId: id,
      });
    }
    if (priority && priority !== currentTask.priority) {
      activities.push({
        action: 'priority_changed',
        description: `Priority changed from ${currentTask.priority} to ${priority}`,
        oldValue: currentTask.priority || undefined,
        newValue: priority || undefined,
        userId: user.id,
        taskId: id,
      });
    }

    if (activities.length > 0) {
      await prisma.taskActivity.createMany({
        data: activities,
      });
    }

    // Log task update
    await createAuditLog({
      action: 'TASK_UPDATE',
      caseId: currentTask.caseId || undefined,
      userId: user.id,
      diff: JSON.stringify({
        taskId: id,
        changes: updateData,
      }),
    });

    return NextResponse.json({ task: updatedTask });
  } catch (error: any) {
    console.error('Failed to update task:', error);
    return NextResponse.json(
      { error: error?.message || 'Internal Server Error' },
      { status: error?.status || 500 }
    );
  }
}

// DELETE - Delete task (ADMIN only)
export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== Role.ADMIN) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 });
    }

    const { id } = params;
    const prisma = await getPrisma();

    const task = await prisma.task.findUnique({
      where: { id },
      include: { case: true },
    });

    if (!task) {
      return NextResponse.json({ error: 'Task not found' }, { status: 404 });
    }

    await prisma.task.delete({
      where: { id },
    });

    // Log task deletion
    await createAuditLog({
      action: 'TASK_DELETE',
      caseId: task.caseId || undefined,
      userId: user.id,
      diff: JSON.stringify({
        taskId: id,
        title: task.title,
        deletedAt: new Date().toISOString(),
      }),
    });

    return NextResponse.json({ message: 'Task deleted successfully' });
  } catch (error: any) {
    console.error('Failed to delete task:', error);
    return NextResponse.json(
      { error: error?.message || 'Internal Server Error' },
      { status: error?.status || 500 }
    );
  }
}
