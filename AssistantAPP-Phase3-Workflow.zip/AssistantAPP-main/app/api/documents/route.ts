import { NextRequest, NextResponse } from 'next/server';
import { getPrisma } from '@/lib/db';
import { getCurrentUser, requireStaffOrAdmin } from "@/lib/rbac";
import { createAuditLog } from "@/lib/audit-log";
import { DocState, Role } from "@prisma/client";

export const dynamic = 'force-dynamic';

// GET - List documents with filtering and folder support
export async function GET(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const caseId = searchParams.get('caseId');
    const folder = searchParams.get('folder');
    const category = searchParams.get('category');
    const state = searchParams.get('state') as DocState | null;
    const search = searchParams.get('search');
    const sharedOnly = searchParams.get('shared') === 'true';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');

    if (!caseId) {
      return NextResponse.json({ error: 'caseId required' }, { status: 400 });
    }

    const skip = (page - 1) * limit;
    const prisma = await getPrisma();

    // Check case access
    const caseRecord = await prisma.case.findUnique({
      where: { id: caseId },
    });

    if (!caseRecord) {
      return NextResponse.json({ error: 'Case not found' }, { status: 404 });
    }

    // Check access permissions
    let hasAccess = false;
    if (user.role === Role.ADMIN) {
      hasAccess = true;
    } else if (user.role === Role.STAFF) {
      hasAccess = caseRecord.caseManagerId === user.id || caseRecord.lawyerId === user.id;
    } else if (user.role === Role.CLIENT) {
      hasAccess = caseRecord.clientId === user.id;
    }

    if (!hasAccess) {
      return NextResponse.json({ error: 'Access denied to case documents' }, { status: 403 });
    }

    let whereClause: any = { caseId };

    // Additional filters
    if (folder) {
      whereClause.folder = folder;
    }
    if (category) {
      whereClause.category = category;
    }
    if (state && Object.values(DocState).includes(state)) {
      whereClause.state = state;
    }
    if (search) {
      whereClause.OR = [
        { name: { contains: search } },
        { originalName: { contains: search } },
        { description: { contains: search } },
      ];
    }
    if (sharedOnly) {
      whereClause.isShared = true;
    }

    // For clients, only show documents they can access
    if (user.role === Role.CLIENT) {
      whereClause.OR = [
        { uploadedBy: user.id },
        { isShared: true },
        { 
          sharedWith: {
            path: `$`,
            array_contains: user.id
          }
        }
      ];
    }

    const [documents, totalCount] = await Promise.all([
      prisma.document.findMany({
        where: whereClause,
        include: {
          uploader: {
            select: {
              id: true,
              name: true,
              email: true,
              firstName: true,
              lastName: true,
            }
          },
          reviewer: {
            select: {
              id: true,
              name: true,
              email: true,
              firstName: true,
              lastName: true,
            }
          },
          _count: {
            select: {
              comments: true,
            }
          }
        },
        orderBy: [
          { folder: 'asc' },
          { createdAt: 'desc' },
        ],
        skip,
        take: limit,
      }),
      prisma.document.count({ where: whereClause }),
    ]);

    // Get folder structure
    const folders = await prisma.document.groupBy({
      by: ['folder'],
      where: { caseId, folder: { not: null } },
      _count: { folder: true },
    });

    // Get categories
    const categories = await prisma.document.groupBy({
      by: ['category'],
      where: { caseId, category: { not: null } },
      _count: { category: true },
    });

    // Parse JSON fields for documents
    const documentsWithParsedFields = documents.map(doc => ({
      ...doc,
      tags: doc.tags ? JSON.parse(doc.tags as string) : [],
      sharedWith: doc.sharedWith ? JSON.parse(doc.sharedWith as string) : [],
    }));

    return NextResponse.json({
      documents: documentsWithParsedFields,
      folders: folders.reduce((acc, f) => {
        acc[f.folder!] = f._count.folder;
        return acc;
      }, {} as Record<string, number>),
      categories: categories.reduce((acc, c) => {
        acc[c.category!] = c._count.category;
        return acc;
      }, {} as Record<string, number>),
      pagination: {
        page,
        limit,
        totalCount,
        totalPages: Math.ceil(totalCount / limit),
      },
    });
  } catch (error: any) {
    console.error("Failed to fetch documents:", error);
    return NextResponse.json(
      { error: error?.message || "Internal Server Error" },
      { status: error?.status || 500 }
    );
  }
}

// POST - Upload or manage documents
export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 });
    }

    const body = await req.json();
    const { action } = body;

    if (action === 'upload') {
      const {
        caseId,
        name,
        originalName,
        fileSize,
        mimeType,
        cloudPath,
        category,
        folder,
        description,
        tags,
        isShared,
        sharedWith,
      } = body;

      if (!caseId || !name || !cloudPath) {
        return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
      }

      const prisma = await getPrisma();

      // Check case access
      const caseRecord = await prisma.case.findUnique({
        where: { id: caseId },
      });

      if (!caseRecord) {
        return NextResponse.json({ error: 'Case not found' }, { status: 404 });
      }

      // Check upload permissions
      let canUpload = false;
      if (user.role === Role.ADMIN) {
        canUpload = true;
      } else if (user.role === Role.STAFF) {
        canUpload = caseRecord.caseManagerId === user.id || caseRecord.lawyerId === user.id;
      } else if (user.role === Role.CLIENT) {
        canUpload = caseRecord.clientId === user.id;
      }

      if (!canUpload) {
        return NextResponse.json({ error: 'Upload permission denied' }, { status: 403 });
      }

      const document = await prisma.document.create({
        data: {
          name,
          originalName: originalName || name,
          fileSize: fileSize || null,
          mimeType: mimeType || null,
          cloudPath,
          category: category || null,
          folder: folder || null,
          description: description || null,
          tags: tags ? JSON.stringify(tags) : undefined,
          isShared: isShared || false,
          sharedWith: sharedWith ? JSON.stringify(sharedWith) : undefined,
          uploadedBy: user.id,
          caseId,
          state: DocState.uploaded,
        },
        include: {
          uploader: {
            select: {
              id: true,
              name: true,
              email: true,
              firstName: true,
              lastName: true,
            }
          }
        },
      });

      // Log document upload
      await createAuditLog({
        action: 'DOCUMENT_UPLOAD',
        caseId,
        userId: user.id,
        diff: JSON.stringify({
          documentId: document.id,
          name: document.name,
          category: document.category,
          folder: document.folder,
        }),
      });

      return NextResponse.json({ document }, { status: 201 });
    }

    if (action === 'review') {
      const { documentId, state, rejectionReason } = body;
      
      if (!documentId || !state) {
        return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
      }

      requireStaffOrAdmin(user);

      if (!Object.values(DocState).includes(state)) {
        return NextResponse.json({ error: 'Invalid document state' }, { status: 400 });
      }

      const prisma = await getPrisma();

      const document = await prisma.document.findUnique({
        where: { id: documentId },
        include: { case: true },
      });

      if (!document) {
        return NextResponse.json({ error: 'Document not found' }, { status: 404 });
      }

      // Check review permissions
      let canReview = false;
      if (user.role === Role.ADMIN) {
        canReview = true;
      } else if (user.role === Role.STAFF) {
        canReview = document.case.caseManagerId === user.id || document.case.lawyerId === user.id;
      }

      if (!canReview) {
        return NextResponse.json({ error: 'Review permission denied' }, { status: 403 });
      }

      const updatedDocument = await prisma.document.update({
        where: { id: documentId },
        data: {
          state,
          reviewedBy: user.id,
          reviewedAt: new Date(),
          rejectionReason: state === DocState.rejected ? rejectionReason : null,
        },
        include: {
          uploader: {
            select: {
              id: true,
              name: true,
              email: true,
              firstName: true,
              lastName: true,
            }
          },
          reviewer: {
            select: {
              id: true,
              name: true,
              email: true,
              firstName: true,
              lastName: true,
            }
          }
        },
      });

      // Log document review
      await createAuditLog({
        action: 'DOCUMENT_REVIEW',
        caseId: document.caseId,
        userId: user.id,
        diff: JSON.stringify({
          documentId,
          state,
          rejectionReason,
        }),
      });

      return NextResponse.json({ document: updatedDocument });
    }

    return NextResponse.json({ error: 'Unsupported action' }, { status: 400 });
  } catch (error: any) {
    console.error('Failed to handle document request:', error);
    return NextResponse.json(
      { error: error?.message || 'Internal Server Error' },
      { status: error?.status || 500 }
    );
  }
}
