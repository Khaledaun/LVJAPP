
import { NextRequest, NextResponse } from "next/server";
import { getPrisma } from "@/lib/db";
import { getCurrentUser, requireStaffOrAdmin } from "@/lib/rbac";
import { createAuditLog } from "@/lib/audit-log";
import { DocState, Role } from "@prisma/client";

export const dynamic = "force-dynamic";

// GET - Get document by ID with details
export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 });
    }

    const { id } = params;
    const prisma = await getPrisma();

    const document = await prisma.document.findUnique({
      where: { id },
      include: {
        case: {
          include: {
            client: {
              select: {
                id: true,
                name: true,
                email: true,
              }
            }
          }
        },
        uploader: {
          select: {
            id: true,
            name: true,
            email: true,
            firstName: true,
            lastName: true,
            avatar: true,
          }
        },
        reviewer: {
          select: {
            id: true,
            name: true,
            email: true,
            firstName: true,
            lastName: true,
            avatar: true,
          }
        },
        comments: {
          include: {
            author: {
              select: {
                id: true,
                name: true,
                email: true,
                firstName: true,
                lastName: true,
                avatar: true,
                role: true,
              }
            }
          },
          orderBy: { createdAt: 'desc' },
        },
      },
    });

    if (!document) {
      return NextResponse.json({ error: 'Document not found' }, { status: 404 });
    }

    // Check access permissions
    let hasAccess = false;
    if (user.role === Role.ADMIN) {
      hasAccess = true;
    } else if (user.role === Role.STAFF) {
      hasAccess = document.case.caseManagerId === user.id || document.case.lawyerId === user.id;
    } else if (user.role === Role.CLIENT) {
      hasAccess = document.case.clientId === user.id || 
                 document.uploadedBy === user.id ||
                 document.isShared ||
                 (document.sharedWith && JSON.parse(document.sharedWith as string || '[]').includes(user.id));
    }

    if (!hasAccess) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 });
    }

    // Parse JSON fields
    const documentWithParsedFields = {
      ...document,
      tags: document.tags ? JSON.parse(document.tags as string) : [],
      sharedWith: document.sharedWith ? JSON.parse(document.sharedWith as string) : [],
    };

    return NextResponse.json({ document: documentWithParsedFields });
  } catch (error: any) {
    console.error("Failed to fetch document:", error);
    return NextResponse.json(
      { error: error?.message || "Internal Server Error" },
      { status: error?.status || 500 }
    );
  }
}

// PUT - Update document
export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await getCurrentUser();
    requireStaffOrAdmin(user);

    const { id } = params;
    const body = await req.json();
    const {
      name,
      description,
      category,
      folder,
      tags,
      isShared,
      sharedWith,
      state,
      rejectionReason,
    } = body;

    const prisma = await getPrisma();

    // Get current document
    const currentDocument = await prisma.document.findUnique({
      where: { id },
      include: { case: true },
    });

    if (!currentDocument) {
      return NextResponse.json({ error: 'Document not found' }, { status: 404 });
    }

    // Check permissions
    let hasAccess = false;
    if (user.role === Role.ADMIN) {
      hasAccess = true;
    } else if (user.role === Role.STAFF) {
      hasAccess = currentDocument.case.caseManagerId === user.id || 
                 currentDocument.case.lawyerId === user.id;
    }

    if (!hasAccess) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 });
    }

    // Validate state if provided
    if (state && !Object.values(DocState).includes(state)) {
      return NextResponse.json(
        { error: 'Invalid document state' },
        { status: 400 }
      );
    }

    // Prepare update data
    const updateData: any = {};
    if (name !== undefined) updateData.name = name;
    if (description !== undefined) updateData.description = description;
    if (category !== undefined) updateData.category = category;
    if (folder !== undefined) updateData.folder = folder;
    if (tags !== undefined) updateData.tags = JSON.stringify(tags);
    if (isShared !== undefined) updateData.isShared = isShared;
    if (sharedWith !== undefined) updateData.sharedWith = JSON.stringify(sharedWith);
    if (state !== undefined) {
      updateData.state = state;
      updateData.reviewedBy = user.id;
      updateData.reviewedAt = new Date();
      if (state === DocState.rejected) {
        updateData.rejectionReason = rejectionReason;
      }
    }

    const updatedDocument = await prisma.document.update({
      where: { id },
      data: updateData,
      include: {
        uploader: {
          select: {
            id: true,
            name: true,
            email: true,
            firstName: true,
            lastName: true,
          }
        },
        reviewer: {
          select: {
            id: true,
            name: true,
            email: true,
            firstName: true,
            lastName: true,
          }
        }
      },
    });

    // Log document update
    await createAuditLog({
      action: 'DOCUMENT_UPDATE',
      caseId: currentDocument.caseId,
      userId: user.id,
      diff: JSON.stringify({
        documentId: id,
        changes: updateData,
      }),
    });

    return NextResponse.json({ document: updatedDocument });
  } catch (error: any) {
    console.error('Failed to update document:', error);
    return NextResponse.json(
      { error: error?.message || 'Internal Server Error' },
      { status: error?.status || 500 }
    );
  }
}

// DELETE - Delete document (ADMIN only)
export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== Role.ADMIN) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 });
    }

    const { id } = params;
    const prisma = await getPrisma();

    const document = await prisma.document.findUnique({
      where: { id },
    });

    if (!document) {
      return NextResponse.json({ error: 'Document not found' }, { status: 404 });
    }

    await prisma.document.delete({
      where: { id },
    });

    // Log document deletion
    await createAuditLog({
      action: 'DOCUMENT_DELETE',
      caseId: document.caseId,
      userId: user.id,
      diff: JSON.stringify({
        documentId: id,
        name: document.name,
        deletedAt: new Date().toISOString(),
      }),
    });

    return NextResponse.json({ message: 'Document deleted successfully' });
  } catch (error: any) {
    console.error('Failed to delete document:', error);
    return NextResponse.json(
      { error: error?.message || 'Internal Server Error' },
      { status: error?.status || 500 }
    );
  }
}
