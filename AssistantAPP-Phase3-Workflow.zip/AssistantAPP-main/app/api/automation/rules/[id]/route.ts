

export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth/options';
import { requireAdmin, getCurrentUser } from '@/lib/rbac';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// GET /api/automation/rules/[id] - Get automation rule details
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    const user = await getCurrentUser();
    requireAdmin(user);

    const rule = await prisma.automationRule.findUnique({
      where: { id: params.id },
      include: {
        createdBy: { select: { name: true } },
        runs: {
          include: {
            case: { select: { caseNumber: true } },
            task: { select: { title: true } },
            document: { select: { name: true } }
          },
          orderBy: { executedAt: 'desc' },
          take: 20
        }
      }
    });

    if (!rule) {
      return NextResponse.json({ success: false, error: 'Automation rule not found' }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      data: rule
    });
  } catch (error: any) {
    console.error('Error getting automation rule:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to get automation rule' },
      { status: error.status || 500 }
    );
  }
}

// PUT /api/automation/rules/[id] - Update automation rule
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    const user = await getCurrentUser();
    requireAdmin(user);

    const body = await request.json();

    const rule = await prisma.automationRule.update({
      where: { id: params.id },
      data: {
        name: body.name,
        description: body.description,
        conditions: body.conditions,
        actions: body.actions,
        isActive: body.isActive,
        priority: body.priority
      }
    });

    return NextResponse.json({
      success: true,
      data: rule
    });
  } catch (error: any) {
    console.error('Error updating automation rule:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to update automation rule' },
      { status: error.status || 500 }
    );
  }
}

// DELETE /api/automation/rules/[id] - Delete automation rule
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    const user = await getCurrentUser();
    requireAdmin(user);

    await prisma.automationRule.delete({
      where: { id: params.id }
    });

    return NextResponse.json({
      success: true,
      message: 'Automation rule deleted successfully'
    });
  } catch (error: any) {
    console.error('Error deleting automation rule:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to delete automation rule' },
      { status: error.status || 500 }
    );
  }
}
