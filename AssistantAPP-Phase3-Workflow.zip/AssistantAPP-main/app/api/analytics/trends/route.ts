
export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth/options';
import { getCurrentUser, requireStaffOrAdmin } from '@/lib/rbac';
import { AnalyticsEngine } from '@/lib/analytics-engine';

// GET /api/analytics/trends - Get trend analysis for metrics
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    requireStaffOrAdmin(user);

    const { searchParams } = new URL(request.url);
    const metricKey = searchParams.get('metric');
    const periods = parseInt(searchParams.get('periods') || '6');
    const period = searchParams.get('period') as 'daily' | 'weekly' | 'monthly' || 'monthly';

    if (!metricKey) {
      return NextResponse.json({ success: false, error: 'Metric parameter required' }, { status: 400 });
    }

    const result = await AnalyticsEngine.generateTrendAnalysis(metricKey, periods, period);
    return NextResponse.json(result);
  } catch (error: any) {
    console.error('Error getting trend analysis:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to get trend analysis' },
      { status: error.status || 500 }
    );
  }
}
