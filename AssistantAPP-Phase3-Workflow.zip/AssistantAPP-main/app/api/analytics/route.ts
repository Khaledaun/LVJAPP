
export const dynamic = 'force-dynamic';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth/options';
import { requireStaffOrAdmin } from '@/lib/rbac';
import { AnalyticsEngine } from '@/lib/analytics-engine';

// GET /api/analytics - Get analytics metrics
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ success: false, error: 'Authentication required' }, { status: 401 });
    }

    // Simple role check for Phase 3
    if (!session.user?.role || !['STAFF', 'ADMIN'].includes(session.user.role)) {
      return NextResponse.json({ success: false, error: 'Insufficient permissions' }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const metricsParam = searchParams.get('metrics');
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');
    const caseTypes = searchParams.get('caseTypes')?.split(',');
    const userIds = searchParams.get('userIds')?.split(',');
    const cachePeriod = searchParams.get('cachePeriod') as 'daily' | 'weekly' | 'monthly' || 'daily';
    const dashboard = searchParams.get('dashboard') === 'true';

    // Dashboard summary metrics
    if (dashboard) {
      const filters = {
        startDate: startDate ? new Date(startDate) : undefined,
        endDate: endDate ? new Date(endDate) : undefined,
        caseTypes,
        userIds
      };

      const result = await AnalyticsEngine.getDashboardMetrics(filters);
      return NextResponse.json(result);
    }

    // Specific metrics
    if (!metricsParam) {
      return NextResponse.json({ success: false, error: 'Metrics parameter required' }, { status: 400 });
    }

    const metrics = metricsParam.split(',');
    const filters = {
      startDate: startDate ? new Date(startDate) : undefined,
      endDate: endDate ? new Date(endDate) : undefined,
      caseTypes,
      userIds
    };

    const result = await AnalyticsEngine.calculateMetrics(metrics, filters, cachePeriod);
    return NextResponse.json(result);
  } catch (error: any) {
    console.error('Error getting analytics:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to get analytics' },
      { status: error.status || 500 }
    );
  }
}
