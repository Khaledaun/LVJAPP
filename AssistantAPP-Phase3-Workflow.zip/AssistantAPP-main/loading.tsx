export default function Loading() {
  return <div className="p-4">Loading…</div>
}
