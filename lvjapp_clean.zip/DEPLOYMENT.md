
# LVJ Immigration Services - Deployment Guide

This guide covers various deployment options for the LVJ Immigration Services platform.

## 🚀 Quick Deployment Options

### Option 1: Vercel (Recommended)

Vercel provides the easiest deployment for Next.js applications with automatic CI/CD.

#### Steps:

1. **Push to GitHub**
```bash
git add .
git commit -m "Ready for deployment"
git push origin main
```

2. **Connect to Vercel**
- Visit [vercel.com](https://vercel.com)
- Import your GitHub repository
- Vercel will automatically detect Next.js

3. **Environment Variables**
Set these in Vercel dashboard:
```env
DATABASE_URL=your_production_database_url
NEXTAUTH_SECRET=your_production_secret_key
NEXTAUTH_URL=https://your-domain.vercel.app
AWS_REGION=us-west-2
AWS_BUCKET_NAME=your_production_bucket
AWS_FOLDER_PREFIX=prod/
NODE_ENV=production
```

4. **Deploy**
- Vercel will automatically build and deploy
- Your app will be available at `https://your-app.vercel.app`

### Option 2: Docker Deployment

#### Create Dockerfile
```dockerfile
FROM node:18-alpine AS base

# Install dependencies only when needed
FROM base AS deps
RUN apk add --no-cache libc6-compat
WORKDIR /app

COPY package.json package-lock.json* ./
RUN npm ci

# Rebuild the source code only when needed
FROM base AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .

# Generate Prisma client
RUN npx prisma generate

# Build the application
RUN npm run build

# Production image, copy all the files and run next
FROM base AS runner
WORKDIR /app

ENV NODE_ENV production

RUN addgroup --system --gid 1001 nodejs
RUN adduser --system --uid 1001 nextjs

COPY --from=builder /app/public ./public
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static

USER nextjs

EXPOSE 3000

ENV PORT 3000
ENV HOSTNAME "0.0.0.0"

CMD ["node", "server.js"]
```

#### Build and Run
```bash
# Build the image
docker build -t lvj-immigration .

# Run the container
docker run -p 3000:3000 \
  -e DATABASE_URL="your_database_url" \
  -e NEXTAUTH_SECRET="your_secret" \
  -e NEXTAUTH_URL="http://localhost:3000" \
  lvj-immigration
```

### Option 3: Traditional VPS/Server

#### Prerequisites
- Ubuntu 20.04+ or similar Linux distribution
- Node.js 18.18+
- PostgreSQL 13+
- Nginx (for reverse proxy)
- PM2 (for process management)

#### Steps:

1. **Server Setup**
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PostgreSQL
sudo apt install postgresql postgresql-contrib

# Install PM2
sudo npm install -g pm2

# Install Nginx
sudo apt install nginx
```

2. **Database Setup**
```bash
# Create database user
sudo -u postgres createuser --interactive
# Enter username: lvj_user
# Superuser: n
# Create databases: y
# Create roles: n

# Create database
sudo -u postgres createdb lvj_immigration

# Set password
sudo -u postgres psql
ALTER USER lvj_user PASSWORD 'secure_password';
\q
```

3. **Application Deployment**
```bash
# Clone repository
git clone <your-repo-url> /var/www/lvj-immigration
cd /var/www/lvj-immigration

# Install dependencies
npm install

# Set up environment
cp .env.example .env
# Edit .env with production values

# Generate Prisma client and run migrations
npx prisma generate
npx prisma migrate deploy

# Build application
npm run build

# Start with PM2
pm2 start npm --name "lvj-immigration" -- start
pm2 save
pm2 startup
```

4. **Nginx Configuration**
```nginx
# /etc/nginx/sites-available/lvj-immigration
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/lvj-immigration /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

5. **SSL Certificate (Let's Encrypt)**
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

## 🔧 Environment Configuration

### Production Environment Variables

```env
# Database
DATABASE_URL="postgresql://username:password@host:5432/database"

# Authentication
NEXTAUTH_SECRET="your-super-secure-secret-key-minimum-32-characters"
NEXTAUTH_URL="https://your-production-domain.com"

# AWS S3
AWS_REGION=us-west-2
AWS_BUCKET_NAME=your-production-bucket
AWS_FOLDER_PREFIX=prod/

# Application
NODE_ENV=production
PORT=3000

# Optional: Disable development features
SKIP_AUTH=0
SKIP_DB=0
```

### Development vs Production

| Feature | Development | Production |
|---------|-------------|------------|
| Database | Local PostgreSQL | Cloud PostgreSQL |
| File Storage | Local/Mock | AWS S3 |
| Authentication | Can be skipped | Always enabled |
| Logging | Console | File/Service |
| Error Handling | Detailed | User-friendly |
| Performance | Development mode | Optimized build |

## 📊 Database Migration

### Production Migration Strategy

1. **Backup Current Database**
```bash
pg_dump -h hostname -U username -d database_name > backup.sql
```

2. **Run Migrations**
```bash
npx prisma migrate deploy
```

3. **Verify Migration**
```bash
npx prisma db pull
npx prisma generate
```

### Zero-Downtime Deployment

1. **Blue-Green Deployment**
```bash
# Deploy to staging environment
# Test thoroughly
# Switch traffic from blue to green
# Keep blue as rollback option
```

2. **Rolling Updates**
```bash
# Update one instance at a time
# Health check before proceeding
# Rollback if issues detected
```

## 🔍 Monitoring & Logging

### Application Monitoring

1. **Health Check Endpoint**
```typescript
// app/api/health/route.ts
export async function GET() {
  return Response.json({ 
    status: 'healthy', 
    timestamp: new Date().toISOString() 
  });
}
```

2. **PM2 Monitoring**
```bash
pm2 monit
pm2 logs lvj-immigration
pm2 restart lvj-immigration
```

3. **Nginx Logs**
```bash
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log
```

### Performance Monitoring

1. **Next.js Analytics**
```bash
npm install @vercel/analytics
```

2. **Database Monitoring**
```sql
-- Check slow queries
SELECT query, mean_time, calls 
FROM pg_stat_statements 
ORDER BY mean_time DESC 
LIMIT 10;
```

## 🔐 Security Checklist

### Pre-Deployment Security

- [ ] Environment variables secured
- [ ] Database credentials rotated
- [ ] SSL certificates configured
- [ ] Firewall rules configured
- [ ] Regular security updates scheduled
- [ ] Backup strategy implemented
- [ ] Access logs monitored
- [ ] Rate limiting configured

### Post-Deployment Security

- [ ] Security headers configured
- [ ] HTTPS enforced
- [ ] Database access restricted
- [ ] File upload restrictions
- [ ] Input validation enabled
- [ ] Error messages sanitized
- [ ] Audit logging enabled

## 🚨 Troubleshooting

### Common Issues

1. **Build Failures**
```bash
# Clear cache and rebuild
rm -rf .next node_modules
npm install
npm run build
```

2. **Database Connection Issues**
```bash
# Test database connection
npx prisma db pull
```

3. **Memory Issues**
```bash
# Increase Node.js memory limit
NODE_OPTIONS="--max-old-space-size=4096" npm run build
```

4. **Permission Issues**
```bash
# Fix file permissions
sudo chown -R www-data:www-data /var/www/lvj-immigration
sudo chmod -R 755 /var/www/lvj-immigration
```

### Performance Issues

1. **Slow Page Loads**
- Check database query performance
- Optimize images and assets
- Enable caching
- Use CDN for static assets

2. **High Memory Usage**
- Monitor with `pm2 monit`
- Check for memory leaks
- Optimize database queries
- Implement pagination

## 📈 Scaling Considerations

### Horizontal Scaling

1. **Load Balancer Configuration**
```nginx
upstream lvj_backend {
    server 127.0.0.1:3000;
    server 127.0.0.1:3001;
    server 127.0.0.1:3002;
}

server {
    location / {
        proxy_pass http://lvj_backend;
    }
}
```

2. **Database Scaling**
- Read replicas for read-heavy operations
- Connection pooling
- Query optimization
- Caching layer (Redis)

### Vertical Scaling

- Increase server resources (CPU, RAM)
- Optimize application performance
- Database tuning
- CDN implementation

## 🔄 Backup & Recovery

### Automated Backups

```bash
#!/bin/bash
# backup.sh
DATE=$(date +%Y%m%d_%H%M%S)
pg_dump -h localhost -U username -d lvj_immigration > backup_$DATE.sql
aws s3 cp backup_$DATE.sql s3://your-backup-bucket/
rm backup_$DATE.sql
```

### Recovery Process

1. **Database Recovery**
```bash
psql -h hostname -U username -d database_name < backup.sql
```

2. **Application Recovery**
```bash
git checkout last-known-good-commit
npm install
npm run build
pm2 restart lvj-immigration
```

---

**For additional support, contact the development team or create an issue in the repository.**
