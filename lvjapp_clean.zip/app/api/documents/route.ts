
import { NextResponse } from 'next/server';
import { getPrisma } from '@/lib/db';
import { assertCaseAccess } from '@/lib/rbac';
import { uploadFile } from '@/lib/s3';
import { Document } from '@prisma/client';

export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const caseId = searchParams.get('caseId');
    const status = searchParams.get('status');

    if (!caseId) {
      return NextResponse.json({ error: 'Case ID is required' }, { status: 400 });
    }

    // Verify access to case
    await assertCaseAccess(caseId);

    const prisma = await getPrisma();

    const whereClause: any = { caseId };
    if (status) {
      whereClause.status = status;
    }

    const documents = await prisma.document.findMany({
      where: whereClause,
      include: {
        documentType: true,
        comments: {
          orderBy: { createdAt: 'desc' },
          take: 1 // Latest comment only for list view
        },
        versions: {
          orderBy: { versionNumber: 'desc' },
          take: 1 // Latest version only for list view
        }
      },
      orderBy: [
        { isRequired: 'desc' },
        { documentType: { order: 'asc' } },
        { createdAt: 'desc' }
      ]
    });

    // Group documents by category for better organization
    type DocumentWithRelations = typeof documents[0];
    const categorizedDocs = documents.reduce((acc: Record<string, DocumentWithRelations[]>, doc: DocumentWithRelations) => {
      const category = doc.category || 'Other';
      if (!acc[category]) {
        acc[category] = [];
      }
      // acc[category] is guaranteed to be defined here
      acc[category]!.push(doc);
      return acc;
    }, {} as Record<string, DocumentWithRelations[]>);

    return NextResponse.json({
      success: true,
      data: {
        documents,
        categorizedDocuments: categorizedDocs,
        summary: {
          total: documents.length,
          pending: documents.filter((d: Document) => d.status === 'pending_review').length,
          approved: documents.filter((d: Document) => d.status === 'approved').length,
          rejected: documents.filter((d: Document) => d.status === 'rejected').length,
          missing: documents.filter((d: Document) => d.status === 'missing').length,
        }
      }
    });

  } catch (error) {
    console.error('Error fetching documents:', error);
    return NextResponse.json(
      { error: 'Failed to fetch documents' },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    const formData = await req.formData();
    const file = formData.get('file') as File;
    const caseId = formData.get('caseId') as string;
    const documentName = formData.get('documentName') as string;
    const category = formData.get('category') as string;
    const documentTypeId = formData.get('documentTypeId') as string;
    const uploadedBy = formData.get('uploadedBy') as string;

    if (!file || !caseId || !documentName) {
      return NextResponse.json(
        { error: 'File, case ID, and document name are required' },
        { status: 400 }
      );
    }

    // Verify access to case
    await assertCaseAccess(caseId);

    // Validate file size and type
    const maxSize = 10 * 1024 * 1024; // 10MB
    if (file.size > maxSize) {
      return NextResponse.json(
        { error: 'File size must be less than 10MB' },
        { status: 400 }
      );
    }

    const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/gif', 
                         'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    if (!allowedTypes.includes(file.type)) {
      return NextResponse.json(
        { error: 'Invalid file type. Please upload PDF, image, or document files.' },
        { status: 400 }
      );
    }

    const prisma = await getPrisma();

    // Upload file to S3
    const buffer = Buffer.from(await file.arrayBuffer());
    const cloudStoragePath = await uploadFile(buffer, file.name);

    // Create document record
    const document = await prisma.document.create({
      data: {
        name: documentName,
        fileName: file.name,
        mimeType: file.type,
        fileSize: file.size,
        cloudStoragePath,
        version: 1,
        state: 'uploaded',
        status: 'pending_review',
        caseId,
        documentTypeId: documentTypeId || null,
        category: category || 'General',
        uploadedBy: uploadedBy || 'client',
        tags: []
      },
      include: {
        documentType: true,
        comments: true,
        versions: true
      }
    });

    // Create initial version record
    await prisma.documentVersion.create({
      data: {
        documentId: document.id,
        versionNumber: 1,
        fileName: file.name,
        cloudStoragePath,
        fileSize: file.size,
        mimeType: file.type,
        uploadedBy: uploadedBy || 'client',
        notes: 'Initial upload'
      }
    });

    return NextResponse.json({
      success: true,
      data: document,
      message: 'Document uploaded successfully'
    }, { status: 201 });

  } catch (error) {
    console.error('Error uploading document:', error);
    return NextResponse.json(
      { error: 'Failed to upload document' },
      { status: 500 }
    );
  }
}
