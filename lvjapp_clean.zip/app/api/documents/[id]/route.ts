
import { NextResponse } from 'next/server';
import { getPrisma } from '@/lib/db';
import { assertCaseAccess } from '@/lib/rbac';
import { downloadFile, deleteFile } from '@/lib/s3';

export const dynamic = 'force-dynamic';

export async function GET(req: Request, { params }: { params: { id: string } }) {
  try {
    const documentId = params.id;
    const { searchParams } = new URL(req.url);
    const action = searchParams.get('action'); // 'download' or 'view'

    const prisma = await getPrisma();

    const document = await prisma.document.findUnique({
      where: { id: documentId },
      include: {
        documentType: true,
        comments: {
          orderBy: { createdAt: 'desc' }
        },
        versions: {
          orderBy: { versionNumber: 'desc' }
        },
        case: {
          select: { id: true, caseNumber: true, title: true }
        }
      }
    });

    if (!document) {
      return NextResponse.json({ error: 'Document not found' }, { status: 404 });
    }

    // Verify access to case
    await assertCaseAccess(document.caseId);

    if (action === 'download' && document.cloudStoragePath) {
      // Generate signed URL for download
      const downloadUrl = await downloadFile(document.cloudStoragePath);
      return NextResponse.json({
        success: true,
        data: {
          document,
          downloadUrl
        }
      });
    }

    return NextResponse.json({
      success: true,
      data: document
    });

  } catch (error) {
    console.error('Error fetching document:', error);
    return NextResponse.json(
      { error: 'Failed to fetch document' },
      { status: 500 }
    );
  }
}

export async function PUT(req: Request, { params }: { params: { id: string } }) {
  try {
    const documentId = params.id;
    const body = await req.json();
    const { action, status, rejectionReason, reviewedBy, notes } = body;

    const prisma = await getPrisma();

    const document = await prisma.document.findUnique({
      where: { id: documentId },
      select: { caseId: true }
    });

    if (!document) {
      return NextResponse.json({ error: 'Document not found' }, { status: 404 });
    }

    // Verify access to case
    await assertCaseAccess(document.caseId);

    const updateData: any = {
      updatedAt: new Date()
    };

    // Handle different actions
    if (action === 'approve') {
      updateData.status = 'approved';
      updateData.state = 'approved';
      updateData.reviewedBy = reviewedBy;
      updateData.reviewedAt = new Date();
    } else if (action === 'reject') {
      updateData.status = 'rejected';
      updateData.state = 'rejected';
      updateData.rejectionReason = rejectionReason;
      updateData.reviewedBy = reviewedBy;
      updateData.reviewedAt = new Date();
    } else if (action === 'request_revision') {
      updateData.status = 'revision_required';
      updateData.rejectionReason = rejectionReason;
      updateData.reviewedBy = reviewedBy;
      updateData.reviewedAt = new Date();
    } else if (status) {
      updateData.status = status;
    }

    const updatedDocument = await prisma.document.update({
      where: { id: documentId },
      data: updateData,
      include: {
        documentType: true,
        comments: {
          orderBy: { createdAt: 'desc' }
        },
        versions: {
          orderBy: { versionNumber: 'desc' }
        }
      }
    });

    // Add comment if notes provided
    if (notes) {
      await prisma.documentComment.create({
        data: {
          documentId,
          content: notes,
          createdBy: reviewedBy || 'system',
          isInternal: action === 'approve' || action === 'reject'
        }
      });
    }

    return NextResponse.json({
      success: true,
      data: updatedDocument,
      message: `Document ${action || 'updated'} successfully`
    });

  } catch (error) {
    console.error('Error updating document:', error);
    return NextResponse.json(
      { error: 'Failed to update document' },
      { status: 500 }
    );
  }
}

export async function DELETE(req: Request, { params }: { params: { id: string } }) {
  try {
    const documentId = params.id;

    const prisma = await getPrisma();

    const document = await prisma.document.findUnique({
      where: { id: documentId },
      select: { caseId: true, cloudStoragePath: true }
    });

    if (!document) {
      return NextResponse.json({ error: 'Document not found' }, { status: 404 });
    }

    // Verify access to case
    await assertCaseAccess(document.caseId);

    // Delete file from S3 if exists
    if (document.cloudStoragePath) {
      try {
        await deleteFile(document.cloudStoragePath);
      } catch (error) {
        console.warn('Failed to delete file from S3:', error);
        // Continue with database deletion even if S3 deletion fails
      }
    }

    // Delete document record (cascade will delete comments and versions)
    await prisma.document.delete({
      where: { id: documentId }
    });

    return NextResponse.json({
      success: true,
      message: 'Document deleted successfully'
    });

  } catch (error) {
    console.error('Error deleting document:', error);
    return NextResponse.json(
      { error: 'Failed to delete document' },
      { status: 500 }
    );
  }
}
