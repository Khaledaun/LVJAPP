
import { NextResponse } from 'next/server';
import { getPrisma } from '@/lib/db';
import { assertCaseAccess } from '@/lib/rbac';

export const dynamic = 'force-dynamic';

export async function GET(req: Request, { params }: { params: { id: string } }) {
  try {
    const documentId = params.id;

    const prisma = await getPrisma();

    // First get the document to verify case access
    const document = await prisma.document.findUnique({
      where: { id: documentId },
      select: { caseId: true }
    });

    if (!document) {
      return NextResponse.json({ error: 'Document not found' }, { status: 404 });
    }

    // Verify access to case
    await assertCaseAccess(document.caseId);

    const comments = await prisma.documentComment.findMany({
      where: { documentId },
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json({
      success: true,
      data: comments
    });

  } catch (error) {
    console.error('Error fetching comments:', error);
    return NextResponse.json(
      { error: 'Failed to fetch comments' },
      { status: 500 }
    );
  }
}

export async function POST(req: Request, { params }: { params: { id: string } }) {
  try {
    const documentId = params.id;
    const body = await req.json();
    const { content, isInternal = false, createdBy } = body;

    if (!content?.trim() || !createdBy) {
      return NextResponse.json(
        { error: 'Comment content and creator are required' },
        { status: 400 }
      );
    }

    const prisma = await getPrisma();

    // First get the document to verify case access
    const document = await prisma.document.findUnique({
      where: { id: documentId },
      select: { caseId: true }
    });

    if (!document) {
      return NextResponse.json({ error: 'Document not found' }, { status: 404 });
    }

    // Verify access to case
    await assertCaseAccess(document.caseId);

    const comment = await prisma.documentComment.create({
      data: {
        documentId,
        content: content.trim(),
        isInternal,
        createdBy
      }
    });

    return NextResponse.json({
      success: true,
      data: comment,
      message: 'Comment added successfully'
    }, { status: 201 });

  } catch (error) {
    console.error('Error creating comment:', error);
    return NextResponse.json(
      { error: 'Failed to create comment' },
      { status: 500 }
    );
  }
}
