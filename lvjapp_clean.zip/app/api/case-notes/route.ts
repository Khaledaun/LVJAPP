
import { NextResponse } from 'next/server';
import { getPrisma } from '@/lib/db';
import { assertCaseAccess } from '@/lib/rbac';
import { getServerSession } from 'next-auth';
import { authOptions } from "@/lib/auth/options";

export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const caseId = searchParams.get('caseId');
    const type = searchParams.get('type');
    const isPrivate = searchParams.get('isPrivate');

    if (!caseId) {
      return NextResponse.json({ error: 'Case ID is required' }, { status: 400 });
    }

    // Verify access to case
    await assertCaseAccess(caseId);

    const prisma = await getPrisma();

    const whereClause: any = { caseId };
    if (type) {
      whereClause.type = type;
    }
    if (isPrivate !== null) {
      whereClause.isPrivate = isPrivate === 'true';
    }

    const caseNotes = await prisma.caseNote.findMany({
      where: whereClause,
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json({
      success: true,
      data: {
        notes: caseNotes,
        summary: {
          total: caseNotes.length,
          private: caseNotes.filter((note: any) => note.isPrivate).length,
          public: caseNotes.filter((note: any) => !note.isPrivate).length,
          types: {
            general: caseNotes.filter((note: any) => note.type === 'general').length,
            legal: caseNotes.filter((note: any) => note.type === 'legal').length,
            financial: caseNotes.filter((note: any) => note.type === 'financial').length,
            todo: caseNotes.filter((note: any) => note.type === 'todo').length,
          }
        }
      }
    });

  } catch (error) {
    console.error('Error fetching case notes:', error);
    return NextResponse.json(
      { error: 'Failed to fetch case notes' },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const {
      caseId,
      content,
      type = 'general',
      isPrivate = false
    } = body;

    if (!caseId || !content) {
      return NextResponse.json(
        { error: 'Case ID and content are required' },
        { status: 400 }
      );
    }

    // Verify access to case
    await assertCaseAccess(caseId);

    const prisma = await getPrisma();

    const newNote = await prisma.caseNote.create({
      data: {
        caseId,
        content,
        type,
        isPrivate,
        createdBy: session.user.id,
      }
    });

    return NextResponse.json({
      success: true,
      data: newNote,
      message: 'Case note created successfully'
    }, { status: 201 });

  } catch (error) {
    console.error('Error creating case note:', error);
    return NextResponse.json(
      { error: 'Failed to create case note' },
      { status: 500 }
    );
  }
}
