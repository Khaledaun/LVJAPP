
import { NextResponse } from 'next/server';
import { getPrisma } from '@/lib/db';
import { getServerSession } from 'next-auth';
import { authOptions } from "@/lib/auth/options";

export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const isRead = searchParams.get('isRead');
    const type = searchParams.get('type');
    const priority = searchParams.get('priority');

    const prisma = await getPrisma();

    const whereClause: any = { userId: session.user.id };
    if (isRead !== null) {
      whereClause.isRead = isRead === 'true';
    }
    if (type) {
      whereClause.type = type;
    }
    if (priority) {
      whereClause.priority = priority;
    }

    const notifications = await prisma.notification.findMany({
      where: whereClause,
      include: {
        case: {
          select: {
            id: true,
            title: true,
            caseNumber: true,
          }
        }
      },
      orderBy: [
        { priority: 'desc' },
        { createdAt: 'desc' }
      ],
      take: 50 // Limit to 50 most recent notifications
    });

    return NextResponse.json({
      success: true,
      data: {
        notifications,
        summary: {
          total: notifications.length,
          unread: notifications.filter((n: any) => !n.isRead).length,
          urgent: notifications.filter((n: any) => n.priority === 'urgent').length,
          high: notifications.filter((n: any) => n.priority === 'high').length,
        }
      }
    });

  } catch (error) {
    console.error('Error fetching notifications:', error);
    return NextResponse.json(
      { error: 'Failed to fetch notifications' },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const {
      userId,
      title,
      message,
      type,
      priority = 'medium',
      actionUrl,
      metadata,
      caseId
    } = body;

    if (!userId || !title || !message) {
      return NextResponse.json(
        { error: 'User ID, title, and message are required' },
        { status: 400 }
      );
    }

    const prisma = await getPrisma();

    const newNotification = await prisma.notification.create({
      data: {
        userId,
        title,
        message,
        type,
        priority,
        actionUrl,
        metadata,
        caseId,
      }
    });

    return NextResponse.json({
      success: true,
      data: newNotification,
      message: 'Notification created successfully'
    }, { status: 201 });

  } catch (error) {
    console.error('Error creating notification:', error);
    return NextResponse.json(
      { error: 'Failed to create notification' },
      { status: 500 }
    );
  }
}
