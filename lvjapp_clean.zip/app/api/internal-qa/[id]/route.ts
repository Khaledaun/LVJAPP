
import { NextResponse } from 'next/server';
import { getPrisma } from '@/lib/db';
import { getServerSession } from 'next-auth';
import { authOptions } from "@/lib/auth/options";

export const dynamic = 'force-dynamic';

export async function PUT(req: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const {
      answer,
      status,
      priority,
      tags
    } = body;

    const prisma = await getPrisma();

    const updateData: any = {
      updatedAt: new Date(),
    };

    if (answer !== undefined) {
      updateData.answer = answer;
      updateData.answeredBy = session.user.id;
      updateData.answeredAt = new Date();
      updateData.status = 'answered';
    }

    if (status !== undefined) {
      updateData.status = status;
    }

    if (priority !== undefined) {
      updateData.priority = priority;
    }

    if (tags !== undefined) {
      updateData.tags = tags;
    }

    const updatedQA = await prisma.internalQA.update({
      where: { id: params.id },
      data: updateData
    });

    return NextResponse.json({
      success: true,
      data: updatedQA,
      message: 'Internal Q&A updated successfully'
    });

  } catch (error) {
    console.error('Error updating internal Q&A:', error);
    return NextResponse.json(
      { error: 'Failed to update internal Q&A' },
      { status: 500 }
    );
  }
}

export async function DELETE(req: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const prisma = await getPrisma();

    await prisma.internalQA.delete({
      where: { id: params.id }
    });

    return NextResponse.json({
      success: true,
      message: 'Internal Q&A deleted successfully'
    });

  } catch (error) {
    console.error('Error deleting internal Q&A:', error);
    return NextResponse.json(
      { error: 'Failed to delete internal Q&A' },
      { status: 500 }
    );
  }
}
