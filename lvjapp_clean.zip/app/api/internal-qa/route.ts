
import { NextResponse } from 'next/server';
import { getPrisma } from '@/lib/db';
import { assertCaseAccess } from '@/lib/rbac';
import { getServerSession } from 'next-auth';
import { authOptions } from "@/lib/auth/options";

export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const caseId = searchParams.get('caseId');
    const status = searchParams.get('status');
    const priority = searchParams.get('priority');

    if (!caseId) {
      return NextResponse.json({ error: 'Case ID is required' }, { status: 400 });
    }

    // Verify access to case
    await assertCaseAccess(caseId);

    const prisma = await getPrisma();

    const whereClause: any = { caseId };
    if (status) {
      whereClause.status = status;
    }
    if (priority) {
      whereClause.priority = priority;
    }

    const internalQAs = await prisma.internalQA.findMany({
      where: whereClause,
      orderBy: [
        { priority: 'desc' },
        { createdAt: 'desc' }
      ]
    });

    return NextResponse.json({
      success: true,
      data: {
        qas: internalQAs,
        summary: {
          total: internalQAs.length,
          open: internalQAs.filter((qa: any) => qa.status === 'open').length,
          in_progress: internalQAs.filter((qa: any) => qa.status === 'in_progress').length,
          answered: internalQAs.filter((qa: any) => qa.status === 'answered').length,
          closed: internalQAs.filter((qa: any) => qa.status === 'closed').length,
        }
      }
    });

  } catch (error) {
    console.error('Error fetching internal Q&As:', error);
    return NextResponse.json(
      { error: 'Failed to fetch internal Q&As' },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const {
      caseId,
      question,
      answer,
      priority = 'medium',
      status = 'open',
      tags = []
    } = body;

    if (!caseId || !question) {
      return NextResponse.json(
        { error: 'Case ID and question are required' },
        { status: 400 }
      );
    }

    // Verify access to case
    await assertCaseAccess(caseId);

    const prisma = await getPrisma();

    const newQA = await prisma.internalQA.create({
      data: {
        caseId,
        question,
        answer: answer || null,
        priority,
        status: answer ? 'answered' : status,
        askedBy: session.user.id,
        answeredBy: answer ? session.user.id : null,
        tags,
        answeredAt: answer ? new Date() : null,
      }
    });

    return NextResponse.json({
      success: true,
      data: newQA,
      message: 'Internal Q&A created successfully'
    }, { status: 201 });

  } catch (error) {
    console.error('Error creating internal Q&A:', error);
    return NextResponse.json(
      { error: 'Failed to create internal Q&A' },
      { status: 500 }
    );
  }
}
