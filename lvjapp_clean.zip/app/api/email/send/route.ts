
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { EmailQueueManager } from '../../../../lib/integrations/email/email-queue';
import { authOptions } from '../../auth/[...nextauth]/route';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const { type, data } = await request.json();

    if (!type || !data) {
      return NextResponse.json(
        { error: 'Email type and data are required' },
        { status: 400 }
      );
    }

    let jobId;

    switch (type) {
      case 'single':
        jobId = await EmailQueueManager.addSingleEmail(data);
        break;

      case 'bulk':
        jobId = await EmailQueueManager.addBulkEmail(data);
        break;

      case 'template':
        jobId = await EmailQueueManager.addTemplateEmail(
          data.template,
          data.recipients,
          data.delay
        );
        break;

      default:
        return NextResponse.json(
          { error: 'Invalid email type' },
          { status: 400 }
        );
    }

    return NextResponse.json({
      success: true,
      jobId: jobId.id,
      message: 'Email queued successfully',
    });
  } catch (error) {
    console.error('Send email error:', error);
    return NextResponse.json(
      { error: 'Failed to queue email' },
      { status: 500 }
    );
  }
}
