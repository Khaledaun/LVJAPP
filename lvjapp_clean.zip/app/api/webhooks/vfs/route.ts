
import { NextRequest, NextResponse } from 'next/server';
import { headers } from 'next/headers';
import { EmailQueueManager } from '../../../../lib/integrations/email/email-queue';
import crypto from 'crypto';

export async function POST(request: NextRequest) {
  try {
    const body = await request.text();
    const signature = headers().get('x-vfs-signature');
    
    // Verify webhook signature (if VFS provides one)
    if (signature && !verifyVFSSignature(body, signature)) {
      return NextResponse.json(
        { error: 'Invalid signature' },
        { status: 401 }
      );
    }

    const event = JSON.parse(body);
    console.log(`Received VFS webhook: ${event.type}`);

    // Handle different VFS event types
    switch (event.type) {
      case 'application.status_updated':
        await handleApplicationStatusUpdate(event.data);
        break;

      case 'appointment.scheduled':
        await handleAppointmentScheduled(event.data);
        break;

      case 'appointment.cancelled':
        await handleAppointmentCancelled(event.data);
        break;

      case 'document.approved':
        await handleDocumentApproved(event.data);
        break;

      case 'document.rejected':
        await handleDocumentRejected(event.data);
        break;

      case 'visa.approved':
        await handleVisaApproved(event.data);
        break;

      case 'visa.rejected':
        await handleVisaRejected(event.data);
        break;

      default:
        console.log(`Unhandled VFS event type: ${event.type}`);
    }

    return NextResponse.json({ received: true });
  } catch (error) {
    console.error('VFS webhook error:', error);
    return NextResponse.json(
      { error: 'Webhook handler failed' },
      { status: 400 }
    );
  }
}

function verifyVFSSignature(payload: string, signature: string): boolean {
  const secret = process.env.VFS_WEBHOOK_SECRET;
  if (!secret) return true; // Skip verification if no secret configured

  const expectedSignature = crypto
    .createHmac('sha256', secret)
    .update(payload)
    .digest('hex');

  return signature === `sha256=${expectedSignature}`;
}

async function handleApplicationStatusUpdate(data: any) {
  console.log('Application status updated:', data);
  
  // Update application status in database
  // Send status update email to applicant
  if (data.applicant?.email) {
    await EmailQueueManager.addTemplateEmail('application-status', [{
      email: data.applicant.email,
      data: {
        name: data.applicant.name,
        applicationId: data.applicationId,
        status: data.newStatus,
        dashboardUrl: `${process.env.NEXTAUTH_URL}/dashboard/applications/${data.applicationId}`,
      },
    }]);
  }
}

async function handleAppointmentScheduled(data: any) {
  console.log('Appointment scheduled:', data);
  
  // Send appointment confirmation email
  if (data.applicant?.email) {
    await EmailQueueManager.addTemplateEmail('appointment-reminder', [{
      email: data.applicant.email,
      data: {
        name: data.applicant.name,
        date: data.appointment.date,
        time: data.appointment.time,
        location: data.appointment.location,
        type: data.appointment.type,
      },
    }]);
  }
}

async function handleAppointmentCancelled(data: any) {
  console.log('Appointment cancelled:', data);
  
  // Send appointment cancellation email
  if (data.applicant?.email) {
    await EmailQueueManager.addSingleEmail({
      to: data.applicant.email,
      subject: 'Appointment Cancelled - LVJ Immigration Services',
      html: `
        <h1>Appointment Cancelled</h1>
        <p>Dear ${data.applicant.name},</p>
        <p>Your appointment scheduled for ${data.appointment.date} at ${data.appointment.time} has been cancelled.</p>
        <p>Reason: ${data.reason || 'Not specified'}</p>
        <p>Please contact us to reschedule your appointment.</p>
      `,
    });
  }
}

async function handleDocumentApproved(data: any) {
  console.log('Document approved:', data);
  
  // Send document approval notification
  if (data.applicant?.email) {
    await EmailQueueManager.addSingleEmail({
      to: data.applicant.email,
      subject: 'Document Approved - LVJ Immigration Services',
      html: `
        <h1>Document Approved</h1>
        <p>Dear ${data.applicant.name},</p>
        <p>Your document "${data.document.name}" has been approved.</p>
        <p>Application ID: ${data.applicationId}</p>
        <p>You can view the status in your dashboard.</p>
      `,
    });
  }
}

async function handleDocumentRejected(data: any) {
  console.log('Document rejected:', data);
  
  // Send document rejection notification
  if (data.applicant?.email) {
    await EmailQueueManager.addSingleEmail({
      to: data.applicant.email,
      subject: 'Document Requires Attention - LVJ Immigration Services',
      html: `
        <h1>Document Requires Attention</h1>
        <p>Dear ${data.applicant.name},</p>
        <p>Your document "${data.document.name}" requires attention.</p>
        <p>Reason: ${data.rejectionReason}</p>
        <p>Please upload a corrected version in your dashboard.</p>
        <p>Application ID: ${data.applicationId}</p>
      `,
    });
  }
}

async function handleVisaApproved(data: any) {
  console.log('Visa approved:', data);
  
  // Send visa approval notification
  if (data.applicant?.email) {
    await EmailQueueManager.addSingleEmail({
      to: data.applicant.email,
      subject: '🎉 Visa Approved - LVJ Immigration Services',
      html: `
        <h1>Congratulations! Your Visa Has Been Approved</h1>
        <p>Dear ${data.applicant.name},</p>
        <p>We are delighted to inform you that your visa application has been approved!</p>
        <p>Application ID: ${data.applicationId}</p>
        <p>Visa Type: ${data.visaType}</p>
        <p>Please check your dashboard for next steps and collection details.</p>
        <p>Thank you for choosing LVJ Immigration Services.</p>
      `,
    });
  }
}

async function handleVisaRejected(data: any) {
  console.log('Visa rejected:', data);
  
  // Send visa rejection notification
  if (data.applicant?.email) {
    await EmailQueueManager.addSingleEmail({
      to: data.applicant.email,
      subject: 'Visa Application Update - LVJ Immigration Services',
      html: `
        <h1>Visa Application Update</h1>
        <p>Dear ${data.applicant.name},</p>
        <p>We regret to inform you that your visa application has not been approved at this time.</p>
        <p>Application ID: ${data.applicationId}</p>
        <p>Reason: ${data.rejectionReason}</p>
        <p>Please contact our support team to discuss your options and next steps.</p>
      `,
    });
  }
}
