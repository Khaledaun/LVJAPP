
import { NextRequest, NextResponse } from 'next/server';
import { headers } from 'next/headers';
import StripeService from '../../../../lib/integrations/payments/stripe-service';
import { EmailQueueManager } from '../../../../lib/integrations/email/email-queue';

export async function POST(request: NextRequest) {
  try {
    const body = await request.text();
    const signature = headers().get('stripe-signature');

    if (!signature) {
      return NextResponse.json(
        { error: 'Missing stripe-signature header' },
        { status: 400 }
      );
    }

    const stripe = StripeService.getInstance();
    const event = stripe.verifyWebhookSignature(body, signature);

    console.log(`Received Stripe webhook: ${event.type}`);

    // Handle different event types
    switch (event.type) {
      case 'payment_intent.succeeded':
        await handlePaymentSucceeded(event.data.object);
        break;

      case 'payment_intent.payment_failed':
        await handlePaymentFailed(event.data.object);
        break;

      case 'customer.subscription.created':
        await handleSubscriptionCreated(event.data.object);
        break;

      case 'customer.subscription.updated':
        await handleSubscriptionUpdated(event.data.object);
        break;

      case 'customer.subscription.deleted':
        await handleSubscriptionCancelled(event.data.object);
        break;

      case 'invoice.payment_succeeded':
        await handleInvoicePaymentSucceeded(event.data.object);
        break;

      case 'invoice.payment_failed':
        await handleInvoicePaymentFailed(event.data.object);
        break;

      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    return NextResponse.json({ received: true });
  } catch (error) {
    console.error('Stripe webhook error:', error);
    return NextResponse.json(
      { error: 'Webhook handler failed' },
      { status: 400 }
    );
  }
}

async function handlePaymentSucceeded(paymentIntent: any) {
  console.log('Payment succeeded:', paymentIntent.id);
  
  // Update application status in database
  // Send confirmation email
  if (paymentIntent.metadata?.email && paymentIntent.metadata?.customerName) {
    await EmailQueueManager.addSingleEmail({
      to: paymentIntent.metadata.email,
      subject: 'Payment Confirmation - LVJ Immigration Services',
      html: `
        <h1>Payment Confirmed</h1>
        <p>Dear ${paymentIntent.metadata.customerName},</p>
        <p>Your payment of $${(paymentIntent.amount / 100).toFixed(2)} has been successfully processed.</p>
        <p>Payment ID: ${paymentIntent.id}</p>
        <p>Thank you for choosing LVJ Immigration Services.</p>
      `,
    });
  }
}

async function handlePaymentFailed(paymentIntent: any) {
  console.log('Payment failed:', paymentIntent.id);
  
  // Send failure notification email
  if (paymentIntent.metadata?.email && paymentIntent.metadata?.customerName) {
    await EmailQueueManager.addSingleEmail({
      to: paymentIntent.metadata.email,
      subject: 'Payment Failed - LVJ Immigration Services',
      html: `
        <h1>Payment Failed</h1>
        <p>Dear ${paymentIntent.metadata.customerName},</p>
        <p>Unfortunately, your payment of $${(paymentIntent.amount / 100).toFixed(2)} could not be processed.</p>
        <p>Please try again or contact our support team for assistance.</p>
        <p>Payment ID: ${paymentIntent.id}</p>
      `,
    });
  }
}

async function handleSubscriptionCreated(subscription: any) {
  console.log('Subscription created:', subscription.id);
  
  // Update user subscription status in database
  // Send welcome email for subscription
}

async function handleSubscriptionUpdated(subscription: any) {
  console.log('Subscription updated:', subscription.id);
  
  // Update subscription details in database
}

async function handleSubscriptionCancelled(subscription: any) {
  console.log('Subscription cancelled:', subscription.id);
  
  // Update subscription status in database
  // Send cancellation confirmation email
}

async function handleInvoicePaymentSucceeded(invoice: any) {
  console.log('Invoice payment succeeded:', invoice.id);
  
  // Send invoice payment confirmation
}

async function handleInvoicePaymentFailed(invoice: any) {
  console.log('Invoice payment failed:', invoice.id);
  
  // Send payment failure notification
  // Potentially retry payment or suspend service
}
