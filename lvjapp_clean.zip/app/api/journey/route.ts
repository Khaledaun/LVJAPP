
import { NextResponse } from 'next/server';
import { getPrisma } from '@/lib/db';
import { assertCaseAccess } from '@/lib/rbac';
import { JourneyStage } from '@prisma/client';

export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const caseId = searchParams.get('caseId');

    if (!caseId) {
      return NextResponse.json({ error: 'Case ID is required' }, { status: 400 });
    }

    // Verify access to case
    await assertCaseAccess(caseId);

    const prisma = await getPrisma();

    // Get journey stages for the case
    const journeyStages = await prisma.journeyStage.findMany({
      where: { caseId },
      orderBy: { order: 'asc' },
      include: {
        template: true
      }
    });

    // Calculate completion percentage
    const completedStages = journeyStages.filter((stage: JourneyStage) => stage.status === 'completed').length;
    const totalStages = journeyStages.length;
    const completionPercentage = totalStages > 0 ? Math.round((completedStages / totalStages) * 100) : 0;

    // Get case details for context
    const caseDetails = await prisma.case.findUnique({
      where: { id: caseId },
      select: {
        title: true,
        caseNumber: true,
        overallStatus: true,
        completionPercentage: true,
        visaType: true,
        destinationCountry: true
      }
    });

    return NextResponse.json({
      success: true,
      data: {
        case: caseDetails,
        stages: journeyStages,
        completionPercentage,
        totalStages,
        completedStages
      }
    });

  } catch (error) {
    console.error('Error fetching journey data:', error);
    return NextResponse.json(
      { error: 'Failed to fetch journey data' },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { caseId, stageId, action, notes } = body;

    if (!caseId || !stageId || !action) {
      return NextResponse.json(
        { error: 'Case ID, stage ID, and action are required' },
        { status: 400 }
      );
    }

    // Verify access to case
    await assertCaseAccess(caseId);

    const prisma = await getPrisma();

    // Update stage status based on action
    const updateData: any = {
      updatedAt: new Date()
    };

    if (notes) {
      updateData.notes = notes;
    }

    switch (action) {
      case 'start':
        updateData.status = 'in_progress';
        updateData.startedAt = new Date();
        break;
      case 'complete':
        updateData.status = 'completed';
        updateData.completedAt = new Date();
        break;
      case 'block':
        updateData.status = 'blocked';
        break;
      case 'skip':
        updateData.status = 'skipped';
        updateData.completedAt = new Date();
        break;
      default:
        return NextResponse.json(
          { error: 'Invalid action' },
          { status: 400 }
        );
    }

    const updatedStage = await prisma.journeyStage.update({
      where: { id: stageId },
      data: updateData
    });

    // Update overall case completion percentage
    const allStages = await prisma.journeyStage.findMany({
      where: { caseId }
    });

    const completed = allStages.filter((s: JourneyStage) => s.status === 'completed' || s.status === 'skipped').length;
    const newCompletionPercentage = Math.round((completed / allStages.length) * 100);

    await prisma.case.update({
      where: { id: caseId },
      data: { 
        completionPercentage: newCompletionPercentage,
        currentStageId: action === 'complete' || action === 'skip' 
          ? getNextStageId(allStages, stageId)
          : stageId
      }
    });

    return NextResponse.json({
      success: true,
      data: {
        stage: updatedStage,
        completionPercentage: newCompletionPercentage
      }
    });

  } catch (error) {
    console.error('Error updating journey stage:', error);
    return NextResponse.json(
      { error: 'Failed to update journey stage' },
      { status: 500 }
    );
  }
}

function getNextStageId(stages: JourneyStage[], currentStageId: string): string | null {
  const currentStage = stages.find(s => s.id === currentStageId);
  if (!currentStage) return null;

  const nextStage = stages.find(s => s.order === currentStage.order + 1 && s.status === 'not_started');
  return nextStage?.id || null;
}
