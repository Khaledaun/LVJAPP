'use client';
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  FileText, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  Users,
  Folder as Cases,
  TrendingUp,
  Plus,
  Eye
} from 'lucide-react';
import JourneyTracker from '@/components/journey/JourneyTracker';
import DocumentList from '@/components/documents/DocumentList';

interface DashboardStats {
  totalCases: number;
  activeCases: number;
  completedCases: number;
  pendingDocuments: number;
  approvedDocuments: number;
  totalDocuments: number;
}

interface RecentCase {
  id: string;
  title: string;
  caseNumber: string;
  overallStatus: string;
  completionPercentage: number;
  client?: {
    name: string;
    email: string;
  };
  updatedAt: string;
}

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentCases, setRecentCases] = useState<RecentCase[]>([]);
  const [selectedCaseId, setSelectedCaseId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadDashboardData = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Fetch cases data
      const casesRes = await fetch('/api/cases');
      const casesData = await casesRes.json();
      
      if (casesData.cases) {
        const cases = casesData.cases;
        setRecentCases(cases.slice(0, 5)); // Show 5 most recent cases
        
        if (cases.length > 0 && !selectedCaseId) {
          setSelectedCaseId(cases[0].id);
        }
        
        // Calculate stats (simplified version - in real app you'd have dedicated API)
        const stats: DashboardStats = {
          totalCases: cases.length,
          activeCases: cases.filter((c: any) => 
            c.overallStatus !== 'approved' && c.overallStatus !== 'denied'
          ).length,
          completedCases: cases.filter((c: any) => 
            c.overallStatus === 'approved'
          ).length,
          // Mock document stats for now
          pendingDocuments: Math.floor(cases.length * 1.5),
          approvedDocuments: Math.floor(cases.length * 2.2),
          totalDocuments: Math.floor(cases.length * 3.8)
        };
        
        setStats(stats);
      }
    } catch (err) {
      console.error('Error loading dashboard data:', err);
      setError('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDashboardData();
  }, []);

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'approved': return 'bg-green-100 text-green-800';
      case 'denied': return 'bg-red-100 text-red-800';
      case 'in_review': return 'bg-blue-100 text-blue-800';
      case 'documents_pending': return 'bg-yellow-100 text-yellow-800';
      case 'submitted': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
          <span className="ml-2">Loading dashboard...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="p-6">
            <div className="text-red-600 text-center">
              <AlertCircle className="inline w-5 h-5 mr-2" />
              {error}
              <Button onClick={loadDashboardData} className="ml-4" variant="outline" size="sm">
                Retry
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-8">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Immigration Case Dashboard</h1>
          <p className="text-muted-foreground">
            Monitor your cases, track journey progress, and manage documents
          </p>
        </div>
        
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          New Case
        </Button>
      </div>

      {/* Stats Cards */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-2">
                  <Cases className="w-8 h-8 text-blue-600" />
                  <div>
                    <p className="text-2xl font-bold">{stats.totalCases}</p>
                    <p className="text-xs text-muted-foreground">Total Cases</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-2">
                  <Clock className="w-8 h-8 text-yellow-600" />
                  <div>
                    <p className="text-2xl font-bold">{stats.activeCases}</p>
                    <p className="text-xs text-muted-foreground">Active Cases</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-8 h-8 text-green-600" />
                  <div>
                    <p className="text-2xl font-bold">{stats.completedCases}</p>
                    <p className="text-xs text-muted-foreground">Completed</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-2">
                  <FileText className="w-8 h-8 text-gray-600" />
                  <div>
                    <p className="text-2xl font-bold">{stats.totalDocuments}</p>
                    <p className="text-xs text-muted-foreground">Total Docs</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-2">
                  <Clock className="w-8 h-8 text-orange-600" />
                  <div>
                    <p className="text-2xl font-bold">{stats.pendingDocuments}</p>
                    <p className="text-xs text-muted-foreground">Pending Review</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-8 h-8 text-green-600" />
                  <div>
                    <p className="text-2xl font-bold">{stats.approvedDocuments}</p>
                    <p className="text-xs text-muted-foreground">Approved Docs</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      )}

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Cases Sidebar */}
        <div className="lg:col-span-1 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Cases className="w-5 h-5 mr-2" />
                Recent Cases
              </CardTitle>
            </CardHeader>
            <CardContent>
              {recentCases.length > 0 ? (
                <div className="space-y-3">
                  {recentCases.map((case_, index) => (
                    <motion.div
                      key={case_.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className={`p-3 border rounded-lg cursor-pointer transition-colors hover:bg-gray-50 ${
                        selectedCaseId === case_.id ? 'border-blue-500 bg-blue-50' : 'border-gray-200'
                      }`}
                      onClick={() => setSelectedCaseId(case_.id)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold text-sm truncate">{case_.title}</h4>
                          <p className="text-xs text-muted-foreground">{case_.caseNumber}</p>
                          {case_.client && (
                            <p className="text-xs text-muted-foreground truncate">
                              {case_.client.name}
                            </p>
                          )}
                        </div>
                        <div className="flex flex-col items-end space-y-1">
                          <Badge 
                            variant="secondary" 
                            className={`text-xs ${getStatusColor(case_.overallStatus)}`}
                          >
                            {case_.overallStatus.replace('_', ' ').toUpperCase()}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {case_.completionPercentage}% complete
                          </span>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Cases className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-sm text-muted-foreground">No cases found</p>
                  <Button size="sm" className="mt-2">
                    <Plus className="w-4 h-4 mr-2" />
                    Create First Case
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Main Dashboard Content */}
        <div className="lg:col-span-2">
          {selectedCaseId ? (
            <Tabs defaultValue="journey" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="journey" className="flex items-center space-x-2">
                  <TrendingUp className="w-4 h-4" />
                  <span>Journey Progress</span>
                </TabsTrigger>
                <TabsTrigger value="documents" className="flex items-center space-x-2">
                  <FileText className="w-4 h-4" />
                  <span>Documents</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="journey" className="mt-6">
                <JourneyTracker caseId={selectedCaseId} />
              </TabsContent>

              <TabsContent value="documents" className="mt-6">
                <DocumentList caseId={selectedCaseId} userRole="ADMIN" />
              </TabsContent>
            </Tabs>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Eye className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-600 mb-2">
                  Select a Case to View Details
                </h3>
                <p className="text-gray-500">
                  Choose a case from the sidebar to view its journey progress and documents
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
