
import { useTranslations } from 'next-intl';
import Link from 'next/link';
import { LanguageSwitcher } from '@/components/ui/language-switcher';

export default function Home({ params: { locale } }: { params: { locale: string } }) {
  const t = useTranslations('common');

  return (
    <main className='p-6 space-y-4'>
      <div className="flex justify-between items-start">
        <div>
          <h1 className='text-2xl font-semibold'>LVJ Immigration Services</h1>
          <p className='text-sm text-muted-foreground'>
            Welcome! Jump into the cases list:
          </p>
        </div>
        <LanguageSwitcher currentLocale={locale} />
      </div>
      
      <Link href={`/${locale}/cases`} className='underline underline-offset-4'>
        {t('cases')}
      </Link>
    </main>
  );
}
