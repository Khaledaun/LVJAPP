
'use client';

import React from 'react';
import { useTranslations } from 'next-intl';
import PaymentTracker from '@/components/payments/PaymentTracker';
import { LanguageSwitcher } from '@/components/ui/language-switcher';

export default function PaymentsPage({ params: { locale } }: { params: { locale: string } }) {
  const t = useTranslations('payments');

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex justify-between items-center p-6">
        <h1 className="text-3xl font-bold">{t('title')}</h1>
        <LanguageSwitcher currentLocale={locale} />
      </div>
      <div className="px-6">
        <PaymentTracker />
      </div>
    </div>
  );
}
