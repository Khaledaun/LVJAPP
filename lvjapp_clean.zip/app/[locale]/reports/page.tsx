
'use client';

import React from 'react';
import { useTranslations } from 'next-intl';
import AdvancedAnalytics from '@/components/analytics/AdvancedAnalytics';
import { LanguageSwitcher } from '@/components/ui/language-switcher';

export default function ReportsPage({ params: { locale } }: { params: { locale: string } }) {
  const t = useTranslations('reports');

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex justify-end p-4">
        <LanguageSwitcher currentLocale={locale} />
      </div>
      <AdvancedAnalytics />
    </div>
  );
}
