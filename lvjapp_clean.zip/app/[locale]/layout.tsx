
import type { Metadata } from 'next';
import { NextIntlClientProvider } from 'next-intl';
import { getMessages } from 'next-intl/server';
import { notFound } from 'next/navigation';
import { Suspense } from 'react';
import Providers from '../providers';
import { ErrorBoundary } from '@/components/Boundary';
import '../globals.css';

const locales = ['en', 'ar', 'pt'];

export const metadata: Metadata = {
  title: 'LVJ Immigration Services',
  description: 'Comprehensive immigration case management platform',
};

export default async function LocaleLayout({
  children,
  params: { locale }
}: {
  children: React.ReactNode;
  params: { locale: string };
}) {
  // Validate that the incoming `locale` parameter is valid
  if (!locales.includes(locale as any)) notFound();

  // Providing all messages to the client
  // side is the easiest way to get started
  const messages = await getMessages();

  return (
    <html lang={locale} dir={locale === 'ar' ? 'rtl' : 'ltr'}>
      <body className={locale === 'ar' ? 'rtl' : 'ltr'}>
        <ErrorBoundary
          fallback={
            <div className='p-4 text-red-600'>App failed to render.</div>
          }
        >
          <NextIntlClientProvider messages={messages}>
            <Providers>
              <Suspense fallback={<div className='p-4'>Loading…</div>}>
                {children}
              </Suspense>
            </Providers>
          </NextIntlClientProvider>
        </ErrorBoundary>
      </body>
    </html>
  );
}

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}
