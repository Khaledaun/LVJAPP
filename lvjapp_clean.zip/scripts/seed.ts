import { PrismaClient, Role, CaseStatus, StageStatus, DocumentStatus, DocState } from '../.prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Start seeding database...');

  try {
    // Create admin user
    const adminUser = await prisma.user.upsert({
      where: { email: 'admin@lvj.local' },
      update: {},
      create: {
        email: 'admin@lvj.local',
        name: 'LVJ Admin',
        role: Role.ADMIN,
        password: 'password123', // In a real app, this should be hashed
      },
    });
    console.log(`✅ Created/updated admin user: ${adminUser.email}`);

    // Create Document Types
    console.log('📄 Creating document types...');
    
    const documentTypes = [
      {
        name: 'Passport',
        description: 'Valid passport document',
        category: 'Identity Documents',
        isRequired: true,
        acceptedFormats: ['pdf', 'jpg', 'png'],
        maxFileSize: 5 * 1024 * 1024,
        instructions: 'Please upload a clear copy of your passport bio page',
        order: 1
      },
      {
        name: 'Birth Certificate',
        description: 'Official birth certificate',
        category: 'Identity Documents',
        isRequired: true,
        acceptedFormats: ['pdf', 'jpg', 'png'],
        maxFileSize: 5 * 1024 * 1024,
        instructions: 'Please upload an official birth certificate',
        order: 2
      },
      {
        name: 'Educational Certificates',
        description: 'Degree certificates and transcripts',
        category: 'Education & Qualifications',
        isRequired: true,
        acceptedFormats: ['pdf', 'jpg', 'png'],
        maxFileSize: 10 * 1024 * 1024,
        instructions: 'Please upload all relevant educational certificates',
        order: 3
      },
      {
        name: 'Employment Letter',
        description: 'Letter from current or future employer',
        category: 'Employment Documents',
        isRequired: false,
        acceptedFormats: ['pdf', 'doc', 'docx'],
        maxFileSize: 5 * 1024 * 1024,
        instructions: 'Please upload employment verification letter',
        order: 4
      },
      {
        name: 'Bank Statements',
        description: 'Recent bank statements (last 3 months)',
        category: 'Financial Documents',
        isRequired: true,
        acceptedFormats: ['pdf'],
        maxFileSize: 10 * 1024 * 1024,
        instructions: 'Please upload bank statements for the last 3 months',
        order: 5
      },
      {
        name: 'Medical Examination',
        description: 'Medical examination report',
        category: 'Medical Records',
        isRequired: false,
        acceptedFormats: ['pdf'],
        maxFileSize: 5 * 1024 * 1024,
        instructions: 'Please upload medical examination report if required',
        order: 6
      }
    ];

    for (const docType of documentTypes) {
      await prisma.documentType.upsert({
        where: { name: docType.name },
        update: {},
        create: docType
      });
    }
    console.log(`✅ Created ${documentTypes.length} document types`);

    // Create Journey Templates
    console.log('🗺️ Creating journey templates...');
    
    const journeyTemplates = [
      {
        name: 'Student Visa - USA',
        description: 'F-1 Student Visa application process',
        visaType: 'F-1 Student',
        country: 'United States',
        isActive: true
      },
      {
        name: 'Work Visa - Canada',
        description: 'Work permit application for Canada',
        visaType: 'Work Permit',
        country: 'Canada',
        isActive: true
      },
      {
        name: 'Tourist Visa - UK',
        description: 'Standard visitor visa for UK',
        visaType: 'Standard Visitor',
        country: 'United Kingdom',
        isActive: true
      }
    ];

    const createdTemplates = [];
    for (const template of journeyTemplates) {
      const created = await prisma.journeyTemplate.upsert({
        where: { name: template.name },
        update: {},
        create: template
      });
      createdTemplates.push(created);
    }
    console.log(`✅ Created ${createdTemplates.length} journey templates`);

    // Create Journey Stage Templates for Student Visa USA
    console.log('📋 Creating journey stage templates...');
    
    const studentVisaStages = [
      {
        title: 'Initial Consultation',
        description: 'Meet with immigration advisor to discuss your case',
        order: 1,
        isRequired: true,
        estimatedDays: 1,
        dependsOnStages: [],
        requiredDocuments: []
      },
      {
        title: 'Document Collection',
        description: 'Gather all required documents for the application',
        order: 2,
        isRequired: true,
        estimatedDays: 7,
        dependsOnStages: [],
        requiredDocuments: ['Passport', 'Birth Certificate', 'Educational Certificates']
      },
      {
        title: 'Application Preparation',
        description: 'Complete and review visa application forms',
        order: 3,
        isRequired: true,
        estimatedDays: 3,
        dependsOnStages: [],
        requiredDocuments: ['Employment Letter', 'Bank Statements']
      },
      {
        title: 'Application Submission',
        description: 'Submit completed application to embassy/consulate',
        order: 4,
        isRequired: true,
        estimatedDays: 1,
        dependsOnStages: [],
        requiredDocuments: []
      },
      {
        title: 'Biometrics Appointment',
        description: 'Attend biometrics appointment',
        order: 5,
        isRequired: true,
        estimatedDays: 14,
        dependsOnStages: [],
        requiredDocuments: []
      },
      {
        title: 'Interview Preparation',
        description: 'Prepare for visa interview',
        order: 6,
        isRequired: true,
        estimatedDays: 7,
        dependsOnStages: [],
        requiredDocuments: []
      },
      {
        title: 'Visa Interview',
        description: 'Attend visa interview at embassy/consulate',
        order: 7,
        isRequired: true,
        estimatedDays: 1,
        dependsOnStages: [],
        requiredDocuments: []
      },
      {
        title: 'Decision & Collection',
        description: 'Receive decision and collect passport',
        order: 8,
        isRequired: true,
        estimatedDays: 10,
        dependsOnStages: [],
        requiredDocuments: []
      }
    ];

    for (const stage of studentVisaStages) {
      await prisma.journeyStageTemplate.create({
        data: {
          ...stage,
          templateId: createdTemplates[0].id
        }
      });
    }
    console.log(`✅ Created ${studentVisaStages.length} stage templates`);

    // Create Sample Cases with Journey Stages
    console.log('📂 Creating sample cases...');
    
    const sampleCases = [
      {
        title: 'Student Visa Application - John Smith',
        caseNumber: 'LVJ-2024-001',
        totalFee: 5000,
        currency: 'USD',
        applicantName: 'John Smith',
        applicantEmail: 'john.smith@email.com',
        overallStatus: CaseStatus.documents_pending,
        stage: 'Document Collection',
        urgencyLevel: 'STANDARD',
        completionPercentage: 25,
        visaType: 'F-1 Student',
        destinationCountry: 'United States',
        journeyTemplateId: createdTemplates[0].id
      },
      {
        title: 'Work Permit Application - Sarah Johnson',
        caseNumber: 'LVJ-2024-002',
        totalFee: 7500,
        currency: 'USD',
        applicantName: 'Sarah Johnson',
        applicantEmail: 'sarah.johnson@email.com',
        overallStatus: CaseStatus.in_review,
        stage: 'Application Review',
        urgencyLevel: 'HIGH',
        completionPercentage: 60,
        visaType: 'Work Permit',
        destinationCountry: 'Canada',
        journeyTemplateId: createdTemplates[1].id
      },
      {
        title: 'Tourist Visa - Michael Brown',
        caseNumber: 'LVJ-2024-003',
        totalFee: 2000,
        currency: 'USD',
        applicantName: 'Michael Brown',
        applicantEmail: 'michael.brown@email.com',
        overallStatus: CaseStatus.new,
        stage: 'Initial Consultation',
        urgencyLevel: 'STANDARD',
        completionPercentage: 10,
        visaType: 'Standard Visitor',
        destinationCountry: 'United Kingdom',
        journeyTemplateId: createdTemplates[2].id
      }
    ];

    for (const caseData of sampleCases) {
      const createdCase = await prisma.case.upsert({
        where: { caseNumber: caseData.caseNumber },
        update: {},
        create: caseData
      });

      // Create journey stages for Student Visa case only (for demonstration)
      if (caseData.caseNumber === 'LVJ-2024-001') {
        for (const [index, stageTemplate] of studentVisaStages.entries()) {
          const stageStatus: StageStatus = 
            index < 2 ? StageStatus.completed :
            index === 2 ? StageStatus.in_progress :
            StageStatus.not_started;

          await prisma.journeyStage.create({
            data: {
              title: stageTemplate.title,
              description: stageTemplate.description,
              order: stageTemplate.order,
              status: stageStatus,
              startedAt: index <= 2 ? new Date() : null,
              completedAt: index < 2 ? new Date() : null,
              estimatedDays: stageTemplate.estimatedDays,
              isRequired: stageTemplate.isRequired,
              dependsOnStages: stageTemplate.dependsOnStages,
              requiredDocuments: stageTemplate.requiredDocuments,
              caseId: createdCase.id
            }
          });
        }
      }

      // Create some sample documents for the first case
      if (caseData.caseNumber === 'LVJ-2024-001') {
        const sampleDocuments = [
          {
            name: 'Passport Copy',
            fileName: 'passport_john_smith.pdf',
            mimeType: 'application/pdf',
            fileSize: 1024000,
            cloudStoragePath: 'mock/path/passport_john_smith.pdf',
            version: 1,
            state: DocState.approved,
            status: DocumentStatus.approved,
            category: 'Identity Documents',
            isRequired: true,
            tags: ['identity'],
            uploadedBy: 'client',
            reviewedBy: 'staff',
            reviewedAt: new Date(),
            caseId: createdCase.id
          },
          {
            name: 'Educational Certificate',
            fileName: 'degree_certificate.pdf',
            mimeType: 'application/pdf',
            fileSize: 2048000,
            cloudStoragePath: 'mock/path/degree_certificate.pdf',
            version: 1,
            state: DocState.uploaded,
            status: DocumentStatus.pending_review,
            category: 'Education & Qualifications',
            isRequired: true,
            tags: ['education'],
            uploadedBy: 'client',
            caseId: createdCase.id
          }
        ];

        for (const docData of sampleDocuments) {
          const document = await prisma.document.create({
            data: docData
          });

          // Create document version
          await prisma.documentVersion.create({
            data: {
              documentId: document.id,
              versionNumber: 1,
              fileName: docData.fileName,
              cloudStoragePath: docData.cloudStoragePath,
              fileSize: docData.fileSize,
              mimeType: docData.mimeType,
              uploadedBy: docData.uploadedBy,
              notes: 'Initial upload'
            }
          });

          // Add comments for approved documents
          if (document.status === DocumentStatus.approved) {
            await prisma.documentComment.create({
              data: {
                documentId: document.id,
                content: 'Document approved. All information is clear and valid.',
                isInternal: false,
                createdBy: 'staff'
              }
            });
          }
        }
      }
    }
    console.log(`✅ Created ${sampleCases.length} sample cases`);

    console.log('🎉 Seeding completed successfully!')
    console.log(`📊 Summary:`)
    console.log(`   • 1 admin user`)
    console.log(`   • ${documentTypes.length} document types`)
    console.log(`   • ${journeyTemplates.length} journey templates`)
    console.log(`   • ${studentVisaStages.length} stage templates`)
    console.log(`   • ${sampleCases.length} sample cases with journey stages`)
    console.log(`   • Sample documents and comments`)
    
  } catch (error) {
    console.error('❌ Error during seeding:', error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

main();
