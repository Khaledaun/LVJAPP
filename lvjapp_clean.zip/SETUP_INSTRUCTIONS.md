
# LVJ Immigration Services - Setup Instructions

## Quick Start Guide

This repository contains the cleaned source code for the LVJ Immigration Services platform, optimized for GitHub deployment. Follow these steps to set up the application locally or deploy it to production.

## Prerequisites

- **Node.js**: Version 18.0 or higher
- **npm**: Version 8.0 or higher (comes with Node.js)
- **Database**: PostgreSQL 13+ or compatible cloud database
- **Docker** (optional): For containerized deployment

## Local Development Setup

### 1. Clone and Install Dependencies

```bash
# Clone the repository
git clone <your-github-repo-url>
cd lvj-immigration-services

# Install dependencies
npm install
```

### 2. Environment Configuration

```bash
# Copy environment template
cp .env.example .env.local

# Edit the environment file with your configurations
nano .env.local
```

**Required Environment Variables:**
```env
# Database
DATABASE_URL="postgresql://username:password@localhost:5432/lvjapp"

# NextAuth.js
NEXTAUTH_URL="http://localhost:3000"
NEXTAUTH_SECRET="your-secret-key-here"

# OAuth Providers (if using)
GOOGLE_CLIENT_ID="your-google-client-id"
GOOGLE_CLIENT_SECRET="your-google-client-secret"

# Email Service (if using)
EMAIL_SERVER_HOST="smtp.gmail.com"
EMAIL_SERVER_PORT=587
EMAIL_SERVER_USER="your-email@gmail.com"
EMAIL_SERVER_PASSWORD="your-app-password"
EMAIL_FROM="noreply@yourdomain.com"

# File Upload (if using AWS S3)
AWS_ACCESS_KEY_ID="your-aws-access-key"
AWS_SECRET_ACCESS_KEY="your-aws-secret-key"
AWS_REGION="us-east-1"
AWS_S3_BUCKET="your-s3-bucket"

# Sentry (optional - for error tracking)
SENTRY_DSN="your-sentry-dsn"
```

### 3. Database Setup

```bash
# Generate Prisma client
npx prisma generate

# Run database migrations
npx prisma migrate deploy

# Seed the database (optional)
npm run seed
```

### 4. Start Development Server

```bash
# Start the development server
npm run dev

# The application will be available at http://localhost:3000
```

## Production Deployment

### Option 1: Docker Deployment

```bash
# Build and run with Docker Compose
docker-compose up -d

# The application will be available at http://localhost:3000
```

### Option 2: Vercel Deployment

1. Push your code to GitHub
2. Connect your GitHub repository to Vercel
3. Configure environment variables in Vercel dashboard
4. Deploy automatically on push to main branch

### Option 3: Manual Server Deployment

```bash
# Install dependencies
npm ci --only=production

# Build the application
npm run build

# Start the production server
npm start
```

## Available Scripts

```bash
# Development
npm run dev          # Start development server
npm run build        # Build for production
npm start           # Start production server

# Database
npm run db:migrate  # Run database migrations
npm run db:seed     # Seed database with initial data
npm run db:studio   # Open Prisma Studio (database GUI)

# Testing
npm test            # Run tests
npm run test:watch  # Run tests in watch mode
npm run test:coverage # Run tests with coverage

# Code Quality
npm run lint        # Run ESLint
npm run lint:fix    # Fix ESLint issues
npm run format      # Format code with Prettier

# Type Checking
npm run type-check  # Run TypeScript type checking
```

## Database Schema

The application uses Prisma ORM with PostgreSQL. Key models include:

- **User**: User authentication and profiles
- **Application**: Immigration application forms
- **Document**: File uploads and document management
- **Appointment**: Scheduling system
- **Payment**: Payment processing records
- **Notification**: System notifications

## Key Features

- 🌐 **Multi-language Support**: English, Portuguese, Arabic
- 🔐 **Authentication**: NextAuth.js with multiple providers
- 📱 **Responsive Design**: Mobile-first approach
- 🗄️ **Database**: PostgreSQL with Prisma ORM
- 📄 **Document Management**: File upload and processing
- 💳 **Payment Integration**: Stripe payment processing
- 📧 **Email Notifications**: Automated email system
- 🔍 **Search & Filtering**: Advanced application search
- 📊 **Analytics Dashboard**: Admin analytics and reporting
- 🐳 **Docker Support**: Containerized deployment
- 🚀 **Performance**: Optimized for production

## Troubleshooting

### Common Issues

1. **Database Connection Error**
   ```bash
   # Check your DATABASE_URL in .env.local
   # Ensure PostgreSQL is running
   # Run: npx prisma db push
   ```

2. **Build Errors**
   ```bash
   # Clear Next.js cache
   rm -rf .next
   npm run build
   ```

3. **Prisma Client Issues**
   ```bash
   # Regenerate Prisma client
   npx prisma generate
   ```

4. **Environment Variables Not Loading**
   ```bash
   # Ensure .env.local exists and has correct format
   # Restart development server after changes
   ```

### Getting Help

- Check the `DEPLOYMENT.md` file for detailed deployment instructions
- Review the `IMPLEMENTATION_SUMMARY.md` for technical details
- Check the `LVJ_VC_AUDIT/` directory for security and compliance documentation

## Security Considerations

- Never commit `.env` files with real credentials
- Use strong, unique secrets for `NEXTAUTH_SECRET`
- Enable HTTPS in production
- Regularly update dependencies
- Review the security documentation in `LVJ_VC_AUDIT/docs/security-compliance/`

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Run tests and linting
5. Submit a pull request

## License

This project is proprietary software for LVJ Immigration Services.
