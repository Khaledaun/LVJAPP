
'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { 
  Calendar, 
  Plus, 
  AlertTriangle,
  CheckCircle,
  Clock,
  FileText,
  User,
  Bell,
  Repeat,
  Target
} from 'lucide-react';
import { format, differenceInDays, isPast } from 'date-fns';

interface DeadlineTrackerProps {
  caseId?: string;
  data?: {
    deadlines: Deadline[];
    summary: {
      total: number;
      pending: number;
      in_progress: number;
      completed: number;
      overdue: number;
      critical: number;
    };
  };
  onRefresh?: () => void;
}

interface Deadline {
  id: string;
  title: string;
  description?: string;
  dueDate: string;
  type: 'document_submission' | 'court_filing' | 'payment_due' | 'meeting_scheduled' | 
        'application_deadline' | 'follow_up' | 'review_period' | 'custom';
  priority: 'low' | 'medium' | 'high' | 'critical';
  status: 'pending' | 'in_progress' | 'completed' | 'overdue' | 'cancelled';
  assignedTo?: string;
  isRecurring: boolean;
  recurringPattern?: any;
  case?: {
    id: string;
    title: string;
    caseNumber: string;
  };
  reminders: any[];
  createdAt: string;
  updatedAt: string;
  completedAt?: string;
}

const getDeadlineTypeIcon = (type: string) => {
  const icons = {
    document_submission: <FileText className="w-4 h-4" />,
    court_filing: <Target className="w-4 h-4" />,
    payment_due: <Target className="w-4 h-4" />,
    meeting_scheduled: <Calendar className="w-4 h-4" />,
    application_deadline: <Target className="w-4 h-4" />,
    follow_up: <Bell className="w-4 h-4" />,
    review_period: <Clock className="w-4 h-4" />,
    custom: <Target className="w-4 h-4" />
  };
  return icons[type as keyof typeof icons] || icons.custom;
};

const getPriorityColor = (priority: string) => {
  const colors = {
    low: 'bg-gray-100 text-gray-700',
    medium: 'bg-blue-100 text-blue-800',
    high: 'bg-orange-100 text-orange-800',
    critical: 'bg-red-100 text-red-800'
  };
  return colors[priority as keyof typeof colors] || colors.medium;
};

const getStatusColor = (status: string) => {
  const colors = {
    pending: 'bg-yellow-100 text-yellow-800',
    in_progress: 'bg-blue-100 text-blue-800',
    completed: 'bg-green-100 text-green-800',
    overdue: 'bg-red-100 text-red-800',
    cancelled: 'bg-gray-100 text-gray-700'
  };
  return colors[status as keyof typeof colors] || colors.pending;
};

const getDaysUntilDue = (dueDate: string) => {
  const days = differenceInDays(new Date(dueDate), new Date());
  return days;
};

const getUrgencyIndicator = (dueDate: string, priority: string) => {
  const days = getDaysUntilDue(dueDate);
  const isOverdue = isPast(new Date(dueDate));
  
  if (isOverdue) return '🔴 Overdue';
  if (days <= 1 && priority === 'critical') return '🔴 Due Today/Tomorrow';
  if (days <= 3 && (priority === 'high' || priority === 'critical')) return '🟠 Due Soon';
  if (days <= 7) return '🟡 Due This Week';
  return '🟢 On Track';
};

export default function DeadlineTracker({ caseId, data, onRefresh }: DeadlineTrackerProps) {
  const [isCreating, setIsCreating] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newDueDate, setNewDueDate] = useState('');
  const [newType, setNewType] = useState<Deadline['type']>('custom');
  const [newPriority, setNewPriority] = useState<Deadline['priority']>('medium');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterPriority, setFilterPriority] = useState<string>('all');
  const [loading, setLoading] = useState(false);

  const handleCreateDeadline = async () => {
    if (!newTitle.trim() || !newDueDate) return;

    setLoading(true);
    try {
      const response = await fetch('/api/deadlines', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          caseId,
          title: newTitle,
          description: newDescription,
          dueDate: newDueDate,
          type: newType,
          priority: newPriority
        })
      });

      if (response.ok) {
        setNewTitle('');
        setNewDescription('');
        setNewDueDate('');
        setNewType('custom');
        setNewPriority('medium');
        setIsCreating(false);
        onRefresh?.();
      }
    } catch (error) {
      console.error('Failed to create deadline:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredDeadlines = data?.deadlines.filter(deadline => {
    const statusMatch = filterStatus === 'all' || deadline.status === filterStatus;
    const priorityMatch = filterPriority === 'all' || deadline.priority === filterPriority;
    return statusMatch && priorityMatch;
  }) || [];

  // Sort deadlines by due date and priority
  const sortedDeadlines = filteredDeadlines.sort((a, b) => {
    // First by due date
    const dateCompare = new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
    if (dateCompare !== 0) return dateCompare;
    
    // Then by priority
    const priorityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
    return priorityOrder[a.priority] - priorityOrder[b.priority];
  });

  if (!data) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Deadline Tracker
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-muted-foreground">
            Loading deadlines...
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Deadline Tracker
            </CardTitle>
            {caseId && (
              <Dialog open={isCreating} onOpenChange={setIsCreating}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    Add Deadline
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add Deadline</DialogTitle>
                    <DialogDescription>
                      Create a new deadline for this case.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="title">Title</Label>
                      <Input
                        id="title"
                        value={newTitle}
                        onChange={(e) => setNewTitle(e.target.value)}
                        placeholder="Enter deadline title..."
                      />
                    </div>
                    <div>
                      <Label htmlFor="description">Description (optional)</Label>
                      <Textarea
                        id="description"
                        value={newDescription}
                        onChange={(e) => setNewDescription(e.target.value)}
                        placeholder="Additional details about this deadline..."
                        rows={2}
                      />
                    </div>
                    <div>
                      <Label htmlFor="dueDate">Due Date</Label>
                      <Input
                        id="dueDate"
                        type="datetime-local"
                        value={newDueDate}
                        onChange={(e) => setNewDueDate(e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="type">Type</Label>
                      <Select value={newType} onValueChange={(value: any) => setNewType(value)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="document_submission">Document Submission</SelectItem>
                          <SelectItem value="court_filing">Court Filing</SelectItem>
                          <SelectItem value="payment_due">Payment Due</SelectItem>
                          <SelectItem value="meeting_scheduled">Meeting Scheduled</SelectItem>
                          <SelectItem value="application_deadline">Application Deadline</SelectItem>
                          <SelectItem value="follow_up">Follow Up</SelectItem>
                          <SelectItem value="review_period">Review Period</SelectItem>
                          <SelectItem value="custom">Custom</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="priority">Priority</Label>
                      <Select value={newPriority} onValueChange={(value: any) => setNewPriority(value)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                          <SelectItem value="critical">Critical</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsCreating(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleCreateDeadline} disabled={loading || !newTitle.trim() || !newDueDate}>
                      Create Deadline
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 md:grid-cols-6 gap-4 mb-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{data.summary.total}</div>
              <div className="text-sm text-muted-foreground">Total</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-600">{data.summary.pending}</div>
              <div className="text-sm text-muted-foreground">Pending</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{data.summary.in_progress}</div>
              <div className="text-sm text-muted-foreground">In Progress</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{data.summary.completed}</div>
              <div className="text-sm text-muted-foreground">Completed</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">{data.summary.overdue}</div>
              <div className="text-sm text-muted-foreground">Overdue</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">{data.summary.critical}</div>
              <div className="text-sm text-muted-foreground">Critical</div>
            </div>
          </div>

          {/* Filters */}
          <div className="flex gap-4">
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="in_progress">In Progress</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="overdue">Overdue</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterPriority} onValueChange={setFilterPriority}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter by priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Priorities</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="low">Low</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Deadlines List */}
      <div className="space-y-4">
        <AnimatePresence>
          {sortedDeadlines.map((deadline, index) => {
            const daysUntil = getDaysUntilDue(deadline.dueDate);
            const urgencyIndicator = getUrgencyIndicator(deadline.dueDate, deadline.priority);
            const isOverdue = isPast(new Date(deadline.dueDate)) && deadline.status !== 'completed';
            
            return (
              <motion.div
                key={deadline.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className={`${isOverdue ? 'border-red-300 bg-red-50/50' : ''} ${deadline.priority === 'critical' ? 'border-orange-300' : ''}`}>
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1 space-y-2">
                          <div className="flex items-center gap-2">
                            <div className={`p-1 rounded ${getPriorityColor(deadline.priority)}`}>
                              {getDeadlineTypeIcon(deadline.type)}
                            </div>
                            <h3 className="font-semibold">{deadline.title}</h3>
                            {deadline.isRecurring && (
                              <Badge variant="outline" className="text-xs">
                                <Repeat className="w-3 h-3 mr-1" />
                                Recurring
                              </Badge>
                            )}
                          </div>
                          
                          {deadline.description && (
                            <p className="text-sm text-muted-foreground pl-8">
                              {deadline.description}
                            </p>
                          )}

                          <div className="flex items-center gap-4 text-sm pl-8">
                            <div className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              Due: {format(new Date(deadline.dueDate), 'MMM d, yyyy HH:mm')}
                            </div>
                            <div className="text-muted-foreground">
                              {isOverdue 
                                ? `${Math.abs(daysUntil)} days overdue`
                                : daysUntil === 0 
                                  ? 'Due today'
                                  : `${daysUntil} days remaining`
                              }
                            </div>
                            {deadline.case && (
                              <div className="flex items-center gap-1">
                                <FileText className="w-3 h-3" />
                                {deadline.case.caseNumber}
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <div className="text-right space-y-1">
                            <div className="text-sm font-medium">
                              {urgencyIndicator}
                            </div>
                            <div className="flex gap-2">
                              <Badge className={getPriorityColor(deadline.priority)}>
                                {deadline.priority}
                              </Badge>
                              <Badge className={getStatusColor(deadline.status)}>
                                {deadline.status.replace('_', ' ')}
                              </Badge>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Reminders */}
                      {deadline.reminders && deadline.reminders.length > 0 && (
                        <div className="pl-8">
                          <div className="text-xs text-muted-foreground mb-1">
                            <Bell className="w-3 h-3 inline mr-1" />
                            {deadline.reminders.length} reminder(s) set
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </AnimatePresence>

        {sortedDeadlines.length === 0 && (
          <Card>
            <CardContent className="pt-6">
              <div className="text-center text-muted-foreground">
                <Calendar className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <div>No deadlines found</div>
                <div className="text-sm">
                  {caseId 
                    ? "No deadlines have been set for this case yet." 
                    : "No deadlines match the current filters."
                  }
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
