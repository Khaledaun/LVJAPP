
'use client';
import React, { useState, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { 
  Upload, 
  FileText, 
  Image as ImageIcon,
  X,
  Check,
  AlertCircle,
  Plus
} from 'lucide-react';

interface DocumentUploadProps {
  caseId: string;
  onUploadComplete?: (uploadedDocument: any) => void;
  onCancel?: () => void;
  acceptedTypes?: string[];
  maxFileSize?: number; // in bytes
}

interface UploadFile {
  file: File;
  id: string;
  progress: number;
  status: 'pending' | 'uploading' | 'success' | 'error';
  error?: string;
  preview?: string;
}

const DOCUMENT_CATEGORIES = [
  { value: 'identity', label: 'Identity Documents' },
  { value: 'education', label: 'Education & Qualifications' },
  { value: 'employment', label: 'Employment Documents' },
  { value: 'financial', label: 'Financial Documents' },
  { value: 'legal', label: 'Legal Documents' },
  { value: 'medical', label: 'Medical Records' },
  { value: 'travel', label: 'Travel Documents' },
  { value: 'other', label: 'Other' }
];

export default function DocumentUpload({
  caseId,
  onUploadComplete,
  onCancel,
  acceptedTypes = ['.pdf', '.jpg', '.jpeg', '.png', '.doc', '.docx'],
  maxFileSize = 10 * 1024 * 1024 // 10MB default
}: DocumentUploadProps) {
  const [files, setFiles] = useState<UploadFile[]>([]);
  const [isDragOver, setIsDragOver] = useState(false);
  const [documentName, setDocumentName] = useState('');
  const [category, setCategory] = useState('');
  const [notes, setNotes] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const generateFileId = () => Math.random().toString(36).substr(2, 9);

  const validateFile = (file: File): string | null => {
    if (file.size > maxFileSize) {
      return `File size must be less than ${Math.round(maxFileSize / 1024 / 1024)}MB`;
    }

    const fileExtension = '.' + file.name.split('.').pop()?.toLowerCase();
    if (!acceptedTypes.includes(fileExtension)) {
      return `File type ${fileExtension} is not allowed. Please use: ${acceptedTypes.join(', ')}`;
    }

    return null;
  };

  const handleFileSelection = async (selectedFiles: FileList) => {
    const newFiles: UploadFile[] = [];

    for (let i = 0; i < selectedFiles.length; i++) {
      const file = selectedFiles[i];
      if (!file) continue;
      
      const validationError = validateFile(file);
      
      if (validationError) {
        continue;
      }

      newFiles.push({
        file,
        id: generateFileId(),
        progress: 0,
        status: 'pending'
      });
    }

    setFiles(prev => [...prev, ...newFiles]);
    
    if (!documentName && newFiles.length === 1) {
      const fileName = newFiles[0]?.file?.name;
      if (fileName) {
        const lastDotIndex = fileName.lastIndexOf('.');
        const nameWithoutExtension = lastDotIndex > 0 
          ? fileName.substring(0, lastDotIndex) 
          : fileName;
        setDocumentName(nameWithoutExtension);
      }
    }
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const droppedFiles = e.dataTransfer.files;
    if (droppedFiles.length > 0) {
      handleFileSelection(droppedFiles);
    }
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const removeFile = (fileId: string) => {
    setFiles(prev => prev.filter(f => f.id !== fileId));
  };

  const uploadFile = async (uploadFile: UploadFile): Promise<boolean> => {
    const formData = new FormData();
    formData.append('file', uploadFile.file);
    formData.append('caseId', caseId);
    formData.append('documentName', documentName || uploadFile.file.name);
    formData.append('category', category || 'other');
    formData.append('uploadedBy', 'client');
    
    if (notes) {
      formData.append('notes', notes);
    }

    try {
      const response = await fetch('/api/documents', {
        method: 'POST',
        body: formData
      });

      const data = await response.json();
      
      if (data.success) {
        return true;
      } else {
        throw new Error(data.error || 'Upload failed');
      }
    } catch (error) {
      console.error('Upload error:', error);
      throw error;
    }
  };

  const handleUpload = async () => {
    if (files.length === 0 || !documentName.trim()) return;

    setIsUploading(true);
    let successCount = 0;
    
    for (const file of files) {
      if (file.status !== 'pending') continue;

      setFiles(prev => prev.map(f => 
        f.id === file.id 
          ? { ...f, status: 'uploading' as const, progress: 0 }
          : f
      ));

      try {
        for (let progress = 10; progress <= 90; progress += 20) {
          setFiles(prev => prev.map(f => 
            f.id === file.id ? { ...f, progress } : f
          ));
          await new Promise(resolve => setTimeout(resolve, 200));
        }

        const success = await uploadFile(file);
        
        if (success) {
          setFiles(prev => prev.map(f => 
            f.id === file.id 
              ? { ...f, status: 'success' as const, progress: 100 }
              : f
          ));
          successCount++;
        }
      } catch (error: any) {
        setFiles(prev => prev.map(f => 
          f.id === file.id 
            ? { ...f, status: 'error' as const, error: error.message, progress: 0 }
            : f
        ));
      }
    }

    setIsUploading(false);

    if (successCount > 0) {
      setTimeout(() => {
        onUploadComplete?.(successCount);
      }, 1500);
    }
  };

  const formatFileSize = (bytes: number) => {
    const units = ['B', 'KB', 'MB', 'GB'];
    let size = bytes;
    let unitIndex = 0;
    
    while (size >= 1024 && unitIndex < units.length - 1) {
      size /= 1024;
      unitIndex++;
    }
    
    return `${size.toFixed(1)} ${units[unitIndex]}`;
  };

  const canUpload = files.length > 0 && documentName.trim() && !isUploading;
  const hasErrors = files.some(f => f.status === 'error');
  const allSuccess = files.length > 0 && files.every(f => f.status === 'success');

  return (
    <div className="space-y-6">
      {/* File Drop Zone */}
      <Card>
        <CardContent className="p-0">
          <div
            className={`p-8 border-2 border-dashed rounded-lg text-center transition-colors cursor-pointer ${
              isDragOver 
                ? 'border-blue-400 bg-blue-50' 
                : files.length > 0
                  ? 'border-green-300 bg-green-50'
                  : 'border-gray-300 hover:border-gray-400'
            }`}
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onClick={() => fileInputRef.current?.click()}
          >
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept={acceptedTypes.join(',')}
              onChange={(e) => e.target.files && handleFileSelection(e.target.files)}
              className="hidden"
            />
            
            <Upload className={`w-12 h-12 mx-auto mb-4 ${
              isDragOver ? 'text-blue-500' : 'text-gray-400'
            }`} />
            
            <h3 className="text-lg font-semibold mb-2">
              {isDragOver ? 'Drop files here' : 'Upload Documents'}
            </h3>
            
            <p className="text-muted-foreground mb-4">
              Drag and drop files here, or click to browse
            </p>
            
            <div className="text-sm text-muted-foreground">
              <p>Accepted formats: {acceptedTypes.join(', ')}</p>
              <p>Maximum file size: {Math.round(maxFileSize / 1024 / 1024)}MB</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Selected Files */}
      <AnimatePresence>
        {files.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
          >
            <Card>
              <CardContent className="p-6">
                <h4 className="font-semibold mb-4">Selected Files ({files.length})</h4>
                
                <div className="space-y-3">
                  {files.map((uploadFile) => (
                    <motion.div
                      key={uploadFile.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="flex items-center space-x-3 p-3 border rounded-lg"
                    >
                      <div className="flex-shrink-0">
                        <FileText className="w-8 h-8 text-blue-600" />
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{uploadFile.file.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {formatFileSize(uploadFile.file.size)}
                        </p>
                        
                        {uploadFile.status === 'uploading' && (
                          <div className="mt-2">
                            <Progress value={uploadFile.progress} className="w-full" />
                          </div>
                        )}
                        
                        {uploadFile.error && (
                          <p className="text-sm text-red-600 mt-1">{uploadFile.error}</p>
                        )}
                      </div>
                      
                      <div className="flex-shrink-0">
                        {uploadFile.status === 'success' && (
                          <Check className="w-5 h-5 text-green-500" />
                        )}
                        {uploadFile.status === 'error' && (
                          <AlertCircle className="w-5 h-5 text-red-500" />
                        )}
                        {(uploadFile.status === 'pending' || uploadFile.status === 'error') && (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => removeFile(uploadFile.id)}
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Document Details Form */}
      {files.length > 0 && (
        <Card>
          <CardContent className="p-6">
            <h4 className="font-semibold mb-4">Document Details</h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="documentName">Document Name *</Label>
                <Input
                  id="documentName"
                  value={documentName}
                  onChange={(e) => setDocumentName(e.target.value)}
                  placeholder="Enter document name"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {DOCUMENT_CATEGORIES.map((cat) => (
                      <SelectItem key={cat.value} value={cat.value}>
                        {cat.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="mt-4 space-y-2">
              <Label htmlFor="notes">Notes (Optional)</Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Add any additional notes about this document..."
                rows={3}
              />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Action Buttons */}
      <div className="flex justify-between items-center">
        <div className="text-sm text-muted-foreground">
          {allSuccess && (
            <span className="text-green-600 flex items-center">
              <Check className="w-4 h-4 mr-1" />
              All files uploaded successfully!
            </span>
          )}
          {hasErrors && (
            <span className="text-red-600 flex items-center">
              <AlertCircle className="w-4 h-4 mr-1" />
              Some files failed to upload
            </span>
          )}
        </div>
        
        <div className="flex space-x-3">
          <Button
            variant="outline"
            onClick={onCancel}
            disabled={isUploading}
          >
            Cancel
          </Button>
          
          <Button
            onClick={handleUpload}
            disabled={!canUpload}
          >
            {isUploading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Uploading...
              </>
            ) : (
              <>
                <Upload className="w-4 h-4 mr-2" />
                Upload Document{files.length > 1 ? 's' : ''}
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
