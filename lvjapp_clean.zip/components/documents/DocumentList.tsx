'use client';
import React, { useEffect, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  CheckCircle,
  XCircle,
  Eye,
  Download,
  Upload,
  FileText,
  Image as ImageIcon,
  AlertCircle,
  Clock,
  MessageSquare,
  Plus,
  Filter,
  MoreVertical
} from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import DocumentUpload from './DocumentUpload';
import DocumentViewer from './DocumentViewer';

type Document = {
  id: string;
  name: string;
  fileName?: string;
  mimeType?: string;
  fileSize?: number;
  cloudStoragePath?: string;
  version: number;
  state: string;
  status: 'pending_review' | 'approved' | 'rejected' | 'missing' | 'expired' | 'revision_required';
  rejectionReason?: string;
  uploadedBy?: string;
  reviewedBy?: string;
  reviewedAt?: string;
  isRequired: boolean;
  category?: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
  documentType?: {
    id: string;
    name: string;
    category: string;
    description?: string;
  };
  comments?: {
    id: string;
    content: string;
    isInternal: boolean;
    createdBy: string;
    createdAt: string;
  }[];
  versions?: {
    id: string;
    versionNumber: number;
    fileName: string;
    uploadedBy: string;
    uploadedAt: string;
  }[];
};

type DocumentSummary = {
  total: number;
  pending: number;
  approved: number;
  rejected: number;
  missing: number;
};

interface DocumentListProps {
  caseId: string;
  userRole?: 'CLIENT' | 'STAFF' | 'ADMIN';
}

export default function DocumentList({ caseId, userRole = 'CLIENT' }: DocumentListProps) {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [categorizedDocuments, setCategorizedDocuments] = useState<Record<string, Document[]>>({});
  const [summary, setSummary] = useState<DocumentSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<string>('all');
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  const [reviewingDocId, setReviewingDocId] = useState<string | null>(null);
  const [reviewNotes, setReviewNotes] = useState<string>('');

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const statusParam = filter !== 'all' ? `&status=${filter}` : '';
      const res = await fetch(`/api/documents?caseId=${caseId}${statusParam}`);
      const data = await res.json();
      
      if (data.success) {
        setDocuments(data.data.documents);
        setCategorizedDocuments(data.data.categorizedDocuments);
        setSummary(data.data.summary);
      } else {
        setError(data.error || 'Failed to load documents');
      }
    } catch (err) {
      console.error('Error loading documents:', err);
      setError('Failed to load documents');
    } finally {
      setLoading(false);
    }
  }, [caseId, filter]);

  const handleDocumentAction = async (documentId: string, action: string, notes?: string) => {
    setReviewingDocId(documentId);
    try {
      const res = await fetch(`/api/documents/${documentId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action,
          rejectionReason: notes,
          reviewedBy: userRole,
          notes
        })
      });

      const data = await res.json();
      if (data.success) {
        await load(); // Reload documents
        setReviewNotes('');
      } else {
        setError(data.error || 'Failed to update document');
      }
    } catch (err) {
      console.error('Error updating document:', err);
      setError('Failed to update document');
    } finally {
      setReviewingDocId(null);
    }
  };

  const handleDownload = async (document: Document) => {
    try {
      const res = await fetch(`/api/documents/${document.id}?action=download`);
      const data = await res.json();
      
      if (data.success && data.data.downloadUrl) {
        window.open(data.data.downloadUrl, '_blank');
      } else {
        setError('Unable to download document');
      }
    } catch (err) {
      console.error('Error downloading document:', err);
      setError('Failed to download document');
    }
  };

  const getStatusIcon = (status: Document['status']) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'rejected':
        return <XCircle className="w-5 h-5 text-red-500" />;
      case 'pending_review':
        return <Clock className="w-5 h-5 text-yellow-500" />;
      case 'revision_required':
        return <AlertCircle className="w-5 h-5 text-orange-500" />;
      case 'missing':
        return <AlertCircle className="w-5 h-5 text-red-400" />;
      default:
        return <FileText className="w-5 h-5 text-gray-400" />;
    }
  };

  const getStatusBadge = (status: Document['status']) => {
    const variants = {
      approved: 'bg-green-100 text-green-800',
      rejected: 'bg-red-100 text-red-800',
      pending_review: 'bg-yellow-100 text-yellow-800',
      revision_required: 'bg-orange-100 text-orange-800',
      missing: 'bg-red-50 text-red-600',
      expired: 'bg-gray-100 text-gray-600'
    };
    
    return (
      <Badge variant="secondary" className={variants[status] || 'bg-gray-100 text-gray-600'}>
        {status.replace('_', ' ').toUpperCase()}
      </Badge>
    );
  };

  const getFileIcon = (mimeType?: string) => {
    if (!mimeType) return <FileText className="w-8 h-8 text-gray-400" />;
    
    if (mimeType.startsWith('image/')) {
      return <ImageIcon className="w-8 h-8 text-blue-500" />;
    }
    
    return <FileText className="w-8 h-8 text-blue-600" />;
  };

  const formatFileSize = (bytes?: number) => {
    if (!bytes) return 'Unknown size';
    const units = ['B', 'KB', 'MB', 'GB'];
    let size = bytes;
    let unitIndex = 0;
    
    while (size >= 1024 && unitIndex < units.length - 1) {
      size /= 1024;
      unitIndex++;
    }
    
    return `${size.toFixed(1)} ${units[unitIndex]}`;
  };

  useEffect(() => {
    if (caseId) {
      load();
    }
  }, [caseId, load]);

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
            <span className="ml-2">Loading documents...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-red-600">
            <AlertCircle className="inline w-5 h-5 mr-2" />
            {error}
            <Button onClick={() => load()} className="ml-4" variant="outline" size="sm">
              Retry
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with Summary and Actions */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Document Management</CardTitle>
              {summary && (
                <p className="text-sm text-muted-foreground mt-1">
                  {summary.total} documents • {summary.pending} pending review • {summary.approved} approved
                </p>
              )}
            </div>
            
            <div className="flex items-center space-x-2">
              <Select value={filter} onValueChange={setFilter}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="pending_review">Pending</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                  <SelectItem value="missing">Missing</SelectItem>
                </SelectContent>
              </Select>
              
              <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    Upload Document
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Upload Document</DialogTitle>
                  </DialogHeader>
                  <DocumentUpload
                    caseId={caseId}
                    onUploadComplete={() => {
                      setShowUploadDialog(false);
                      load();
                    }}
                    onCancel={() => setShowUploadDialog(false)}
                  />
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </CardHeader>
        
        {summary && (
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div className="text-center p-3 bg-gray-50 rounded-lg">
                <div className="text-2xl font-bold text-gray-900">{summary.total}</div>
                <div className="text-xs text-gray-600">Total</div>
              </div>
              <div className="text-center p-3 bg-yellow-50 rounded-lg">
                <div className="text-2xl font-bold text-yellow-600">{summary.pending}</div>
                <div className="text-xs text-yellow-600">Pending</div>
              </div>
              <div className="text-center p-3 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600">{summary.approved}</div>
                <div className="text-xs text-green-600">Approved</div>
              </div>
              <div className="text-center p-3 bg-red-50 rounded-lg">
                <div className="text-2xl font-bold text-red-600">{summary.rejected}</div>
                <div className="text-xs text-red-600">Rejected</div>
              </div>
              <div className="text-center p-3 bg-orange-50 rounded-lg">
                <div className="text-2xl font-bold text-orange-600">{summary.missing}</div>
                <div className="text-xs text-orange-600">Missing</div>
              </div>
            </div>
          </CardContent>
        )}
      </Card>

      {/* Document List */}
      <Card>
        <CardContent className="p-0">
          {documents.length === 0 ? (
            <div className="p-8 text-center">
              <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-600 mb-2">No Documents Found</h3>
              <p className="text-gray-500 mb-4">
                {filter === 'all' 
                  ? 'No documents have been uploaded for this case yet.' 
                  : `No documents match the ${filter.replace('_', ' ')} filter.`
                }
              </p>
              <Button onClick={() => setShowUploadDialog(true)}>
                <Upload className="w-4 h-4 mr-2" />
                Upload First Document
              </Button>
            </div>
          ) : (
            <div className="divide-y">
              <AnimatePresence>
                {documents.map((document, index) => (
                  <motion.div
                    key={document.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ delay: index * 0.05 }}
                    className="p-6 hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-4 flex-1">
                        <div className="flex-shrink-0">
                          {getFileIcon(document.mimeType)}
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-1">
                            <h3 className="font-semibold text-lg">{document.name}</h3>
                            {getStatusBadge(document.status)}
                            {document.isRequired && (
                              <Badge variant="outline" className="text-xs">Required</Badge>
                            )}
                          </div>
                          
                          <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-2">
                            <span>{document.fileName}</span>
                            <span>{formatFileSize(document.fileSize)}</span>
                            <span>v{document.version}</span>
                            {document.uploadedBy && (
                              <span>Uploaded by {document.uploadedBy}</span>
                            )}
                          </div>
                          
                          {document.category && (
                            <div className="mb-2">
                              <Badge variant="outline" className="text-xs">
                                {document.category}
                              </Badge>
                            </div>
                          )}
                          
                          {document.rejectionReason && (
                            <div className="mt-2 p-2 bg-red-50 border border-red-200 rounded text-sm">
                              <strong>Rejection Reason:</strong> {document.rejectionReason}
                            </div>
                          )}
                          
                          {document.comments && document.comments.length > 0 && (
                            <div className="mt-2">
                              <div className="text-xs text-muted-foreground flex items-center">
                                <MessageSquare className="w-3 h-3 mr-1" />
                                {document.comments.length} comment{document.comments.length !== 1 ? 's' : ''}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex items-center space-x-2 ml-4">
                        <Button
                          onClick={() => handleDownload(document)}
                          size="sm"
                          variant="outline"
                        >
                          <Download className="w-4 h-4 mr-1" />
                          Download
                        </Button>
                        
                        <Button
                          onClick={() => setSelectedDocument(document)}
                          size="sm"
                          variant="outline"
                        >
                          <Eye className="w-4 h-4 mr-1" />
                          View
                        </Button>
                        
                        {/* Lawyer Review Actions */}
                        {(userRole === 'STAFF' || userRole === 'ADMIN') && 
                         document.status === 'pending_review' && (
                          <div className="flex space-x-1">
                            <Button
                              onClick={() => handleDocumentAction(document.id, 'approve')}
                              disabled={reviewingDocId === document.id}
                              size="sm"
                              className="bg-green-600 hover:bg-green-700"
                            >
                              <CheckCircle className="w-4 h-4 mr-1" />
                              Approve
                            </Button>
                            
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="text-red-600 hover:text-red-700"
                                  disabled={reviewingDocId === document.id}
                                >
                                  <XCircle className="w-4 h-4 mr-1" />
                                  Reject
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent className="w-80">
                                <div className="p-3">
                                  <label className="text-sm font-semibold">Rejection Reason:</label>
                                  <Textarea
                                    placeholder="Please specify why this document is being rejected..."
                                    value={reviewNotes}
                                    onChange={(e) => setReviewNotes(e.target.value)}
                                    className="mt-2 mb-3"
                                    rows={3}
                                  />
                                  <div className="flex space-x-2">
                                    <Button
                                      onClick={() => {
                                        handleDocumentAction(document.id, 'reject', reviewNotes);
                                      }}
                                      size="sm"
                                      className="bg-red-600 hover:bg-red-700"
                                      disabled={!reviewNotes.trim()}
                                    >
                                      Reject Document
                                    </Button>
                                    <Button
                                      onClick={() => {
                                        handleDocumentAction(document.id, 'request_revision', reviewNotes);
                                      }}
                                      size="sm"
                                      variant="outline"
                                      disabled={!reviewNotes.trim()}
                                    >
                                      Request Revision
                                    </Button>
                                  </div>
                                </div>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        )}
                        
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button size="sm" variant="ghost">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent>
                            <DropdownMenuItem onClick={() => setSelectedDocument(document)}>
                              <Eye className="w-4 h-4 mr-2" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleDownload(document)}>
                              <Download className="w-4 h-4 mr-2" />
                              Download
                            </DropdownMenuItem>
                            {document.comments && document.comments.length > 0 && (
                              <DropdownMenuItem onClick={() => setSelectedDocument(document)}>
                                <MessageSquare className="w-4 h-4 mr-2" />
                                View Comments
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Document Viewer Dialog */}
      {selectedDocument && (
        <Dialog open={!!selectedDocument} onOpenChange={() => setSelectedDocument(null)}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>{selectedDocument.name}</DialogTitle>
            </DialogHeader>
            <div className="p-6">
              <p className="text-sm text-muted-foreground">
                Document details and preview would be shown here.
              </p>
              <div className="mt-4 space-y-2">
                <p><strong>File:</strong> {selectedDocument.fileName}</p>
                <p><strong>Status:</strong> {selectedDocument.status}</p>
                <p><strong>Category:</strong> {selectedDocument.category}</p>
                <p><strong>Size:</strong> {formatFileSize(selectedDocument.fileSize)}</p>
              </div>
              {selectedDocument.comments && selectedDocument.comments.length > 0 && (
                <div className="mt-6">
                  <h4 className="font-semibold mb-2">Comments</h4>
                  <div className="space-y-2">
                    {selectedDocument.comments.map((comment) => (
                      <div key={comment.id} className="p-3 bg-gray-50 rounded">
                        <p className="text-sm">{comment.content}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          By {comment.createdBy} on {new Date(comment.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
