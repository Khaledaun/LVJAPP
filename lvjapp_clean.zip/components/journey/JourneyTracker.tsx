
'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { 
  Clock, 
  CheckCircle, 
  AlertCircle, 
  PlayCircle,
  Square,
  Calendar,
  FileText,
  User,
  MapPin
} from 'lucide-react';
import StatusTimeline from './StatusTimeline';
import { format } from 'date-fns';

interface JourneyStage {
  id: string;
  title: string;
  description?: string;
  status: 'not_started' | 'in_progress' | 'blocked' | 'completed' | 'skipped';
  order: number;
  startedAt?: Date | string | null;
  completedAt?: Date | string | null;
  dueDate?: Date | string | null;
  estimatedDays?: number;
  isRequired: boolean;
  notes?: string;
  dependsOnStages?: string[];
  requiredDocuments?: string[];
}

interface JourneyData {
  case: {
    title: string;
    caseNumber: string;
    overallStatus: string;
    visaType?: string;
    destinationCountry?: string;
  };
  stages: JourneyStage[];
  completionPercentage: number;
  totalStages: number;
  completedStages: number;
}

interface JourneyTrackerProps {
  caseId: string;
  data?: JourneyData; // Made optional with default
  onStageUpdate?: (stageId: string, action: string, notes?: string) => Promise<void>;
}

const getStatusColor = (status: JourneyStage['status']) => {
  const colors = {
    not_started: 'bg-gray-200 text-gray-700',
    in_progress: 'bg-blue-200 text-blue-800',
    blocked: 'bg-red-200 text-red-800',
    completed: 'bg-green-200 text-green-800',
    skipped: 'bg-yellow-200 text-yellow-800'
  };
  return colors[status];
};

const getStatusIcon = (status: JourneyStage['status']) => {
  const icons = {
    not_started: <Square className="w-4 h-4" />,
    in_progress: <PlayCircle className="w-4 h-4" />,
    blocked: <AlertCircle className="w-4 h-4" />,
    completed: <CheckCircle className="w-4 h-4" />,
    skipped: <Square className="w-4 h-4" />
  };
  return icons[status];
};

const getTrafficLight = (status: JourneyStage['status']) => {
  if (status === 'completed' || status === 'skipped') return '🟢';
  if (status === 'in_progress') return '🟡';
  if (status === 'blocked') return '🔴';
  return '⚪';
};

// Default mock data for when no data is provided
const defaultData: JourneyData = {
  case: {
    title: 'Loading...',
    caseNumber: 'LOADING',
    overallStatus: 'new',
    visaType: 'Unknown',
    destinationCountry: 'Unknown'
  },
  stages: [],
  completionPercentage: 0,
  totalStages: 0,
  completedStages: 0
};

export default function JourneyTracker({ caseId, data = defaultData, onStageUpdate }: JourneyTrackerProps) {
  const [selectedStage, setSelectedStage] = useState<string | null>(null);
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);

  const handleStageAction = async (stageId: string, action: string) => {
    if (!onStageUpdate) return;
    
    setLoading(true);
    try {
      await onStageUpdate(stageId, action, notes);
      setSelectedStage(null);
      setNotes('');
    } catch (error) {
      console.error('Failed to update stage:', error);
    } finally {
      setLoading(false);
    }
  };

  const canTakeAction = (stage: JourneyStage) => {
    // Check if all dependent stages are completed
    if (stage.dependsOnStages && stage.dependsOnStages.length > 0) {
      const dependentStages = data.stages.filter(s => stage.dependsOnStages?.includes(s.id));
      return dependentStages.every(s => s.status === 'completed' || s.status === 'skipped');
    }
    return true;
  };

  const getAvailableActions = (stage: JourneyStage) => {
    const actions = [];
    
    if (stage.status === 'not_started' && canTakeAction(stage)) {
      actions.push({ label: 'Start', action: 'start', variant: 'default' });
    }
    
    if (stage.status === 'in_progress') {
      actions.push({ label: 'Complete', action: 'complete', variant: 'default' });
      actions.push({ label: 'Block', action: 'block', variant: 'destructive' });
    }
    
    if (stage.status === 'blocked') {
      actions.push({ label: 'Resume', action: 'start', variant: 'default' });
    }
    
    if (stage.status !== 'completed' && stage.status !== 'skipped') {
      actions.push({ label: 'Skip', action: 'skip', variant: 'secondary' });
    }
    
    return actions;
  };

  return (
    <div className="space-y-6">
      {/* Case Overview Card */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              {data.case.title}
            </CardTitle>
            <Badge variant="outline">
              {data.case.caseNumber}
            </Badge>
          </div>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            {data.case.visaType && (
              <div className="flex items-center gap-1">
                <User className="w-4 h-4" />
                {data.case.visaType}
              </div>
            )}
            {data.case.destinationCountry && (
              <div className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                {data.case.destinationCountry}
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Overall Progress</span>
              <span className="text-sm text-muted-foreground">
                {data.completedStages} of {data.totalStages} stages
              </span>
            </div>
            <Progress value={data.completionPercentage} className="h-2" />
            <div className="text-center text-2xl font-bold text-green-600">
              {data.completionPercentage}% Complete
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Journey Stages */}
      <Card>
        <CardHeader>
          <CardTitle>Journey Stages</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <AnimatePresence>
              {data.stages.map((stage, index) => (
                <motion.div
                  key={stage.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="border rounded-lg p-4 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="text-2xl">
                        {getTrafficLight(stage.status)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold">{stage.title}</h3>
                          {!stage.isRequired && (
                            <Badge variant="secondary" className="text-xs">
                              Optional
                            </Badge>
                          )}
                        </div>
                        {stage.description && (
                          <p className="text-sm text-muted-foreground">
                            {stage.description}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={getStatusColor(stage.status)}>
                        {getStatusIcon(stage.status)}
                        <span className="ml-1 capitalize">
                          {stage.status.replace('_', ' ')}
                        </span>
                      </Badge>
                    </div>
                  </div>

                  {/* Stage Details */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    {stage.startedAt && (
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <Clock className="w-3 h-3" />
                        Started: {format(new Date(stage.startedAt), 'MMM d, yyyy')}
                      </div>
                    )}
                    {stage.completedAt && (
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <CheckCircle className="w-3 h-3" />
                        Completed: {format(new Date(stage.completedAt), 'MMM d, yyyy')}
                      </div>
                    )}
                    {stage.dueDate && (
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <Calendar className="w-3 h-3" />
                        Due: {format(new Date(stage.dueDate), 'MMM d, yyyy')}
                      </div>
                    )}
                    {stage.estimatedDays && (
                      <div className="text-muted-foreground">
                        Est. {stage.estimatedDays} days
                      </div>
                    )}
                  </div>

                  {/* Stage Notes */}
                  {stage.notes && (
                    <div className="bg-muted/50 rounded p-2">
                      <p className="text-sm">{stage.notes}</p>
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="flex items-center gap-2 flex-wrap">
                    {getAvailableActions(stage).map((actionBtn) => (
                      <Button
                        key={actionBtn.action}
                        variant={actionBtn.variant as any}
                        size="sm"
                        disabled={loading}
                        onClick={() => setSelectedStage(stage.id)}
                      >
                        {actionBtn.label}
                      </Button>
                    ))}
                  </div>

                  {/* Action Modal */}
                  {selectedStage === stage.id && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="border-t pt-3 space-y-3"
                    >
                      <div>
                        <Label htmlFor="stage-notes">Notes (optional)</Label>
                        <Textarea
                          id="stage-notes"
                          value={notes}
                          onChange={(e) => setNotes(e.target.value)}
                          placeholder="Add any notes about this stage update..."
                          rows={2}
                        />
                      </div>
                      <div className="flex gap-2">
                        {getAvailableActions(stage).map((actionBtn) => (
                          <Button
                            key={actionBtn.action}
                            variant={actionBtn.variant as any}
                            size="sm"
                            disabled={loading}
                            onClick={() => handleStageAction(stage.id, actionBtn.action)}
                          >
                            {actionBtn.label}
                          </Button>
                        ))}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setSelectedStage(null);
                            setNotes('');
                          }}
                        >
                          Cancel
                        </Button>
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </CardContent>
      </Card>

      {/* Status Timeline */}
      <StatusTimeline stages={data.stages
        .filter(s => s.dueDate) // Only include stages with due dates
        .map(s => ({
          id: s.id,
          title: s.title, 
          status: s.status === 'skipped' ? 'completed' : s.status,
          due_date: s.dueDate ? (typeof s.dueDate === 'string' ? s.dueDate : s.dueDate.toISOString()) : ''
        }))} />
    </div>
  );
}
