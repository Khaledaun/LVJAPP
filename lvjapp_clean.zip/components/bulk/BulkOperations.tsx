
'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  CheckSquare, 
  Square, 
  Download, 
  Upload, 
  Trash2, 
  Edit, 
  Send, 
  FileText, 
  Users, 
  AlertCircle,
  CheckCircle,
  Clock,
  X,
  Play,
  Pause,
  RotateCcw
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface BulkItem {
  id: string;
  type: 'case' | 'document' | 'client' | 'payment';
  title: string;
  subtitle: string;
  status: string;
  metadata: {
    [key: string]: any;
  };
}

interface BulkOperation {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  requiresInput?: boolean;
  inputFields?: Array<{
    name: string;
    label: string;
    type: 'text' | 'textarea' | 'select' | 'date';
    options?: string[];
    required?: boolean;
  }>;
  confirmationMessage?: string;
  dangerLevel?: 'low' | 'medium' | 'high';
}

interface BulkOperationsProps {
  items: BulkItem[];
  selectedItems: string[];
  onSelectionChange: (selectedIds: string[]) => void;
  onOperationComplete: (operation: string, results: any) => void;
}

const bulkOperations: BulkOperation[] = [
  {
    id: 'update_status',
    name: 'Update Status',
    description: 'Change the status of selected items',
    icon: <Edit className="w-4 h-4" />,
    requiresInput: true,
    inputFields: [
      {
        name: 'status',
        label: 'New Status',
        type: 'select',
        options: ['new', 'documents_pending', 'in_review', 'submitted', 'approved', 'denied'],
        required: true
      },
      {
        name: 'note',
        label: 'Update Note',
        type: 'textarea',
        required: false
      }
    ],
    dangerLevel: 'low'
  },
  {
    id: 'assign_staff',
    name: 'Assign Staff',
    description: 'Assign cases to staff members',
    icon: <Users className="w-4 h-4" />,
    requiresInput: true,
    inputFields: [
      {
        name: 'staffType',
        label: 'Staff Type',
        type: 'select',
        options: ['case_manager', 'lawyer'],
        required: true
      },
      {
        name: 'staffMember',
        label: 'Staff Member',
        type: 'select',
        options: ['Sarah Johnson', 'Michael Chen', 'Emily Rodriguez', 'David Kim'],
        required: true
      }
    ],
    dangerLevel: 'low'
  },
  {
    id: 'send_notification',
    name: 'Send Notification',
    description: 'Send notifications to clients',
    icon: <Send className="w-4 h-4" />,
    requiresInput: true,
    inputFields: [
      {
        name: 'subject',
        label: 'Subject',
        type: 'text',
        required: true
      },
      {
        name: 'message',
        label: 'Message',
        type: 'textarea',
        required: true
      },
      {
        name: 'method',
        label: 'Notification Method',
        type: 'select',
        options: ['email', 'sms', 'in_app', 'all'],
        required: true
      }
    ],
    dangerLevel: 'low'
  },
  {
    id: 'export_data',
    name: 'Export Data',
    description: 'Export selected items to file',
    icon: <Download className="w-4 h-4" />,
    requiresInput: true,
    inputFields: [
      {
        name: 'format',
        label: 'Export Format',
        type: 'select',
        options: ['csv', 'excel', 'pdf', 'json'],
        required: true
      },
      {
        name: 'includeDocuments',
        label: 'Include Documents',
        type: 'select',
        options: ['yes', 'no'],
        required: false
      }
    ],
    dangerLevel: 'low'
  },
  {
    id: 'archive_items',
    name: 'Archive Items',
    description: 'Move selected items to archive',
    icon: <FileText className="w-4 h-4" />,
    confirmationMessage: 'Are you sure you want to archive these items? They will be moved to the archive and hidden from the main view.',
    dangerLevel: 'medium'
  },
  {
    id: 'delete_items',
    name: 'Delete Items',
    description: 'Permanently delete selected items',
    icon: <Trash2 className="w-4 h-4" />,
    confirmationMessage: 'Are you sure you want to permanently delete these items? This action cannot be undone.',
    dangerLevel: 'high'
  }
];

export default function BulkOperations({ 
  items, 
  selectedItems, 
  onSelectionChange, 
  onOperationComplete 
}: BulkOperationsProps) {
  const [showOperationDialog, setShowOperationDialog] = useState(false);
  const [selectedOperation, setSelectedOperation] = useState<BulkOperation | null>(null);
  const [operationInputs, setOperationInputs] = useState<{[key: string]: any}>({});
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingProgress, setProcessingProgress] = useState(0);
  const [processingStatus, setProcessingStatus] = useState<string>('');
  const [operationResults, setOperationResults] = useState<any>(null);

  const handleSelectAll = () => {
    if (selectedItems.length === items.length) {
      onSelectionChange([]);
    } else {
      onSelectionChange(items.map(item => item.id));
    }
  };

  const handleItemSelect = (itemId: string) => {
    if (selectedItems.includes(itemId)) {
      onSelectionChange(selectedItems.filter(id => id !== itemId));
    } else {
      onSelectionChange([...selectedItems, itemId]);
    }
  };

  const startOperation = (operation: BulkOperation) => {
    setSelectedOperation(operation);
    setOperationInputs({});
    setOperationResults(null);
    setShowOperationDialog(true);
  };

  const executeOperation = async () => {
    if (!selectedOperation) return;

    setIsProcessing(true);
    setProcessingProgress(0);
    setProcessingStatus('Initializing...');

    try {
      // Simulate operation execution
      const totalItems = selectedItems.length;
      const results = {
        successful: 0,
        failed: 0,
        errors: [] as string[]
      };

      for (let i = 0; i < totalItems; i++) {
        const itemId = selectedItems[i];
        const item = items.find(item => item.id === itemId);
        
        setProcessingStatus(`Processing ${item?.title || itemId}...`);
        setProcessingProgress(((i + 1) / totalItems) * 100);

        // Simulate API call delay
        await new Promise(resolve => setTimeout(resolve, 500));

        // Mock success/failure
        if (Math.random() > 0.1) { // 90% success rate
          results.successful++;
        } else {
          results.failed++;
          results.errors.push(`Failed to process ${item?.title || itemId}`);
        }
      }

      setOperationResults(results);
      setProcessingStatus('Operation completed');
      
      // Call the completion callback
      onOperationComplete(selectedOperation.id, results);

    } catch (error) {
      console.error('Bulk operation error:', error);
      setOperationResults({
        successful: 0,
        failed: selectedItems.length,
        errors: ['Operation failed due to an unexpected error']
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const getDangerColor = (level?: string) => {
    switch (level) {
      case 'high': return 'text-red-600 border-red-200 hover:bg-red-50';
      case 'medium': return 'text-orange-600 border-orange-200 hover:bg-orange-50';
      default: return 'text-blue-600 border-blue-200 hover:bg-blue-50';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'pending': return <Clock className="w-4 h-4 text-yellow-600" />;
      case 'rejected': return <X className="w-4 h-4 text-red-600" />;
      default: return <AlertCircle className="w-4 h-4 text-gray-600" />;
    }
  };

  return (
    <div className="space-y-4">
      {/* Selection Controls */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center space-x-2">
              <CheckSquare className="w-5 h-5" />
              <span>Bulk Operations</span>
              {selectedItems.length > 0 && (
                <Badge variant="secondary">
                  {selectedItems.length} selected
                </Badge>
              )}
            </CardTitle>
            
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleSelectAll}
                className="flex items-center space-x-1"
              >
                {selectedItems.length === items.length ? (
                  <CheckSquare className="w-4 h-4" />
                ) : (
                  <Square className="w-4 h-4" />
                )}
                <span>Select All</span>
              </Button>
            </div>
          </div>
        </CardHeader>
        
        {selectedItems.length > 0 && (
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2">
              {bulkOperations.map((operation) => (
                <Button
                  key={operation.id}
                  variant="outline"
                  size="sm"
                  onClick={() => startOperation(operation)}
                  className={`flex flex-col items-center space-y-1 h-auto py-3 ${getDangerColor(operation.dangerLevel)}`}
                >
                  {operation.icon}
                  <span className="text-xs text-center">{operation.name}</span>
                </Button>
              ))}
            </div>
          </CardContent>
        )}
      </Card>

      {/* Items List */}
      <Card>
        <CardHeader>
          <CardTitle>Items ({items.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {items.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className={`flex items-center space-x-3 p-3 border rounded-lg cursor-pointer transition-colors ${
                  selectedItems.includes(item.id) 
                    ? 'bg-blue-50 border-blue-200' 
                    : 'hover:bg-gray-50'
                }`}
                onClick={() => handleItemSelect(item.id)}
              >
                <Checkbox
                  checked={selectedItems.includes(item.id)}
                  onChange={() => handleItemSelect(item.id)}
                />
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium truncate">{item.title}</h4>
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline" className="text-xs">
                        {item.type}
                      </Badge>
                      {getStatusIcon(item.status)}
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground truncate">
                    {item.subtitle}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Operation Dialog */}
      <Dialog open={showOperationDialog} onOpenChange={setShowOperationDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              {selectedOperation?.icon}
              <span>{selectedOperation?.name}</span>
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              {selectedOperation?.description}
            </p>
            
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                This operation will affect {selectedItems.length} selected items.
              </AlertDescription>
            </Alert>

            {/* Operation Inputs */}
            {selectedOperation?.inputFields && (
              <div className="space-y-4">
                {selectedOperation.inputFields.map((field) => (
                  <div key={field.name}>
                    <Label htmlFor={field.name}>{field.label}</Label>
                    {field.type === 'select' ? (
                      <Select
                        value={operationInputs[field.name] || ''}
                        onValueChange={(value) => setOperationInputs(prev => ({
                          ...prev,
                          [field.name]: value
                        }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder={`Select ${field.label.toLowerCase()}`} />
                        </SelectTrigger>
                        <SelectContent>
                          {field.options?.map((option) => (
                            <SelectItem key={option} value={option}>
                              {option.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    ) : field.type === 'textarea' ? (
                      <Textarea
                        id={field.name}
                        placeholder={`Enter ${field.label.toLowerCase()}`}
                        value={operationInputs[field.name] || ''}
                        onChange={(e) => setOperationInputs(prev => ({
                          ...prev,
                          [field.name]: e.target.value
                        }))}
                      />
                    ) : (
                      <Input
                        id={field.name}
                        type={field.type}
                        placeholder={`Enter ${field.label.toLowerCase()}`}
                        value={operationInputs[field.name] || ''}
                        onChange={(e) => setOperationInputs(prev => ({
                          ...prev,
                          [field.name]: e.target.value
                        }))}
                      />
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* Confirmation Message */}
            {selectedOperation?.confirmationMessage && (
              <Alert className={selectedOperation.dangerLevel === 'high' ? 'border-red-200' : ''}>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  {selectedOperation.confirmationMessage}
                </AlertDescription>
              </Alert>
            )}

            {/* Processing Status */}
            {isProcessing && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Processing...</span>
                  <span className="text-sm text-muted-foreground">
                    {Math.round(processingProgress)}%
                  </span>
                </div>
                <Progress value={processingProgress} />
                <p className="text-xs text-muted-foreground">{processingStatus}</p>
              </div>
            )}

            {/* Operation Results */}
            {operationResults && (
              <div className="space-y-2">
                <h4 className="font-medium">Operation Results</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">
                      {operationResults.successful}
                    </div>
                    <div className="text-xs text-muted-foreground">Successful</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-red-600">
                      {operationResults.failed}
                    </div>
                    <div className="text-xs text-muted-foreground">Failed</div>
                  </div>
                </div>
                
                {operationResults.errors.length > 0 && (
                  <div className="mt-4">
                    <h5 className="text-sm font-medium text-red-600 mb-2">Errors:</h5>
                    <div className="space-y-1">
                      {operationResults.errors.map((error: string, index: number) => (
                        <p key={index} className="text-xs text-red-600">
                          • {error}
                        </p>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex justify-end space-x-2">
              <Button 
                variant="outline" 
                onClick={() => setShowOperationDialog(false)}
                disabled={isProcessing}
              >
                {operationResults ? 'Close' : 'Cancel'}
              </Button>
              
              {!operationResults && (
                <Button 
                  onClick={executeOperation}
                  disabled={isProcessing}
                  className={selectedOperation?.dangerLevel === 'high' ? 'bg-red-600 hover:bg-red-700' : ''}
                >
                  {isProcessing ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Processing...
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 mr-2" />
                      Execute Operation
                    </>
                  )}
                </Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
