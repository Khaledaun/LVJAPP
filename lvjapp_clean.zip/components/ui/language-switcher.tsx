
'use client';

import React from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Globe, Languages } from 'lucide-react';

interface Language {
  code: string;
  name: string;
  nativeName: string;
  flag: string;
  rtl?: boolean;
}

const languages: Language[] = [
  {
    code: 'en',
    name: 'English',
    nativeName: 'English',
    flag: '🇺🇸'
  },
  {
    code: 'ar',
    name: 'Arabic',
    nativeName: 'العربية',
    flag: '🇸🇦',
    rtl: true
  },
  {
    code: 'pt',
    name: 'Portuguese',
    nativeName: 'Português',
    flag: '🇧🇷'
  }
];

interface LanguageSwitcherProps {
  currentLocale: string;
  variant?: 'select' | 'buttons';
  showFlag?: boolean;
  showNativeName?: boolean;
}

export function LanguageSwitcher({ 
  currentLocale, 
  variant = 'select',
  showFlag = true,
  showNativeName = true 
}: LanguageSwitcherProps) {
  const router = useRouter();
  const pathname = usePathname();

  const switchLanguage = (newLocale: string) => {
    // Remove the current locale from the pathname
    const pathWithoutLocale = pathname.replace(/^\/[a-z]{2}/, '');
    
    // Navigate to the new locale
    router.push(`/${newLocale}${pathWithoutLocale}`);
  };

  const getCurrentLanguage = () => {
    return languages.find(lang => lang.code === currentLocale) || languages[0];
  };

  if (variant === 'buttons') {
    return (
      <div className="flex items-center space-x-1">
        {languages.map((language) => (
          <Button
            key={language.code}
            variant={currentLocale === language.code ? 'default' : 'ghost'}
            size="sm"
            onClick={() => switchLanguage(language.code)}
            className={`flex items-center space-x-1 ${
              language.rtl ? 'flex-row-reverse space-x-reverse' : ''
            }`}
          >
            {showFlag && <span className="text-sm">{language.flag}</span>}
            <span className="text-xs font-medium">
              {showNativeName ? language.nativeName : language.name}
            </span>
          </Button>
        ))}
      </div>
    );
  }

  return (
    <Select value={currentLocale} onValueChange={switchLanguage}>
      <SelectTrigger className="w-auto min-w-[120px]">
        <div className="flex items-center space-x-2">
          <Globe className="w-4 h-4" />
          <SelectValue>
            <div className="flex items-center space-x-1">
              {showFlag && <span>{getCurrentLanguage().flag}</span>}
              <span className="text-sm">
                {showNativeName ? getCurrentLanguage().nativeName : getCurrentLanguage().name}
              </span>
            </div>
          </SelectValue>
        </div>
      </SelectTrigger>
      <SelectContent>
        {languages.map((language) => (
          <SelectItem key={language.code} value={language.code}>
            <div className={`flex items-center space-x-2 ${
              language.rtl ? 'flex-row-reverse space-x-reverse' : ''
            }`}>
              {showFlag && <span>{language.flag}</span>}
              <div className="flex flex-col">
                <span className="font-medium">
                  {showNativeName ? language.nativeName : language.name}
                </span>
                {showNativeName && language.nativeName !== language.name && (
                  <span className="text-xs text-muted-foreground">
                    {language.name}
                  </span>
                )}
              </div>
            </div>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

// Compact version for mobile/header use
export function CompactLanguageSwitcher({ currentLocale }: { currentLocale: string }) {
  const router = useRouter();
  const pathname = usePathname();

  const switchLanguage = (newLocale: string) => {
    const pathWithoutLocale = pathname.replace(/^\/[a-z]{2}/, '');
    router.push(`/${newLocale}${pathWithoutLocale}`);
  };

  const getCurrentLanguage = () => {
    return languages.find(lang => lang.code === currentLocale) || languages[0];
  };

  return (
    <Select value={currentLocale} onValueChange={switchLanguage}>
      <SelectTrigger className="w-16 h-8 p-1">
        <SelectValue>
          <span className="text-sm">{getCurrentLanguage().flag}</span>
        </SelectValue>
      </SelectTrigger>
      <SelectContent>
        {languages.map((language) => (
          <SelectItem key={language.code} value={language.code}>
            <div className="flex items-center space-x-2">
              <span>{language.flag}</span>
              <span className="text-sm">{language.code.toUpperCase()}</span>
            </div>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
