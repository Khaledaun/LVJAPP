
'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { 
  MessageSquare, 
  Plus, 
  AlertCircle,
  CheckCircle,
  Clock,
  User,
  Tag,
  Calendar
} from 'lucide-react';
import { format } from 'date-fns';

interface InternalQAProps {
  caseId: string;
  data?: {
    qas: InternalQA[];
    summary: {
      total: number;
      open: number;
      in_progress: number;
      answered: number;
      closed: number;
    };
  };
  onRefresh?: () => void;
}

interface InternalQA {
  id: string;
  question: string;
  answer?: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'open' | 'in_progress' | 'answered' | 'closed';
  askedBy: string;
  answeredBy?: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
  answeredAt?: string;
}

const getPriorityColor = (priority: string) => {
  const colors = {
    low: 'bg-gray-100 text-gray-700',
    medium: 'bg-blue-100 text-blue-800',
    high: 'bg-orange-100 text-orange-800',
    urgent: 'bg-red-100 text-red-800'
  };
  return colors[priority as keyof typeof colors] || colors.medium;
};

const getStatusColor = (status: string) => {
  const colors = {
    open: 'bg-yellow-100 text-yellow-800',
    in_progress: 'bg-blue-100 text-blue-800',
    answered: 'bg-green-100 text-green-800',
    closed: 'bg-gray-100 text-gray-700'
  };
  return colors[status as keyof typeof colors] || colors.open;
};

const getStatusIcon = (status: string) => {
  const icons = {
    open: <AlertCircle className="w-4 h-4" />,
    in_progress: <Clock className="w-4 h-4" />,
    answered: <CheckCircle className="w-4 h-4" />,
    closed: <CheckCircle className="w-4 h-4" />
  };
  return icons[status as keyof typeof icons] || icons.open;
};

export default function InternalQA({ caseId, data, onRefresh }: InternalQAProps) {
  const [selectedQA, setSelectedQA] = useState<InternalQA | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [isAnswering, setIsAnswering] = useState(false);
  const [newQuestion, setNewQuestion] = useState('');
  const [newPriority, setNewPriority] = useState<'low' | 'medium' | 'high' | 'urgent'>('medium');
  const [newTags, setNewTags] = useState('');
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(false);

  const handleCreateQA = async () => {
    if (!newQuestion.trim()) return;

    setLoading(true);
    try {
      const response = await fetch('/api/internal-qa', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          caseId,
          question: newQuestion,
          priority: newPriority,
          tags: newTags.split(',').map(tag => tag.trim()).filter(Boolean)
        })
      });

      if (response.ok) {
        setNewQuestion('');
        setNewPriority('medium');
        setNewTags('');
        setIsCreating(false);
        onRefresh?.();
      }
    } catch (error) {
      console.error('Failed to create Q&A:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAnswerQA = async () => {
    if (!selectedQA || !answer.trim()) return;

    setLoading(true);
    try {
      const response = await fetch(`/api/internal-qa/${selectedQA.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          answer,
          status: 'answered'
        })
      });

      if (response.ok) {
        setAnswer('');
        setIsAnswering(false);
        setSelectedQA(null);
        onRefresh?.();
      }
    } catch (error) {
      console.error('Failed to answer Q&A:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (qaId: string, newStatus: string) => {
    setLoading(true);
    try {
      await fetch(`/api/internal-qa/${qaId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });
      onRefresh?.();
    } catch (error) {
      console.error('Failed to update status:', error);
    } finally {
      setLoading(false);
    }
  };

  if (!data) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5" />
            Internal Q&A System
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-muted-foreground">
            Loading internal Q&A data...
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="w-5 h-5" />
              Internal Q&A System
            </CardTitle>
            <Dialog open={isCreating} onOpenChange={setIsCreating}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Ask Question
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Ask a Question</DialogTitle>
                  <DialogDescription>
                    Ask a question to the LVJ staff team about this case.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="question">Question</Label>
                    <Textarea
                      id="question"
                      value={newQuestion}
                      onChange={(e) => setNewQuestion(e.target.value)}
                      placeholder="What would you like to ask about this case?"
                      rows={3}
                    />
                  </div>
                  <div>
                    <Label htmlFor="priority">Priority</Label>
                    <Select value={newPriority} onValueChange={(value: any) => setNewPriority(value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="urgent">Urgent</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="tags">Tags (comma-separated)</Label>
                    <Input
                      id="tags"
                      value={newTags}
                      onChange={(e) => setNewTags(e.target.value)}
                      placeholder="e.g., visa, documents, timeline"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsCreating(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleCreateQA} disabled={loading || !newQuestion.trim()}>
                    Ask Question
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{data.summary.total}</div>
              <div className="text-sm text-muted-foreground">Total Q&As</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-600">{data.summary.open}</div>
              <div className="text-sm text-muted-foreground">Open</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{data.summary.in_progress}</div>
              <div className="text-sm text-muted-foreground">In Progress</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{data.summary.answered}</div>
              <div className="text-sm text-muted-foreground">Answered</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-600">{data.summary.closed}</div>
              <div className="text-sm text-muted-foreground">Closed</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Q&A List */}
      <div className="space-y-4">
        <AnimatePresence>
          {data.qas.map((qa, index) => (
            <motion.div
              key={qa.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card>
                <CardContent className="pt-6">
                  <div className="space-y-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center gap-2">
                          <Badge className={getPriorityColor(qa.priority)}>
                            {qa.priority}
                          </Badge>
                          <Badge className={getStatusColor(qa.status)}>
                            {getStatusIcon(qa.status)}
                            <span className="ml-1 capitalize">{qa.status.replace('_', ' ')}</span>
                          </Badge>
                          <div className="flex items-center gap-1 text-sm text-muted-foreground">
                            <Calendar className="w-3 h-3" />
                            {format(new Date(qa.createdAt), 'MMM d, yyyy')}
                          </div>
                        </div>
                        <div className="text-sm font-medium">{qa.question}</div>
                        {qa.tags.length > 0 && (
                          <div className="flex items-center gap-1 flex-wrap">
                            <Tag className="w-3 h-3 text-muted-foreground" />
                            {qa.tags.map((tag, i) => (
                              <Badge key={i} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        {qa.status === 'open' && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setSelectedQA(qa);
                              setIsAnswering(true);
                            }}
                          >
                            Answer
                          </Button>
                        )}
                        <Select onValueChange={(value) => handleStatusChange(qa.id, value)}>
                          <SelectTrigger className="w-32">
                            <SelectValue placeholder="Change status" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="open">Open</SelectItem>
                            <SelectItem value="in_progress">In Progress</SelectItem>
                            <SelectItem value="answered">Answered</SelectItem>
                            <SelectItem value="closed">Closed</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {qa.answer && (
                      <div className="border-l-4 border-green-500 pl-4 bg-green-50 p-3 rounded-r">
                        <div className="text-sm font-medium text-green-800 mb-1">Answer:</div>
                        <div className="text-sm text-green-700">{qa.answer}</div>
                        {qa.answeredAt && (
                          <div className="text-xs text-green-600 mt-2">
                            Answered on {format(new Date(qa.answeredAt), 'MMM d, yyyy')}
                          </div>
                        )}
                      </div>
                    )}

                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <User className="w-3 h-3" />
                        Asked by: {qa.askedBy}
                      </div>
                      {qa.answeredBy && (
                        <div className="flex items-center gap-1">
                          <User className="w-3 h-3" />
                          Answered by: {qa.answeredBy}
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </AnimatePresence>

        {data.qas.length === 0 && (
          <Card>
            <CardContent className="pt-6">
              <div className="text-center text-muted-foreground">
                No questions have been asked yet. Click "Ask Question" to start a discussion.
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Answer Dialog */}
      <Dialog open={isAnswering} onOpenChange={setIsAnswering}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Answer Question</DialogTitle>
            <DialogDescription>
              {selectedQA?.question}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="answer">Answer</Label>
              <Textarea
                id="answer"
                value={answer}
                onChange={(e) => setAnswer(e.target.value)}
                placeholder="Provide a detailed answer to this question..."
                rows={4}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAnswering(false)}>
              Cancel
            </Button>
            <Button onClick={handleAnswerQA} disabled={loading || !answer.trim()}>
              Submit Answer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
