
'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { 
  StickyNote, 
  Plus, 
  Eye,
  EyeOff,
  Calendar,
  User,
  FileText,
  DollarSign,
  MessageSquare,
  CheckSquare,
  Milestone
} from 'lucide-react';
import { format } from 'date-fns';

interface CaseNotesProps {
  caseId: string;
  data?: {
    notes: CaseNote[];
    summary: {
      total: number;
      private: number;
      public: number;
      types: {
        general: number;
        legal: number;
        financial: number;
        todo: number;
      };
    };
  };
  onRefresh?: () => void;
}

interface CaseNote {
  id: string;
  content: string;
  type: 'general' | 'legal' | 'financial' | 'client_communication' | 'internal_discussion' | 'todo' | 'milestone';
  isPrivate: boolean;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

const getNoteTypeIcon = (type: string) => {
  const icons = {
    general: <StickyNote className="w-4 h-4" />,
    legal: <FileText className="w-4 h-4" />,
    financial: <DollarSign className="w-4 h-4" />,
    client_communication: <MessageSquare className="w-4 h-4" />,
    internal_discussion: <MessageSquare className="w-4 h-4" />,
    todo: <CheckSquare className="w-4 h-4" />,
    milestone: <Milestone className="w-4 h-4" />
  };
  return icons[type as keyof typeof icons] || icons.general;
};

const getNoteTypeColor = (type: string) => {
  const colors = {
    general: 'bg-gray-100 text-gray-700',
    legal: 'bg-blue-100 text-blue-800',
    financial: 'bg-green-100 text-green-800',
    client_communication: 'bg-purple-100 text-purple-800',
    internal_discussion: 'bg-orange-100 text-orange-800',
    todo: 'bg-yellow-100 text-yellow-800',
    milestone: 'bg-red-100 text-red-800'
  };
  return colors[type as keyof typeof colors] || colors.general;
};

export default function CaseNotes({ caseId, data, onRefresh }: CaseNotesProps) {
  const [isCreating, setIsCreating] = useState(false);
  const [newContent, setNewContent] = useState('');
  const [newType, setNewType] = useState<CaseNote['type']>('general');
  const [isPrivate, setIsPrivate] = useState(false);
  const [filterType, setFilterType] = useState<string>('all');
  const [filterPrivacy, setFilterPrivacy] = useState<string>('all');
  const [loading, setLoading] = useState(false);

  const handleCreateNote = async () => {
    if (!newContent.trim()) return;

    setLoading(true);
    try {
      const response = await fetch('/api/case-notes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          caseId,
          content: newContent,
          type: newType,
          isPrivate
        })
      });

      if (response.ok) {
        setNewContent('');
        setNewType('general');
        setIsPrivate(false);
        setIsCreating(false);
        onRefresh?.();
      }
    } catch (error) {
      console.error('Failed to create note:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredNotes = data?.notes.filter(note => {
    const typeMatch = filterType === 'all' || note.type === filterType;
    const privacyMatch = filterPrivacy === 'all' || 
      (filterPrivacy === 'private' && note.isPrivate) ||
      (filterPrivacy === 'public' && !note.isPrivate);
    return typeMatch && privacyMatch;
  }) || [];

  if (!data) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <StickyNote className="w-5 h-5" />
            Case Notes
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-muted-foreground">
            Loading case notes...
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <StickyNote className="w-5 h-5" />
              Case Notes
            </CardTitle>
            <Dialog open={isCreating} onOpenChange={setIsCreating}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Note
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add Case Note</DialogTitle>
                  <DialogDescription>
                    Add a note to keep track of important information about this case.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="content">Note Content</Label>
                    <Textarea
                      id="content"
                      value={newContent}
                      onChange={(e) => setNewContent(e.target.value)}
                      placeholder="Enter your note here..."
                      rows={4}
                    />
                  </div>
                  <div>
                    <Label htmlFor="type">Note Type</Label>
                    <Select value={newType} onValueChange={(value: any) => setNewType(value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="general">General</SelectItem>
                        <SelectItem value="legal">Legal</SelectItem>
                        <SelectItem value="financial">Financial</SelectItem>
                        <SelectItem value="client_communication">Client Communication</SelectItem>
                        <SelectItem value="internal_discussion">Internal Discussion</SelectItem>
                        <SelectItem value="todo">To-Do</SelectItem>
                        <SelectItem value="milestone">Milestone</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="private"
                      checked={isPrivate}
                      onCheckedChange={(checked) => setIsPrivate(!!checked)}
                    />
                    <Label htmlFor="private" className="text-sm">
                      Private note (visible only to internal staff)
                    </Label>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsCreating(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleCreateNote} disabled={loading || !newContent.trim()}>
                    Add Note
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{data.summary.total}</div>
              <div className="text-sm text-muted-foreground">Total Notes</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">{data.summary.private}</div>
              <div className="text-sm text-muted-foreground">Private</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{data.summary.public}</div>
              <div className="text-sm text-muted-foreground">Public</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-600">{data.summary.types.todo}</div>
              <div className="text-sm text-muted-foreground">To-Do Items</div>
            </div>
          </div>

          {/* Filters */}
          <div className="flex gap-4">
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="general">General</SelectItem>
                <SelectItem value="legal">Legal</SelectItem>
                <SelectItem value="financial">Financial</SelectItem>
                <SelectItem value="client_communication">Client Communication</SelectItem>
                <SelectItem value="internal_discussion">Internal Discussion</SelectItem>
                <SelectItem value="todo">To-Do</SelectItem>
                <SelectItem value="milestone">Milestone</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterPrivacy} onValueChange={setFilterPrivacy}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter by privacy" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Notes</SelectItem>
                <SelectItem value="public">Public Only</SelectItem>
                <SelectItem value="private">Private Only</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Notes List */}
      <div className="space-y-4">
        <AnimatePresence>
          {filteredNotes.map((note, index) => (
            <motion.div
              key={note.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className={note.isPrivate ? 'border-red-200 bg-red-50/50' : ''}>
                <CardContent className="pt-6">
                  <div className="space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2">
                        <Badge className={getNoteTypeColor(note.type)}>
                          {getNoteTypeIcon(note.type)}
                          <span className="ml-1 capitalize">
                            {note.type.replace('_', ' ')}
                          </span>
                        </Badge>
                        {note.isPrivate && (
                          <Badge variant="outline" className="text-red-600 border-red-300">
                            <EyeOff className="w-3 h-3 mr-1" />
                            Private
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Calendar className="w-3 h-3" />
                        {format(new Date(note.createdAt), 'MMM d, yyyy HH:mm')}
                      </div>
                    </div>

                    <div className="text-sm leading-relaxed whitespace-pre-wrap">
                      {note.content}
                    </div>

                    <div className="flex items-center gap-1 text-xs text-muted-foreground pt-2 border-t">
                      <User className="w-3 h-3" />
                      Created by: {note.createdBy}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </AnimatePresence>

        {filteredNotes.length === 0 && (
          <Card>
            <CardContent className="pt-6">
              <div className="text-center text-muted-foreground">
                No notes found. Click "Add Note" to create the first note for this case.
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
