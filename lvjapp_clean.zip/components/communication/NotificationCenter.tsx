
'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { 
  Bell, 
  BellOff,
  CheckCircle,
  AlertCircle,
  FileText,
  User,
  DollarSign,
  Calendar,
  Settings,
  MoreVertical,
  ExternalLink
} from 'lucide-react';
import { format } from 'date-fns';
import { useRouter } from 'next/navigation';

interface NotificationCenterProps {
  data?: {
    notifications: Notification[];
    summary: {
      total: number;
      unread: number;
      urgent: number;
      high: number;
    };
  };
  onRefresh?: () => void;
}

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'case_update' | 'document_upload' | 'document_approved' | 'document_rejected' | 
        'deadline_reminder' | 'qa_question' | 'qa_answer' | 'system_alert' | 
        'payment_received' | 'workflow_trigger';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  isRead: boolean;
  actionUrl?: string;
  metadata?: any;
  caseId?: string;
  case?: {
    id: string;
    title: string;
    caseNumber: string;
  };
  createdAt: string;
  readAt?: string;
}

const getNotificationIcon = (type: string) => {
  const icons = {
    case_update: <FileText className="w-4 h-4" />,
    document_upload: <FileText className="w-4 h-4" />,
    document_approved: <CheckCircle className="w-4 h-4" />,
    document_rejected: <AlertCircle className="w-4 h-4" />,
    deadline_reminder: <Calendar className="w-4 h-4" />,
    qa_question: <Bell className="w-4 h-4" />,
    qa_answer: <Bell className="w-4 h-4" />,
    system_alert: <AlertCircle className="w-4 h-4" />,
    payment_received: <DollarSign className="w-4 h-4" />,
    workflow_trigger: <Settings className="w-4 h-4" />
  };
  return icons[type as keyof typeof icons] || icons.system_alert;
};

const getPriorityColor = (priority: string) => {
  const colors = {
    low: 'bg-gray-100 text-gray-700',
    medium: 'bg-blue-100 text-blue-800',
    high: 'bg-orange-100 text-orange-800',
    urgent: 'bg-red-100 text-red-800'
  };
  return colors[priority as keyof typeof colors] || colors.medium;
};

export default function NotificationCenter({ data, onRefresh }: NotificationCenterProps) {
  const router = useRouter();
  const [filter, setFilter] = useState<string>('all');
  const [loading, setLoading] = useState(false);

  const handleMarkAsRead = async (notificationId: string) => {
    setLoading(true);
    try {
      await fetch(`/api/notifications/${notificationId}/read`, {
        method: 'PUT'
      });
      onRefresh?.();
    } catch (error) {
      console.error('Failed to mark notification as read:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleNotificationClick = async (notification: Notification) => {
    // Mark as read when clicked
    if (!notification.isRead) {
      await handleMarkAsRead(notification.id);
    }

    // Navigate to action URL if provided
    if (notification.actionUrl) {
      router.push(notification.actionUrl);
    }
  };

  const filteredNotifications = data?.notifications.filter(notification => {
    if (filter === 'all') return true;
    if (filter === 'unread') return !notification.isRead;
    return notification.type === filter;
  }) || [];

  if (!data) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="w-5 h-5" />
            Notifications
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-muted-foreground">
            Loading notifications...
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="h-[600px] flex flex-col">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Bell className="w-5 h-5" />
            Notifications
            {data.summary.unread > 0 && (
              <Badge variant="destructive" className="ml-2">
                {data.summary.unread}
              </Badge>
            )}
          </CardTitle>
          <Button variant="outline" size="sm" onClick={onRefresh}>
            Refresh
          </Button>
        </div>
        
        {/* Summary Stats */}
        <div className="grid grid-cols-4 gap-4 mt-4">
          <div className="text-center">
            <div className="text-lg font-bold text-blue-600">{data.summary.total}</div>
            <div className="text-xs text-muted-foreground">Total</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-yellow-600">{data.summary.unread}</div>
            <div className="text-xs text-muted-foreground">Unread</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-orange-600">{data.summary.high}</div>
            <div className="text-xs text-muted-foreground">High Priority</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-red-600">{data.summary.urgent}</div>
            <div className="text-xs text-muted-foreground">Urgent</div>
          </div>
        </div>

        {/* Filter */}
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="Filter notifications" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Notifications</SelectItem>
            <SelectItem value="unread">Unread Only</SelectItem>
            <SelectItem value="case_update">Case Updates</SelectItem>
            <SelectItem value="document_upload">Document Uploads</SelectItem>
            <SelectItem value="deadline_reminder">Deadline Reminders</SelectItem>
            <SelectItem value="payment_received">Payment Notifications</SelectItem>
            <SelectItem value="system_alert">System Alerts</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>

      <CardContent className="flex-1 p-0">
        <ScrollArea className="h-full px-6">
          <div className="space-y-2">
            <AnimatePresence>
              {filteredNotifications.map((notification, index) => (
                <motion.div
                  key={notification.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ delay: index * 0.05 }}
                  className={`p-4 rounded-lg border transition-colors cursor-pointer hover:bg-muted/50 ${
                    !notification.isRead ? 'bg-blue-50 border-blue-200' : 'bg-background'
                  }`}
                  onClick={() => handleNotificationClick(notification)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3 flex-1">
                      <div className={`p-2 rounded-lg ${getPriorityColor(notification.priority)}`}>
                        {getNotificationIcon(notification.type)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <div className="font-medium text-sm truncate">
                            {notification.title}
                          </div>
                          {!notification.isRead && (
                            <div className="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0" />
                          )}
                        </div>
                        <div className="text-sm text-muted-foreground mb-2">
                          {notification.message}
                        </div>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {format(new Date(notification.createdAt), 'MMM d, HH:mm')}
                          </div>
                          {notification.case && (
                            <div className="flex items-center gap-1">
                              <FileText className="w-3 h-3" />
                              {notification.case.caseNumber}
                            </div>
                          )}
                          <Badge variant="outline" className="text-xs">
                            {notification.type.replace('_', ' ')}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {notification.actionUrl && (
                        <ExternalLink className="w-4 h-4 text-muted-foreground" />
                      )}
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <MoreVertical className="w-3 h-3" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          {!notification.isRead && (
                            <DropdownMenuItem 
                              onClick={(e) => {
                                e.stopPropagation();
                                handleMarkAsRead(notification.id);
                              }}
                            >
                              <CheckCircle className="w-4 h-4 mr-2" />
                              Mark as read
                            </DropdownMenuItem>
                          )}
                          {notification.case && (
                            <DropdownMenuItem 
                              onClick={(e) => {
                                e.stopPropagation();
                                router.push(`/cases/${notification.case?.id}`);
                              }}
                            >
                              <FileText className="w-4 h-4 mr-2" />
                              View case
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {filteredNotifications.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                <BellOff className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <div>No notifications found</div>
                <div className="text-sm">
                  {filter === 'unread' 
                    ? "You're all caught up!" 
                    : "You don't have any notifications yet."
                  }
                </div>
              </div>
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
