'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface AnalyticsData {
  caseMetrics: {
    totalCases: number;
    activeCases: number;
    completedCases: number;
    pendingCases: number;
    averageProcessingTime: number;
    successRate: number;
  };
  documentMetrics: {
    totalDocuments: number;
    approved: number;
    pendingReview: number;
    rejected: number;
    averageReviewTime: number;
  };
  financialMetrics: {
    totalRevenue: number;
    monthlyRevenue: number;
    averageCaseValue: number;
    outstandingPayments: number;
  };
  performanceMetrics: {
    casesByMonth: Array<{ month: string; cases: number; revenue: number }>;
    documentsByStatus: Array<{ status: string; count: number }>;
    casesByType: Array<{ type: string; count: number; averageTime: number }>;
    userActivity: Array<{ date: string; activeUsers: number; newCases: number }>;
  };
}

interface AdvancedAnalyticsProps {
  data?: AnalyticsData;
  dateRange?: { from: Date; to: Date };
  onDateRangeChange?: (range: { from: Date; to: Date }) => void;
  onExport?: (format: 'pdf' | 'excel' | 'csv') => void;
}

export default function AdvancedAnalytics({
  data,
  dateRange,
  onDateRangeChange,
  onExport
}: AdvancedAnalyticsProps) {
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');

  // Mock data if none provided
  const mockData: AnalyticsData = {
    caseMetrics: {
      totalCases: 150,
      activeCases: 45,
      completedCases: 95,
      pendingCases: 10,
      averageProcessingTime: 30,
      successRate: 92.5,
    },
    documentMetrics: {
      totalDocuments: 450,
      approved: 380,
      pendingReview: 50,
      rejected: 20,
      averageReviewTime: 5,
    },
    financialMetrics: {
      totalRevenue: 125000,
      monthlyRevenue: 15000,
      averageCaseValue: 833,
      outstandingPayments: 5000,
    },
    performanceMetrics: {
      casesByMonth: [
        { month: 'Jan', cases: 12, revenue: 10000 },
        { month: 'Feb', cases: 15, revenue: 12500 },
        { month: 'Mar', cases: 18, revenue: 15000 },
      ],
      documentsByStatus: [
        { status: 'Approved', count: 380 },
        { status: 'Pending', count: 50 },
        { status: 'Rejected', count: 20 },
      ],
      casesByType: [
        { type: 'Work Visa', count: 60, averageTime: 25 },
        { type: 'Student Visa', count: 45, averageTime: 20 },
        { type: 'Family Visa', count: 35, averageTime: 35 },
      ],
      userActivity: [
        { date: '2024-01-01', activeUsers: 25, newCases: 3 },
        { date: '2024-01-02', activeUsers: 30, newCases: 5 },
      ],
    },
  };

  const analyticsData = data || mockData;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Advanced Analytics</h1>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => onExport?.('pdf')}>
            Export PDF
          </Button>
          <Button variant="outline" onClick={() => onExport?.('excel')}>
            Export Excel
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="cases">Cases</TabsTrigger>
          <TabsTrigger value="documents">Documents</TabsTrigger>
          <TabsTrigger value="financial">Financial</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Cases</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{analyticsData.caseMetrics.totalCases}</div>
                <p className="text-xs text-muted-foreground">
                  {analyticsData.caseMetrics.activeCases} active cases
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{analyticsData.caseMetrics.successRate}%</div>
                <p className="text-xs text-muted-foreground">
                  {analyticsData.caseMetrics.completedCases} completed cases
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  ${analyticsData.financialMetrics.totalRevenue.toLocaleString()}
                </div>
                <p className="text-xs text-muted-foreground">
                  ${analyticsData.financialMetrics.monthlyRevenue.toLocaleString()} this month
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Documents</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{analyticsData.documentMetrics.totalDocuments}</div>
                <p className="text-xs text-muted-foreground">
                  {analyticsData.documentMetrics.pendingReview} pending review
                </p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="cases" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Case Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span>Active Cases</span>
                  <Badge variant="default">{analyticsData.caseMetrics.activeCases}</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Completed Cases</span>
                  <Badge variant="secondary">{analyticsData.caseMetrics.completedCases}</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Pending Cases</span>
                  <Badge variant="outline">{analyticsData.caseMetrics.pendingCases}</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="documents" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Document Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span>Approved</span>
                  <Badge variant="default">{analyticsData.documentMetrics.approved}</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Pending Review</span>
                  <Badge variant="secondary">{analyticsData.documentMetrics.pendingReview}</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Rejected</span>
                  <Badge variant="destructive">{analyticsData.documentMetrics.rejected}</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="financial" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Financial Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span>Total Revenue</span>
                  <span className="font-bold">
                    ${analyticsData.financialMetrics.totalRevenue.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Monthly Revenue</span>
                  <span className="font-bold">
                    ${analyticsData.financialMetrics.monthlyRevenue.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Average Case Value</span>
                  <span className="font-bold">
                    ${analyticsData.financialMetrics.averageCaseValue.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Outstanding Payments</span>
                  <Badge variant="outline">
                    ${analyticsData.financialMetrics.outstandingPayments.toLocaleString()}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
