'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface AnalyticsData {
  totalCases: number;
  activeCases: number;
  completedCases: number;
  pendingDocuments: number;
  totalRevenue: number;
  casesByStatus: Array<{ name: string; value: number; color: string }>;
  monthlyTrends: Array<{ month: string; cases: number; revenue: number }>;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

export default function SimpleAnalytics() {
  const [data, setData] = useState<AnalyticsData>({
    totalCases: 0,
    activeCases: 0,
    completedCases: 0,
    pendingDocuments: 0,
    totalRevenue: 0,
    casesByStatus: [],
    monthlyTrends: []
  });
  const [selectedMetric, setSelectedMetric] = useState('cases');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnalyticsData();
  }, []);

  const fetchAnalyticsData = async () => {
    try {
      // Mock data for now - replace with actual API call
      const mockData: AnalyticsData = {
        totalCases: 156,
        activeCases: 89,
        completedCases: 67,
        pendingDocuments: 23,
        totalRevenue: 45600,
        casesByStatus: [
          { name: 'New', value: 25, color: COLORS[0] },
          { name: 'In Progress', value: 45, color: COLORS[1] },
          { name: 'Under Review', value: 19, color: COLORS[2] },
          { name: 'Completed', value: 67, color: COLORS[3] }
        ],
        monthlyTrends: [
          { month: 'Jan', cases: 12, revenue: 3200 },
          { month: 'Feb', cases: 19, revenue: 4800 },
          { month: 'Mar', cases: 15, revenue: 3900 },
          { month: 'Apr', cases: 22, revenue: 5600 },
          { month: 'May', cases: 18, revenue: 4200 },
          { month: 'Jun', cases: 25, revenue: 6800 }
        ]
      };
      
      setData(mockData);
      setLoading(false);
    } catch (error) {
      console.error('Failed to fetch analytics data:', error);
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardHeader className="animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-8 bg-gray-200 rounded w-1/2"></div>
              </CardHeader>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Cases</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.totalCases}</div>
            <p className="text-xs text-muted-foreground">
              +12% from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Cases</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.activeCases}</div>
            <p className="text-xs text-muted-foreground">
              +8% from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completed Cases</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.completedCases}</div>
            <p className="text-xs text-muted-foreground">
              +15% from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${data.totalRevenue.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              +20% from last month
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Case Status Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Case Status Distribution</CardTitle>
            <CardDescription>Current status of all cases</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {data.casesByStatus.map((item, index) => (
                <div key={item.name} className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div 
                      className="w-4 h-4 rounded mr-3" 
                      style={{ backgroundColor: item.color }}
                    />
                    <span className="text-sm font-medium">{item.name}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-bold">{item.value}</span>
                    <div className="w-20 bg-gray-200 rounded-full h-2">
                      <div 
                        className="h-2 rounded-full" 
                        style={{ 
                          backgroundColor: item.color,
                          width: `${(item.value / data.totalCases) * 100}%`
                        }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Monthly Trends */}
        <Card>
          <CardHeader>
            <CardTitle>Monthly Trends</CardTitle>
            <CardDescription>Cases and revenue over time</CardDescription>
            <Select value={selectedMetric} onValueChange={setSelectedMetric}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="cases">Cases</SelectItem>
                <SelectItem value="revenue">Revenue</SelectItem>
              </SelectContent>
            </Select>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {data.monthlyTrends.map((item, index) => {
                const value = selectedMetric === 'cases' ? item.cases : item.revenue;
                const maxValue = selectedMetric === 'cases' 
                  ? Math.max(...data.monthlyTrends.map(t => t.cases))
                  : Math.max(...data.monthlyTrends.map(t => t.revenue));
                
                return (
                  <div key={item.month} className="flex items-center justify-between">
                    <span className="text-sm font-medium w-12">{item.month}</span>
                    <div className="flex-1 mx-4">
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <div 
                          className="bg-blue-600 h-3 rounded-full transition-all duration-300" 
                          style={{ width: `${(value / maxValue) * 100}%` }}
                        />
                      </div>
                    </div>
                    <span className="text-sm font-bold w-16 text-right">
                      {selectedMetric === 'cases' ? value : `$${value.toLocaleString()}`}
                    </span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Additional Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Pending Documents</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-orange-600">{data.pendingDocuments}</div>
            <p className="text-sm text-muted-foreground mt-2">
              Documents awaiting review
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Average Processing Time</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">14 days</div>
            <p className="text-sm text-muted-foreground mt-2">
              -2 days from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Client Satisfaction</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">4.8/5</div>
            <p className="text-sm text-muted-foreground mt-2">
              Based on 127 reviews
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
