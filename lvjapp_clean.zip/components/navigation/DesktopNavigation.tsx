
'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { LanguageSwitcher } from '@/components/ui/language-switcher';
import { 
  Home, 
  BarChart3, 
  FileText, 
  CreditCard, 
  Users, 
  Settings, 
  Bell,
  Search
} from 'lucide-react';

interface NavigationItem {
  href: string;
  label: string;
  icon: React.ReactNode;
  badge?: number;
}

interface DesktopNavigationProps {
  locale: string;
  notificationCount?: number;
}

export default function DesktopNavigation({ locale, notificationCount = 0 }: DesktopNavigationProps) {
  const pathname = usePathname();
  const t = useTranslations('navigation');

  const navigationItems: NavigationItem[] = [
    {
      href: `/${locale}`,
      label: t('home'),
      icon: <Home className="w-5 h-5" />
    },
    {
      href: `/${locale}/dashboard`,
      label: t('dashboard'),
      icon: <BarChart3 className="w-5 h-5" />
    },
    {
      href: `/${locale}/cases`,
      label: t('cases'),
      icon: <FileText className="w-5 h-5" />
    },
    {
      href: `/${locale}/documents`,
      label: t('documents'),
      icon: <FileText className="w-5 h-5" />
    },
    {
      href: `/${locale}/payments`,
      label: t('payments'),
      icon: <CreditCard className="w-5 h-5" />
    },
    {
      href: `/${locale}/reports`,
      label: t('reports'),
      icon: <BarChart3 className="w-5 h-5" />
    }
  ];

  const isActive = (href: string) => {
    if (href === `/${locale}`) {
      return pathname === href;
    }
    return pathname.startsWith(href);
  };

  return (
    <div className="hidden lg:flex fixed top-0 left-0 right-0 z-50 bg-white border-b border-gray-200 px-6 py-4">
      <div className="flex items-center justify-between w-full max-w-7xl mx-auto">
        {/* Logo */}
        <div className="flex items-center space-x-8">
          <Link href={`/${locale}`} className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">LVJ</span>
            </div>
            <div>
              <h1 className="text-lg font-semibold">LVJ Immigration</h1>
              <p className="text-xs text-muted-foreground">Case Management</p>
            </div>
          </Link>

          {/* Navigation Items */}
          <nav className="flex items-center space-x-1">
            {navigationItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors ${
                  isActive(item.href)
                    ? 'bg-blue-50 text-blue-700'
                    : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                {item.icon}
                <span className="font-medium">{item.label}</span>
                {item.badge && (
                  <Badge variant="secondary" className="ml-1">
                    {item.badge}
                  </Badge>
                )}
              </Link>
            ))}
          </nav>
        </div>

        {/* Right Side Actions */}
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm">
            <Search className="w-5 h-5" />
          </Button>
          
          <Button variant="ghost" size="sm" className="relative">
            <Bell className="w-5 h-5" />
            {notificationCount > 0 && (
              <Badge 
                variant="destructive" 
                className="absolute -top-1 -right-1 px-1 min-w-[1.25rem] h-5 text-xs"
              >
                {notificationCount}
              </Badge>
            )}
          </Button>

          <LanguageSwitcher currentLocale={locale} />

          <div className="flex items-center space-x-2">
            <Link href={`/${locale}/profile`}>
              <Button variant="ghost" size="sm">
                <Users className="w-5 h-5 mr-2" />
                Profile
              </Button>
            </Link>
            
            <Link href={`/${locale}/settings`}>
              <Button variant="ghost" size="sm">
                <Settings className="w-5 h-5" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
