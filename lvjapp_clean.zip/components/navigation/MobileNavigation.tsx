
'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';
import { CompactLanguageSwitcher } from '@/components/ui/language-switcher';
import { 
  Menu, 
  Home, 
  BarChart3, 
  FileText, 
  CreditCard, 
  Users, 
  Settings, 
  Bell,
  Search,
  X
} from 'lucide-react';
import { motion } from 'framer-motion';

interface NavigationItem {
  href: string;
  label: string;
  icon: React.ReactNode;
  badge?: number;
  description?: string;
}

interface MobileNavigationProps {
  locale: string;
  notificationCount?: number;
}

export default function MobileNavigation({ locale, notificationCount = 0 }: MobileNavigationProps) {
  const [isOpen, setIsOpen] = useState(false);
  const pathname = usePathname();
  const t = useTranslations('navigation');

  const navigationItems: NavigationItem[] = [
    {
      href: `/${locale}`,
      label: t('home'),
      icon: <Home className="w-5 h-5" />,
      description: 'Dashboard overview'
    },
    {
      href: `/${locale}/dashboard`,
      label: t('dashboard'),
      icon: <BarChart3 className="w-5 h-5" />,
      description: 'Case management dashboard'
    },
    {
      href: `/${locale}/cases`,
      label: t('cases'),
      icon: <FileText className="w-5 h-5" />,
      description: 'Manage immigration cases'
    },
    {
      href: `/${locale}/documents`,
      label: t('documents'),
      icon: <FileText className="w-5 h-5" />,
      description: 'Document management'
    },
    {
      href: `/${locale}/payments`,
      label: t('payments'),
      icon: <CreditCard className="w-5 h-5" />,
      description: 'Payment tracking'
    },
    {
      href: `/${locale}/reports`,
      label: t('reports'),
      icon: <BarChart3 className="w-5 h-5" />,
      description: 'Analytics and reports'
    },
    {
      href: `/${locale}/profile`,
      label: t('profile'),
      icon: <Users className="w-5 h-5" />,
      description: 'User profile settings'
    },
    {
      href: `/${locale}/settings`,
      label: t('settings'),
      icon: <Settings className="w-5 h-5" />,
      description: 'Application settings'
    }
  ];

  const isActive = (href: string) => {
    if (href === `/${locale}`) {
      return pathname === href;
    }
    return pathname.startsWith(href);
  };

  return (
    <>
      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-50 bg-white border-b border-gray-200 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm" className="p-2">
                  <Menu className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-80 p-0">
                <div className="flex flex-col h-full">
                  {/* Header */}
                  <div className="p-6 border-b">
                    <div className="flex items-center justify-between">
                      <div>
                        <h2 className="text-lg font-semibold">LVJ Immigration</h2>
                        <p className="text-sm text-muted-foreground">Case Management</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setIsOpen(false)}
                        className="p-2"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  {/* Navigation Items */}
                  <div className="flex-1 overflow-y-auto py-4">
                    <nav className="space-y-1 px-3">
                      {navigationItems.map((item, index) => (
                        <motion.div
                          key={item.href}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.05 }}
                        >
                          <Link
                            href={item.href}
                            onClick={() => setIsOpen(false)}
                            className={`flex items-center space-x-3 px-3 py-3 rounded-lg transition-colors ${
                              isActive(item.href)
                                ? 'bg-blue-50 text-blue-700 border-l-4 border-blue-700'
                                : 'text-gray-700 hover:bg-gray-50'
                            }`}
                          >
                            <div className="flex-shrink-0">
                              {item.icon}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between">
                                <span className="font-medium">{item.label}</span>
                                {item.badge && (
                                  <Badge variant="secondary" className="ml-2">
                                    {item.badge}
                                  </Badge>
                                )}
                              </div>
                              {item.description && (
                                <p className="text-xs text-muted-foreground mt-1">
                                  {item.description}
                                </p>
                              )}
                            </div>
                          </Link>
                        </motion.div>
                      ))}
                    </nav>
                  </div>

                  {/* Footer */}
                  <div className="p-4 border-t">
                    <div className="flex items-center justify-between">
                      <CompactLanguageSwitcher currentLocale={locale} />
                      <Button variant="outline" size="sm">
                        <Bell className="w-4 h-4 mr-2" />
                        {notificationCount > 0 && (
                          <Badge variant="destructive" className="ml-1 px-1 min-w-[1.25rem] h-5">
                            {notificationCount}
                          </Badge>
                        )}
                      </Button>
                    </div>
                  </div>
                </div>
              </SheetContent>
            </Sheet>

            <div>
              <h1 className="text-lg font-semibold">LVJ Immigration</h1>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" className="p-2">
              <Search className="w-5 h-5" />
            </Button>
            
            <Button variant="ghost" size="sm" className="p-2 relative">
              <Bell className="w-5 h-5" />
              {notificationCount > 0 && (
                <Badge 
                  variant="destructive" 
                  className="absolute -top-1 -right-1 px-1 min-w-[1.25rem] h-5 text-xs"
                >
                  {notificationCount}
                </Badge>
              )}
            </Button>

            <CompactLanguageSwitcher currentLocale={locale} />
          </div>
        </div>
      </div>

      {/* Spacer for fixed header */}
      <div className="lg:hidden h-16" />
    </>
  );
}
