
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  DollarSign, 
  CreditCard, 
  Calendar, 
  AlertCircle, 
  CheckCircle, 
  Clock,
  Plus,
  Download,
  Filter,
  Search,
  TrendingUp,
  TrendingDown
} from 'lucide-react';
import { motion } from 'framer-motion';

interface Payment {
  id: string;
  caseId: string;
  caseNumber: string;
  clientName: string;
  amount: number;
  currency: string;
  status: 'paid' | 'pending' | 'overdue' | 'partial';
  dueDate: string;
  paidDate?: string;
  paymentMethod?: string;
  description: string;
  invoiceNumber: string;
  stripePaymentId?: string;
  installmentPlan?: {
    totalInstallments: number;
    currentInstallment: number;
    installmentAmount: number;
  };
}

interface PaymentSummary {
  totalRevenue: number;
  paidAmount: number;
  pendingAmount: number;
  overdueAmount: number;
  thisMonthRevenue: number;
  lastMonthRevenue: number;
  averagePaymentTime: number;
  paymentMethods: {
    [key: string]: number;
  };
}

export default function PaymentTracker({ caseId }: { caseId?: string }) {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [summary, setSummary] = useState<PaymentSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [showAddPayment, setShowAddPayment] = useState(false);
  const [newPayment, setNewPayment] = useState({
    caseId: caseId || '',
    amount: '',
    currency: 'USD',
    description: '',
    dueDate: '',
    paymentMethod: 'stripe'
  });

  useEffect(() => {
    loadPayments();
    loadPaymentSummary();
  }, [caseId]);

  const loadPayments = async () => {
    try {
      const url = caseId ? `/api/cases/${caseId}/payments` : '/api/payments';
      const response = await fetch(url);
      const data = await response.json();
      
      // Mock data for demonstration
      const mockPayments: Payment[] = [
        {
          id: '1',
          caseId: 'case-1',
          caseNumber: 'LVJ-2024-001',
          clientName: 'John Smith',
          amount: 2500,
          currency: 'USD',
          status: 'paid',
          dueDate: '2024-01-15',
          paidDate: '2024-01-10',
          paymentMethod: 'stripe',
          description: 'Initial consultation and filing fee',
          invoiceNumber: 'INV-001',
          stripePaymentId: 'pi_1234567890'
        },
        {
          id: '2',
          caseId: 'case-2',
          caseNumber: 'LVJ-2024-002',
          clientName: 'Maria Garcia',
          amount: 1800,
          currency: 'USD',
          status: 'pending',
          dueDate: '2024-02-01',
          description: 'Document preparation fee',
          invoiceNumber: 'INV-002',
          installmentPlan: {
            totalInstallments: 3,
            currentInstallment: 1,
            installmentAmount: 600
          }
        },
        {
          id: '3',
          caseId: 'case-3',
          caseNumber: 'LVJ-2024-003',
          clientName: 'Ahmed Hassan',
          amount: 3200,
          currency: 'USD',
          status: 'overdue',
          dueDate: '2024-01-20',
          description: 'Legal representation fee',
          invoiceNumber: 'INV-003'
        }
      ];
      
      setPayments(mockPayments);
    } catch (error) {
      console.error('Error loading payments:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadPaymentSummary = async () => {
    try {
      // Mock summary data
      const mockSummary: PaymentSummary = {
        totalRevenue: 485750,
        paidAmount: 398200,
        pendingAmount: 67550,
        overdueAmount: 20000,
        thisMonthRevenue: 87750,
        lastMonthRevenue: 78000,
        averagePaymentTime: 12,
        paymentMethods: {
          stripe: 65,
          bank_transfer: 25,
          check: 8,
          cash: 2
        }
      };
      
      setSummary(mockSummary);
    } catch (error) {
      console.error('Error loading payment summary:', error);
    }
  };

  const handleAddPayment = async () => {
    try {
      const response = await fetch('/api/payments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...newPayment,
          amount: parseFloat(newPayment.amount)
        }),
      });

      if (response.ok) {
        setShowAddPayment(false);
        setNewPayment({
          caseId: caseId || '',
          amount: '',
          currency: 'USD',
          description: '',
          dueDate: '',
          paymentMethod: 'stripe'
        });
        loadPayments();
        loadPaymentSummary();
      }
    } catch (error) {
      console.error('Error adding payment:', error);
    }
  };

  const processStripePayment = async (paymentId: string) => {
    try {
      // Mock Stripe integration
      console.log('Processing Stripe payment for:', paymentId);
      // In real app, this would integrate with Stripe API
      
      // Update payment status
      setPayments(prev => prev.map(p => 
        p.id === paymentId 
          ? { ...p, status: 'paid' as const, paidDate: new Date().toISOString().split('T')[0] }
          : p
      ));
    } catch (error) {
      console.error('Error processing Stripe payment:', error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'overdue': return 'bg-red-100 text-red-800';
      case 'partial': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatCurrency = (amount: number, currency: string = 'USD') => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency
    }).format(amount);
  };

  const filteredPayments = payments.filter(payment => {
    const matchesSearch = payment.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         payment.caseNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         payment.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || payment.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  if (loading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
          <span className="ml-2">Loading payments...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Payment Summary Cards */}
      {summary && !caseId && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Revenue</p>
                    <p className="text-2xl font-bold">{formatCurrency(summary.totalRevenue)}</p>
                    <p className="text-xs text-green-600 flex items-center mt-1">
                      <TrendingUp className="w-3 h-3 mr-1" />
                      +{((summary.thisMonthRevenue - summary.lastMonthRevenue) / summary.lastMonthRevenue * 100).toFixed(1)}% from last month
                    </p>
                  </div>
                  <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <DollarSign className="h-6 w-6 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Paid Amount</p>
                    <p className="text-2xl font-bold">{formatCurrency(summary.paidAmount)}</p>
                    <p className="text-xs text-muted-foreground">
                      {((summary.paidAmount / summary.totalRevenue) * 100).toFixed(1)}% of total
                    </p>
                  </div>
                  <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <CheckCircle className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Pending Amount</p>
                    <p className="text-2xl font-bold">{formatCurrency(summary.pendingAmount)}</p>
                    <p className="text-xs text-muted-foreground">
                      {((summary.pendingAmount / summary.totalRevenue) * 100).toFixed(1)}% of total
                    </p>
                  </div>
                  <div className="h-12 w-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <Clock className="h-6 w-6 text-yellow-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Overdue Amount</p>
                    <p className="text-2xl font-bold">{formatCurrency(summary.overdueAmount)}</p>
                    <p className="text-xs text-red-600">
                      Requires immediate attention
                    </p>
                  </div>
                  <div className="h-12 w-12 bg-red-100 rounded-lg flex items-center justify-center">
                    <AlertCircle className="h-6 w-6 text-red-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      )}

      {/* Controls */}
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search payments..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
          
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="paid">Paid</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="overdue">Overdue</SelectItem>
              <SelectItem value="partial">Partial</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center space-x-2">
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          
          <Dialog open={showAddPayment} onOpenChange={setShowAddPayment}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Add Payment
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Add New Payment</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="amount">Amount</Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="0.00"
                    value={newPayment.amount}
                    onChange={(e) => setNewPayment(prev => ({ ...prev, amount: e.target.value }))}
                  />
                </div>
                
                <div>
                  <Label htmlFor="currency">Currency</Label>
                  <Select value={newPayment.currency} onValueChange={(value) => setNewPayment(prev => ({ ...prev, currency: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="USD">USD</SelectItem>
                      <SelectItem value="EUR">EUR</SelectItem>
                      <SelectItem value="GBP">GBP</SelectItem>
                      <SelectItem value="CAD">CAD</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    placeholder="Payment description..."
                    value={newPayment.description}
                    onChange={(e) => setNewPayment(prev => ({ ...prev, description: e.target.value }))}
                  />
                </div>
                
                <div>
                  <Label htmlFor="dueDate">Due Date</Label>
                  <Input
                    id="dueDate"
                    type="date"
                    value={newPayment.dueDate}
                    onChange={(e) => setNewPayment(prev => ({ ...prev, dueDate: e.target.value }))}
                  />
                </div>
                
                <div>
                  <Label htmlFor="paymentMethod">Payment Method</Label>
                  <Select value={newPayment.paymentMethod} onValueChange={(value) => setNewPayment(prev => ({ ...prev, paymentMethod: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="stripe">Stripe</SelectItem>
                      <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                      <SelectItem value="check">Check</SelectItem>
                      <SelectItem value="cash">Cash</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setShowAddPayment(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddPayment}>
                    Add Payment
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Payments Table */}
      <Card>
        <CardHeader>
          <CardTitle>Payment Records</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-3">Invoice</th>
                  <th className="text-left p-3">Case</th>
                  <th className="text-left p-3">Client</th>
                  <th className="text-left p-3">Amount</th>
                  <th className="text-left p-3">Status</th>
                  <th className="text-left p-3">Due Date</th>
                  <th className="text-left p-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredPayments.map((payment, index) => (
                  <motion.tr
                    key={payment.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="border-b hover:bg-gray-50"
                  >
                    <td className="p-3">
                      <div>
                        <p className="font-medium">{payment.invoiceNumber}</p>
                        <p className="text-sm text-muted-foreground">{payment.description}</p>
                      </div>
                    </td>
                    <td className="p-3">
                      <p className="font-medium">{payment.caseNumber}</p>
                    </td>
                    <td className="p-3">
                      <p className="font-medium">{payment.clientName}</p>
                    </td>
                    <td className="p-3">
                      <div>
                        <p className="font-medium">{formatCurrency(payment.amount, payment.currency)}</p>
                        {payment.installmentPlan && (
                          <p className="text-sm text-muted-foreground">
                            {payment.installmentPlan.currentInstallment}/{payment.installmentPlan.totalInstallments} installments
                          </p>
                        )}
                      </div>
                    </td>
                    <td className="p-3">
                      <Badge className={getStatusColor(payment.status)}>
                        {payment.status.toUpperCase()}
                      </Badge>
                    </td>
                    <td className="p-3">
                      <div>
                        <p>{new Date(payment.dueDate).toLocaleDateString()}</p>
                        {payment.paidDate && (
                          <p className="text-sm text-green-600">
                            Paid: {new Date(payment.paidDate).toLocaleDateString()}
                          </p>
                        )}
                      </div>
                    </td>
                    <td className="p-3">
                      <div className="flex items-center space-x-2">
                        {payment.status === 'pending' && (
                          <Button
                            size="sm"
                            onClick={() => processStripePayment(payment.id)}
                          >
                            <CreditCard className="w-4 h-4 mr-1" />
                            Pay Now
                          </Button>
                        )}
                        <Button variant="outline" size="sm">
                          <Download className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
          
          {filteredPayments.length === 0 && (
            <div className="text-center py-8">
              <DollarSign className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-muted-foreground">No payments found</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
