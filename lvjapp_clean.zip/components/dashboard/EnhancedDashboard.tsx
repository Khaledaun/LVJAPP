
'use client';

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  FileText, 
  MessageSquare, 
  Bell, 
  Calendar,
  Users,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Clock,
  DollarSign,
  BarChart3,
  Activity
} from 'lucide-react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import InternalQA from '@/components/communication/InternalQA';
import CaseNotes from '@/components/communication/CaseNotes';
import NotificationCenter from '@/components/communication/NotificationCenter';
import DeadlineTracker from '@/components/workflow/DeadlineTracker';

interface EnhancedDashboardProps {
  userRole: 'CLIENT' | 'STAFF' | 'ADMIN';
}

interface DashboardData {
  overview: {
    totalCases: number;
    activeCases: number;
    completedCases: number;
    pendingDocuments: number;
    unreadNotifications: number;
    overdueDeadlines: number;
  };
  recentActivity: Array<{
    id: string;
    type: string;
    message: string;
    timestamp: string;
    caseId?: string;
  }>;
  upcomingDeadlines: Array<{
    id: string;
    title: string;
    dueDate: string;
    priority: string;
    caseId: string;
  }>;
}

const StatCard = ({ 
  title, 
  value, 
  icon: Icon, 
  color = "blue", 
  trend 
}: { 
  title: string; 
  value: number; 
  icon: any; 
  color?: string; 
  trend?: { value: number; label: string };
}) => {
  const colorClasses = {
    blue: 'text-blue-600 bg-blue-100',
    green: 'text-green-600 bg-green-100',
    yellow: 'text-yellow-600 bg-yellow-100',
    red: 'text-red-600 bg-red-100',
    purple: 'text-purple-600 bg-purple-100',
    orange: 'text-orange-600 bg-orange-100'
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <p className="text-2xl font-bold">{value}</p>
            {trend && (
              <p className="text-xs text-muted-foreground mt-1">
                <span className={trend.value > 0 ? 'text-green-600' : 'text-red-600'}>
                  {trend.value > 0 ? '+' : ''}{trend.value}%
                </span>
                {' '}{trend.label}
              </p>
            )}
          </div>
          <div className={`p-3 rounded-full ${colorClasses[color as keyof typeof colorClasses]}`}>
            <Icon className="h-6 w-6" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default function EnhancedDashboard({ userRole }: EnhancedDashboardProps) {
  const { data: session } = useSession();
  const router = useRouter();
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      // Simulate API call - replace with actual API endpoints
      const mockData: DashboardData = {
        overview: {
          totalCases: 45,
          activeCases: 23,
          completedCases: 22,
          pendingDocuments: 12,
          unreadNotifications: 8,
          overdueDeadlines: 3
        },
        recentActivity: [
          {
            id: '1',
            type: 'document_upload',
            message: 'New document uploaded for Case #2024-001',
            timestamp: new Date().toISOString(),
            caseId: '1'
          },
          {
            id: '2',
            type: 'case_update',
            message: 'Case status updated to "In Review"',
            timestamp: new Date(Date.now() - 3600000).toISOString(),
            caseId: '2'
          },
          {
            id: '3',
            type: 'deadline_reminder',
            message: 'Document submission deadline approaching',
            timestamp: new Date(Date.now() - 7200000).toISOString(),
            caseId: '3'
          }
        ],
        upcomingDeadlines: [
          {
            id: '1',
            title: 'Submit I-485 Application',
            dueDate: new Date(Date.now() + 86400000).toISOString(),
            priority: 'high',
            caseId: '1'
          },
          {
            id: '2',
            title: 'Client Interview Scheduled',
            dueDate: new Date(Date.now() + 259200000).toISOString(),
            priority: 'medium',
            caseId: '2'
          }
        ]
      };
      
      setDashboardData(mockData);
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const renderClientDashboard = () => (
    <div className="space-y-6">
      {/* Client Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="My Cases" 
          value={dashboardData?.overview.activeCases || 0} 
          icon={FileText} 
          color="blue"
          trend={{ value: 12, label: "this month" }}
        />
        <StatCard 
          title="Pending Documents" 
          value={dashboardData?.overview.pendingDocuments || 0} 
          icon={Clock} 
          color="yellow"
        />
        <StatCard 
          title="Notifications" 
          value={dashboardData?.overview.unreadNotifications || 0} 
          icon={Bell} 
          color="purple"
        />
        <StatCard 
          title="Upcoming Deadlines" 
          value={dashboardData?.upcomingDeadlines.length || 0} 
          icon={Calendar} 
          color="orange"
        />
      </div>

      {/* Client-specific content */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5" />
              Recent Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {dashboardData?.recentActivity.map((activity, index) => (
                <div key={activity.id} className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                  <div className="p-2 bg-blue-100 rounded-full">
                    <FileText className="w-4 h-4 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm">{activity.message}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(activity.timestamp).toLocaleString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Upcoming Deadlines
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {dashboardData?.upcomingDeadlines.map((deadline) => (
                <div key={deadline.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div>
                    <p className="text-sm font-medium">{deadline.title}</p>
                    <p className="text-xs text-muted-foreground">
                      Due: {new Date(deadline.dueDate).toLocaleDateString()}
                    </p>
                  </div>
                  <Badge variant={deadline.priority === 'high' ? 'destructive' : 'secondary'}>
                    {deadline.priority}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  const renderStaffAdminDashboard = () => (
    <div className="space-y-6">
      {/* Staff/Admin Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-6">
        <StatCard 
          title="Total Cases" 
          value={dashboardData?.overview.totalCases || 0} 
          icon={FileText} 
          color="blue"
          trend={{ value: 8, label: "this month" }}
        />
        <StatCard 
          title="Active Cases" 
          value={dashboardData?.overview.activeCases || 0} 
          icon={Activity} 
          color="green"
        />
        <StatCard 
          title="Completed" 
          value={dashboardData?.overview.completedCases || 0} 
          icon={CheckCircle} 
          color="green"
        />
        <StatCard 
          title="Pending Docs" 
          value={dashboardData?.overview.pendingDocuments || 0} 
          icon={Clock} 
          color="yellow"
        />
        <StatCard 
          title="Overdue" 
          value={dashboardData?.overview.overdueDeadlines || 0} 
          icon={AlertTriangle} 
          color="red"
        />
        <StatCard 
          title="Notifications" 
          value={dashboardData?.overview.unreadNotifications || 0} 
          icon={Bell} 
          color="purple"
        />
      </div>

      {/* Staff/Admin Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="qa">Internal Q&A</TabsTrigger>
          <TabsTrigger value="notes">Case Notes</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="deadlines">Deadlines</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  Case Statistics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Family Immigration</span>
                    <div className="flex items-center gap-2">
                      <div className="w-24 bg-gray-200 rounded-full h-2">
                        <div className="bg-blue-500 h-2 rounded-full w-3/4"></div>
                      </div>
                      <span className="text-sm font-medium">75%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Business Immigration</span>
                    <div className="flex items-center gap-2">
                      <div className="w-24 bg-gray-200 rounded-full h-2">
                        <div className="bg-green-500 h-2 rounded-full w-1/2"></div>
                      </div>
                      <span className="text-sm font-medium">50%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Asylum Cases</span>
                    <div className="flex items-center gap-2">
                      <div className="w-24 bg-gray-200 rounded-full h-2">
                        <div className="bg-orange-500 h-2 rounded-full w-1/3"></div>
                      </div>
                      <span className="text-sm font-medium">33%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  Monthly Performance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-sm">Cases Opened</span>
                    <span className="text-sm font-medium text-green-600">+12</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Cases Completed</span>
                    <span className="text-sm font-medium text-blue-600">8</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Client Satisfaction</span>
                    <span className="text-sm font-medium text-green-600">98%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Avg. Processing Time</span>
                    <span className="text-sm font-medium">45 days</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="w-5 h-5" />
                Recent System Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {dashboardData?.recentActivity.map((activity) => (
                  <div key={activity.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-blue-100 rounded-full">
                        <FileText className="w-4 h-4 text-blue-600" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">{activity.message}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(activity.timestamp).toLocaleString()}
                        </p>
                      </div>
                    </div>
                    {activity.caseId && (
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => router.push(`/cases/${activity.caseId}`)}
                      >
                        View Case
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="qa">
          <InternalQA caseId="" />
        </TabsContent>

        <TabsContent value="notes">
          <CaseNotes caseId="" />
        </TabsContent>

        <TabsContent value="notifications">
          <NotificationCenter />
        </TabsContent>

        <TabsContent value="deadlines">
          <DeadlineTracker />
        </TabsContent>
      </Tabs>
    </div>
  );

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <div className="h-20 bg-muted rounded"></div>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="h-96 bg-muted rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="p-8 space-y-8"
    >
      <div>
        <h1 className="text-3xl font-bold">
          Welcome back, {session?.user?.name || session?.user?.email}
        </h1>
        <p className="text-muted-foreground">
          Here's what's happening with your {userRole === 'CLIENT' ? 'cases' : 'immigration practice'} today.
        </p>
      </div>

      {userRole === 'CLIENT' ? renderClientDashboard() : renderStaffAdminDashboard()}
    </motion.div>
  );
}
