
'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { DatePickerWithRange } from '@/components/ui/date-range-picker';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { 
  Search, 
  Filter, 
  X, 
  ChevronDown, 
  ChevronUp,
  Calendar,
  User,
  FileText,
  MapPin,
  Tag,
  Clock,
  DollarSign
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface SearchFilters {
  query: string;
  status: string[];
  visaType: string[];
  country: string[];
  caseManager: string[];
  lawyer: string[];
  dateRange: {
    from: Date | undefined;
    to: Date | undefined;
  };
  urgencyLevel: string[];
  completionRange: {
    min: number;
    max: number;
  };
  feeRange: {
    min: number;
    max: number;
  };
  tags: string[];
  documentStatus: string[];
}

interface SearchResult {
  id: string;
  type: 'case' | 'document' | 'client' | 'payment';
  title: string;
  subtitle: string;
  description: string;
  metadata: {
    [key: string]: any;
  };
  relevanceScore: number;
  highlights: string[];
}

interface AdvancedSearchProps {
  onSearch: (filters: SearchFilters, results: SearchResult[]) => void;
  placeholder?: string;
  showFilters?: boolean;
}

export default function AdvancedSearch({ 
  onSearch, 
  placeholder = "Search cases, documents, clients...",
  showFilters = true 
}: AdvancedSearchProps) {
  const [filters, setFilters] = useState<SearchFilters>({
    query: '',
    status: [],
    visaType: [],
    country: [],
    caseManager: [],
    lawyer: [],
    dateRange: { from: undefined, to: undefined },
    urgencyLevel: [],
    completionRange: { min: 0, max: 100 },
    feeRange: { min: 0, max: 50000 },
    tags: [],
    documentStatus: []
  });

  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [suggestions, setSuggestions] = useState<string[]>([]);

  // Mock data for dropdowns
  const statusOptions = ['new', 'documents_pending', 'in_review', 'submitted', 'approved', 'denied'];
  const visaTypeOptions = ['Tourist', 'Student', 'Work', 'Family', 'Business', 'Transit'];
  const countryOptions = ['United States', 'Canada', 'United Kingdom', 'Australia', 'Germany', 'France'];
  const staffOptions = ['Sarah Johnson', 'Michael Chen', 'Emily Rodriguez', 'David Kim'];
  const urgencyOptions = ['LOW', 'STANDARD', 'HIGH', 'URGENT'];
  const documentStatusOptions = ['pending_review', 'approved', 'rejected', 'missing', 'expired'];

  useEffect(() => {
    if (filters.query.length > 2) {
      performSearch();
    } else {
      setResults([]);
    }
  }, [filters]);

  const performSearch = async () => {
    setLoading(true);
    try {
      // Mock search API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Mock search results
      const mockResults: SearchResult[] = [
        {
          id: '1',
          type: 'case',
          title: 'John Smith - Tourist Visa Application',
          subtitle: 'LVJ-2024-001 • United States',
          description: 'Tourist visa application for family vacation. All documents submitted and under review.',
          metadata: {
            status: 'in_review',
            visaType: 'Tourist',
            country: 'United States',
            completionPercentage: 75
          },
          relevanceScore: 0.95,
          highlights: ['Tourist', 'United States', 'review']
        },
        {
          id: '2',
          type: 'document',
          title: 'Passport Copy - Maria Garcia',
          subtitle: 'Document • LVJ-2024-002',
          description: 'Passport copy for student visa application. Approved by case manager.',
          metadata: {
            documentType: 'Passport',
            status: 'approved',
            caseNumber: 'LVJ-2024-002'
          },
          relevanceScore: 0.87,
          highlights: ['Passport', 'approved']
        },
        {
          id: '3',
          type: 'client',
          title: 'Ahmed Hassan',
          subtitle: 'Client • ahmed.hassan@email.com',
          description: 'Work visa application for software engineer position in Canada.',
          metadata: {
            email: 'ahmed.hassan@email.com',
            caseCount: 1,
            status: 'active'
          },
          relevanceScore: 0.82,
          highlights: ['Work visa', 'Canada']
        }
      ];

      // Filter results based on current filters
      const filteredResults = mockResults.filter(result => {
        if (filters.query && !result.title.toLowerCase().includes(filters.query.toLowerCase()) &&
            !result.description.toLowerCase().includes(filters.query.toLowerCase())) {
          return false;
        }
        
        if (filters.status.length > 0 && result.metadata.status && 
            !filters.status.includes(result.metadata.status)) {
          return false;
        }
        
        return true;
      });

      setResults(filteredResults);
      onSearch(filters, filteredResults);
      
      // Add to recent searches
      if (filters.query && !recentSearches.includes(filters.query)) {
        setRecentSearches(prev => [filters.query, ...prev.slice(0, 4)]);
      }
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateFilter = (key: keyof SearchFilters, value: any) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const toggleArrayFilter = (key: keyof SearchFilters, value: string) => {
    setFilters(prev => ({
      ...prev,
      [key]: (prev[key] as string[]).includes(value)
        ? (prev[key] as string[]).filter(item => item !== value)
        : [...(prev[key] as string[]), value]
    }));
  };

  const clearFilters = () => {
    setFilters({
      query: '',
      status: [],
      visaType: [],
      country: [],
      caseManager: [],
      lawyer: [],
      dateRange: { from: undefined, to: undefined },
      urgencyLevel: [],
      completionRange: { min: 0, max: 100 },
      feeRange: { min: 0, max: 50000 },
      tags: [],
      documentStatus: []
    });
  };

  const getActiveFilterCount = () => {
    let count = 0;
    if (filters.status.length > 0) count++;
    if (filters.visaType.length > 0) count++;
    if (filters.country.length > 0) count++;
    if (filters.caseManager.length > 0) count++;
    if (filters.lawyer.length > 0) count++;
    if (filters.dateRange.from || filters.dateRange.to) count++;
    if (filters.urgencyLevel.length > 0) count++;
    if (filters.tags.length > 0) count++;
    if (filters.documentStatus.length > 0) count++;
    return count;
  };

  const getResultIcon = (type: string) => {
    switch (type) {
      case 'case': return <FileText className="w-4 h-4" />;
      case 'document': return <FileText className="w-4 h-4" />;
      case 'client': return <User className="w-4 h-4" />;
      case 'payment': return <DollarSign className="w-4 h-4" />;
      default: return <Search className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-4">
      {/* Main Search Bar */}
      <div className="relative">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <Input
            placeholder={placeholder}
            value={filters.query}
            onChange={(e) => updateFilter('query', e.target.value)}
            className="pl-12 pr-12 h-12 text-lg"
          />
          {loading && (
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-500"></div>
            </div>
          )}
        </div>

        {/* Search Suggestions */}
        {filters.query.length > 0 && suggestions.length > 0 && (
          <Card className="absolute top-full left-0 right-0 z-50 mt-1">
            <CardContent className="p-2">
              {suggestions.map((suggestion, index) => (
                <div
                  key={index}
                  className="p-2 hover:bg-gray-100 cursor-pointer rounded"
                  onClick={() => updateFilter('query', suggestion)}
                >
                  <Search className="w-4 h-4 inline mr-2 text-gray-400" />
                  {suggestion}
                </div>
              ))}
            </CardContent>
          </Card>
        )}
      </div>

      {/* Filter Controls */}
      {showFilters && (
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
              className="flex items-center space-x-2"
            >
              <Filter className="w-4 h-4" />
              <span>Filters</span>
              {getActiveFilterCount() > 0 && (
                <Badge variant="secondary" className="ml-1">
                  {getActiveFilterCount()}
                </Badge>
              )}
              {showAdvancedFilters ? (
                <ChevronUp className="w-4 h-4" />
              ) : (
                <ChevronDown className="w-4 h-4" />
              )}
            </Button>

            {getActiveFilterCount() > 0 && (
              <Button variant="ghost" size="sm" onClick={clearFilters}>
                <X className="w-4 h-4 mr-1" />
                Clear Filters
              </Button>
            )}
          </div>

          <div className="text-sm text-muted-foreground">
            {results.length} results found
          </div>
        </div>
      )}

      {/* Advanced Filters */}
      <AnimatePresence>
        {showAdvancedFilters && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Advanced Filters</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {/* Status Filter */}
                  <div>
                    <Label className="text-sm font-medium mb-2 block">Status</Label>
                    <div className="space-y-2">
                      {statusOptions.map(status => (
                        <div key={status} className="flex items-center space-x-2">
                          <Checkbox
                            id={`status-${status}`}
                            checked={filters.status.includes(status)}
                            onCheckedChange={() => toggleArrayFilter('status', status)}
                          />
                          <Label htmlFor={`status-${status}`} className="text-sm capitalize">
                            {status.replace('_', ' ')}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Visa Type Filter */}
                  <div>
                    <Label className="text-sm font-medium mb-2 block">Visa Type</Label>
                    <div className="space-y-2">
                      {visaTypeOptions.map(type => (
                        <div key={type} className="flex items-center space-x-2">
                          <Checkbox
                            id={`visa-${type}`}
                            checked={filters.visaType.includes(type)}
                            onCheckedChange={() => toggleArrayFilter('visaType', type)}
                          />
                          <Label htmlFor={`visa-${type}`} className="text-sm">
                            {type}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Country Filter */}
                  <div>
                    <Label className="text-sm font-medium mb-2 block">Country</Label>
                    <div className="space-y-2">
                      {countryOptions.map(country => (
                        <div key={country} className="flex items-center space-x-2">
                          <Checkbox
                            id={`country-${country}`}
                            checked={filters.country.includes(country)}
                            onCheckedChange={() => toggleArrayFilter('country', country)}
                          />
                          <Label htmlFor={`country-${country}`} className="text-sm">
                            {country}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Case Manager Filter */}
                  <div>
                    <Label className="text-sm font-medium mb-2 block">Case Manager</Label>
                    <div className="space-y-2">
                      {staffOptions.map(staff => (
                        <div key={staff} className="flex items-center space-x-2">
                          <Checkbox
                            id={`manager-${staff}`}
                            checked={filters.caseManager.includes(staff)}
                            onCheckedChange={() => toggleArrayFilter('caseManager', staff)}
                          />
                          <Label htmlFor={`manager-${staff}`} className="text-sm">
                            {staff}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Urgency Level Filter */}
                  <div>
                    <Label className="text-sm font-medium mb-2 block">Urgency Level</Label>
                    <div className="space-y-2">
                      {urgencyOptions.map(urgency => (
                        <div key={urgency} className="flex items-center space-x-2">
                          <Checkbox
                            id={`urgency-${urgency}`}
                            checked={filters.urgencyLevel.includes(urgency)}
                            onCheckedChange={() => toggleArrayFilter('urgencyLevel', urgency)}
                          />
                          <Label htmlFor={`urgency-${urgency}`} className="text-sm">
                            {urgency}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Date Range Filter */}
                  <div>
                    <Label className="text-sm font-medium mb-2 block">Date Range</Label>
                    <DatePickerWithRange
                      date={filters.dateRange}
                      onDateChange={(range) => updateFilter('dateRange', range)}
                    />
                  </div>
                </div>

                {/* Range Filters */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label className="text-sm font-medium mb-2 block">
                      Completion Percentage: {filters.completionRange.min}% - {filters.completionRange.max}%
                    </Label>
                    <div className="flex items-center space-x-4">
                      <Input
                        type="number"
                        min="0"
                        max="100"
                        value={filters.completionRange.min}
                        onChange={(e) => updateFilter('completionRange', {
                          ...filters.completionRange,
                          min: parseInt(e.target.value) || 0
                        })}
                        className="w-20"
                      />
                      <span>to</span>
                      <Input
                        type="number"
                        min="0"
                        max="100"
                        value={filters.completionRange.max}
                        onChange={(e) => updateFilter('completionRange', {
                          ...filters.completionRange,
                          max: parseInt(e.target.value) || 100
                        })}
                        className="w-20"
                      />
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium mb-2 block">
                      Fee Range: ${filters.feeRange.min} - ${filters.feeRange.max}
                    </Label>
                    <div className="flex items-center space-x-4">
                      <Input
                        type="number"
                        min="0"
                        value={filters.feeRange.min}
                        onChange={(e) => updateFilter('feeRange', {
                          ...filters.feeRange,
                          min: parseInt(e.target.value) || 0
                        })}
                        className="w-24"
                      />
                      <span>to</span>
                      <Input
                        type="number"
                        min="0"
                        value={filters.feeRange.max}
                        onChange={(e) => updateFilter('feeRange', {
                          ...filters.feeRange,
                          max: parseInt(e.target.value) || 50000
                        })}
                        className="w-24"
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Active Filters Display */}
      {getActiveFilterCount() > 0 && (
        <div className="flex flex-wrap gap-2">
          {filters.status.map(status => (
            <Badge key={`status-${status}`} variant="secondary" className="flex items-center space-x-1">
              <span>Status: {status.replace('_', ' ')}</span>
              <X 
                className="w-3 h-3 cursor-pointer" 
                onClick={() => toggleArrayFilter('status', status)}
              />
            </Badge>
          ))}
          {filters.visaType.map(type => (
            <Badge key={`visa-${type}`} variant="secondary" className="flex items-center space-x-1">
              <span>Visa: {type}</span>
              <X 
                className="w-3 h-3 cursor-pointer" 
                onClick={() => toggleArrayFilter('visaType', type)}
              />
            </Badge>
          ))}
          {filters.country.map(country => (
            <Badge key={`country-${country}`} variant="secondary" className="flex items-center space-x-1">
              <span>Country: {country}</span>
              <X 
                className="w-3 h-3 cursor-pointer" 
                onClick={() => toggleArrayFilter('country', country)}
              />
            </Badge>
          ))}
        </div>
      )}

      {/* Search Results */}
      {results.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Search Results</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {results.map((result, index) => (
                <motion.div
                  key={result.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="p-4 border rounded-lg hover:bg-gray-50 cursor-pointer"
                >
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0 mt-1">
                      {getResultIcon(result.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium text-gray-900 truncate">
                          {result.title}
                        </h4>
                        <Badge variant="outline" className="ml-2">
                          {result.type}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600 mt-1">
                        {result.subtitle}
                      </p>
                      <p className="text-sm text-gray-500 mt-2">
                        {result.description}
                      </p>
                      {result.highlights.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {result.highlights.map((highlight, idx) => (
                            <Badge key={idx} variant="secondary" className="text-xs">
                              {highlight}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent Searches */}
      {recentSearches.length > 0 && filters.query === '' && (
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Recent Searches</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {recentSearches.map((search, index) => (
                <Badge
                  key={index}
                  variant="outline"
                  className="cursor-pointer hover:bg-gray-100"
                  onClick={() => updateFilter('query', search)}
                >
                  <Clock className="w-3 h-3 mr-1" />
                  {search}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
