
# LVJ Immigration Services Platform

A comprehensive, multilingual immigration case management platform built with Next.js 14, featuring advanced analytics, payment tracking, and document management.

## 🌟 Features

### Phase 1: Foundation & Core Infrastructure ✅
- **Next.js 14** with App Router
- **TypeScript** for type safety
- **Prisma ORM** with PostgreSQL
- **NextAuth.js** for authentication
- **Tailwind CSS** for styling
- **Radix UI** components
- **AWS S3** integration for file storage

### Phase 2: Journey Tracker & Document Management ✅
- **Journey Tracker** with traffic light statuses (🟢🟡⚪)
- **Document Cards** system with approve/reject functionality
- **File Upload** and document management
- **Client Portal** and lawyer interfaces
- **Case Timeline** and status tracking

### Phase 3: Internal Communication & Workflow ✅
- **Internal Q&A System** for private lawyer-LVJ communication
- **Case Notes** and internal comments
- **Notification System** with in-app alerts
- **Workflow Automation** and status transitions
- **Enhanced Dashboards** for all user types
- **Deadline Management** and reminders

### Phase 4: Multilingual & Advanced Features ✅
- **Trilingual Support** (Arabic RTL, English, Portuguese) using next-intl
- **Advanced Analytics** and reporting dashboards with Recharts
- **Payment Tracking System** with Stripe integration placeholders
- **Enhanced Search** and filtering capabilities
- **Professional UI/UX** with modern design
- **Mobile Optimization** and responsive design
- **Bulk Operations** and batch processing
- **RTL Support** for Arabic language

## 🚀 Quick Start

### Prerequisites
- Node.js 18.18+ 
- npm 9.0.0+
- PostgreSQL database
- AWS S3 bucket (optional)

### Installation

1. **Clone the repository**
```bash
git clone <repository-url>
cd lvj-immigration-services
```

2. **Install dependencies**
```bash
npm install
```

3. **Set up environment variables**
```bash
cp .env.example .env
```

Edit `.env` with your configuration:
```env
# Database
DATABASE_URL="postgresql://username:password@localhost:5432/lvj_immigration"

# NextAuth
NEXTAUTH_SECRET="your-super-secret-key-at-least-32-characters-long"
NEXTAUTH_URL="http://localhost:3000"

# AWS S3 (Optional)
AWS_REGION=us-west-2
AWS_BUCKET_NAME=your-bucket-name
AWS_FOLDER_PREFIX=lvj/

# Development Flags
SKIP_AUTH=1          # Set to 1 to bypass authentication for demos
SKIP_DB=0            # Set to 0 to use real database
NODE_ENV=development
PORT=3000
```

4. **Set up the database**
```bash
# Generate Prisma client
npx prisma generate

# Run database migrations
npx prisma migrate dev

# Seed the database (optional)
npm run db:seed
```

5. **Start the development server**
```bash
npm run dev
```

Visit `http://localhost:3000` to see the application.

## 🌍 Internationalization

The application supports three languages:
- **English** (`/en`) - Default
- **Arabic** (`/ar`) - RTL support
- **Portuguese** (`/pt`)

### Adding New Languages

1. Add the locale to `middleware.ts`:
```typescript
locales: ['en', 'ar', 'pt', 'new-locale']
```

2. Create translation file:
```bash
cp messages/en.json messages/new-locale.json
```

3. Translate the content in the new file.

## 📊 Analytics & Reporting

The platform includes comprehensive analytics:
- **Case Metrics**: Total cases, approval rates, processing times
- **Document Analytics**: Upload rates, approval statistics
- **Payment Tracking**: Revenue analysis, payment methods
- **Staff Performance**: Productivity metrics, client satisfaction
- **Custom Reports**: Exportable in PDF, Excel, CSV formats

## 💳 Payment Integration

Stripe integration is prepared with:
- Payment tracking and history
- Installment plans support
- Multiple currency support
- Invoice generation
- Automated payment reminders

To enable Stripe:
1. Add Stripe keys to environment variables
2. Implement webhook endpoints
3. Configure payment methods

## 🔍 Advanced Search

Features include:
- **Full-text search** across cases, documents, and clients
- **Advanced filters** by status, type, date ranges
- **Bulk operations** for batch processing
- **Recent searches** and suggestions
- **Export capabilities**

## 📱 Mobile Optimization

- **Responsive design** for all screen sizes
- **Mobile navigation** with slide-out menu
- **Touch-friendly** interface
- **Progressive Web App** ready
- **Offline capabilities** (can be extended)

## 🛠️ Development

### Available Scripts

```bash
# Development
npm run dev              # Start development server
npm run build           # Build for production
npm run start           # Start production server

# Database
npm run db:generate     # Generate Prisma client
npm run db:migrate      # Run database migrations
npm run db:seed         # Seed database with sample data
npm run db:studio       # Open Prisma Studio
npm run db:reset        # Reset database

# Code Quality
npm run lint            # Run ESLint
npm run lint:fix        # Fix ESLint issues
npm run type-check      # Run TypeScript checks
npm run format          # Format code with Prettier
npm run format:check    # Check code formatting

# Testing
npm run test            # Run tests
npm run test:watch      # Run tests in watch mode
npm run test:coverage   # Run tests with coverage

# Utilities
npm run clean           # Clean build artifacts
npm run analyze         # Analyze bundle size
```

### Project Structure

```
├── app/                    # Next.js App Router
│   ├── [locale]/          # Internationalized routes
│   │   ├── dashboard/     # Dashboard pages
│   │   ├── cases/         # Case management
│   │   ├── reports/       # Analytics & reports
│   │   └── payments/      # Payment tracking
│   ├── api/               # API routes
│   └── globals.css        # Global styles with RTL support
├── components/            # React components
│   ├── analytics/         # Analytics components
│   ├── bulk/             # Bulk operations
│   ├── navigation/       # Navigation components
│   ├── payments/         # Payment components
│   ├── search/           # Search components
│   └── ui/               # UI components
├── lib/                  # Utility libraries
├── messages/             # Translation files
├── prisma/               # Database schema and migrations
├── types/                # TypeScript type definitions
└── middleware.ts         # Next.js middleware for i18n
```

## 🔐 Security Features

- **Authentication** with NextAuth.js
- **Role-based access control** (Client, Staff, Admin)
- **Data validation** with Zod
- **SQL injection protection** with Prisma
- **XSS protection** with proper sanitization
- **CSRF protection** built-in with Next.js
- **Environment variable validation**

## 🚀 Deployment

### Vercel (Recommended)

1. Connect your GitHub repository to Vercel
2. Set environment variables in Vercel dashboard
3. Deploy automatically on push to main branch

### Docker

```bash
# Build Docker image
docker build -t lvj-immigration .

# Run container
docker run -p 3000:3000 lvj-immigration
```

### Manual Deployment

```bash
# Build the application
npm run build

# Start production server
npm start
```

## 📈 Performance Optimizations

- **Next.js Image Optimization**
- **Code splitting** and lazy loading
- **Bundle analysis** and optimization
- **Database query optimization**
- **Caching strategies**
- **CDN integration** ready

## 🧪 Testing

The project includes:
- **Unit tests** with Jest
- **Component tests** with React Testing Library
- **API tests** for backend endpoints
- **E2E tests** setup ready

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Commit changes: `git commit -m 'Add amazing feature'`
4. Push to branch: `git push origin feature/amazing-feature`
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

For support and questions:
- Create an issue in the GitHub repository
- Contact the development team
- Check the documentation wiki

## 🔄 Changelog

### Version 1.0.0 (Current)
- ✅ Complete Phase 1-4 implementation
- ✅ Trilingual support with RTL
- ✅ Advanced analytics and reporting
- ✅ Payment tracking system
- ✅ Mobile optimization
- ✅ Bulk operations
- ✅ Enhanced search and filtering

### Roadmap
- 🔄 Real-time notifications with WebSockets
- 🔄 Advanced workflow automation
- 🔄 Integration with external immigration APIs
- 🔄 Mobile app development
- 🔄 AI-powered document analysis
- 🔄 Advanced reporting with custom dashboards

---

**Built with ❤️ for LVJ Immigration Services**
