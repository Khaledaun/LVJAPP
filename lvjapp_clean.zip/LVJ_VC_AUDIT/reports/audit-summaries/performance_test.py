from locust import HttpUser, task, between
import json
import random

class LVJPlatformUser(HttpUser):
    wait_time = between(1, 3)
    
    def on_start(self):
        """Login user at start"""
        self.client.post("/api/auth/signin", json={
            "email": "test@example.com",
            "password": "testpassword"
        })
    
    @task(3)
    def view_dashboard(self):
        """Test dashboard loading"""
        self.client.get("/dashboard")
    
    @task(2)
    def view_cases(self):
        """Test cases page"""
        self.client.get("/cases")
    
    @task(1)
    def api_health_check(self):
        """Test health check endpoint"""
        self.client.get("/api/health")
    
    @task(1)
    def view_documents(self):
        """Test documents page"""
        self.client.get("/documents")
    
    @task(1)
    def search_cases(self):
        """Test search functionality"""
        search_terms = ["visa", "passport", "application", "tourist"]
        term = random.choice(search_terms)
        self.client.get(f"/api/search?q={term}")
