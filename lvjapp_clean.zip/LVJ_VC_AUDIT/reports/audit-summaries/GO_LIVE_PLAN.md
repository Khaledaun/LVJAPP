# LVJ Immigration Services Platform - Go-Live Plan

**Document Version:** 1.0  
**Created:** September 10, 2025  
**Last Updated:** September 10, 2025  
**Status:** DRAFT - Pending Critical Fixes  

## Pre-Deployment Requirements

### CRITICAL: Issues Must Be Resolved Before Deployment

⚠️ **WARNING:** The platform currently has critical issues that prevent production deployment. Complete all items in the "Critical Fixes Required" section before proceeding.

## Critical Fixes Required

### 1. Database Schema Updates

**Priority:** CRITICAL  
**Estimated Time:** 4-6 hours  

#### Update Prisma Schema File (`prisma/schema.prisma`)

Add missing tables and fields:

```prisma
model User {
  id                String   @id @default(cuid())
  email             String   @unique
  password          String?
  name              String?
  firstName         String?
  lastName          String?
  phone             String?
  role              Role     @default(CLIENT)
  preferredLanguage String   @default("en")
  renderMode        String   @default("light")
  timezone          String   @default("UTC")
  isActive          Boolean  @default(true)
  lastLoginAt       DateTime?
  termsVersion      String?
  termsAcceptedAt   DateTime?
  createdAt         DateTime @default(now())
  updatedAt         DateTime @updatedAt
}

model AuditLog {
  id        String   @id @default(cuid())
  userId    String
  caseId    String?
  action    String
  details   Json?
  at        DateTime @default(now())
  user      User     @relation(fields: [userId], references: [id])
  case      Case?    @relation(fields: [caseId], references: [id])
}

model TermsAcceptance {
  id         String   @id @default(cuid())
  userId     String
  termsType  String
  version    String
  ip         String?
  acceptedAt DateTime @default(now())
  user       User     @relation(fields: [userId], references: [id])
}

model Message {
  id        String   @id @default(cuid())
  caseId    String
  sender    String   // 'client' | 'staff'
  body      String
  createdAt DateTime @default(now())
  case      Case     @relation(fields: [caseId], references: [id])
}

model Payment {
  id            String        @id @default(cuid())
  caseId        String
  description   String
  amountCents   Int
  currency      String        @default("USD")
  status        PaymentStatus @default(unpaid)
  invoiceNumber String?
  issuedAt      DateTime      @default(now())
  paidAt        DateTime?
  case          Case          @relation(fields: [caseId], references: [id])
}
```

#### Run Database Migration

```bash
npx prisma migrate dev --name "add-missing-fields-and-tables"
npx prisma generate
```

### 2. Fix Authentication Configuration

**Priority:** CRITICAL  
**Estimated Time:** 2-3 hours  

#### Update NextAuth Route (`app/api/auth/[...nextauth]/route.ts`)

```typescript
import NextAuth from 'next-auth';
import { authOptions } from '../../../../lib/auth/options';

const handler = NextAuth(authOptions);

export { handler as GET, handler as POST, authOptions };
```

#### Update Auth Options Export (`lib/auth/options.ts`)

Ensure proper export structure for NextAuth configuration.

### 3. Fix Chart Component Issues

**Priority:** MEDIUM  
**Estimated Time:** 3-4 hours  

#### Update Package Dependencies

```bash
npm install recharts@^2.8.0 @types/react@^18.2.0
npm update
```

#### Fix Chart Component Types

Update chart components to use proper TypeScript interfaces.

## Deployment Steps

### Phase 1: Environment Setup

#### 1.1 Production Environment Variables

Create `.env.production` file:

```bash
# Database
DATABASE_URL="postgresql://username:password@host:5432/lvj_production"

# Authentication
NEXTAUTH_URL="https://your-domain.com"
NEXTAUTH_SECRET="your-super-secret-key-here"

# Email
SENDGRID_API_KEY="your-sendgrid-api-key"
SMTP_HOST="smtp.sendgrid.net"
SMTP_PORT="587"
SMTP_USER="apikey"
SMTP_PASS="your-sendgrid-api-key"

# Payments
STRIPE_SECRET_KEY="sk_live_your-stripe-secret-key"
STRIPE_PUBLISHABLE_KEY="pk_live_your-stripe-publishable-key"
STRIPE_WEBHOOK_SECRET="whsec_your-webhook-secret"

# Storage
AWS_ACCESS_KEY_ID="your-aws-access-key"
AWS_SECRET_ACCESS_KEY="your-aws-secret-key"
AWS_REGION="us-east-1"
AWS_S3_BUCKET="lvj-documents-production"

# Redis
REDIS_URL="redis://your-redis-host:6379"

# VFS Integration
VFS_API_URL="https://api.vfs.com"
VFS_API_KEY="your-vfs-api-key"

# Monitoring
SENTRY_DSN="your-sentry-dsn"

# Application
NODE_ENV="production"
TERMS_VERSION="v1.0"
```

#### 1.2 SSL Certificate Setup

```bash
# Using Let's Encrypt with Certbot
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

#### 1.3 Database Setup

```bash
# Create production database
createdb lvj_production

# Run migrations
npx prisma migrate deploy
npx prisma generate

# Seed initial data (if needed)
npm run db:seed
```

### Phase 2: Application Deployment

#### 2.1 Build Application

```bash
# Install dependencies
npm ci --production

# Build application
npm run build

# Verify build
npm run start
```

#### 2.2 Docker Deployment (Recommended)

```bash
# Build Docker image
docker build -t lvj-platform:latest .

# Run with Docker Compose
docker-compose -f docker-compose.production.yml up -d
```

#### 2.3 Process Management

```bash
# Using PM2 for process management
npm install -g pm2

# Start application
pm2 start npm --name "lvj-platform" -- start

# Save PM2 configuration
pm2 save
pm2 startup
```

### Phase 3: Infrastructure Setup

#### 3.1 Reverse Proxy (Nginx)

Create `/etc/nginx/sites-available/lvj-platform`:

```nginx
server {
    listen 80;
    server_name your-domain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.com;

    ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

#### 3.2 Firewall Configuration

```bash
# Configure UFW firewall
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

#### 3.3 Monitoring Setup

```bash
# Install monitoring tools
npm install @sentry/nextjs

# Configure health check endpoint
curl https://your-domain.com/api/health
```

### Phase 4: Testing & Validation

#### 4.1 Smoke Tests

```bash
# Test critical endpoints
curl -f https://your-domain.com/api/health
curl -f https://your-domain.com/api/auth/session
curl -f https://your-domain.com/dashboard
```

#### 4.2 Load Testing

```bash
# Run performance tests
cd audit
locust -f performance_test.py --host=https://your-domain.com
```

#### 4.3 Security Validation

```bash
# SSL/TLS check
nmap --script ssl-enum-ciphers -p 443 your-domain.com

# Security headers check
curl -I https://your-domain.com
```

## Post-Deployment Checklist

### Immediate (Day 1)

- [ ] Verify all critical endpoints are responding
- [ ] Test user registration and login
- [ ] Verify email notifications are working
- [ ] Test payment processing (small test transaction)
- [ ] Check database connectivity and performance
- [ ] Verify SSL certificate is working
- [ ] Test multilingual functionality
- [ ] Monitor error logs for issues

### Short-term (Week 1)

- [ ] Monitor application performance metrics
- [ ] Review and analyze user feedback
- [ ] Check database backup procedures
- [ ] Verify monitoring and alerting systems
- [ ] Test disaster recovery procedures
- [ ] Review security logs
- [ ] Optimize database queries if needed
- [ ] Update documentation based on deployment experience

### Long-term (Month 1)

- [ ] Analyze usage patterns and performance
- [ ] Plan scaling strategies
- [ ] Review and update security measures
- [ ] Implement additional monitoring
- [ ] Plan feature updates and improvements
- [ ] Review backup and recovery procedures
- [ ] Conduct security audit
- [ ] Plan maintenance windows

## Rollback Plan

### Immediate Rollback (< 5 minutes)

```bash
# Stop current application
pm2 stop lvj-platform

# Revert to previous version
docker run -d --name lvj-platform-rollback lvj-platform:previous

# Update load balancer
# (Update your load balancer configuration)
```

### Database Rollback

```bash
# Restore from backup
pg_restore -d lvj_production backup_file.sql

# Revert migrations if needed
npx prisma migrate reset
```

## Monitoring & Maintenance

### Health Check Endpoints

- **Application Health:** `GET /api/health`
- **Database Health:** `GET /api/health/database`
- **Redis Health:** `GET /api/health/redis`

### Key Metrics to Monitor

1. **Application Performance**
   - Response time < 2 seconds
   - Error rate < 1%
   - Uptime > 99.9%

2. **Database Performance**
   - Query response time < 500ms
   - Connection pool utilization < 80%
   - Disk usage < 80%

3. **System Resources**
   - CPU usage < 70%
   - Memory usage < 80%
   - Disk usage < 80%

### Backup Procedures

```bash
# Daily database backup
pg_dump lvj_production > backup_$(date +%Y%m%d).sql

# Weekly full system backup
tar -czf system_backup_$(date +%Y%m%d).tar.gz /var/www/lvj-platform
```

## Support & Troubleshooting

### Common Issues

1. **Application Won't Start**
   - Check environment variables
   - Verify database connectivity
   - Check port availability

2. **Database Connection Issues**
   - Verify DATABASE_URL
   - Check database server status
   - Review connection pool settings

3. **Authentication Problems**
   - Verify NEXTAUTH_SECRET
   - Check NEXTAUTH_URL configuration
   - Review session configuration

### Log Locations

- **Application Logs:** `/var/log/lvj-platform/`
- **Nginx Logs:** `/var/log/nginx/`
- **Database Logs:** `/var/log/postgresql/`
- **PM2 Logs:** `~/.pm2/logs/`

### Emergency Contacts

- **Technical Lead:** [Contact Information]
- **Database Administrator:** [Contact Information]
- **DevOps Engineer:** [Contact Information]
- **Security Team:** [Contact Information]

## Conclusion

This go-live plan provides a comprehensive roadmap for deploying the LVJ Immigration Services platform to production. **Critical fixes must be completed before deployment.**

**Important:** This plan assumes all critical issues identified in the audit have been resolved. Do not proceed with deployment until all critical fixes are implemented and tested.

---

**Document Status:** DRAFT - Requires Critical Fixes  
**Next Review:** After critical issues are resolved  
**Approval Required:** Technical Lead, Security Team, Project Manager
