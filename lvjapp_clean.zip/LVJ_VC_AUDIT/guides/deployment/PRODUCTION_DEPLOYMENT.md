
# Production Deployment Guide - LVJ Immigration Services

## Pre-Deployment Checklist

### 1. Environment Preparation
- [ ] Production database configured and accessible
- [ ] Environment variables configured
- [ ] SSL certificates obtained and configured
- [ ] Domain DNS configured
- [ ] CDN configured (if applicable)
- [ ] Monitoring tools configured

### 2. Database Setup
```bash
# Apply pending migrations
npx prisma migrate deploy

# Generate Prisma client
npx prisma generate

# Verify database connection
npx prisma db pull
```

### 3. Security Configuration
- [ ] JWT secrets configured
- [ ] API keys secured
- [ ] CORS origins configured
- [ ] Security headers enabled
- [ ] Rate limiting configured

## Docker Deployment

### 1. Build Production Image
```dockerfile
# Multi-stage build for optimization
FROM node:18-alpine AS base
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

FROM node:18-alpine AS build
WORKDIR /app
COPY . .
RUN npm ci
RUN npm run build

FROM node:18-alpine AS production
WORKDIR /app
COPY --from=base /app/node_modules ./node_modules
COPY --from=build /app/.next ./.next
COPY --from=build /app/public ./public
COPY --from=build /app/package.json ./package.json

EXPOSE 3000
CMD ["npm", "start"]
```

### 2. Docker Compose Production
```yaml
version: '3.8'
services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - DATABASE_URL=${DATABASE_URL}
      - NEXTAUTH_SECRET=${NEXTAUTH_SECRET}
      - NEXTAUTH_URL=${NEXTAUTH_URL}
    depends_on:
      - postgres
      - redis
    restart: unless-stopped
    
  postgres:
    image: postgres:15
    environment:
      - POSTGRES_DB=${POSTGRES_DB}
      - POSTGRES_USER=${POSTGRES_USER}
      - POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
    volumes:
      - postgres_data:/var/lib/postgresql/data
    restart: unless-stopped
    
  redis:
    image: redis:7-alpine
    restart: unless-stopped
    
  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - app
    restart: unless-stopped

volumes:
  postgres_data:
```

## Environment Configuration

### 1. Production Environment Variables
```bash
# Application
NODE_ENV=production
PORT=3000
NEXTAUTH_URL=https://your-domain.com
NEXTAUTH_SECRET=your-super-secret-jwt-key

# Database
DATABASE_URL=postgresql://user:password@host:5432/database?sslmode=require

# External Services
SENDGRID_API_KEY=your-sendgrid-api-key
STRIPE_SECRET_KEY=your-stripe-secret-key
STRIPE_WEBHOOK_SECRET=your-stripe-webhook-secret

# File Storage
AWS_ACCESS_KEY_ID=your-aws-access-key
AWS_SECRET_ACCESS_KEY=your-aws-secret-key
AWS_REGION=us-east-1
AWS_S3_BUCKET=your-s3-bucket

# Redis (if using)
REDIS_URL=redis://redis:6379

# Monitoring
SENTRY_DSN=your-sentry-dsn
```

### 2. Security Configuration
```bash
# Encryption
ENCRYPTION_KEY=your-32-character-encryption-key

# CORS
ALLOWED_ORIGINS=https://your-domain.com,https://www.your-domain.com

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
```

## Nginx Configuration

### 1. Nginx Reverse Proxy
```nginx
upstream app {
    server app:3000;
}

server {
    listen 80;
    server_name your-domain.com www.your-domain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.com www.your-domain.com;

    ssl_certificate /etc/nginx/ssl/cert.pem;
    ssl_certificate_key /etc/nginx/ssl/key.pem;
    
    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains";

    # Gzip compression
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;

    location / {
        proxy_pass http://app;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # Static files caching
    location /_next/static/ {
        proxy_pass http://app;
        add_header Cache-Control "public, max-age=31536000, immutable";
    }
}
```

## Database Migration Strategy

### 1. Zero-Downtime Migrations
```bash
# 1. Create backup
pg_dump $DATABASE_URL > backup_$(date +%Y%m%d_%H%M%S).sql

# 2. Run migrations
npx prisma migrate deploy

# 3. Verify migration
npx prisma migrate status

# 4. Test application connectivity
curl -f http://localhost:3000/api/health || exit 1
```

### 2. Rollback Strategy
```bash
# If migration fails, rollback
psql $DATABASE_URL < backup_YYYYMMDD_HHMMSS.sql

# Restart application
docker-compose restart app
```

## Health Checks & Monitoring

### 1. Application Health Checks
```typescript
// /api/health endpoint
export async function GET() {
  const checks = {
    database: await checkDatabase(),
    redis: await checkRedis(),
    external_apis: await checkExternalAPIs(),
    timestamp: new Date().toISOString()
  };
  
  const healthy = Object.values(checks).every(check => 
    typeof check === 'boolean' ? check : check.status === 'healthy'
  );
  
  return Response.json(checks, { 
    status: healthy ? 200 : 503 
  });
}
```

### 2. Docker Health Check
```dockerfile
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
  CMD curl -f http://localhost:3000/api/health || exit 1
```

## SSL/TLS Configuration

### 1. Let's Encrypt Setup
```bash
# Install certbot
apt-get update && apt-get install -y certbot python3-certbot-nginx

# Obtain certificate
certbot --nginx -d your-domain.com -d www.your-domain.com

# Auto-renewal
echo "0 12 * * * /usr/bin/certbot renew --quiet" | crontab -
```

### 2. SSL Configuration
```nginx
# Strong SSL configuration
ssl_protocols TLSv1.2 TLSv1.3;
ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384;
ssl_prefer_server_ciphers off;
ssl_session_cache shared:SSL:10m;
ssl_session_timeout 10m;
```

## Performance Optimization

### 1. Next.js Optimization
```javascript
// next.config.js
module.exports = {
  output: 'standalone',
  compress: true,
  poweredByHeader: false,
  generateEtags: false,
  images: {
    domains: ['your-cdn-domain.com'],
    formats: ['image/webp', 'image/avif'],
  },
  experimental: {
    optimizeCss: true,
  }
};
```

### 2. Database Optimization
```sql
-- Create indexes for performance
CREATE INDEX CONCURRENTLY idx_cases_user_id ON cases(user_id);
CREATE INDEX CONCURRENTLY idx_documents_case_id ON documents(case_id);
CREATE INDEX CONCURRENTLY idx_payments_case_id ON payments(case_id);
```

## Backup Strategy

### 1. Database Backups
```bash
#!/bin/bash
# Daily backup script
BACKUP_DIR="/backups"
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="$BACKUP_DIR/lvj_backup_$DATE.sql"

# Create backup
pg_dump $DATABASE_URL > $BACKUP_FILE

# Compress backup
gzip $BACKUP_FILE

# Upload to S3 (optional)
aws s3 cp $BACKUP_FILE.gz s3://your-backup-bucket/

# Clean old backups (keep 30 days)
find $BACKUP_DIR -name "*.sql.gz" -mtime +30 -delete
```

### 2. File Storage Backup
```bash
# Sync S3 bucket to backup location
aws s3 sync s3://your-main-bucket s3://your-backup-bucket --delete
```

## Monitoring & Alerting

### 1. Application Monitoring
```bash
# Install monitoring tools
npm install @sentry/nextjs

# Configure Sentry
echo "SENTRY_DSN=your-sentry-dsn" >> .env.production
```

### 2. Infrastructure Monitoring
```yaml
# docker-compose.monitoring.yml
version: '3.8'
services:
  prometheus:
    image: prom/prometheus
    ports:
      - "9090:9090"
    volumes:
      - ./prometheus.yml:/etc/prometheus/prometheus.yml
      
  grafana:
    image: grafana/grafana
    ports:
      - "3001:3000"
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin
```

## Deployment Automation

### 1. CI/CD Pipeline
```yaml
# .github/workflows/deploy.yml
name: Deploy to Production
on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Build and push Docker image
        run: |
          docker build -t your-registry/lvj-app:${{ github.sha }} .
          docker push your-registry/lvj-app:${{ github.sha }}
          
      - name: Deploy to production
        run: |
          ssh production-server "docker pull your-registry/lvj-app:${{ github.sha }}"
          ssh production-server "docker-compose up -d"
```

### 2. Blue-Green Deployment
```bash
#!/bin/bash
# Blue-green deployment script
NEW_VERSION=$1
CURRENT_COLOR=$(docker-compose ps | grep "app" | grep "Up" | awk '{print $1}' | cut -d'_' -1)

if [ "$CURRENT_COLOR" = "blue" ]; then
    NEW_COLOR="green"
else
    NEW_COLOR="blue"
fi

# Deploy new version
docker-compose -f docker-compose.$NEW_COLOR.yml up -d

# Health check
sleep 30
curl -f http://localhost:3000/api/health || exit 1

# Switch traffic
# Update load balancer configuration

# Stop old version
docker-compose -f docker-compose.$CURRENT_COLOR.yml down
```

## Troubleshooting

### 1. Common Issues
```bash
# Check application logs
docker-compose logs app

# Check database connectivity
docker-compose exec app npx prisma db pull

# Check disk space
df -h

# Check memory usage
free -h

# Check process status
docker-compose ps
```

### 2. Emergency Procedures
```bash
# Quick rollback
docker-compose down
docker-compose up -d --scale app=0
# Fix issue
docker-compose up -d

# Database emergency restore
psql $DATABASE_URL < latest_backup.sql
```

## Security Hardening

### 1. Server Hardening
```bash
# Update system
apt-get update && apt-get upgrade -y

# Configure firewall
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw enable

# Disable root login
sed -i 's/PermitRootLogin yes/PermitRootLogin no/' /etc/ssh/sshd_config
systemctl restart ssh
```

### 2. Container Security
```dockerfile
# Use non-root user
RUN addgroup -g 1001 -S nodejs
RUN adduser -S nextjs -u 1001
USER nextjs
```

---

This production deployment guide ensures a secure, scalable, and maintainable deployment of the LVJ Immigration Services platform with proper monitoring, backup, and recovery procedures.
