
import { NextRequest, NextResponse } from "next/server";
import { getPrisma } from "@/lib/db";
import { getCurrentUser, requireStaffOrAdmin } from "@/lib/rbac";
import { Role } from "@prisma/client";

export const dynamic = "force-dynamic";

// GET - Get task comments
export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 });
    }

    const { id: taskId } = params;
    const prisma = await getPrisma();

    // First check if user has access to the task
    const task = await prisma.task.findUnique({
      where: { id: taskId },
      include: {
        case: {
          include: {
            client: true,
          }
        }
      },
    });

    if (!task) {
      return NextResponse.json({ error: 'Task not found' }, { status: 404 });
    }

    // Check access permissions
    let hasAccess = false;
    if (user.role === Role.ADMIN) {
      hasAccess = true;
    } else if (user.role === Role.STAFF) {
      hasAccess = task.assignedToId === user.id || 
                 task.createdById === user.id ||
                 task.case?.caseManagerId === user.id ||
                 task.case?.lawyerId === user.id;
    } else if (user.role === Role.CLIENT) {
      hasAccess = task.case?.clientId === user.id;
    }

    if (!hasAccess) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 });
    }

    const comments = await prisma.taskComment.findMany({
      where: { taskId },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            email: true,
            firstName: true,
            lastName: true,
            avatar: true,
            role: true,
          }
        }
      },
      orderBy: { createdAt: 'asc' },
    });

    return NextResponse.json({ comments });
  } catch (error: any) {
    console.error("Failed to fetch task comments:", error);
    return NextResponse.json(
      { error: error?.message || "Internal Server Error" },
      { status: error?.status || 500 }
    );
  }
}

// POST - Add a comment to a task
export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 });
    }

    const { id: taskId } = params;
    const body = await req.json();
    const { content } = body;

    if (!content || content.trim() === '') {
      return NextResponse.json(
        { error: 'Comment content is required' },
        { status: 400 }
      );
    }

    const prisma = await getPrisma();

    // Check if user has access to the task (same logic as GET)
    const task = await prisma.task.findUnique({
      where: { id: taskId },
      include: {
        case: true
      },
    });

    if (!task) {
      return NextResponse.json({ error: 'Task not found' }, { status: 404 });
    }

    // Check access permissions
    let hasAccess = false;
    if (user.role === Role.ADMIN) {
      hasAccess = true;
    } else if (user.role === Role.STAFF) {
      hasAccess = task.assignedToId === user.id || 
                 task.createdById === user.id ||
                 task.case?.caseManagerId === user.id ||
                 task.case?.lawyerId === user.id;
    } else if (user.role === Role.CLIENT) {
      hasAccess = task.case?.clientId === user.id;
    }

    if (!hasAccess) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 });
    }

    const comment = await prisma.taskComment.create({
      data: {
        content: content.trim(),
        authorId: user.id,
        taskId,
      },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            email: true,
            firstName: true,
            lastName: true,
            avatar: true,
            role: true,
          }
        }
      },
    });

    // Create activity log
    await prisma.taskActivity.create({
      data: {
        action: 'comment_added',
        description: `Comment added to task`,
        userId: user.id,
        taskId,
      },
    });

    return NextResponse.json({ comment }, { status: 201 });
  } catch (error: any) {
    console.error('Failed to create task comment:', error);
    return NextResponse.json(
      { error: error?.message || 'Internal Server Error' },
      { status: error?.status || 500 }
    );
  }
}
