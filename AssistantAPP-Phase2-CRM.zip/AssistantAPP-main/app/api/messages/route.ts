import { NextRequest, NextResponse } from 'next/server';
import { getPrisma } from '@/lib/db';
import { getCurrentUser } from "@/lib/rbac";
import { createAuditLog } from "@/lib/audit-log";
import { MessageType, MessageStatus, Priority, Role } from "@prisma/client";

export const dynamic = 'force-dynamic';

// GET - List messages with threading and filtering
export async function GET(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const caseId = searchParams.get('caseId');
    const threadId = searchParams.get('threadId');
    const messageType = searchParams.get('type') as MessageType | null;
    const status = searchParams.get('status') as MessageStatus | null;
    const isInternal = searchParams.get('internal');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');

    if (!caseId) {
      return NextResponse.json({ error: 'caseId required' }, { status: 400 });
    }

    const skip = (page - 1) * limit;
    const prisma = await getPrisma();

    // Check case access
    const caseRecord = await prisma.case.findUnique({
      where: { id: caseId },
    });

    if (!caseRecord) {
      return NextResponse.json({ error: 'Case not found' }, { status: 404 });
    }

    // Check access permissions
    let hasAccess = false;
    if (user.role === Role.ADMIN) {
      hasAccess = true;
    } else if (user.role === Role.STAFF) {
      hasAccess = caseRecord.caseManagerId === user.id || caseRecord.lawyerId === user.id;
    } else if (user.role === Role.CLIENT) {
      hasAccess = caseRecord.clientId === user.id;
    }

    if (!hasAccess) {
      return NextResponse.json({ error: 'Access denied to case messages' }, { status: 403 });
    }

    let whereClause: any = { caseId };

    // For clients, filter out internal messages
    if (user.role === Role.CLIENT) {
      whereClause.OR = [
        { isInternal: false },
        { senderId: user.id },
        { 
          recipientIds: {
            path: `$`,
            array_contains: user.id
          }
        }
      ];
    }

    // Additional filters
    if (threadId) {
      whereClause.threadId = threadId;
    }
    if (messageType && Object.values(MessageType).includes(messageType)) {
      whereClause.messageType = messageType;
    }
    if (status && Object.values(MessageStatus).includes(status)) {
      whereClause.status = status;
    }
    if (isInternal !== null) {
      whereClause.isInternal = isInternal === 'true';
    }

    const [messages, totalCount] = await Promise.all([
      prisma.message.findMany({
        where: whereClause,
        include: {
          sender: {
            select: {
              id: true,
              name: true,
              email: true,
              firstName: true,
              lastName: true,
              avatar: true,
              role: true,
            }
          },
          parentMessage: {
            select: {
              id: true,
              body: true,
              sender: {
                select: {
                  name: true,
                  firstName: true,
                  lastName: true,
                }
              }
            }
          },
          replies: {
            select: {
              id: true,
              body: true,
              createdAt: true,
              sender: {
                select: {
                  name: true,
                  firstName: true,
                  lastName: true,
                }
              }
            },
            orderBy: { createdAt: 'asc' },
            take: 3, // Show preview of first few replies
          },
          _count: {
            select: {
              replies: true,
            }
          }
        },
        orderBy: [
          { isUrgent: 'desc' },
          { createdAt: 'desc' },
        ],
        skip,
        take: limit,
      }),
      prisma.message.count({ where: whereClause }),
    ]);

    // Parse JSON fields
    const messagesWithParsedFields = messages.map(msg => ({
      ...msg,
      attachments: msg.attachments ? JSON.parse(msg.attachments as string) : [],
      recipientIds: msg.recipientIds ? JSON.parse(msg.recipientIds as string) : [],
      readBy: msg.readBy ? JSON.parse(msg.readBy as string) : {},
    }));

    return NextResponse.json({
      messages: messagesWithParsedFields,
      pagination: {
        page,
        limit,
        totalCount,
        totalPages: Math.ceil(totalCount / limit),
      },
    });
  } catch (error: any) {
    console.error("Failed to fetch messages:", error);
    return NextResponse.json(
      { error: error?.message || "Internal Server Error" },
      { status: error?.status || 500 }
    );
  }
}

// POST - Create or manage messages
export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 });
    }

    const body = await req.json();
    const { action } = body;

    if (action === 'post' || action === 'send') {
      const {
        caseId,
        body: messageBody,
        messageType = MessageType.note,
        priority = Priority.normal,
        isUrgent = false,
        isInternal = true,
        recipientIds = [],
        parentMessageId,
        threadId,
        attachments = [],
      } = body;

      if (!caseId || !messageBody) {
        return NextResponse.json({ error: 'caseId and message body are required' }, { status: 400 });
      }

      const prisma = await getPrisma();

      // Check case access
      const caseRecord = await prisma.case.findUnique({
        where: { id: caseId },
      });

      if (!caseRecord) {
        return NextResponse.json({ error: 'Case not found' }, { status: 404 });
      }

      // Check send permissions
      let canSend = false;
      if (user.role === Role.ADMIN) {
        canSend = true;
      } else if (user.role === Role.STAFF) {
        canSend = caseRecord.caseManagerId === user.id || caseRecord.lawyerId === user.id;
      } else if (user.role === Role.CLIENT) {
        canSend = caseRecord.clientId === user.id;
        // Clients can only send non-internal messages
        if (isInternal) {
          return NextResponse.json({ error: 'Clients cannot send internal messages' }, { status: 403 });
        }
      }

      if (!canSend) {
        return NextResponse.json({ error: 'Send permission denied' }, { status: 403 });
      }

      // Validate parent message if replying
      let finalThreadId = threadId;
      if (parentMessageId) {
        const parentMessage = await prisma.message.findUnique({
          where: { id: parentMessageId },
        });
        if (!parentMessage) {
          return NextResponse.json({ error: 'Parent message not found' }, { status: 404 });
        }
        finalThreadId = parentMessage.threadId || parentMessage.id;
      }

      // Generate thread ID if new thread
      if (!finalThreadId && !parentMessageId) {
        finalThreadId = `thread_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      }

      const message = await prisma.message.create({
        data: {
          body: messageBody,
          messageType: messageType || MessageType.note,
          priority: priority || Priority.normal,
          isUrgent: isUrgent || false,
          isInternal: isInternal ?? true,
          attachments: attachments.length > 0 ? JSON.stringify(attachments) : undefined,
          recipientIds: recipientIds.length > 0 ? JSON.stringify(recipientIds) : undefined,
          threadId: finalThreadId,
          parentMessageId: parentMessageId || null,
          senderId: user.id,
          caseId,
          status: MessageStatus.unread,
        },
        include: {
          sender: {
            select: {
              id: true,
              name: true,
              email: true,
              firstName: true,
              lastName: true,
              avatar: true,
              role: true,
            }
          }
        },
      });

      // Log message creation
      await createAuditLog({
        action: 'MESSAGE_SEND',
        caseId,
        userId: user.id,
        diff: JSON.stringify({
          messageId: message.id,
          messageType,
          isInternal,
          recipientCount: recipientIds.length,
        }),
      });

      return NextResponse.json({ message }, { status: 201 });
    }

    if (action === 'status') {
      const { messageId, status } = body;
      
      if (!messageId || !status) {
        return NextResponse.json({ error: 'messageId and status are required' }, { status: 400 });
      }

      if (!Object.values(MessageStatus).includes(status)) {
        return NextResponse.json({ error: 'Invalid status' }, { status: 400 });
      }

      const prisma = await getPrisma();

      const message = await prisma.message.findUnique({
        where: { id: messageId },
        include: { case: true },
      });

      if (!message) {
        return NextResponse.json({ error: 'Message not found' }, { status: 404 });
      }

      // Check access permissions
      let hasAccess = false;
      if (user.role === Role.ADMIN) {
        hasAccess = true;
      } else if (user.role === Role.STAFF) {
        hasAccess = message.case.caseManagerId === user.id || message.case.lawyerId === user.id;
      } else if (user.role === Role.CLIENT) {
        hasAccess = message.case.clientId === user.id || message.senderId === user.id;
      }

      if (!hasAccess) {
        return NextResponse.json({ error: 'Access denied' }, { status: 403 });
      }

      // Update read tracking
      const readBy = message.readBy ? JSON.parse(message.readBy as string) : {};
      readBy[user.id] = new Date().toISOString();

      const updatedMessage = await prisma.message.update({
        where: { id: messageId },
        data: {
          status,
          readBy: JSON.stringify(readBy),
        },
      });

      return NextResponse.json({ updated: true, message: updatedMessage });
    }

    return NextResponse.json({ error: 'Unsupported action' }, { status: 400 });
  } catch (error: any) {
    console.error('Failed to handle message request:', error);
    return NextResponse.json(
      { error: error?.message || 'Internal Server Error' },
      { status: error?.status || 500 }
    );
  }
}
