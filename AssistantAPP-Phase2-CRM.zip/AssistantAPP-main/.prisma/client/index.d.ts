
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model User
 * 
 */
export type User = $Result.DefaultSelection<Prisma.$UserPayload>
/**
 * Model Case
 * 
 */
export type Case = $Result.DefaultSelection<Prisma.$CasePayload>
/**
 * Model PartnerRole
 * 
 */
export type PartnerRole = $Result.DefaultSelection<Prisma.$PartnerRolePayload>
/**
 * Model ExternalPartner
 * 
 */
export type ExternalPartner = $Result.DefaultSelection<Prisma.$ExternalPartnerPayload>
/**
 * Model ExternalCommunication
 * 
 */
export type ExternalCommunication = $Result.DefaultSelection<Prisma.$ExternalCommunicationPayload>
/**
 * Model Document
 * 
 */
export type Document = $Result.DefaultSelection<Prisma.$DocumentPayload>
/**
 * Model Payment
 * 
 */
export type Payment = $Result.DefaultSelection<Prisma.$PaymentPayload>
/**
 * Model TimelineEvent
 * 
 */
export type TimelineEvent = $Result.DefaultSelection<Prisma.$TimelineEventPayload>
/**
 * Model Message
 * 
 */
export type Message = $Result.DefaultSelection<Prisma.$MessagePayload>

/**
 * Enums
 */
export namespace $Enums {
  export const Role: {
  CLIENT: 'CLIENT',
  STAFF: 'STAFF',
  ADMIN: 'ADMIN'
};

export type Role = (typeof Role)[keyof typeof Role]


export const CaseStatus: {
  new: 'new',
  documents_pending: 'documents_pending',
  in_review: 'in_review',
  submitted: 'submitted',
  approved: 'approved',
  denied: 'denied'
};

export type CaseStatus = (typeof CaseStatus)[keyof typeof CaseStatus]


export const DocState: {
  requested: 'requested',
  uploaded: 'uploaded',
  approved: 'approved',
  rejected: 'rejected'
};

export type DocState = (typeof DocState)[keyof typeof DocState]


export const PaymentStatus: {
  paid: 'paid',
  unpaid: 'unpaid',
  overdue: 'overdue'
};

export type PaymentStatus = (typeof PaymentStatus)[keyof typeof PaymentStatus]


export const Direction: {
  INCOMING: 'INCOMING',
  OUTGOING: 'OUTGOING'
};

export type Direction = (typeof Direction)[keyof typeof Direction]

}

export type Role = $Enums.Role

export const Role: typeof $Enums.Role

export type CaseStatus = $Enums.CaseStatus

export const CaseStatus: typeof $Enums.CaseStatus

export type DocState = $Enums.DocState

export const DocState: typeof $Enums.DocState

export type PaymentStatus = $Enums.PaymentStatus

export const PaymentStatus: typeof $Enums.PaymentStatus

export type Direction = $Enums.Direction

export const Direction: typeof $Enums.Direction

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Users
 * const users = await prisma.user.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  const U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Users
   * const users = await prisma.user.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.user`: Exposes CRUD operations for the **User** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Users
    * const users = await prisma.user.findMany()
    * ```
    */
  get user(): Prisma.UserDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.case`: Exposes CRUD operations for the **Case** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Cases
    * const cases = await prisma.case.findMany()
    * ```
    */
  get case(): Prisma.CaseDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.partnerRole`: Exposes CRUD operations for the **PartnerRole** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more PartnerRoles
    * const partnerRoles = await prisma.partnerRole.findMany()
    * ```
    */
  get partnerRole(): Prisma.PartnerRoleDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.externalPartner`: Exposes CRUD operations for the **ExternalPartner** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more ExternalPartners
    * const externalPartners = await prisma.externalPartner.findMany()
    * ```
    */
  get externalPartner(): Prisma.ExternalPartnerDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.externalCommunication`: Exposes CRUD operations for the **ExternalCommunication** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more ExternalCommunications
    * const externalCommunications = await prisma.externalCommunication.findMany()
    * ```
    */
  get externalCommunication(): Prisma.ExternalCommunicationDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.document`: Exposes CRUD operations for the **Document** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Documents
    * const documents = await prisma.document.findMany()
    * ```
    */
  get document(): Prisma.DocumentDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.payment`: Exposes CRUD operations for the **Payment** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Payments
    * const payments = await prisma.payment.findMany()
    * ```
    */
  get payment(): Prisma.PaymentDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.timelineEvent`: Exposes CRUD operations for the **TimelineEvent** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more TimelineEvents
    * const timelineEvents = await prisma.timelineEvent.findMany()
    * ```
    */
  get timelineEvent(): Prisma.TimelineEventDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.message`: Exposes CRUD operations for the **Message** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Messages
    * const messages = await prisma.message.findMany()
    * ```
    */
  get message(): Prisma.MessageDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 6.14.0
   * Query Engine version: 717184b7b35ea05dfa71a3236b7af656013e1e49
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    User: 'User',
    Case: 'Case',
    PartnerRole: 'PartnerRole',
    ExternalPartner: 'ExternalPartner',
    ExternalCommunication: 'ExternalCommunication',
    Document: 'Document',
    Payment: 'Payment',
    TimelineEvent: 'TimelineEvent',
    Message: 'Message'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }

  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "user" | "case" | "partnerRole" | "externalPartner" | "externalCommunication" | "document" | "payment" | "timelineEvent" | "message"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      User: {
        payload: Prisma.$UserPayload<ExtArgs>
        fields: Prisma.UserFieldRefs
        operations: {
          findUnique: {
            args: Prisma.UserFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.UserFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findFirst: {
            args: Prisma.UserFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.UserFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findMany: {
            args: Prisma.UserFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          create: {
            args: Prisma.UserCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          createMany: {
            args: Prisma.UserCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.UserCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          delete: {
            args: Prisma.UserDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          update: {
            args: Prisma.UserUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          deleteMany: {
            args: Prisma.UserDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.UserUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.UserUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          upsert: {
            args: Prisma.UserUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          aggregate: {
            args: Prisma.UserAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUser>
          }
          groupBy: {
            args: Prisma.UserGroupByArgs<ExtArgs>
            result: $Utils.Optional<UserGroupByOutputType>[]
          }
          count: {
            args: Prisma.UserCountArgs<ExtArgs>
            result: $Utils.Optional<UserCountAggregateOutputType> | number
          }
        }
      }
      Case: {
        payload: Prisma.$CasePayload<ExtArgs>
        fields: Prisma.CaseFieldRefs
        operations: {
          findUnique: {
            args: Prisma.CaseFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CasePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.CaseFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CasePayload>
          }
          findFirst: {
            args: Prisma.CaseFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CasePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.CaseFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CasePayload>
          }
          findMany: {
            args: Prisma.CaseFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CasePayload>[]
          }
          create: {
            args: Prisma.CaseCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CasePayload>
          }
          createMany: {
            args: Prisma.CaseCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.CaseCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CasePayload>[]
          }
          delete: {
            args: Prisma.CaseDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CasePayload>
          }
          update: {
            args: Prisma.CaseUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CasePayload>
          }
          deleteMany: {
            args: Prisma.CaseDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.CaseUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.CaseUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CasePayload>[]
          }
          upsert: {
            args: Prisma.CaseUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CasePayload>
          }
          aggregate: {
            args: Prisma.CaseAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateCase>
          }
          groupBy: {
            args: Prisma.CaseGroupByArgs<ExtArgs>
            result: $Utils.Optional<CaseGroupByOutputType>[]
          }
          count: {
            args: Prisma.CaseCountArgs<ExtArgs>
            result: $Utils.Optional<CaseCountAggregateOutputType> | number
          }
        }
      }
      PartnerRole: {
        payload: Prisma.$PartnerRolePayload<ExtArgs>
        fields: Prisma.PartnerRoleFieldRefs
        operations: {
          findUnique: {
            args: Prisma.PartnerRoleFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PartnerRolePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.PartnerRoleFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PartnerRolePayload>
          }
          findFirst: {
            args: Prisma.PartnerRoleFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PartnerRolePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.PartnerRoleFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PartnerRolePayload>
          }
          findMany: {
            args: Prisma.PartnerRoleFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PartnerRolePayload>[]
          }
          create: {
            args: Prisma.PartnerRoleCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PartnerRolePayload>
          }
          createMany: {
            args: Prisma.PartnerRoleCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.PartnerRoleCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PartnerRolePayload>[]
          }
          delete: {
            args: Prisma.PartnerRoleDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PartnerRolePayload>
          }
          update: {
            args: Prisma.PartnerRoleUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PartnerRolePayload>
          }
          deleteMany: {
            args: Prisma.PartnerRoleDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.PartnerRoleUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.PartnerRoleUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PartnerRolePayload>[]
          }
          upsert: {
            args: Prisma.PartnerRoleUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PartnerRolePayload>
          }
          aggregate: {
            args: Prisma.PartnerRoleAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregatePartnerRole>
          }
          groupBy: {
            args: Prisma.PartnerRoleGroupByArgs<ExtArgs>
            result: $Utils.Optional<PartnerRoleGroupByOutputType>[]
          }
          count: {
            args: Prisma.PartnerRoleCountArgs<ExtArgs>
            result: $Utils.Optional<PartnerRoleCountAggregateOutputType> | number
          }
        }
      }
      ExternalPartner: {
        payload: Prisma.$ExternalPartnerPayload<ExtArgs>
        fields: Prisma.ExternalPartnerFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ExternalPartnerFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExternalPartnerPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ExternalPartnerFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExternalPartnerPayload>
          }
          findFirst: {
            args: Prisma.ExternalPartnerFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExternalPartnerPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ExternalPartnerFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExternalPartnerPayload>
          }
          findMany: {
            args: Prisma.ExternalPartnerFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExternalPartnerPayload>[]
          }
          create: {
            args: Prisma.ExternalPartnerCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExternalPartnerPayload>
          }
          createMany: {
            args: Prisma.ExternalPartnerCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.ExternalPartnerCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExternalPartnerPayload>[]
          }
          delete: {
            args: Prisma.ExternalPartnerDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExternalPartnerPayload>
          }
          update: {
            args: Prisma.ExternalPartnerUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExternalPartnerPayload>
          }
          deleteMany: {
            args: Prisma.ExternalPartnerDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ExternalPartnerUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.ExternalPartnerUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExternalPartnerPayload>[]
          }
          upsert: {
            args: Prisma.ExternalPartnerUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExternalPartnerPayload>
          }
          aggregate: {
            args: Prisma.ExternalPartnerAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateExternalPartner>
          }
          groupBy: {
            args: Prisma.ExternalPartnerGroupByArgs<ExtArgs>
            result: $Utils.Optional<ExternalPartnerGroupByOutputType>[]
          }
          count: {
            args: Prisma.ExternalPartnerCountArgs<ExtArgs>
            result: $Utils.Optional<ExternalPartnerCountAggregateOutputType> | number
          }
        }
      }
      ExternalCommunication: {
        payload: Prisma.$ExternalCommunicationPayload<ExtArgs>
        fields: Prisma.ExternalCommunicationFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ExternalCommunicationFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExternalCommunicationPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ExternalCommunicationFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExternalCommunicationPayload>
          }
          findFirst: {
            args: Prisma.ExternalCommunicationFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExternalCommunicationPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ExternalCommunicationFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExternalCommunicationPayload>
          }
          findMany: {
            args: Prisma.ExternalCommunicationFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExternalCommunicationPayload>[]
          }
          create: {
            args: Prisma.ExternalCommunicationCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExternalCommunicationPayload>
          }
          createMany: {
            args: Prisma.ExternalCommunicationCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.ExternalCommunicationCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExternalCommunicationPayload>[]
          }
          delete: {
            args: Prisma.ExternalCommunicationDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExternalCommunicationPayload>
          }
          update: {
            args: Prisma.ExternalCommunicationUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExternalCommunicationPayload>
          }
          deleteMany: {
            args: Prisma.ExternalCommunicationDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ExternalCommunicationUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.ExternalCommunicationUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExternalCommunicationPayload>[]
          }
          upsert: {
            args: Prisma.ExternalCommunicationUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExternalCommunicationPayload>
          }
          aggregate: {
            args: Prisma.ExternalCommunicationAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateExternalCommunication>
          }
          groupBy: {
            args: Prisma.ExternalCommunicationGroupByArgs<ExtArgs>
            result: $Utils.Optional<ExternalCommunicationGroupByOutputType>[]
          }
          count: {
            args: Prisma.ExternalCommunicationCountArgs<ExtArgs>
            result: $Utils.Optional<ExternalCommunicationCountAggregateOutputType> | number
          }
        }
      }
      Document: {
        payload: Prisma.$DocumentPayload<ExtArgs>
        fields: Prisma.DocumentFieldRefs
        operations: {
          findUnique: {
            args: Prisma.DocumentFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DocumentPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.DocumentFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DocumentPayload>
          }
          findFirst: {
            args: Prisma.DocumentFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DocumentPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.DocumentFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DocumentPayload>
          }
          findMany: {
            args: Prisma.DocumentFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DocumentPayload>[]
          }
          create: {
            args: Prisma.DocumentCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DocumentPayload>
          }
          createMany: {
            args: Prisma.DocumentCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.DocumentCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DocumentPayload>[]
          }
          delete: {
            args: Prisma.DocumentDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DocumentPayload>
          }
          update: {
            args: Prisma.DocumentUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DocumentPayload>
          }
          deleteMany: {
            args: Prisma.DocumentDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.DocumentUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.DocumentUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DocumentPayload>[]
          }
          upsert: {
            args: Prisma.DocumentUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$DocumentPayload>
          }
          aggregate: {
            args: Prisma.DocumentAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateDocument>
          }
          groupBy: {
            args: Prisma.DocumentGroupByArgs<ExtArgs>
            result: $Utils.Optional<DocumentGroupByOutputType>[]
          }
          count: {
            args: Prisma.DocumentCountArgs<ExtArgs>
            result: $Utils.Optional<DocumentCountAggregateOutputType> | number
          }
        }
      }
      Payment: {
        payload: Prisma.$PaymentPayload<ExtArgs>
        fields: Prisma.PaymentFieldRefs
        operations: {
          findUnique: {
            args: Prisma.PaymentFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.PaymentFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentPayload>
          }
          findFirst: {
            args: Prisma.PaymentFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.PaymentFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentPayload>
          }
          findMany: {
            args: Prisma.PaymentFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentPayload>[]
          }
          create: {
            args: Prisma.PaymentCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentPayload>
          }
          createMany: {
            args: Prisma.PaymentCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.PaymentCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentPayload>[]
          }
          delete: {
            args: Prisma.PaymentDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentPayload>
          }
          update: {
            args: Prisma.PaymentUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentPayload>
          }
          deleteMany: {
            args: Prisma.PaymentDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.PaymentUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.PaymentUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentPayload>[]
          }
          upsert: {
            args: Prisma.PaymentUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PaymentPayload>
          }
          aggregate: {
            args: Prisma.PaymentAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregatePayment>
          }
          groupBy: {
            args: Prisma.PaymentGroupByArgs<ExtArgs>
            result: $Utils.Optional<PaymentGroupByOutputType>[]
          }
          count: {
            args: Prisma.PaymentCountArgs<ExtArgs>
            result: $Utils.Optional<PaymentCountAggregateOutputType> | number
          }
        }
      }
      TimelineEvent: {
        payload: Prisma.$TimelineEventPayload<ExtArgs>
        fields: Prisma.TimelineEventFieldRefs
        operations: {
          findUnique: {
            args: Prisma.TimelineEventFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TimelineEventPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.TimelineEventFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TimelineEventPayload>
          }
          findFirst: {
            args: Prisma.TimelineEventFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TimelineEventPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.TimelineEventFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TimelineEventPayload>
          }
          findMany: {
            args: Prisma.TimelineEventFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TimelineEventPayload>[]
          }
          create: {
            args: Prisma.TimelineEventCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TimelineEventPayload>
          }
          createMany: {
            args: Prisma.TimelineEventCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.TimelineEventCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TimelineEventPayload>[]
          }
          delete: {
            args: Prisma.TimelineEventDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TimelineEventPayload>
          }
          update: {
            args: Prisma.TimelineEventUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TimelineEventPayload>
          }
          deleteMany: {
            args: Prisma.TimelineEventDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.TimelineEventUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.TimelineEventUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TimelineEventPayload>[]
          }
          upsert: {
            args: Prisma.TimelineEventUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TimelineEventPayload>
          }
          aggregate: {
            args: Prisma.TimelineEventAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateTimelineEvent>
          }
          groupBy: {
            args: Prisma.TimelineEventGroupByArgs<ExtArgs>
            result: $Utils.Optional<TimelineEventGroupByOutputType>[]
          }
          count: {
            args: Prisma.TimelineEventCountArgs<ExtArgs>
            result: $Utils.Optional<TimelineEventCountAggregateOutputType> | number
          }
        }
      }
      Message: {
        payload: Prisma.$MessagePayload<ExtArgs>
        fields: Prisma.MessageFieldRefs
        operations: {
          findUnique: {
            args: Prisma.MessageFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessagePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.MessageFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessagePayload>
          }
          findFirst: {
            args: Prisma.MessageFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessagePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.MessageFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessagePayload>
          }
          findMany: {
            args: Prisma.MessageFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessagePayload>[]
          }
          create: {
            args: Prisma.MessageCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessagePayload>
          }
          createMany: {
            args: Prisma.MessageCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.MessageCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessagePayload>[]
          }
          delete: {
            args: Prisma.MessageDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessagePayload>
          }
          update: {
            args: Prisma.MessageUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessagePayload>
          }
          deleteMany: {
            args: Prisma.MessageDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.MessageUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.MessageUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessagePayload>[]
          }
          upsert: {
            args: Prisma.MessageUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessagePayload>
          }
          aggregate: {
            args: Prisma.MessageAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateMessage>
          }
          groupBy: {
            args: Prisma.MessageGroupByArgs<ExtArgs>
            result: $Utils.Optional<MessageGroupByOutputType>[]
          }
          count: {
            args: Prisma.MessageCountArgs<ExtArgs>
            result: $Utils.Optional<MessageCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Shorthand for `emit: 'stdout'`
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events only
     * log: [
     *   { emit: 'event', level: 'query' },
     *   { emit: 'event', level: 'info' },
     *   { emit: 'event', level: 'warn' }
     *   { emit: 'event', level: 'error' }
     * ]
     * 
     * / Emit as events and log to stdout
     * og: [
     *  { emit: 'stdout', level: 'query' },
     *  { emit: 'stdout', level: 'info' },
     *  { emit: 'stdout', level: 'warn' }
     *  { emit: 'stdout', level: 'error' }
     * 
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
  }
  export type GlobalOmitConfig = {
    user?: UserOmit
    case?: CaseOmit
    partnerRole?: PartnerRoleOmit
    externalPartner?: ExternalPartnerOmit
    externalCommunication?: ExternalCommunicationOmit
    document?: DocumentOmit
    payment?: PaymentOmit
    timelineEvent?: TimelineEventOmit
    message?: MessageOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type CheckIsLogLevel<T> = T extends LogLevel ? T : never;

  export type GetLogType<T> = CheckIsLogLevel<
    T extends LogDefinition ? T['level'] : T
  >;

  export type GetEvents<T extends any[]> = T extends Array<LogLevel | LogDefinition>
    ? GetLogType<T[number]>
    : never;

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type UserCountOutputType
   */

  export type UserCountOutputType = {
    casesAsClient: number
    casesAsManager: number
    casesAsLawyer: number
  }

  export type UserCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    casesAsClient?: boolean | UserCountOutputTypeCountCasesAsClientArgs
    casesAsManager?: boolean | UserCountOutputTypeCountCasesAsManagerArgs
    casesAsLawyer?: boolean | UserCountOutputTypeCountCasesAsLawyerArgs
  }

  // Custom InputTypes
  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserCountOutputType
     */
    select?: UserCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountCasesAsClientArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: CaseWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountCasesAsManagerArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: CaseWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountCasesAsLawyerArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: CaseWhereInput
  }


  /**
   * Count Type CaseCountOutputType
   */

  export type CaseCountOutputType = {
    documents: number
    payments: number
    timelineEvents: number
    internalMessages: number
    externalPartners: number
    externalComms: number
  }

  export type CaseCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    documents?: boolean | CaseCountOutputTypeCountDocumentsArgs
    payments?: boolean | CaseCountOutputTypeCountPaymentsArgs
    timelineEvents?: boolean | CaseCountOutputTypeCountTimelineEventsArgs
    internalMessages?: boolean | CaseCountOutputTypeCountInternalMessagesArgs
    externalPartners?: boolean | CaseCountOutputTypeCountExternalPartnersArgs
    externalComms?: boolean | CaseCountOutputTypeCountExternalCommsArgs
  }

  // Custom InputTypes
  /**
   * CaseCountOutputType without action
   */
  export type CaseCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CaseCountOutputType
     */
    select?: CaseCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * CaseCountOutputType without action
   */
  export type CaseCountOutputTypeCountDocumentsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: DocumentWhereInput
  }

  /**
   * CaseCountOutputType without action
   */
  export type CaseCountOutputTypeCountPaymentsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PaymentWhereInput
  }

  /**
   * CaseCountOutputType without action
   */
  export type CaseCountOutputTypeCountTimelineEventsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TimelineEventWhereInput
  }

  /**
   * CaseCountOutputType without action
   */
  export type CaseCountOutputTypeCountInternalMessagesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MessageWhereInput
  }

  /**
   * CaseCountOutputType without action
   */
  export type CaseCountOutputTypeCountExternalPartnersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ExternalPartnerWhereInput
  }

  /**
   * CaseCountOutputType without action
   */
  export type CaseCountOutputTypeCountExternalCommsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ExternalCommunicationWhereInput
  }


  /**
   * Count Type PartnerRoleCountOutputType
   */

  export type PartnerRoleCountOutputType = {
    partners: number
  }

  export type PartnerRoleCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    partners?: boolean | PartnerRoleCountOutputTypeCountPartnersArgs
  }

  // Custom InputTypes
  /**
   * PartnerRoleCountOutputType without action
   */
  export type PartnerRoleCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PartnerRoleCountOutputType
     */
    select?: PartnerRoleCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * PartnerRoleCountOutputType without action
   */
  export type PartnerRoleCountOutputTypeCountPartnersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ExternalPartnerWhereInput
  }


  /**
   * Models
   */

  /**
   * Model User
   */

  export type AggregateUser = {
    _count: UserCountAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  export type UserMinAggregateOutputType = {
    id: string | null
    email: string | null
    name: string | null
    role: $Enums.Role | null
    password: string | null
  }

  export type UserMaxAggregateOutputType = {
    id: string | null
    email: string | null
    name: string | null
    role: $Enums.Role | null
    password: string | null
  }

  export type UserCountAggregateOutputType = {
    id: number
    email: number
    name: number
    role: number
    password: number
    _all: number
  }


  export type UserMinAggregateInputType = {
    id?: true
    email?: true
    name?: true
    role?: true
    password?: true
  }

  export type UserMaxAggregateInputType = {
    id?: true
    email?: true
    name?: true
    role?: true
    password?: true
  }

  export type UserCountAggregateInputType = {
    id?: true
    email?: true
    name?: true
    role?: true
    password?: true
    _all?: true
  }

  export type UserAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which User to aggregate.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Users
    **/
    _count?: true | UserCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UserMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UserMaxAggregateInputType
  }

  export type GetUserAggregateType<T extends UserAggregateArgs> = {
        [P in keyof T & keyof AggregateUser]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUser[P]>
      : GetScalarType<T[P], AggregateUser[P]>
  }




  export type UserGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserWhereInput
    orderBy?: UserOrderByWithAggregationInput | UserOrderByWithAggregationInput[]
    by: UserScalarFieldEnum[] | UserScalarFieldEnum
    having?: UserScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UserCountAggregateInputType | true
    _min?: UserMinAggregateInputType
    _max?: UserMaxAggregateInputType
  }

  export type UserGroupByOutputType = {
    id: string
    email: string
    name: string | null
    role: $Enums.Role
    password: string | null
    _count: UserCountAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  type GetUserGroupByPayload<T extends UserGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UserGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UserGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UserGroupByOutputType[P]>
            : GetScalarType<T[P], UserGroupByOutputType[P]>
        }
      >
    >


  export type UserSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    email?: boolean
    name?: boolean
    role?: boolean
    password?: boolean
    casesAsClient?: boolean | User$casesAsClientArgs<ExtArgs>
    casesAsManager?: boolean | User$casesAsManagerArgs<ExtArgs>
    casesAsLawyer?: boolean | User$casesAsLawyerArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["user"]>

  export type UserSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    email?: boolean
    name?: boolean
    role?: boolean
    password?: boolean
  }, ExtArgs["result"]["user"]>

  export type UserSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    email?: boolean
    name?: boolean
    role?: boolean
    password?: boolean
  }, ExtArgs["result"]["user"]>

  export type UserSelectScalar = {
    id?: boolean
    email?: boolean
    name?: boolean
    role?: boolean
    password?: boolean
  }

  export type UserOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "email" | "name" | "role" | "password", ExtArgs["result"]["user"]>
  export type UserInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    casesAsClient?: boolean | User$casesAsClientArgs<ExtArgs>
    casesAsManager?: boolean | User$casesAsManagerArgs<ExtArgs>
    casesAsLawyer?: boolean | User$casesAsLawyerArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type UserIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type UserIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $UserPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "User"
    objects: {
      casesAsClient: Prisma.$CasePayload<ExtArgs>[]
      casesAsManager: Prisma.$CasePayload<ExtArgs>[]
      casesAsLawyer: Prisma.$CasePayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      email: string
      name: string | null
      role: $Enums.Role
      password: string | null
    }, ExtArgs["result"]["user"]>
    composites: {}
  }

  type UserGetPayload<S extends boolean | null | undefined | UserDefaultArgs> = $Result.GetResult<Prisma.$UserPayload, S>

  type UserCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<UserFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UserCountAggregateInputType | true
    }

  export interface UserDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['User'], meta: { name: 'User' } }
    /**
     * Find zero or one User that matches the filter.
     * @param {UserFindUniqueArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends UserFindUniqueArgs>(args: SelectSubset<T, UserFindUniqueArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one User that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {UserFindUniqueOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends UserFindUniqueOrThrowArgs>(args: SelectSubset<T, UserFindUniqueOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends UserFindFirstArgs>(args?: SelectSubset<T, UserFindFirstArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends UserFindFirstOrThrowArgs>(args?: SelectSubset<T, UserFindFirstOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Users that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Users
     * const users = await prisma.user.findMany()
     * 
     * // Get first 10 Users
     * const users = await prisma.user.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const userWithIdOnly = await prisma.user.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends UserFindManyArgs>(args?: SelectSubset<T, UserFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a User.
     * @param {UserCreateArgs} args - Arguments to create a User.
     * @example
     * // Create one User
     * const User = await prisma.user.create({
     *   data: {
     *     // ... data to create a User
     *   }
     * })
     * 
     */
    create<T extends UserCreateArgs>(args: SelectSubset<T, UserCreateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Users.
     * @param {UserCreateManyArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const user = await prisma.user.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends UserCreateManyArgs>(args?: SelectSubset<T, UserCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Users and returns the data saved in the database.
     * @param {UserCreateManyAndReturnArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const user = await prisma.user.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Users and only return the `id`
     * const userWithIdOnly = await prisma.user.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends UserCreateManyAndReturnArgs>(args?: SelectSubset<T, UserCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a User.
     * @param {UserDeleteArgs} args - Arguments to delete one User.
     * @example
     * // Delete one User
     * const User = await prisma.user.delete({
     *   where: {
     *     // ... filter to delete one User
     *   }
     * })
     * 
     */
    delete<T extends UserDeleteArgs>(args: SelectSubset<T, UserDeleteArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one User.
     * @param {UserUpdateArgs} args - Arguments to update one User.
     * @example
     * // Update one User
     * const user = await prisma.user.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends UserUpdateArgs>(args: SelectSubset<T, UserUpdateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Users.
     * @param {UserDeleteManyArgs} args - Arguments to filter Users to delete.
     * @example
     * // Delete a few Users
     * const { count } = await prisma.user.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends UserDeleteManyArgs>(args?: SelectSubset<T, UserDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends UserUpdateManyArgs>(args: SelectSubset<T, UserUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users and returns the data updated in the database.
     * @param {UserUpdateManyAndReturnArgs} args - Arguments to update many Users.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Users and only return the `id`
     * const userWithIdOnly = await prisma.user.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends UserUpdateManyAndReturnArgs>(args: SelectSubset<T, UserUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one User.
     * @param {UserUpsertArgs} args - Arguments to update or create a User.
     * @example
     * // Update or create a User
     * const user = await prisma.user.upsert({
     *   create: {
     *     // ... data to create a User
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the User we want to update
     *   }
     * })
     */
    upsert<T extends UserUpsertArgs>(args: SelectSubset<T, UserUpsertArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserCountArgs} args - Arguments to filter Users to count.
     * @example
     * // Count the number of Users
     * const count = await prisma.user.count({
     *   where: {
     *     // ... the filter for the Users we want to count
     *   }
     * })
    **/
    count<T extends UserCountArgs>(
      args?: Subset<T, UserCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UserCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UserAggregateArgs>(args: Subset<T, UserAggregateArgs>): Prisma.PrismaPromise<GetUserAggregateType<T>>

    /**
     * Group by User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends UserGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: UserGroupByArgs['orderBy'] }
        : { orderBy?: UserGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, UserGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUserGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the User model
   */
  readonly fields: UserFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for User.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__UserClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    casesAsClient<T extends User$casesAsClientArgs<ExtArgs> = {}>(args?: Subset<T, User$casesAsClientArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CasePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    casesAsManager<T extends User$casesAsManagerArgs<ExtArgs> = {}>(args?: Subset<T, User$casesAsManagerArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CasePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    casesAsLawyer<T extends User$casesAsLawyerArgs<ExtArgs> = {}>(args?: Subset<T, User$casesAsLawyerArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CasePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the User model
   */
  interface UserFieldRefs {
    readonly id: FieldRef<"User", 'String'>
    readonly email: FieldRef<"User", 'String'>
    readonly name: FieldRef<"User", 'String'>
    readonly role: FieldRef<"User", 'Role'>
    readonly password: FieldRef<"User", 'String'>
  }
    

  // Custom InputTypes
  /**
   * User findUnique
   */
  export type UserFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findUniqueOrThrow
   */
  export type UserFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findFirst
   */
  export type UserFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findFirstOrThrow
   */
  export type UserFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findMany
   */
  export type UserFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which Users to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User create
   */
  export type UserCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to create a User.
     */
    data: XOR<UserCreateInput, UserUncheckedCreateInput>
  }

  /**
   * User createMany
   */
  export type UserCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Users.
     */
    data: UserCreateManyInput | UserCreateManyInput[]
  }

  /**
   * User createManyAndReturn
   */
  export type UserCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * The data used to create many Users.
     */
    data: UserCreateManyInput | UserCreateManyInput[]
  }

  /**
   * User update
   */
  export type UserUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to update a User.
     */
    data: XOR<UserUpdateInput, UserUncheckedUpdateInput>
    /**
     * Choose, which User to update.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User updateMany
   */
  export type UserUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Users.
     */
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyInput>
    /**
     * Filter which Users to update
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to update.
     */
    limit?: number
  }

  /**
   * User updateManyAndReturn
   */
  export type UserUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * The data used to update Users.
     */
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyInput>
    /**
     * Filter which Users to update
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to update.
     */
    limit?: number
  }

  /**
   * User upsert
   */
  export type UserUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The filter to search for the User to update in case it exists.
     */
    where: UserWhereUniqueInput
    /**
     * In case the User found by the `where` argument doesn't exist, create a new User with this data.
     */
    create: XOR<UserCreateInput, UserUncheckedCreateInput>
    /**
     * In case the User was found with the provided `where` argument, update it with this data.
     */
    update: XOR<UserUpdateInput, UserUncheckedUpdateInput>
  }

  /**
   * User delete
   */
  export type UserDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter which User to delete.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User deleteMany
   */
  export type UserDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Users to delete
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to delete.
     */
    limit?: number
  }

  /**
   * User.casesAsClient
   */
  export type User$casesAsClientArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Case
     */
    select?: CaseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Case
     */
    omit?: CaseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CaseInclude<ExtArgs> | null
    where?: CaseWhereInput
    orderBy?: CaseOrderByWithRelationInput | CaseOrderByWithRelationInput[]
    cursor?: CaseWhereUniqueInput
    take?: number
    skip?: number
    distinct?: CaseScalarFieldEnum | CaseScalarFieldEnum[]
  }

  /**
   * User.casesAsManager
   */
  export type User$casesAsManagerArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Case
     */
    select?: CaseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Case
     */
    omit?: CaseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CaseInclude<ExtArgs> | null
    where?: CaseWhereInput
    orderBy?: CaseOrderByWithRelationInput | CaseOrderByWithRelationInput[]
    cursor?: CaseWhereUniqueInput
    take?: number
    skip?: number
    distinct?: CaseScalarFieldEnum | CaseScalarFieldEnum[]
  }

  /**
   * User.casesAsLawyer
   */
  export type User$casesAsLawyerArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Case
     */
    select?: CaseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Case
     */
    omit?: CaseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CaseInclude<ExtArgs> | null
    where?: CaseWhereInput
    orderBy?: CaseOrderByWithRelationInput | CaseOrderByWithRelationInput[]
    cursor?: CaseWhereUniqueInput
    take?: number
    skip?: number
    distinct?: CaseScalarFieldEnum | CaseScalarFieldEnum[]
  }

  /**
   * User without action
   */
  export type UserDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
  }


  /**
   * Model Case
   */

  export type AggregateCase = {
    _count: CaseCountAggregateOutputType | null
    _avg: CaseAvgAggregateOutputType | null
    _sum: CaseSumAggregateOutputType | null
    _min: CaseMinAggregateOutputType | null
    _max: CaseMaxAggregateOutputType | null
  }

  export type CaseAvgAggregateOutputType = {
    totalFee: number | null
    completionPercentage: number | null
  }

  export type CaseSumAggregateOutputType = {
    totalFee: number | null
    completionPercentage: number | null
  }

  export type CaseMinAggregateOutputType = {
    id: string | null
    createdAt: Date | null
    updatedAt: Date | null
    title: string | null
    caseNumber: string | null
    totalFee: number | null
    currency: string | null
    applicantName: string | null
    applicantEmail: string | null
    overallStatus: $Enums.CaseStatus | null
    stage: string | null
    urgencyLevel: string | null
    completionPercentage: number | null
    clientId: string | null
    caseManagerId: string | null
    lawyerId: string | null
  }

  export type CaseMaxAggregateOutputType = {
    id: string | null
    createdAt: Date | null
    updatedAt: Date | null
    title: string | null
    caseNumber: string | null
    totalFee: number | null
    currency: string | null
    applicantName: string | null
    applicantEmail: string | null
    overallStatus: $Enums.CaseStatus | null
    stage: string | null
    urgencyLevel: string | null
    completionPercentage: number | null
    clientId: string | null
    caseManagerId: string | null
    lawyerId: string | null
  }

  export type CaseCountAggregateOutputType = {
    id: number
    createdAt: number
    updatedAt: number
    title: number
    caseNumber: number
    totalFee: number
    currency: number
    applicantName: number
    applicantEmail: number
    overallStatus: number
    stage: number
    urgencyLevel: number
    completionPercentage: number
    clientId: number
    caseManagerId: number
    lawyerId: number
    _all: number
  }


  export type CaseAvgAggregateInputType = {
    totalFee?: true
    completionPercentage?: true
  }

  export type CaseSumAggregateInputType = {
    totalFee?: true
    completionPercentage?: true
  }

  export type CaseMinAggregateInputType = {
    id?: true
    createdAt?: true
    updatedAt?: true
    title?: true
    caseNumber?: true
    totalFee?: true
    currency?: true
    applicantName?: true
    applicantEmail?: true
    overallStatus?: true
    stage?: true
    urgencyLevel?: true
    completionPercentage?: true
    clientId?: true
    caseManagerId?: true
    lawyerId?: true
  }

  export type CaseMaxAggregateInputType = {
    id?: true
    createdAt?: true
    updatedAt?: true
    title?: true
    caseNumber?: true
    totalFee?: true
    currency?: true
    applicantName?: true
    applicantEmail?: true
    overallStatus?: true
    stage?: true
    urgencyLevel?: true
    completionPercentage?: true
    clientId?: true
    caseManagerId?: true
    lawyerId?: true
  }

  export type CaseCountAggregateInputType = {
    id?: true
    createdAt?: true
    updatedAt?: true
    title?: true
    caseNumber?: true
    totalFee?: true
    currency?: true
    applicantName?: true
    applicantEmail?: true
    overallStatus?: true
    stage?: true
    urgencyLevel?: true
    completionPercentage?: true
    clientId?: true
    caseManagerId?: true
    lawyerId?: true
    _all?: true
  }

  export type CaseAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Case to aggregate.
     */
    where?: CaseWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Cases to fetch.
     */
    orderBy?: CaseOrderByWithRelationInput | CaseOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: CaseWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Cases from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Cases.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Cases
    **/
    _count?: true | CaseCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: CaseAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: CaseSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: CaseMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: CaseMaxAggregateInputType
  }

  export type GetCaseAggregateType<T extends CaseAggregateArgs> = {
        [P in keyof T & keyof AggregateCase]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateCase[P]>
      : GetScalarType<T[P], AggregateCase[P]>
  }




  export type CaseGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: CaseWhereInput
    orderBy?: CaseOrderByWithAggregationInput | CaseOrderByWithAggregationInput[]
    by: CaseScalarFieldEnum[] | CaseScalarFieldEnum
    having?: CaseScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: CaseCountAggregateInputType | true
    _avg?: CaseAvgAggregateInputType
    _sum?: CaseSumAggregateInputType
    _min?: CaseMinAggregateInputType
    _max?: CaseMaxAggregateInputType
  }

  export type CaseGroupByOutputType = {
    id: string
    createdAt: Date
    updatedAt: Date
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    clientId: string | null
    caseManagerId: string | null
    lawyerId: string | null
    _count: CaseCountAggregateOutputType | null
    _avg: CaseAvgAggregateOutputType | null
    _sum: CaseSumAggregateOutputType | null
    _min: CaseMinAggregateOutputType | null
    _max: CaseMaxAggregateOutputType | null
  }

  type GetCaseGroupByPayload<T extends CaseGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<CaseGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof CaseGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], CaseGroupByOutputType[P]>
            : GetScalarType<T[P], CaseGroupByOutputType[P]>
        }
      >
    >


  export type CaseSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    title?: boolean
    caseNumber?: boolean
    totalFee?: boolean
    currency?: boolean
    applicantName?: boolean
    applicantEmail?: boolean
    overallStatus?: boolean
    stage?: boolean
    urgencyLevel?: boolean
    completionPercentage?: boolean
    clientId?: boolean
    caseManagerId?: boolean
    lawyerId?: boolean
    client?: boolean | Case$clientArgs<ExtArgs>
    caseManager?: boolean | Case$caseManagerArgs<ExtArgs>
    lawyer?: boolean | Case$lawyerArgs<ExtArgs>
    documents?: boolean | Case$documentsArgs<ExtArgs>
    payments?: boolean | Case$paymentsArgs<ExtArgs>
    timelineEvents?: boolean | Case$timelineEventsArgs<ExtArgs>
    internalMessages?: boolean | Case$internalMessagesArgs<ExtArgs>
    externalPartners?: boolean | Case$externalPartnersArgs<ExtArgs>
    externalComms?: boolean | Case$externalCommsArgs<ExtArgs>
    _count?: boolean | CaseCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["case"]>

  export type CaseSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    title?: boolean
    caseNumber?: boolean
    totalFee?: boolean
    currency?: boolean
    applicantName?: boolean
    applicantEmail?: boolean
    overallStatus?: boolean
    stage?: boolean
    urgencyLevel?: boolean
    completionPercentage?: boolean
    clientId?: boolean
    caseManagerId?: boolean
    lawyerId?: boolean
    client?: boolean | Case$clientArgs<ExtArgs>
    caseManager?: boolean | Case$caseManagerArgs<ExtArgs>
    lawyer?: boolean | Case$lawyerArgs<ExtArgs>
  }, ExtArgs["result"]["case"]>

  export type CaseSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    title?: boolean
    caseNumber?: boolean
    totalFee?: boolean
    currency?: boolean
    applicantName?: boolean
    applicantEmail?: boolean
    overallStatus?: boolean
    stage?: boolean
    urgencyLevel?: boolean
    completionPercentage?: boolean
    clientId?: boolean
    caseManagerId?: boolean
    lawyerId?: boolean
    client?: boolean | Case$clientArgs<ExtArgs>
    caseManager?: boolean | Case$caseManagerArgs<ExtArgs>
    lawyer?: boolean | Case$lawyerArgs<ExtArgs>
  }, ExtArgs["result"]["case"]>

  export type CaseSelectScalar = {
    id?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    title?: boolean
    caseNumber?: boolean
    totalFee?: boolean
    currency?: boolean
    applicantName?: boolean
    applicantEmail?: boolean
    overallStatus?: boolean
    stage?: boolean
    urgencyLevel?: boolean
    completionPercentage?: boolean
    clientId?: boolean
    caseManagerId?: boolean
    lawyerId?: boolean
  }

  export type CaseOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "createdAt" | "updatedAt" | "title" | "caseNumber" | "totalFee" | "currency" | "applicantName" | "applicantEmail" | "overallStatus" | "stage" | "urgencyLevel" | "completionPercentage" | "clientId" | "caseManagerId" | "lawyerId", ExtArgs["result"]["case"]>
  export type CaseInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    client?: boolean | Case$clientArgs<ExtArgs>
    caseManager?: boolean | Case$caseManagerArgs<ExtArgs>
    lawyer?: boolean | Case$lawyerArgs<ExtArgs>
    documents?: boolean | Case$documentsArgs<ExtArgs>
    payments?: boolean | Case$paymentsArgs<ExtArgs>
    timelineEvents?: boolean | Case$timelineEventsArgs<ExtArgs>
    internalMessages?: boolean | Case$internalMessagesArgs<ExtArgs>
    externalPartners?: boolean | Case$externalPartnersArgs<ExtArgs>
    externalComms?: boolean | Case$externalCommsArgs<ExtArgs>
    _count?: boolean | CaseCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type CaseIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    client?: boolean | Case$clientArgs<ExtArgs>
    caseManager?: boolean | Case$caseManagerArgs<ExtArgs>
    lawyer?: boolean | Case$lawyerArgs<ExtArgs>
  }
  export type CaseIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    client?: boolean | Case$clientArgs<ExtArgs>
    caseManager?: boolean | Case$caseManagerArgs<ExtArgs>
    lawyer?: boolean | Case$lawyerArgs<ExtArgs>
  }

  export type $CasePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Case"
    objects: {
      client: Prisma.$UserPayload<ExtArgs> | null
      caseManager: Prisma.$UserPayload<ExtArgs> | null
      lawyer: Prisma.$UserPayload<ExtArgs> | null
      documents: Prisma.$DocumentPayload<ExtArgs>[]
      payments: Prisma.$PaymentPayload<ExtArgs>[]
      timelineEvents: Prisma.$TimelineEventPayload<ExtArgs>[]
      internalMessages: Prisma.$MessagePayload<ExtArgs>[]
      externalPartners: Prisma.$ExternalPartnerPayload<ExtArgs>[]
      externalComms: Prisma.$ExternalCommunicationPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      createdAt: Date
      updatedAt: Date
      title: string
      caseNumber: string
      totalFee: number
      currency: string
      applicantName: string
      applicantEmail: string
      overallStatus: $Enums.CaseStatus
      stage: string
      urgencyLevel: string
      completionPercentage: number
      clientId: string | null
      caseManagerId: string | null
      lawyerId: string | null
    }, ExtArgs["result"]["case"]>
    composites: {}
  }

  type CaseGetPayload<S extends boolean | null | undefined | CaseDefaultArgs> = $Result.GetResult<Prisma.$CasePayload, S>

  type CaseCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<CaseFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: CaseCountAggregateInputType | true
    }

  export interface CaseDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Case'], meta: { name: 'Case' } }
    /**
     * Find zero or one Case that matches the filter.
     * @param {CaseFindUniqueArgs} args - Arguments to find a Case
     * @example
     * // Get one Case
     * const case = await prisma.case.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends CaseFindUniqueArgs>(args: SelectSubset<T, CaseFindUniqueArgs<ExtArgs>>): Prisma__CaseClient<$Result.GetResult<Prisma.$CasePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Case that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {CaseFindUniqueOrThrowArgs} args - Arguments to find a Case
     * @example
     * // Get one Case
     * const case = await prisma.case.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends CaseFindUniqueOrThrowArgs>(args: SelectSubset<T, CaseFindUniqueOrThrowArgs<ExtArgs>>): Prisma__CaseClient<$Result.GetResult<Prisma.$CasePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Case that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CaseFindFirstArgs} args - Arguments to find a Case
     * @example
     * // Get one Case
     * const case = await prisma.case.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends CaseFindFirstArgs>(args?: SelectSubset<T, CaseFindFirstArgs<ExtArgs>>): Prisma__CaseClient<$Result.GetResult<Prisma.$CasePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Case that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CaseFindFirstOrThrowArgs} args - Arguments to find a Case
     * @example
     * // Get one Case
     * const case = await prisma.case.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends CaseFindFirstOrThrowArgs>(args?: SelectSubset<T, CaseFindFirstOrThrowArgs<ExtArgs>>): Prisma__CaseClient<$Result.GetResult<Prisma.$CasePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Cases that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CaseFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Cases
     * const cases = await prisma.case.findMany()
     * 
     * // Get first 10 Cases
     * const cases = await prisma.case.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const caseWithIdOnly = await prisma.case.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends CaseFindManyArgs>(args?: SelectSubset<T, CaseFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CasePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Case.
     * @param {CaseCreateArgs} args - Arguments to create a Case.
     * @example
     * // Create one Case
     * const Case = await prisma.case.create({
     *   data: {
     *     // ... data to create a Case
     *   }
     * })
     * 
     */
    create<T extends CaseCreateArgs>(args: SelectSubset<T, CaseCreateArgs<ExtArgs>>): Prisma__CaseClient<$Result.GetResult<Prisma.$CasePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Cases.
     * @param {CaseCreateManyArgs} args - Arguments to create many Cases.
     * @example
     * // Create many Cases
     * const case = await prisma.case.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends CaseCreateManyArgs>(args?: SelectSubset<T, CaseCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Cases and returns the data saved in the database.
     * @param {CaseCreateManyAndReturnArgs} args - Arguments to create many Cases.
     * @example
     * // Create many Cases
     * const case = await prisma.case.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Cases and only return the `id`
     * const caseWithIdOnly = await prisma.case.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends CaseCreateManyAndReturnArgs>(args?: SelectSubset<T, CaseCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CasePayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Case.
     * @param {CaseDeleteArgs} args - Arguments to delete one Case.
     * @example
     * // Delete one Case
     * const Case = await prisma.case.delete({
     *   where: {
     *     // ... filter to delete one Case
     *   }
     * })
     * 
     */
    delete<T extends CaseDeleteArgs>(args: SelectSubset<T, CaseDeleteArgs<ExtArgs>>): Prisma__CaseClient<$Result.GetResult<Prisma.$CasePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Case.
     * @param {CaseUpdateArgs} args - Arguments to update one Case.
     * @example
     * // Update one Case
     * const case = await prisma.case.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends CaseUpdateArgs>(args: SelectSubset<T, CaseUpdateArgs<ExtArgs>>): Prisma__CaseClient<$Result.GetResult<Prisma.$CasePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Cases.
     * @param {CaseDeleteManyArgs} args - Arguments to filter Cases to delete.
     * @example
     * // Delete a few Cases
     * const { count } = await prisma.case.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends CaseDeleteManyArgs>(args?: SelectSubset<T, CaseDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Cases.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CaseUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Cases
     * const case = await prisma.case.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends CaseUpdateManyArgs>(args: SelectSubset<T, CaseUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Cases and returns the data updated in the database.
     * @param {CaseUpdateManyAndReturnArgs} args - Arguments to update many Cases.
     * @example
     * // Update many Cases
     * const case = await prisma.case.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Cases and only return the `id`
     * const caseWithIdOnly = await prisma.case.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends CaseUpdateManyAndReturnArgs>(args: SelectSubset<T, CaseUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CasePayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Case.
     * @param {CaseUpsertArgs} args - Arguments to update or create a Case.
     * @example
     * // Update or create a Case
     * const case = await prisma.case.upsert({
     *   create: {
     *     // ... data to create a Case
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Case we want to update
     *   }
     * })
     */
    upsert<T extends CaseUpsertArgs>(args: SelectSubset<T, CaseUpsertArgs<ExtArgs>>): Prisma__CaseClient<$Result.GetResult<Prisma.$CasePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Cases.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CaseCountArgs} args - Arguments to filter Cases to count.
     * @example
     * // Count the number of Cases
     * const count = await prisma.case.count({
     *   where: {
     *     // ... the filter for the Cases we want to count
     *   }
     * })
    **/
    count<T extends CaseCountArgs>(
      args?: Subset<T, CaseCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], CaseCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Case.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CaseAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends CaseAggregateArgs>(args: Subset<T, CaseAggregateArgs>): Prisma.PrismaPromise<GetCaseAggregateType<T>>

    /**
     * Group by Case.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CaseGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends CaseGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: CaseGroupByArgs['orderBy'] }
        : { orderBy?: CaseGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, CaseGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetCaseGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Case model
   */
  readonly fields: CaseFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Case.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__CaseClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    client<T extends Case$clientArgs<ExtArgs> = {}>(args?: Subset<T, Case$clientArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    caseManager<T extends Case$caseManagerArgs<ExtArgs> = {}>(args?: Subset<T, Case$caseManagerArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    lawyer<T extends Case$lawyerArgs<ExtArgs> = {}>(args?: Subset<T, Case$lawyerArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    documents<T extends Case$documentsArgs<ExtArgs> = {}>(args?: Subset<T, Case$documentsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$DocumentPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    payments<T extends Case$paymentsArgs<ExtArgs> = {}>(args?: Subset<T, Case$paymentsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PaymentPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    timelineEvents<T extends Case$timelineEventsArgs<ExtArgs> = {}>(args?: Subset<T, Case$timelineEventsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TimelineEventPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    internalMessages<T extends Case$internalMessagesArgs<ExtArgs> = {}>(args?: Subset<T, Case$internalMessagesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    externalPartners<T extends Case$externalPartnersArgs<ExtArgs> = {}>(args?: Subset<T, Case$externalPartnersArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ExternalPartnerPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    externalComms<T extends Case$externalCommsArgs<ExtArgs> = {}>(args?: Subset<T, Case$externalCommsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ExternalCommunicationPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Case model
   */
  interface CaseFieldRefs {
    readonly id: FieldRef<"Case", 'String'>
    readonly createdAt: FieldRef<"Case", 'DateTime'>
    readonly updatedAt: FieldRef<"Case", 'DateTime'>
    readonly title: FieldRef<"Case", 'String'>
    readonly caseNumber: FieldRef<"Case", 'String'>
    readonly totalFee: FieldRef<"Case", 'Int'>
    readonly currency: FieldRef<"Case", 'String'>
    readonly applicantName: FieldRef<"Case", 'String'>
    readonly applicantEmail: FieldRef<"Case", 'String'>
    readonly overallStatus: FieldRef<"Case", 'CaseStatus'>
    readonly stage: FieldRef<"Case", 'String'>
    readonly urgencyLevel: FieldRef<"Case", 'String'>
    readonly completionPercentage: FieldRef<"Case", 'Int'>
    readonly clientId: FieldRef<"Case", 'String'>
    readonly caseManagerId: FieldRef<"Case", 'String'>
    readonly lawyerId: FieldRef<"Case", 'String'>
  }
    

  // Custom InputTypes
  /**
   * Case findUnique
   */
  export type CaseFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Case
     */
    select?: CaseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Case
     */
    omit?: CaseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CaseInclude<ExtArgs> | null
    /**
     * Filter, which Case to fetch.
     */
    where: CaseWhereUniqueInput
  }

  /**
   * Case findUniqueOrThrow
   */
  export type CaseFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Case
     */
    select?: CaseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Case
     */
    omit?: CaseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CaseInclude<ExtArgs> | null
    /**
     * Filter, which Case to fetch.
     */
    where: CaseWhereUniqueInput
  }

  /**
   * Case findFirst
   */
  export type CaseFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Case
     */
    select?: CaseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Case
     */
    omit?: CaseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CaseInclude<ExtArgs> | null
    /**
     * Filter, which Case to fetch.
     */
    where?: CaseWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Cases to fetch.
     */
    orderBy?: CaseOrderByWithRelationInput | CaseOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Cases.
     */
    cursor?: CaseWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Cases from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Cases.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Cases.
     */
    distinct?: CaseScalarFieldEnum | CaseScalarFieldEnum[]
  }

  /**
   * Case findFirstOrThrow
   */
  export type CaseFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Case
     */
    select?: CaseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Case
     */
    omit?: CaseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CaseInclude<ExtArgs> | null
    /**
     * Filter, which Case to fetch.
     */
    where?: CaseWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Cases to fetch.
     */
    orderBy?: CaseOrderByWithRelationInput | CaseOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Cases.
     */
    cursor?: CaseWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Cases from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Cases.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Cases.
     */
    distinct?: CaseScalarFieldEnum | CaseScalarFieldEnum[]
  }

  /**
   * Case findMany
   */
  export type CaseFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Case
     */
    select?: CaseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Case
     */
    omit?: CaseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CaseInclude<ExtArgs> | null
    /**
     * Filter, which Cases to fetch.
     */
    where?: CaseWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Cases to fetch.
     */
    orderBy?: CaseOrderByWithRelationInput | CaseOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Cases.
     */
    cursor?: CaseWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Cases from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Cases.
     */
    skip?: number
    distinct?: CaseScalarFieldEnum | CaseScalarFieldEnum[]
  }

  /**
   * Case create
   */
  export type CaseCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Case
     */
    select?: CaseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Case
     */
    omit?: CaseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CaseInclude<ExtArgs> | null
    /**
     * The data needed to create a Case.
     */
    data: XOR<CaseCreateInput, CaseUncheckedCreateInput>
  }

  /**
   * Case createMany
   */
  export type CaseCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Cases.
     */
    data: CaseCreateManyInput | CaseCreateManyInput[]
  }

  /**
   * Case createManyAndReturn
   */
  export type CaseCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Case
     */
    select?: CaseSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Case
     */
    omit?: CaseOmit<ExtArgs> | null
    /**
     * The data used to create many Cases.
     */
    data: CaseCreateManyInput | CaseCreateManyInput[]
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CaseIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Case update
   */
  export type CaseUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Case
     */
    select?: CaseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Case
     */
    omit?: CaseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CaseInclude<ExtArgs> | null
    /**
     * The data needed to update a Case.
     */
    data: XOR<CaseUpdateInput, CaseUncheckedUpdateInput>
    /**
     * Choose, which Case to update.
     */
    where: CaseWhereUniqueInput
  }

  /**
   * Case updateMany
   */
  export type CaseUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Cases.
     */
    data: XOR<CaseUpdateManyMutationInput, CaseUncheckedUpdateManyInput>
    /**
     * Filter which Cases to update
     */
    where?: CaseWhereInput
    /**
     * Limit how many Cases to update.
     */
    limit?: number
  }

  /**
   * Case updateManyAndReturn
   */
  export type CaseUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Case
     */
    select?: CaseSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Case
     */
    omit?: CaseOmit<ExtArgs> | null
    /**
     * The data used to update Cases.
     */
    data: XOR<CaseUpdateManyMutationInput, CaseUncheckedUpdateManyInput>
    /**
     * Filter which Cases to update
     */
    where?: CaseWhereInput
    /**
     * Limit how many Cases to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CaseIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Case upsert
   */
  export type CaseUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Case
     */
    select?: CaseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Case
     */
    omit?: CaseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CaseInclude<ExtArgs> | null
    /**
     * The filter to search for the Case to update in case it exists.
     */
    where: CaseWhereUniqueInput
    /**
     * In case the Case found by the `where` argument doesn't exist, create a new Case with this data.
     */
    create: XOR<CaseCreateInput, CaseUncheckedCreateInput>
    /**
     * In case the Case was found with the provided `where` argument, update it with this data.
     */
    update: XOR<CaseUpdateInput, CaseUncheckedUpdateInput>
  }

  /**
   * Case delete
   */
  export type CaseDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Case
     */
    select?: CaseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Case
     */
    omit?: CaseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CaseInclude<ExtArgs> | null
    /**
     * Filter which Case to delete.
     */
    where: CaseWhereUniqueInput
  }

  /**
   * Case deleteMany
   */
  export type CaseDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Cases to delete
     */
    where?: CaseWhereInput
    /**
     * Limit how many Cases to delete.
     */
    limit?: number
  }

  /**
   * Case.client
   */
  export type Case$clientArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    where?: UserWhereInput
  }

  /**
   * Case.caseManager
   */
  export type Case$caseManagerArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    where?: UserWhereInput
  }

  /**
   * Case.lawyer
   */
  export type Case$lawyerArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    where?: UserWhereInput
  }

  /**
   * Case.documents
   */
  export type Case$documentsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Document
     */
    select?: DocumentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Document
     */
    omit?: DocumentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DocumentInclude<ExtArgs> | null
    where?: DocumentWhereInput
    orderBy?: DocumentOrderByWithRelationInput | DocumentOrderByWithRelationInput[]
    cursor?: DocumentWhereUniqueInput
    take?: number
    skip?: number
    distinct?: DocumentScalarFieldEnum | DocumentScalarFieldEnum[]
  }

  /**
   * Case.payments
   */
  export type Case$paymentsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Payment
     */
    select?: PaymentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Payment
     */
    omit?: PaymentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentInclude<ExtArgs> | null
    where?: PaymentWhereInput
    orderBy?: PaymentOrderByWithRelationInput | PaymentOrderByWithRelationInput[]
    cursor?: PaymentWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PaymentScalarFieldEnum | PaymentScalarFieldEnum[]
  }

  /**
   * Case.timelineEvents
   */
  export type Case$timelineEventsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineEvent
     */
    select?: TimelineEventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineEvent
     */
    omit?: TimelineEventOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineEventInclude<ExtArgs> | null
    where?: TimelineEventWhereInput
    orderBy?: TimelineEventOrderByWithRelationInput | TimelineEventOrderByWithRelationInput[]
    cursor?: TimelineEventWhereUniqueInput
    take?: number
    skip?: number
    distinct?: TimelineEventScalarFieldEnum | TimelineEventScalarFieldEnum[]
  }

  /**
   * Case.internalMessages
   */
  export type Case$internalMessagesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInclude<ExtArgs> | null
    where?: MessageWhereInput
    orderBy?: MessageOrderByWithRelationInput | MessageOrderByWithRelationInput[]
    cursor?: MessageWhereUniqueInput
    take?: number
    skip?: number
    distinct?: MessageScalarFieldEnum | MessageScalarFieldEnum[]
  }

  /**
   * Case.externalPartners
   */
  export type Case$externalPartnersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalPartner
     */
    select?: ExternalPartnerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalPartner
     */
    omit?: ExternalPartnerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalPartnerInclude<ExtArgs> | null
    where?: ExternalPartnerWhereInput
    orderBy?: ExternalPartnerOrderByWithRelationInput | ExternalPartnerOrderByWithRelationInput[]
    cursor?: ExternalPartnerWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ExternalPartnerScalarFieldEnum | ExternalPartnerScalarFieldEnum[]
  }

  /**
   * Case.externalComms
   */
  export type Case$externalCommsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalCommunication
     */
    select?: ExternalCommunicationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalCommunication
     */
    omit?: ExternalCommunicationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalCommunicationInclude<ExtArgs> | null
    where?: ExternalCommunicationWhereInput
    orderBy?: ExternalCommunicationOrderByWithRelationInput | ExternalCommunicationOrderByWithRelationInput[]
    cursor?: ExternalCommunicationWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ExternalCommunicationScalarFieldEnum | ExternalCommunicationScalarFieldEnum[]
  }

  /**
   * Case without action
   */
  export type CaseDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Case
     */
    select?: CaseSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Case
     */
    omit?: CaseOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CaseInclude<ExtArgs> | null
  }


  /**
   * Model PartnerRole
   */

  export type AggregatePartnerRole = {
    _count: PartnerRoleCountAggregateOutputType | null
    _min: PartnerRoleMinAggregateOutputType | null
    _max: PartnerRoleMaxAggregateOutputType | null
  }

  export type PartnerRoleMinAggregateOutputType = {
    id: string | null
    name: string | null
  }

  export type PartnerRoleMaxAggregateOutputType = {
    id: string | null
    name: string | null
  }

  export type PartnerRoleCountAggregateOutputType = {
    id: number
    name: number
    _all: number
  }


  export type PartnerRoleMinAggregateInputType = {
    id?: true
    name?: true
  }

  export type PartnerRoleMaxAggregateInputType = {
    id?: true
    name?: true
  }

  export type PartnerRoleCountAggregateInputType = {
    id?: true
    name?: true
    _all?: true
  }

  export type PartnerRoleAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PartnerRole to aggregate.
     */
    where?: PartnerRoleWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PartnerRoles to fetch.
     */
    orderBy?: PartnerRoleOrderByWithRelationInput | PartnerRoleOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: PartnerRoleWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PartnerRoles from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PartnerRoles.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned PartnerRoles
    **/
    _count?: true | PartnerRoleCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: PartnerRoleMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: PartnerRoleMaxAggregateInputType
  }

  export type GetPartnerRoleAggregateType<T extends PartnerRoleAggregateArgs> = {
        [P in keyof T & keyof AggregatePartnerRole]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePartnerRole[P]>
      : GetScalarType<T[P], AggregatePartnerRole[P]>
  }




  export type PartnerRoleGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PartnerRoleWhereInput
    orderBy?: PartnerRoleOrderByWithAggregationInput | PartnerRoleOrderByWithAggregationInput[]
    by: PartnerRoleScalarFieldEnum[] | PartnerRoleScalarFieldEnum
    having?: PartnerRoleScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: PartnerRoleCountAggregateInputType | true
    _min?: PartnerRoleMinAggregateInputType
    _max?: PartnerRoleMaxAggregateInputType
  }

  export type PartnerRoleGroupByOutputType = {
    id: string
    name: string
    _count: PartnerRoleCountAggregateOutputType | null
    _min: PartnerRoleMinAggregateOutputType | null
    _max: PartnerRoleMaxAggregateOutputType | null
  }

  type GetPartnerRoleGroupByPayload<T extends PartnerRoleGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<PartnerRoleGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof PartnerRoleGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], PartnerRoleGroupByOutputType[P]>
            : GetScalarType<T[P], PartnerRoleGroupByOutputType[P]>
        }
      >
    >


  export type PartnerRoleSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    partners?: boolean | PartnerRole$partnersArgs<ExtArgs>
    _count?: boolean | PartnerRoleCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["partnerRole"]>

  export type PartnerRoleSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
  }, ExtArgs["result"]["partnerRole"]>

  export type PartnerRoleSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
  }, ExtArgs["result"]["partnerRole"]>

  export type PartnerRoleSelectScalar = {
    id?: boolean
    name?: boolean
  }

  export type PartnerRoleOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name", ExtArgs["result"]["partnerRole"]>
  export type PartnerRoleInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    partners?: boolean | PartnerRole$partnersArgs<ExtArgs>
    _count?: boolean | PartnerRoleCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type PartnerRoleIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type PartnerRoleIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $PartnerRolePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "PartnerRole"
    objects: {
      partners: Prisma.$ExternalPartnerPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
    }, ExtArgs["result"]["partnerRole"]>
    composites: {}
  }

  type PartnerRoleGetPayload<S extends boolean | null | undefined | PartnerRoleDefaultArgs> = $Result.GetResult<Prisma.$PartnerRolePayload, S>

  type PartnerRoleCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<PartnerRoleFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: PartnerRoleCountAggregateInputType | true
    }

  export interface PartnerRoleDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['PartnerRole'], meta: { name: 'PartnerRole' } }
    /**
     * Find zero or one PartnerRole that matches the filter.
     * @param {PartnerRoleFindUniqueArgs} args - Arguments to find a PartnerRole
     * @example
     * // Get one PartnerRole
     * const partnerRole = await prisma.partnerRole.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends PartnerRoleFindUniqueArgs>(args: SelectSubset<T, PartnerRoleFindUniqueArgs<ExtArgs>>): Prisma__PartnerRoleClient<$Result.GetResult<Prisma.$PartnerRolePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one PartnerRole that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {PartnerRoleFindUniqueOrThrowArgs} args - Arguments to find a PartnerRole
     * @example
     * // Get one PartnerRole
     * const partnerRole = await prisma.partnerRole.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends PartnerRoleFindUniqueOrThrowArgs>(args: SelectSubset<T, PartnerRoleFindUniqueOrThrowArgs<ExtArgs>>): Prisma__PartnerRoleClient<$Result.GetResult<Prisma.$PartnerRolePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PartnerRole that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PartnerRoleFindFirstArgs} args - Arguments to find a PartnerRole
     * @example
     * // Get one PartnerRole
     * const partnerRole = await prisma.partnerRole.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends PartnerRoleFindFirstArgs>(args?: SelectSubset<T, PartnerRoleFindFirstArgs<ExtArgs>>): Prisma__PartnerRoleClient<$Result.GetResult<Prisma.$PartnerRolePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PartnerRole that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PartnerRoleFindFirstOrThrowArgs} args - Arguments to find a PartnerRole
     * @example
     * // Get one PartnerRole
     * const partnerRole = await prisma.partnerRole.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends PartnerRoleFindFirstOrThrowArgs>(args?: SelectSubset<T, PartnerRoleFindFirstOrThrowArgs<ExtArgs>>): Prisma__PartnerRoleClient<$Result.GetResult<Prisma.$PartnerRolePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more PartnerRoles that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PartnerRoleFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all PartnerRoles
     * const partnerRoles = await prisma.partnerRole.findMany()
     * 
     * // Get first 10 PartnerRoles
     * const partnerRoles = await prisma.partnerRole.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const partnerRoleWithIdOnly = await prisma.partnerRole.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends PartnerRoleFindManyArgs>(args?: SelectSubset<T, PartnerRoleFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PartnerRolePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a PartnerRole.
     * @param {PartnerRoleCreateArgs} args - Arguments to create a PartnerRole.
     * @example
     * // Create one PartnerRole
     * const PartnerRole = await prisma.partnerRole.create({
     *   data: {
     *     // ... data to create a PartnerRole
     *   }
     * })
     * 
     */
    create<T extends PartnerRoleCreateArgs>(args: SelectSubset<T, PartnerRoleCreateArgs<ExtArgs>>): Prisma__PartnerRoleClient<$Result.GetResult<Prisma.$PartnerRolePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many PartnerRoles.
     * @param {PartnerRoleCreateManyArgs} args - Arguments to create many PartnerRoles.
     * @example
     * // Create many PartnerRoles
     * const partnerRole = await prisma.partnerRole.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends PartnerRoleCreateManyArgs>(args?: SelectSubset<T, PartnerRoleCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many PartnerRoles and returns the data saved in the database.
     * @param {PartnerRoleCreateManyAndReturnArgs} args - Arguments to create many PartnerRoles.
     * @example
     * // Create many PartnerRoles
     * const partnerRole = await prisma.partnerRole.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many PartnerRoles and only return the `id`
     * const partnerRoleWithIdOnly = await prisma.partnerRole.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends PartnerRoleCreateManyAndReturnArgs>(args?: SelectSubset<T, PartnerRoleCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PartnerRolePayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a PartnerRole.
     * @param {PartnerRoleDeleteArgs} args - Arguments to delete one PartnerRole.
     * @example
     * // Delete one PartnerRole
     * const PartnerRole = await prisma.partnerRole.delete({
     *   where: {
     *     // ... filter to delete one PartnerRole
     *   }
     * })
     * 
     */
    delete<T extends PartnerRoleDeleteArgs>(args: SelectSubset<T, PartnerRoleDeleteArgs<ExtArgs>>): Prisma__PartnerRoleClient<$Result.GetResult<Prisma.$PartnerRolePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one PartnerRole.
     * @param {PartnerRoleUpdateArgs} args - Arguments to update one PartnerRole.
     * @example
     * // Update one PartnerRole
     * const partnerRole = await prisma.partnerRole.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends PartnerRoleUpdateArgs>(args: SelectSubset<T, PartnerRoleUpdateArgs<ExtArgs>>): Prisma__PartnerRoleClient<$Result.GetResult<Prisma.$PartnerRolePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more PartnerRoles.
     * @param {PartnerRoleDeleteManyArgs} args - Arguments to filter PartnerRoles to delete.
     * @example
     * // Delete a few PartnerRoles
     * const { count } = await prisma.partnerRole.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends PartnerRoleDeleteManyArgs>(args?: SelectSubset<T, PartnerRoleDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PartnerRoles.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PartnerRoleUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many PartnerRoles
     * const partnerRole = await prisma.partnerRole.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends PartnerRoleUpdateManyArgs>(args: SelectSubset<T, PartnerRoleUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PartnerRoles and returns the data updated in the database.
     * @param {PartnerRoleUpdateManyAndReturnArgs} args - Arguments to update many PartnerRoles.
     * @example
     * // Update many PartnerRoles
     * const partnerRole = await prisma.partnerRole.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more PartnerRoles and only return the `id`
     * const partnerRoleWithIdOnly = await prisma.partnerRole.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends PartnerRoleUpdateManyAndReturnArgs>(args: SelectSubset<T, PartnerRoleUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PartnerRolePayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one PartnerRole.
     * @param {PartnerRoleUpsertArgs} args - Arguments to update or create a PartnerRole.
     * @example
     * // Update or create a PartnerRole
     * const partnerRole = await prisma.partnerRole.upsert({
     *   create: {
     *     // ... data to create a PartnerRole
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the PartnerRole we want to update
     *   }
     * })
     */
    upsert<T extends PartnerRoleUpsertArgs>(args: SelectSubset<T, PartnerRoleUpsertArgs<ExtArgs>>): Prisma__PartnerRoleClient<$Result.GetResult<Prisma.$PartnerRolePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of PartnerRoles.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PartnerRoleCountArgs} args - Arguments to filter PartnerRoles to count.
     * @example
     * // Count the number of PartnerRoles
     * const count = await prisma.partnerRole.count({
     *   where: {
     *     // ... the filter for the PartnerRoles we want to count
     *   }
     * })
    **/
    count<T extends PartnerRoleCountArgs>(
      args?: Subset<T, PartnerRoleCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], PartnerRoleCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a PartnerRole.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PartnerRoleAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PartnerRoleAggregateArgs>(args: Subset<T, PartnerRoleAggregateArgs>): Prisma.PrismaPromise<GetPartnerRoleAggregateType<T>>

    /**
     * Group by PartnerRole.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PartnerRoleGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends PartnerRoleGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: PartnerRoleGroupByArgs['orderBy'] }
        : { orderBy?: PartnerRoleGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, PartnerRoleGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPartnerRoleGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the PartnerRole model
   */
  readonly fields: PartnerRoleFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for PartnerRole.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__PartnerRoleClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    partners<T extends PartnerRole$partnersArgs<ExtArgs> = {}>(args?: Subset<T, PartnerRole$partnersArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ExternalPartnerPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the PartnerRole model
   */
  interface PartnerRoleFieldRefs {
    readonly id: FieldRef<"PartnerRole", 'String'>
    readonly name: FieldRef<"PartnerRole", 'String'>
  }
    

  // Custom InputTypes
  /**
   * PartnerRole findUnique
   */
  export type PartnerRoleFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PartnerRole
     */
    select?: PartnerRoleSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PartnerRole
     */
    omit?: PartnerRoleOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PartnerRoleInclude<ExtArgs> | null
    /**
     * Filter, which PartnerRole to fetch.
     */
    where: PartnerRoleWhereUniqueInput
  }

  /**
   * PartnerRole findUniqueOrThrow
   */
  export type PartnerRoleFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PartnerRole
     */
    select?: PartnerRoleSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PartnerRole
     */
    omit?: PartnerRoleOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PartnerRoleInclude<ExtArgs> | null
    /**
     * Filter, which PartnerRole to fetch.
     */
    where: PartnerRoleWhereUniqueInput
  }

  /**
   * PartnerRole findFirst
   */
  export type PartnerRoleFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PartnerRole
     */
    select?: PartnerRoleSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PartnerRole
     */
    omit?: PartnerRoleOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PartnerRoleInclude<ExtArgs> | null
    /**
     * Filter, which PartnerRole to fetch.
     */
    where?: PartnerRoleWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PartnerRoles to fetch.
     */
    orderBy?: PartnerRoleOrderByWithRelationInput | PartnerRoleOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PartnerRoles.
     */
    cursor?: PartnerRoleWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PartnerRoles from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PartnerRoles.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PartnerRoles.
     */
    distinct?: PartnerRoleScalarFieldEnum | PartnerRoleScalarFieldEnum[]
  }

  /**
   * PartnerRole findFirstOrThrow
   */
  export type PartnerRoleFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PartnerRole
     */
    select?: PartnerRoleSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PartnerRole
     */
    omit?: PartnerRoleOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PartnerRoleInclude<ExtArgs> | null
    /**
     * Filter, which PartnerRole to fetch.
     */
    where?: PartnerRoleWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PartnerRoles to fetch.
     */
    orderBy?: PartnerRoleOrderByWithRelationInput | PartnerRoleOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PartnerRoles.
     */
    cursor?: PartnerRoleWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PartnerRoles from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PartnerRoles.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PartnerRoles.
     */
    distinct?: PartnerRoleScalarFieldEnum | PartnerRoleScalarFieldEnum[]
  }

  /**
   * PartnerRole findMany
   */
  export type PartnerRoleFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PartnerRole
     */
    select?: PartnerRoleSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PartnerRole
     */
    omit?: PartnerRoleOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PartnerRoleInclude<ExtArgs> | null
    /**
     * Filter, which PartnerRoles to fetch.
     */
    where?: PartnerRoleWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PartnerRoles to fetch.
     */
    orderBy?: PartnerRoleOrderByWithRelationInput | PartnerRoleOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing PartnerRoles.
     */
    cursor?: PartnerRoleWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PartnerRoles from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PartnerRoles.
     */
    skip?: number
    distinct?: PartnerRoleScalarFieldEnum | PartnerRoleScalarFieldEnum[]
  }

  /**
   * PartnerRole create
   */
  export type PartnerRoleCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PartnerRole
     */
    select?: PartnerRoleSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PartnerRole
     */
    omit?: PartnerRoleOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PartnerRoleInclude<ExtArgs> | null
    /**
     * The data needed to create a PartnerRole.
     */
    data: XOR<PartnerRoleCreateInput, PartnerRoleUncheckedCreateInput>
  }

  /**
   * PartnerRole createMany
   */
  export type PartnerRoleCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many PartnerRoles.
     */
    data: PartnerRoleCreateManyInput | PartnerRoleCreateManyInput[]
  }

  /**
   * PartnerRole createManyAndReturn
   */
  export type PartnerRoleCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PartnerRole
     */
    select?: PartnerRoleSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the PartnerRole
     */
    omit?: PartnerRoleOmit<ExtArgs> | null
    /**
     * The data used to create many PartnerRoles.
     */
    data: PartnerRoleCreateManyInput | PartnerRoleCreateManyInput[]
  }

  /**
   * PartnerRole update
   */
  export type PartnerRoleUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PartnerRole
     */
    select?: PartnerRoleSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PartnerRole
     */
    omit?: PartnerRoleOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PartnerRoleInclude<ExtArgs> | null
    /**
     * The data needed to update a PartnerRole.
     */
    data: XOR<PartnerRoleUpdateInput, PartnerRoleUncheckedUpdateInput>
    /**
     * Choose, which PartnerRole to update.
     */
    where: PartnerRoleWhereUniqueInput
  }

  /**
   * PartnerRole updateMany
   */
  export type PartnerRoleUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update PartnerRoles.
     */
    data: XOR<PartnerRoleUpdateManyMutationInput, PartnerRoleUncheckedUpdateManyInput>
    /**
     * Filter which PartnerRoles to update
     */
    where?: PartnerRoleWhereInput
    /**
     * Limit how many PartnerRoles to update.
     */
    limit?: number
  }

  /**
   * PartnerRole updateManyAndReturn
   */
  export type PartnerRoleUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PartnerRole
     */
    select?: PartnerRoleSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the PartnerRole
     */
    omit?: PartnerRoleOmit<ExtArgs> | null
    /**
     * The data used to update PartnerRoles.
     */
    data: XOR<PartnerRoleUpdateManyMutationInput, PartnerRoleUncheckedUpdateManyInput>
    /**
     * Filter which PartnerRoles to update
     */
    where?: PartnerRoleWhereInput
    /**
     * Limit how many PartnerRoles to update.
     */
    limit?: number
  }

  /**
   * PartnerRole upsert
   */
  export type PartnerRoleUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PartnerRole
     */
    select?: PartnerRoleSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PartnerRole
     */
    omit?: PartnerRoleOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PartnerRoleInclude<ExtArgs> | null
    /**
     * The filter to search for the PartnerRole to update in case it exists.
     */
    where: PartnerRoleWhereUniqueInput
    /**
     * In case the PartnerRole found by the `where` argument doesn't exist, create a new PartnerRole with this data.
     */
    create: XOR<PartnerRoleCreateInput, PartnerRoleUncheckedCreateInput>
    /**
     * In case the PartnerRole was found with the provided `where` argument, update it with this data.
     */
    update: XOR<PartnerRoleUpdateInput, PartnerRoleUncheckedUpdateInput>
  }

  /**
   * PartnerRole delete
   */
  export type PartnerRoleDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PartnerRole
     */
    select?: PartnerRoleSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PartnerRole
     */
    omit?: PartnerRoleOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PartnerRoleInclude<ExtArgs> | null
    /**
     * Filter which PartnerRole to delete.
     */
    where: PartnerRoleWhereUniqueInput
  }

  /**
   * PartnerRole deleteMany
   */
  export type PartnerRoleDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PartnerRoles to delete
     */
    where?: PartnerRoleWhereInput
    /**
     * Limit how many PartnerRoles to delete.
     */
    limit?: number
  }

  /**
   * PartnerRole.partners
   */
  export type PartnerRole$partnersArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalPartner
     */
    select?: ExternalPartnerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalPartner
     */
    omit?: ExternalPartnerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalPartnerInclude<ExtArgs> | null
    where?: ExternalPartnerWhereInput
    orderBy?: ExternalPartnerOrderByWithRelationInput | ExternalPartnerOrderByWithRelationInput[]
    cursor?: ExternalPartnerWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ExternalPartnerScalarFieldEnum | ExternalPartnerScalarFieldEnum[]
  }

  /**
   * PartnerRole without action
   */
  export type PartnerRoleDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PartnerRole
     */
    select?: PartnerRoleSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PartnerRole
     */
    omit?: PartnerRoleOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PartnerRoleInclude<ExtArgs> | null
  }


  /**
   * Model ExternalPartner
   */

  export type AggregateExternalPartner = {
    _count: ExternalPartnerCountAggregateOutputType | null
    _min: ExternalPartnerMinAggregateOutputType | null
    _max: ExternalPartnerMaxAggregateOutputType | null
  }

  export type ExternalPartnerMinAggregateOutputType = {
    id: string | null
    name: string | null
    email: string | null
    type: string | null
    caseId: string | null
    roleId: string | null
  }

  export type ExternalPartnerMaxAggregateOutputType = {
    id: string | null
    name: string | null
    email: string | null
    type: string | null
    caseId: string | null
    roleId: string | null
  }

  export type ExternalPartnerCountAggregateOutputType = {
    id: number
    name: number
    email: number
    type: number
    caseId: number
    roleId: number
    _all: number
  }


  export type ExternalPartnerMinAggregateInputType = {
    id?: true
    name?: true
    email?: true
    type?: true
    caseId?: true
    roleId?: true
  }

  export type ExternalPartnerMaxAggregateInputType = {
    id?: true
    name?: true
    email?: true
    type?: true
    caseId?: true
    roleId?: true
  }

  export type ExternalPartnerCountAggregateInputType = {
    id?: true
    name?: true
    email?: true
    type?: true
    caseId?: true
    roleId?: true
    _all?: true
  }

  export type ExternalPartnerAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ExternalPartner to aggregate.
     */
    where?: ExternalPartnerWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ExternalPartners to fetch.
     */
    orderBy?: ExternalPartnerOrderByWithRelationInput | ExternalPartnerOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ExternalPartnerWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ExternalPartners from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ExternalPartners.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned ExternalPartners
    **/
    _count?: true | ExternalPartnerCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ExternalPartnerMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ExternalPartnerMaxAggregateInputType
  }

  export type GetExternalPartnerAggregateType<T extends ExternalPartnerAggregateArgs> = {
        [P in keyof T & keyof AggregateExternalPartner]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateExternalPartner[P]>
      : GetScalarType<T[P], AggregateExternalPartner[P]>
  }




  export type ExternalPartnerGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ExternalPartnerWhereInput
    orderBy?: ExternalPartnerOrderByWithAggregationInput | ExternalPartnerOrderByWithAggregationInput[]
    by: ExternalPartnerScalarFieldEnum[] | ExternalPartnerScalarFieldEnum
    having?: ExternalPartnerScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ExternalPartnerCountAggregateInputType | true
    _min?: ExternalPartnerMinAggregateInputType
    _max?: ExternalPartnerMaxAggregateInputType
  }

  export type ExternalPartnerGroupByOutputType = {
    id: string
    name: string
    email: string | null
    type: string
    caseId: string
    roleId: string
    _count: ExternalPartnerCountAggregateOutputType | null
    _min: ExternalPartnerMinAggregateOutputType | null
    _max: ExternalPartnerMaxAggregateOutputType | null
  }

  type GetExternalPartnerGroupByPayload<T extends ExternalPartnerGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ExternalPartnerGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ExternalPartnerGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ExternalPartnerGroupByOutputType[P]>
            : GetScalarType<T[P], ExternalPartnerGroupByOutputType[P]>
        }
      >
    >


  export type ExternalPartnerSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    email?: boolean
    type?: boolean
    caseId?: boolean
    roleId?: boolean
    case?: boolean | CaseDefaultArgs<ExtArgs>
    role?: boolean | PartnerRoleDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["externalPartner"]>

  export type ExternalPartnerSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    email?: boolean
    type?: boolean
    caseId?: boolean
    roleId?: boolean
    case?: boolean | CaseDefaultArgs<ExtArgs>
    role?: boolean | PartnerRoleDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["externalPartner"]>

  export type ExternalPartnerSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    email?: boolean
    type?: boolean
    caseId?: boolean
    roleId?: boolean
    case?: boolean | CaseDefaultArgs<ExtArgs>
    role?: boolean | PartnerRoleDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["externalPartner"]>

  export type ExternalPartnerSelectScalar = {
    id?: boolean
    name?: boolean
    email?: boolean
    type?: boolean
    caseId?: boolean
    roleId?: boolean
  }

  export type ExternalPartnerOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "email" | "type" | "caseId" | "roleId", ExtArgs["result"]["externalPartner"]>
  export type ExternalPartnerInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    case?: boolean | CaseDefaultArgs<ExtArgs>
    role?: boolean | PartnerRoleDefaultArgs<ExtArgs>
  }
  export type ExternalPartnerIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    case?: boolean | CaseDefaultArgs<ExtArgs>
    role?: boolean | PartnerRoleDefaultArgs<ExtArgs>
  }
  export type ExternalPartnerIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    case?: boolean | CaseDefaultArgs<ExtArgs>
    role?: boolean | PartnerRoleDefaultArgs<ExtArgs>
  }

  export type $ExternalPartnerPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "ExternalPartner"
    objects: {
      case: Prisma.$CasePayload<ExtArgs>
      role: Prisma.$PartnerRolePayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
      email: string | null
      type: string
      caseId: string
      roleId: string
    }, ExtArgs["result"]["externalPartner"]>
    composites: {}
  }

  type ExternalPartnerGetPayload<S extends boolean | null | undefined | ExternalPartnerDefaultArgs> = $Result.GetResult<Prisma.$ExternalPartnerPayload, S>

  type ExternalPartnerCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ExternalPartnerFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ExternalPartnerCountAggregateInputType | true
    }

  export interface ExternalPartnerDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['ExternalPartner'], meta: { name: 'ExternalPartner' } }
    /**
     * Find zero or one ExternalPartner that matches the filter.
     * @param {ExternalPartnerFindUniqueArgs} args - Arguments to find a ExternalPartner
     * @example
     * // Get one ExternalPartner
     * const externalPartner = await prisma.externalPartner.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ExternalPartnerFindUniqueArgs>(args: SelectSubset<T, ExternalPartnerFindUniqueArgs<ExtArgs>>): Prisma__ExternalPartnerClient<$Result.GetResult<Prisma.$ExternalPartnerPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one ExternalPartner that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ExternalPartnerFindUniqueOrThrowArgs} args - Arguments to find a ExternalPartner
     * @example
     * // Get one ExternalPartner
     * const externalPartner = await prisma.externalPartner.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ExternalPartnerFindUniqueOrThrowArgs>(args: SelectSubset<T, ExternalPartnerFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ExternalPartnerClient<$Result.GetResult<Prisma.$ExternalPartnerPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first ExternalPartner that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExternalPartnerFindFirstArgs} args - Arguments to find a ExternalPartner
     * @example
     * // Get one ExternalPartner
     * const externalPartner = await prisma.externalPartner.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ExternalPartnerFindFirstArgs>(args?: SelectSubset<T, ExternalPartnerFindFirstArgs<ExtArgs>>): Prisma__ExternalPartnerClient<$Result.GetResult<Prisma.$ExternalPartnerPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first ExternalPartner that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExternalPartnerFindFirstOrThrowArgs} args - Arguments to find a ExternalPartner
     * @example
     * // Get one ExternalPartner
     * const externalPartner = await prisma.externalPartner.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ExternalPartnerFindFirstOrThrowArgs>(args?: SelectSubset<T, ExternalPartnerFindFirstOrThrowArgs<ExtArgs>>): Prisma__ExternalPartnerClient<$Result.GetResult<Prisma.$ExternalPartnerPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more ExternalPartners that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExternalPartnerFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all ExternalPartners
     * const externalPartners = await prisma.externalPartner.findMany()
     * 
     * // Get first 10 ExternalPartners
     * const externalPartners = await prisma.externalPartner.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const externalPartnerWithIdOnly = await prisma.externalPartner.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends ExternalPartnerFindManyArgs>(args?: SelectSubset<T, ExternalPartnerFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ExternalPartnerPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a ExternalPartner.
     * @param {ExternalPartnerCreateArgs} args - Arguments to create a ExternalPartner.
     * @example
     * // Create one ExternalPartner
     * const ExternalPartner = await prisma.externalPartner.create({
     *   data: {
     *     // ... data to create a ExternalPartner
     *   }
     * })
     * 
     */
    create<T extends ExternalPartnerCreateArgs>(args: SelectSubset<T, ExternalPartnerCreateArgs<ExtArgs>>): Prisma__ExternalPartnerClient<$Result.GetResult<Prisma.$ExternalPartnerPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many ExternalPartners.
     * @param {ExternalPartnerCreateManyArgs} args - Arguments to create many ExternalPartners.
     * @example
     * // Create many ExternalPartners
     * const externalPartner = await prisma.externalPartner.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ExternalPartnerCreateManyArgs>(args?: SelectSubset<T, ExternalPartnerCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many ExternalPartners and returns the data saved in the database.
     * @param {ExternalPartnerCreateManyAndReturnArgs} args - Arguments to create many ExternalPartners.
     * @example
     * // Create many ExternalPartners
     * const externalPartner = await prisma.externalPartner.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many ExternalPartners and only return the `id`
     * const externalPartnerWithIdOnly = await prisma.externalPartner.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends ExternalPartnerCreateManyAndReturnArgs>(args?: SelectSubset<T, ExternalPartnerCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ExternalPartnerPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a ExternalPartner.
     * @param {ExternalPartnerDeleteArgs} args - Arguments to delete one ExternalPartner.
     * @example
     * // Delete one ExternalPartner
     * const ExternalPartner = await prisma.externalPartner.delete({
     *   where: {
     *     // ... filter to delete one ExternalPartner
     *   }
     * })
     * 
     */
    delete<T extends ExternalPartnerDeleteArgs>(args: SelectSubset<T, ExternalPartnerDeleteArgs<ExtArgs>>): Prisma__ExternalPartnerClient<$Result.GetResult<Prisma.$ExternalPartnerPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one ExternalPartner.
     * @param {ExternalPartnerUpdateArgs} args - Arguments to update one ExternalPartner.
     * @example
     * // Update one ExternalPartner
     * const externalPartner = await prisma.externalPartner.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ExternalPartnerUpdateArgs>(args: SelectSubset<T, ExternalPartnerUpdateArgs<ExtArgs>>): Prisma__ExternalPartnerClient<$Result.GetResult<Prisma.$ExternalPartnerPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more ExternalPartners.
     * @param {ExternalPartnerDeleteManyArgs} args - Arguments to filter ExternalPartners to delete.
     * @example
     * // Delete a few ExternalPartners
     * const { count } = await prisma.externalPartner.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ExternalPartnerDeleteManyArgs>(args?: SelectSubset<T, ExternalPartnerDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more ExternalPartners.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExternalPartnerUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many ExternalPartners
     * const externalPartner = await prisma.externalPartner.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ExternalPartnerUpdateManyArgs>(args: SelectSubset<T, ExternalPartnerUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more ExternalPartners and returns the data updated in the database.
     * @param {ExternalPartnerUpdateManyAndReturnArgs} args - Arguments to update many ExternalPartners.
     * @example
     * // Update many ExternalPartners
     * const externalPartner = await prisma.externalPartner.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more ExternalPartners and only return the `id`
     * const externalPartnerWithIdOnly = await prisma.externalPartner.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends ExternalPartnerUpdateManyAndReturnArgs>(args: SelectSubset<T, ExternalPartnerUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ExternalPartnerPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one ExternalPartner.
     * @param {ExternalPartnerUpsertArgs} args - Arguments to update or create a ExternalPartner.
     * @example
     * // Update or create a ExternalPartner
     * const externalPartner = await prisma.externalPartner.upsert({
     *   create: {
     *     // ... data to create a ExternalPartner
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the ExternalPartner we want to update
     *   }
     * })
     */
    upsert<T extends ExternalPartnerUpsertArgs>(args: SelectSubset<T, ExternalPartnerUpsertArgs<ExtArgs>>): Prisma__ExternalPartnerClient<$Result.GetResult<Prisma.$ExternalPartnerPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of ExternalPartners.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExternalPartnerCountArgs} args - Arguments to filter ExternalPartners to count.
     * @example
     * // Count the number of ExternalPartners
     * const count = await prisma.externalPartner.count({
     *   where: {
     *     // ... the filter for the ExternalPartners we want to count
     *   }
     * })
    **/
    count<T extends ExternalPartnerCountArgs>(
      args?: Subset<T, ExternalPartnerCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ExternalPartnerCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a ExternalPartner.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExternalPartnerAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ExternalPartnerAggregateArgs>(args: Subset<T, ExternalPartnerAggregateArgs>): Prisma.PrismaPromise<GetExternalPartnerAggregateType<T>>

    /**
     * Group by ExternalPartner.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExternalPartnerGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ExternalPartnerGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ExternalPartnerGroupByArgs['orderBy'] }
        : { orderBy?: ExternalPartnerGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ExternalPartnerGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetExternalPartnerGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the ExternalPartner model
   */
  readonly fields: ExternalPartnerFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for ExternalPartner.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ExternalPartnerClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    case<T extends CaseDefaultArgs<ExtArgs> = {}>(args?: Subset<T, CaseDefaultArgs<ExtArgs>>): Prisma__CaseClient<$Result.GetResult<Prisma.$CasePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    role<T extends PartnerRoleDefaultArgs<ExtArgs> = {}>(args?: Subset<T, PartnerRoleDefaultArgs<ExtArgs>>): Prisma__PartnerRoleClient<$Result.GetResult<Prisma.$PartnerRolePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the ExternalPartner model
   */
  interface ExternalPartnerFieldRefs {
    readonly id: FieldRef<"ExternalPartner", 'String'>
    readonly name: FieldRef<"ExternalPartner", 'String'>
    readonly email: FieldRef<"ExternalPartner", 'String'>
    readonly type: FieldRef<"ExternalPartner", 'String'>
    readonly caseId: FieldRef<"ExternalPartner", 'String'>
    readonly roleId: FieldRef<"ExternalPartner", 'String'>
  }
    

  // Custom InputTypes
  /**
   * ExternalPartner findUnique
   */
  export type ExternalPartnerFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalPartner
     */
    select?: ExternalPartnerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalPartner
     */
    omit?: ExternalPartnerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalPartnerInclude<ExtArgs> | null
    /**
     * Filter, which ExternalPartner to fetch.
     */
    where: ExternalPartnerWhereUniqueInput
  }

  /**
   * ExternalPartner findUniqueOrThrow
   */
  export type ExternalPartnerFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalPartner
     */
    select?: ExternalPartnerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalPartner
     */
    omit?: ExternalPartnerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalPartnerInclude<ExtArgs> | null
    /**
     * Filter, which ExternalPartner to fetch.
     */
    where: ExternalPartnerWhereUniqueInput
  }

  /**
   * ExternalPartner findFirst
   */
  export type ExternalPartnerFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalPartner
     */
    select?: ExternalPartnerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalPartner
     */
    omit?: ExternalPartnerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalPartnerInclude<ExtArgs> | null
    /**
     * Filter, which ExternalPartner to fetch.
     */
    where?: ExternalPartnerWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ExternalPartners to fetch.
     */
    orderBy?: ExternalPartnerOrderByWithRelationInput | ExternalPartnerOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ExternalPartners.
     */
    cursor?: ExternalPartnerWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ExternalPartners from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ExternalPartners.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ExternalPartners.
     */
    distinct?: ExternalPartnerScalarFieldEnum | ExternalPartnerScalarFieldEnum[]
  }

  /**
   * ExternalPartner findFirstOrThrow
   */
  export type ExternalPartnerFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalPartner
     */
    select?: ExternalPartnerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalPartner
     */
    omit?: ExternalPartnerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalPartnerInclude<ExtArgs> | null
    /**
     * Filter, which ExternalPartner to fetch.
     */
    where?: ExternalPartnerWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ExternalPartners to fetch.
     */
    orderBy?: ExternalPartnerOrderByWithRelationInput | ExternalPartnerOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ExternalPartners.
     */
    cursor?: ExternalPartnerWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ExternalPartners from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ExternalPartners.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ExternalPartners.
     */
    distinct?: ExternalPartnerScalarFieldEnum | ExternalPartnerScalarFieldEnum[]
  }

  /**
   * ExternalPartner findMany
   */
  export type ExternalPartnerFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalPartner
     */
    select?: ExternalPartnerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalPartner
     */
    omit?: ExternalPartnerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalPartnerInclude<ExtArgs> | null
    /**
     * Filter, which ExternalPartners to fetch.
     */
    where?: ExternalPartnerWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ExternalPartners to fetch.
     */
    orderBy?: ExternalPartnerOrderByWithRelationInput | ExternalPartnerOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing ExternalPartners.
     */
    cursor?: ExternalPartnerWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ExternalPartners from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ExternalPartners.
     */
    skip?: number
    distinct?: ExternalPartnerScalarFieldEnum | ExternalPartnerScalarFieldEnum[]
  }

  /**
   * ExternalPartner create
   */
  export type ExternalPartnerCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalPartner
     */
    select?: ExternalPartnerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalPartner
     */
    omit?: ExternalPartnerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalPartnerInclude<ExtArgs> | null
    /**
     * The data needed to create a ExternalPartner.
     */
    data: XOR<ExternalPartnerCreateInput, ExternalPartnerUncheckedCreateInput>
  }

  /**
   * ExternalPartner createMany
   */
  export type ExternalPartnerCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many ExternalPartners.
     */
    data: ExternalPartnerCreateManyInput | ExternalPartnerCreateManyInput[]
  }

  /**
   * ExternalPartner createManyAndReturn
   */
  export type ExternalPartnerCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalPartner
     */
    select?: ExternalPartnerSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalPartner
     */
    omit?: ExternalPartnerOmit<ExtArgs> | null
    /**
     * The data used to create many ExternalPartners.
     */
    data: ExternalPartnerCreateManyInput | ExternalPartnerCreateManyInput[]
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalPartnerIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * ExternalPartner update
   */
  export type ExternalPartnerUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalPartner
     */
    select?: ExternalPartnerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalPartner
     */
    omit?: ExternalPartnerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalPartnerInclude<ExtArgs> | null
    /**
     * The data needed to update a ExternalPartner.
     */
    data: XOR<ExternalPartnerUpdateInput, ExternalPartnerUncheckedUpdateInput>
    /**
     * Choose, which ExternalPartner to update.
     */
    where: ExternalPartnerWhereUniqueInput
  }

  /**
   * ExternalPartner updateMany
   */
  export type ExternalPartnerUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update ExternalPartners.
     */
    data: XOR<ExternalPartnerUpdateManyMutationInput, ExternalPartnerUncheckedUpdateManyInput>
    /**
     * Filter which ExternalPartners to update
     */
    where?: ExternalPartnerWhereInput
    /**
     * Limit how many ExternalPartners to update.
     */
    limit?: number
  }

  /**
   * ExternalPartner updateManyAndReturn
   */
  export type ExternalPartnerUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalPartner
     */
    select?: ExternalPartnerSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalPartner
     */
    omit?: ExternalPartnerOmit<ExtArgs> | null
    /**
     * The data used to update ExternalPartners.
     */
    data: XOR<ExternalPartnerUpdateManyMutationInput, ExternalPartnerUncheckedUpdateManyInput>
    /**
     * Filter which ExternalPartners to update
     */
    where?: ExternalPartnerWhereInput
    /**
     * Limit how many ExternalPartners to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalPartnerIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * ExternalPartner upsert
   */
  export type ExternalPartnerUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalPartner
     */
    select?: ExternalPartnerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalPartner
     */
    omit?: ExternalPartnerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalPartnerInclude<ExtArgs> | null
    /**
     * The filter to search for the ExternalPartner to update in case it exists.
     */
    where: ExternalPartnerWhereUniqueInput
    /**
     * In case the ExternalPartner found by the `where` argument doesn't exist, create a new ExternalPartner with this data.
     */
    create: XOR<ExternalPartnerCreateInput, ExternalPartnerUncheckedCreateInput>
    /**
     * In case the ExternalPartner was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ExternalPartnerUpdateInput, ExternalPartnerUncheckedUpdateInput>
  }

  /**
   * ExternalPartner delete
   */
  export type ExternalPartnerDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalPartner
     */
    select?: ExternalPartnerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalPartner
     */
    omit?: ExternalPartnerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalPartnerInclude<ExtArgs> | null
    /**
     * Filter which ExternalPartner to delete.
     */
    where: ExternalPartnerWhereUniqueInput
  }

  /**
   * ExternalPartner deleteMany
   */
  export type ExternalPartnerDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ExternalPartners to delete
     */
    where?: ExternalPartnerWhereInput
    /**
     * Limit how many ExternalPartners to delete.
     */
    limit?: number
  }

  /**
   * ExternalPartner without action
   */
  export type ExternalPartnerDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalPartner
     */
    select?: ExternalPartnerSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalPartner
     */
    omit?: ExternalPartnerOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalPartnerInclude<ExtArgs> | null
  }


  /**
   * Model ExternalCommunication
   */

  export type AggregateExternalCommunication = {
    _count: ExternalCommunicationCountAggregateOutputType | null
    _min: ExternalCommunicationMinAggregateOutputType | null
    _max: ExternalCommunicationMaxAggregateOutputType | null
  }

  export type ExternalCommunicationMinAggregateOutputType = {
    id: string | null
    createdAt: Date | null
    direction: $Enums.Direction | null
    body: string | null
    sender: string | null
    caseId: string | null
  }

  export type ExternalCommunicationMaxAggregateOutputType = {
    id: string | null
    createdAt: Date | null
    direction: $Enums.Direction | null
    body: string | null
    sender: string | null
    caseId: string | null
  }

  export type ExternalCommunicationCountAggregateOutputType = {
    id: number
    createdAt: number
    direction: number
    body: number
    sender: number
    caseId: number
    _all: number
  }


  export type ExternalCommunicationMinAggregateInputType = {
    id?: true
    createdAt?: true
    direction?: true
    body?: true
    sender?: true
    caseId?: true
  }

  export type ExternalCommunicationMaxAggregateInputType = {
    id?: true
    createdAt?: true
    direction?: true
    body?: true
    sender?: true
    caseId?: true
  }

  export type ExternalCommunicationCountAggregateInputType = {
    id?: true
    createdAt?: true
    direction?: true
    body?: true
    sender?: true
    caseId?: true
    _all?: true
  }

  export type ExternalCommunicationAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ExternalCommunication to aggregate.
     */
    where?: ExternalCommunicationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ExternalCommunications to fetch.
     */
    orderBy?: ExternalCommunicationOrderByWithRelationInput | ExternalCommunicationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ExternalCommunicationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ExternalCommunications from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ExternalCommunications.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned ExternalCommunications
    **/
    _count?: true | ExternalCommunicationCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ExternalCommunicationMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ExternalCommunicationMaxAggregateInputType
  }

  export type GetExternalCommunicationAggregateType<T extends ExternalCommunicationAggregateArgs> = {
        [P in keyof T & keyof AggregateExternalCommunication]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateExternalCommunication[P]>
      : GetScalarType<T[P], AggregateExternalCommunication[P]>
  }




  export type ExternalCommunicationGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ExternalCommunicationWhereInput
    orderBy?: ExternalCommunicationOrderByWithAggregationInput | ExternalCommunicationOrderByWithAggregationInput[]
    by: ExternalCommunicationScalarFieldEnum[] | ExternalCommunicationScalarFieldEnum
    having?: ExternalCommunicationScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ExternalCommunicationCountAggregateInputType | true
    _min?: ExternalCommunicationMinAggregateInputType
    _max?: ExternalCommunicationMaxAggregateInputType
  }

  export type ExternalCommunicationGroupByOutputType = {
    id: string
    createdAt: Date
    direction: $Enums.Direction
    body: string
    sender: string
    caseId: string
    _count: ExternalCommunicationCountAggregateOutputType | null
    _min: ExternalCommunicationMinAggregateOutputType | null
    _max: ExternalCommunicationMaxAggregateOutputType | null
  }

  type GetExternalCommunicationGroupByPayload<T extends ExternalCommunicationGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ExternalCommunicationGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ExternalCommunicationGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ExternalCommunicationGroupByOutputType[P]>
            : GetScalarType<T[P], ExternalCommunicationGroupByOutputType[P]>
        }
      >
    >


  export type ExternalCommunicationSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    createdAt?: boolean
    direction?: boolean
    body?: boolean
    sender?: boolean
    caseId?: boolean
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["externalCommunication"]>

  export type ExternalCommunicationSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    createdAt?: boolean
    direction?: boolean
    body?: boolean
    sender?: boolean
    caseId?: boolean
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["externalCommunication"]>

  export type ExternalCommunicationSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    createdAt?: boolean
    direction?: boolean
    body?: boolean
    sender?: boolean
    caseId?: boolean
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["externalCommunication"]>

  export type ExternalCommunicationSelectScalar = {
    id?: boolean
    createdAt?: boolean
    direction?: boolean
    body?: boolean
    sender?: boolean
    caseId?: boolean
  }

  export type ExternalCommunicationOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "createdAt" | "direction" | "body" | "sender" | "caseId", ExtArgs["result"]["externalCommunication"]>
  export type ExternalCommunicationInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }
  export type ExternalCommunicationIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }
  export type ExternalCommunicationIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }

  export type $ExternalCommunicationPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "ExternalCommunication"
    objects: {
      case: Prisma.$CasePayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      createdAt: Date
      direction: $Enums.Direction
      body: string
      sender: string
      caseId: string
    }, ExtArgs["result"]["externalCommunication"]>
    composites: {}
  }

  type ExternalCommunicationGetPayload<S extends boolean | null | undefined | ExternalCommunicationDefaultArgs> = $Result.GetResult<Prisma.$ExternalCommunicationPayload, S>

  type ExternalCommunicationCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ExternalCommunicationFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ExternalCommunicationCountAggregateInputType | true
    }

  export interface ExternalCommunicationDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['ExternalCommunication'], meta: { name: 'ExternalCommunication' } }
    /**
     * Find zero or one ExternalCommunication that matches the filter.
     * @param {ExternalCommunicationFindUniqueArgs} args - Arguments to find a ExternalCommunication
     * @example
     * // Get one ExternalCommunication
     * const externalCommunication = await prisma.externalCommunication.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ExternalCommunicationFindUniqueArgs>(args: SelectSubset<T, ExternalCommunicationFindUniqueArgs<ExtArgs>>): Prisma__ExternalCommunicationClient<$Result.GetResult<Prisma.$ExternalCommunicationPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one ExternalCommunication that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ExternalCommunicationFindUniqueOrThrowArgs} args - Arguments to find a ExternalCommunication
     * @example
     * // Get one ExternalCommunication
     * const externalCommunication = await prisma.externalCommunication.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ExternalCommunicationFindUniqueOrThrowArgs>(args: SelectSubset<T, ExternalCommunicationFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ExternalCommunicationClient<$Result.GetResult<Prisma.$ExternalCommunicationPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first ExternalCommunication that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExternalCommunicationFindFirstArgs} args - Arguments to find a ExternalCommunication
     * @example
     * // Get one ExternalCommunication
     * const externalCommunication = await prisma.externalCommunication.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ExternalCommunicationFindFirstArgs>(args?: SelectSubset<T, ExternalCommunicationFindFirstArgs<ExtArgs>>): Prisma__ExternalCommunicationClient<$Result.GetResult<Prisma.$ExternalCommunicationPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first ExternalCommunication that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExternalCommunicationFindFirstOrThrowArgs} args - Arguments to find a ExternalCommunication
     * @example
     * // Get one ExternalCommunication
     * const externalCommunication = await prisma.externalCommunication.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ExternalCommunicationFindFirstOrThrowArgs>(args?: SelectSubset<T, ExternalCommunicationFindFirstOrThrowArgs<ExtArgs>>): Prisma__ExternalCommunicationClient<$Result.GetResult<Prisma.$ExternalCommunicationPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more ExternalCommunications that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExternalCommunicationFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all ExternalCommunications
     * const externalCommunications = await prisma.externalCommunication.findMany()
     * 
     * // Get first 10 ExternalCommunications
     * const externalCommunications = await prisma.externalCommunication.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const externalCommunicationWithIdOnly = await prisma.externalCommunication.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends ExternalCommunicationFindManyArgs>(args?: SelectSubset<T, ExternalCommunicationFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ExternalCommunicationPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a ExternalCommunication.
     * @param {ExternalCommunicationCreateArgs} args - Arguments to create a ExternalCommunication.
     * @example
     * // Create one ExternalCommunication
     * const ExternalCommunication = await prisma.externalCommunication.create({
     *   data: {
     *     // ... data to create a ExternalCommunication
     *   }
     * })
     * 
     */
    create<T extends ExternalCommunicationCreateArgs>(args: SelectSubset<T, ExternalCommunicationCreateArgs<ExtArgs>>): Prisma__ExternalCommunicationClient<$Result.GetResult<Prisma.$ExternalCommunicationPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many ExternalCommunications.
     * @param {ExternalCommunicationCreateManyArgs} args - Arguments to create many ExternalCommunications.
     * @example
     * // Create many ExternalCommunications
     * const externalCommunication = await prisma.externalCommunication.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ExternalCommunicationCreateManyArgs>(args?: SelectSubset<T, ExternalCommunicationCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many ExternalCommunications and returns the data saved in the database.
     * @param {ExternalCommunicationCreateManyAndReturnArgs} args - Arguments to create many ExternalCommunications.
     * @example
     * // Create many ExternalCommunications
     * const externalCommunication = await prisma.externalCommunication.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many ExternalCommunications and only return the `id`
     * const externalCommunicationWithIdOnly = await prisma.externalCommunication.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends ExternalCommunicationCreateManyAndReturnArgs>(args?: SelectSubset<T, ExternalCommunicationCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ExternalCommunicationPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a ExternalCommunication.
     * @param {ExternalCommunicationDeleteArgs} args - Arguments to delete one ExternalCommunication.
     * @example
     * // Delete one ExternalCommunication
     * const ExternalCommunication = await prisma.externalCommunication.delete({
     *   where: {
     *     // ... filter to delete one ExternalCommunication
     *   }
     * })
     * 
     */
    delete<T extends ExternalCommunicationDeleteArgs>(args: SelectSubset<T, ExternalCommunicationDeleteArgs<ExtArgs>>): Prisma__ExternalCommunicationClient<$Result.GetResult<Prisma.$ExternalCommunicationPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one ExternalCommunication.
     * @param {ExternalCommunicationUpdateArgs} args - Arguments to update one ExternalCommunication.
     * @example
     * // Update one ExternalCommunication
     * const externalCommunication = await prisma.externalCommunication.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ExternalCommunicationUpdateArgs>(args: SelectSubset<T, ExternalCommunicationUpdateArgs<ExtArgs>>): Prisma__ExternalCommunicationClient<$Result.GetResult<Prisma.$ExternalCommunicationPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more ExternalCommunications.
     * @param {ExternalCommunicationDeleteManyArgs} args - Arguments to filter ExternalCommunications to delete.
     * @example
     * // Delete a few ExternalCommunications
     * const { count } = await prisma.externalCommunication.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ExternalCommunicationDeleteManyArgs>(args?: SelectSubset<T, ExternalCommunicationDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more ExternalCommunications.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExternalCommunicationUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many ExternalCommunications
     * const externalCommunication = await prisma.externalCommunication.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ExternalCommunicationUpdateManyArgs>(args: SelectSubset<T, ExternalCommunicationUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more ExternalCommunications and returns the data updated in the database.
     * @param {ExternalCommunicationUpdateManyAndReturnArgs} args - Arguments to update many ExternalCommunications.
     * @example
     * // Update many ExternalCommunications
     * const externalCommunication = await prisma.externalCommunication.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more ExternalCommunications and only return the `id`
     * const externalCommunicationWithIdOnly = await prisma.externalCommunication.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends ExternalCommunicationUpdateManyAndReturnArgs>(args: SelectSubset<T, ExternalCommunicationUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ExternalCommunicationPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one ExternalCommunication.
     * @param {ExternalCommunicationUpsertArgs} args - Arguments to update or create a ExternalCommunication.
     * @example
     * // Update or create a ExternalCommunication
     * const externalCommunication = await prisma.externalCommunication.upsert({
     *   create: {
     *     // ... data to create a ExternalCommunication
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the ExternalCommunication we want to update
     *   }
     * })
     */
    upsert<T extends ExternalCommunicationUpsertArgs>(args: SelectSubset<T, ExternalCommunicationUpsertArgs<ExtArgs>>): Prisma__ExternalCommunicationClient<$Result.GetResult<Prisma.$ExternalCommunicationPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of ExternalCommunications.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExternalCommunicationCountArgs} args - Arguments to filter ExternalCommunications to count.
     * @example
     * // Count the number of ExternalCommunications
     * const count = await prisma.externalCommunication.count({
     *   where: {
     *     // ... the filter for the ExternalCommunications we want to count
     *   }
     * })
    **/
    count<T extends ExternalCommunicationCountArgs>(
      args?: Subset<T, ExternalCommunicationCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ExternalCommunicationCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a ExternalCommunication.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExternalCommunicationAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ExternalCommunicationAggregateArgs>(args: Subset<T, ExternalCommunicationAggregateArgs>): Prisma.PrismaPromise<GetExternalCommunicationAggregateType<T>>

    /**
     * Group by ExternalCommunication.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExternalCommunicationGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ExternalCommunicationGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ExternalCommunicationGroupByArgs['orderBy'] }
        : { orderBy?: ExternalCommunicationGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ExternalCommunicationGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetExternalCommunicationGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the ExternalCommunication model
   */
  readonly fields: ExternalCommunicationFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for ExternalCommunication.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ExternalCommunicationClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    case<T extends CaseDefaultArgs<ExtArgs> = {}>(args?: Subset<T, CaseDefaultArgs<ExtArgs>>): Prisma__CaseClient<$Result.GetResult<Prisma.$CasePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the ExternalCommunication model
   */
  interface ExternalCommunicationFieldRefs {
    readonly id: FieldRef<"ExternalCommunication", 'String'>
    readonly createdAt: FieldRef<"ExternalCommunication", 'DateTime'>
    readonly direction: FieldRef<"ExternalCommunication", 'Direction'>
    readonly body: FieldRef<"ExternalCommunication", 'String'>
    readonly sender: FieldRef<"ExternalCommunication", 'String'>
    readonly caseId: FieldRef<"ExternalCommunication", 'String'>
  }
    

  // Custom InputTypes
  /**
   * ExternalCommunication findUnique
   */
  export type ExternalCommunicationFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalCommunication
     */
    select?: ExternalCommunicationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalCommunication
     */
    omit?: ExternalCommunicationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalCommunicationInclude<ExtArgs> | null
    /**
     * Filter, which ExternalCommunication to fetch.
     */
    where: ExternalCommunicationWhereUniqueInput
  }

  /**
   * ExternalCommunication findUniqueOrThrow
   */
  export type ExternalCommunicationFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalCommunication
     */
    select?: ExternalCommunicationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalCommunication
     */
    omit?: ExternalCommunicationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalCommunicationInclude<ExtArgs> | null
    /**
     * Filter, which ExternalCommunication to fetch.
     */
    where: ExternalCommunicationWhereUniqueInput
  }

  /**
   * ExternalCommunication findFirst
   */
  export type ExternalCommunicationFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalCommunication
     */
    select?: ExternalCommunicationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalCommunication
     */
    omit?: ExternalCommunicationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalCommunicationInclude<ExtArgs> | null
    /**
     * Filter, which ExternalCommunication to fetch.
     */
    where?: ExternalCommunicationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ExternalCommunications to fetch.
     */
    orderBy?: ExternalCommunicationOrderByWithRelationInput | ExternalCommunicationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ExternalCommunications.
     */
    cursor?: ExternalCommunicationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ExternalCommunications from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ExternalCommunications.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ExternalCommunications.
     */
    distinct?: ExternalCommunicationScalarFieldEnum | ExternalCommunicationScalarFieldEnum[]
  }

  /**
   * ExternalCommunication findFirstOrThrow
   */
  export type ExternalCommunicationFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalCommunication
     */
    select?: ExternalCommunicationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalCommunication
     */
    omit?: ExternalCommunicationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalCommunicationInclude<ExtArgs> | null
    /**
     * Filter, which ExternalCommunication to fetch.
     */
    where?: ExternalCommunicationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ExternalCommunications to fetch.
     */
    orderBy?: ExternalCommunicationOrderByWithRelationInput | ExternalCommunicationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for ExternalCommunications.
     */
    cursor?: ExternalCommunicationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ExternalCommunications from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ExternalCommunications.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of ExternalCommunications.
     */
    distinct?: ExternalCommunicationScalarFieldEnum | ExternalCommunicationScalarFieldEnum[]
  }

  /**
   * ExternalCommunication findMany
   */
  export type ExternalCommunicationFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalCommunication
     */
    select?: ExternalCommunicationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalCommunication
     */
    omit?: ExternalCommunicationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalCommunicationInclude<ExtArgs> | null
    /**
     * Filter, which ExternalCommunications to fetch.
     */
    where?: ExternalCommunicationWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of ExternalCommunications to fetch.
     */
    orderBy?: ExternalCommunicationOrderByWithRelationInput | ExternalCommunicationOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing ExternalCommunications.
     */
    cursor?: ExternalCommunicationWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` ExternalCommunications from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` ExternalCommunications.
     */
    skip?: number
    distinct?: ExternalCommunicationScalarFieldEnum | ExternalCommunicationScalarFieldEnum[]
  }

  /**
   * ExternalCommunication create
   */
  export type ExternalCommunicationCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalCommunication
     */
    select?: ExternalCommunicationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalCommunication
     */
    omit?: ExternalCommunicationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalCommunicationInclude<ExtArgs> | null
    /**
     * The data needed to create a ExternalCommunication.
     */
    data: XOR<ExternalCommunicationCreateInput, ExternalCommunicationUncheckedCreateInput>
  }

  /**
   * ExternalCommunication createMany
   */
  export type ExternalCommunicationCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many ExternalCommunications.
     */
    data: ExternalCommunicationCreateManyInput | ExternalCommunicationCreateManyInput[]
  }

  /**
   * ExternalCommunication createManyAndReturn
   */
  export type ExternalCommunicationCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalCommunication
     */
    select?: ExternalCommunicationSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalCommunication
     */
    omit?: ExternalCommunicationOmit<ExtArgs> | null
    /**
     * The data used to create many ExternalCommunications.
     */
    data: ExternalCommunicationCreateManyInput | ExternalCommunicationCreateManyInput[]
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalCommunicationIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * ExternalCommunication update
   */
  export type ExternalCommunicationUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalCommunication
     */
    select?: ExternalCommunicationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalCommunication
     */
    omit?: ExternalCommunicationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalCommunicationInclude<ExtArgs> | null
    /**
     * The data needed to update a ExternalCommunication.
     */
    data: XOR<ExternalCommunicationUpdateInput, ExternalCommunicationUncheckedUpdateInput>
    /**
     * Choose, which ExternalCommunication to update.
     */
    where: ExternalCommunicationWhereUniqueInput
  }

  /**
   * ExternalCommunication updateMany
   */
  export type ExternalCommunicationUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update ExternalCommunications.
     */
    data: XOR<ExternalCommunicationUpdateManyMutationInput, ExternalCommunicationUncheckedUpdateManyInput>
    /**
     * Filter which ExternalCommunications to update
     */
    where?: ExternalCommunicationWhereInput
    /**
     * Limit how many ExternalCommunications to update.
     */
    limit?: number
  }

  /**
   * ExternalCommunication updateManyAndReturn
   */
  export type ExternalCommunicationUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalCommunication
     */
    select?: ExternalCommunicationSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalCommunication
     */
    omit?: ExternalCommunicationOmit<ExtArgs> | null
    /**
     * The data used to update ExternalCommunications.
     */
    data: XOR<ExternalCommunicationUpdateManyMutationInput, ExternalCommunicationUncheckedUpdateManyInput>
    /**
     * Filter which ExternalCommunications to update
     */
    where?: ExternalCommunicationWhereInput
    /**
     * Limit how many ExternalCommunications to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalCommunicationIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * ExternalCommunication upsert
   */
  export type ExternalCommunicationUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalCommunication
     */
    select?: ExternalCommunicationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalCommunication
     */
    omit?: ExternalCommunicationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalCommunicationInclude<ExtArgs> | null
    /**
     * The filter to search for the ExternalCommunication to update in case it exists.
     */
    where: ExternalCommunicationWhereUniqueInput
    /**
     * In case the ExternalCommunication found by the `where` argument doesn't exist, create a new ExternalCommunication with this data.
     */
    create: XOR<ExternalCommunicationCreateInput, ExternalCommunicationUncheckedCreateInput>
    /**
     * In case the ExternalCommunication was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ExternalCommunicationUpdateInput, ExternalCommunicationUncheckedUpdateInput>
  }

  /**
   * ExternalCommunication delete
   */
  export type ExternalCommunicationDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalCommunication
     */
    select?: ExternalCommunicationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalCommunication
     */
    omit?: ExternalCommunicationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalCommunicationInclude<ExtArgs> | null
    /**
     * Filter which ExternalCommunication to delete.
     */
    where: ExternalCommunicationWhereUniqueInput
  }

  /**
   * ExternalCommunication deleteMany
   */
  export type ExternalCommunicationDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which ExternalCommunications to delete
     */
    where?: ExternalCommunicationWhereInput
    /**
     * Limit how many ExternalCommunications to delete.
     */
    limit?: number
  }

  /**
   * ExternalCommunication without action
   */
  export type ExternalCommunicationDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the ExternalCommunication
     */
    select?: ExternalCommunicationSelect<ExtArgs> | null
    /**
     * Omit specific fields from the ExternalCommunication
     */
    omit?: ExternalCommunicationOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExternalCommunicationInclude<ExtArgs> | null
  }


  /**
   * Model Document
   */

  export type AggregateDocument = {
    _count: DocumentCountAggregateOutputType | null
    _min: DocumentMinAggregateOutputType | null
    _max: DocumentMaxAggregateOutputType | null
  }

  export type DocumentMinAggregateOutputType = {
    id: string | null
    name: string | null
    state: $Enums.DocState | null
    caseId: string | null
  }

  export type DocumentMaxAggregateOutputType = {
    id: string | null
    name: string | null
    state: $Enums.DocState | null
    caseId: string | null
  }

  export type DocumentCountAggregateOutputType = {
    id: number
    name: number
    state: number
    caseId: number
    _all: number
  }


  export type DocumentMinAggregateInputType = {
    id?: true
    name?: true
    state?: true
    caseId?: true
  }

  export type DocumentMaxAggregateInputType = {
    id?: true
    name?: true
    state?: true
    caseId?: true
  }

  export type DocumentCountAggregateInputType = {
    id?: true
    name?: true
    state?: true
    caseId?: true
    _all?: true
  }

  export type DocumentAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Document to aggregate.
     */
    where?: DocumentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Documents to fetch.
     */
    orderBy?: DocumentOrderByWithRelationInput | DocumentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: DocumentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Documents from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Documents.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Documents
    **/
    _count?: true | DocumentCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: DocumentMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: DocumentMaxAggregateInputType
  }

  export type GetDocumentAggregateType<T extends DocumentAggregateArgs> = {
        [P in keyof T & keyof AggregateDocument]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateDocument[P]>
      : GetScalarType<T[P], AggregateDocument[P]>
  }




  export type DocumentGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: DocumentWhereInput
    orderBy?: DocumentOrderByWithAggregationInput | DocumentOrderByWithAggregationInput[]
    by: DocumentScalarFieldEnum[] | DocumentScalarFieldEnum
    having?: DocumentScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: DocumentCountAggregateInputType | true
    _min?: DocumentMinAggregateInputType
    _max?: DocumentMaxAggregateInputType
  }

  export type DocumentGroupByOutputType = {
    id: string
    name: string
    state: $Enums.DocState
    caseId: string
    _count: DocumentCountAggregateOutputType | null
    _min: DocumentMinAggregateOutputType | null
    _max: DocumentMaxAggregateOutputType | null
  }

  type GetDocumentGroupByPayload<T extends DocumentGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<DocumentGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof DocumentGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], DocumentGroupByOutputType[P]>
            : GetScalarType<T[P], DocumentGroupByOutputType[P]>
        }
      >
    >


  export type DocumentSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    state?: boolean
    caseId?: boolean
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["document"]>

  export type DocumentSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    state?: boolean
    caseId?: boolean
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["document"]>

  export type DocumentSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    state?: boolean
    caseId?: boolean
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["document"]>

  export type DocumentSelectScalar = {
    id?: boolean
    name?: boolean
    state?: boolean
    caseId?: boolean
  }

  export type DocumentOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "state" | "caseId", ExtArgs["result"]["document"]>
  export type DocumentInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }
  export type DocumentIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }
  export type DocumentIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }

  export type $DocumentPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Document"
    objects: {
      case: Prisma.$CasePayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
      state: $Enums.DocState
      caseId: string
    }, ExtArgs["result"]["document"]>
    composites: {}
  }

  type DocumentGetPayload<S extends boolean | null | undefined | DocumentDefaultArgs> = $Result.GetResult<Prisma.$DocumentPayload, S>

  type DocumentCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<DocumentFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: DocumentCountAggregateInputType | true
    }

  export interface DocumentDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Document'], meta: { name: 'Document' } }
    /**
     * Find zero or one Document that matches the filter.
     * @param {DocumentFindUniqueArgs} args - Arguments to find a Document
     * @example
     * // Get one Document
     * const document = await prisma.document.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends DocumentFindUniqueArgs>(args: SelectSubset<T, DocumentFindUniqueArgs<ExtArgs>>): Prisma__DocumentClient<$Result.GetResult<Prisma.$DocumentPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Document that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {DocumentFindUniqueOrThrowArgs} args - Arguments to find a Document
     * @example
     * // Get one Document
     * const document = await prisma.document.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends DocumentFindUniqueOrThrowArgs>(args: SelectSubset<T, DocumentFindUniqueOrThrowArgs<ExtArgs>>): Prisma__DocumentClient<$Result.GetResult<Prisma.$DocumentPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Document that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DocumentFindFirstArgs} args - Arguments to find a Document
     * @example
     * // Get one Document
     * const document = await prisma.document.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends DocumentFindFirstArgs>(args?: SelectSubset<T, DocumentFindFirstArgs<ExtArgs>>): Prisma__DocumentClient<$Result.GetResult<Prisma.$DocumentPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Document that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DocumentFindFirstOrThrowArgs} args - Arguments to find a Document
     * @example
     * // Get one Document
     * const document = await prisma.document.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends DocumentFindFirstOrThrowArgs>(args?: SelectSubset<T, DocumentFindFirstOrThrowArgs<ExtArgs>>): Prisma__DocumentClient<$Result.GetResult<Prisma.$DocumentPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Documents that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DocumentFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Documents
     * const documents = await prisma.document.findMany()
     * 
     * // Get first 10 Documents
     * const documents = await prisma.document.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const documentWithIdOnly = await prisma.document.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends DocumentFindManyArgs>(args?: SelectSubset<T, DocumentFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$DocumentPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Document.
     * @param {DocumentCreateArgs} args - Arguments to create a Document.
     * @example
     * // Create one Document
     * const Document = await prisma.document.create({
     *   data: {
     *     // ... data to create a Document
     *   }
     * })
     * 
     */
    create<T extends DocumentCreateArgs>(args: SelectSubset<T, DocumentCreateArgs<ExtArgs>>): Prisma__DocumentClient<$Result.GetResult<Prisma.$DocumentPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Documents.
     * @param {DocumentCreateManyArgs} args - Arguments to create many Documents.
     * @example
     * // Create many Documents
     * const document = await prisma.document.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends DocumentCreateManyArgs>(args?: SelectSubset<T, DocumentCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Documents and returns the data saved in the database.
     * @param {DocumentCreateManyAndReturnArgs} args - Arguments to create many Documents.
     * @example
     * // Create many Documents
     * const document = await prisma.document.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Documents and only return the `id`
     * const documentWithIdOnly = await prisma.document.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends DocumentCreateManyAndReturnArgs>(args?: SelectSubset<T, DocumentCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$DocumentPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Document.
     * @param {DocumentDeleteArgs} args - Arguments to delete one Document.
     * @example
     * // Delete one Document
     * const Document = await prisma.document.delete({
     *   where: {
     *     // ... filter to delete one Document
     *   }
     * })
     * 
     */
    delete<T extends DocumentDeleteArgs>(args: SelectSubset<T, DocumentDeleteArgs<ExtArgs>>): Prisma__DocumentClient<$Result.GetResult<Prisma.$DocumentPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Document.
     * @param {DocumentUpdateArgs} args - Arguments to update one Document.
     * @example
     * // Update one Document
     * const document = await prisma.document.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends DocumentUpdateArgs>(args: SelectSubset<T, DocumentUpdateArgs<ExtArgs>>): Prisma__DocumentClient<$Result.GetResult<Prisma.$DocumentPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Documents.
     * @param {DocumentDeleteManyArgs} args - Arguments to filter Documents to delete.
     * @example
     * // Delete a few Documents
     * const { count } = await prisma.document.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends DocumentDeleteManyArgs>(args?: SelectSubset<T, DocumentDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Documents.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DocumentUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Documents
     * const document = await prisma.document.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends DocumentUpdateManyArgs>(args: SelectSubset<T, DocumentUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Documents and returns the data updated in the database.
     * @param {DocumentUpdateManyAndReturnArgs} args - Arguments to update many Documents.
     * @example
     * // Update many Documents
     * const document = await prisma.document.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Documents and only return the `id`
     * const documentWithIdOnly = await prisma.document.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends DocumentUpdateManyAndReturnArgs>(args: SelectSubset<T, DocumentUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$DocumentPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Document.
     * @param {DocumentUpsertArgs} args - Arguments to update or create a Document.
     * @example
     * // Update or create a Document
     * const document = await prisma.document.upsert({
     *   create: {
     *     // ... data to create a Document
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Document we want to update
     *   }
     * })
     */
    upsert<T extends DocumentUpsertArgs>(args: SelectSubset<T, DocumentUpsertArgs<ExtArgs>>): Prisma__DocumentClient<$Result.GetResult<Prisma.$DocumentPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Documents.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DocumentCountArgs} args - Arguments to filter Documents to count.
     * @example
     * // Count the number of Documents
     * const count = await prisma.document.count({
     *   where: {
     *     // ... the filter for the Documents we want to count
     *   }
     * })
    **/
    count<T extends DocumentCountArgs>(
      args?: Subset<T, DocumentCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], DocumentCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Document.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DocumentAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends DocumentAggregateArgs>(args: Subset<T, DocumentAggregateArgs>): Prisma.PrismaPromise<GetDocumentAggregateType<T>>

    /**
     * Group by Document.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {DocumentGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends DocumentGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: DocumentGroupByArgs['orderBy'] }
        : { orderBy?: DocumentGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, DocumentGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetDocumentGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Document model
   */
  readonly fields: DocumentFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Document.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__DocumentClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    case<T extends CaseDefaultArgs<ExtArgs> = {}>(args?: Subset<T, CaseDefaultArgs<ExtArgs>>): Prisma__CaseClient<$Result.GetResult<Prisma.$CasePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Document model
   */
  interface DocumentFieldRefs {
    readonly id: FieldRef<"Document", 'String'>
    readonly name: FieldRef<"Document", 'String'>
    readonly state: FieldRef<"Document", 'DocState'>
    readonly caseId: FieldRef<"Document", 'String'>
  }
    

  // Custom InputTypes
  /**
   * Document findUnique
   */
  export type DocumentFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Document
     */
    select?: DocumentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Document
     */
    omit?: DocumentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DocumentInclude<ExtArgs> | null
    /**
     * Filter, which Document to fetch.
     */
    where: DocumentWhereUniqueInput
  }

  /**
   * Document findUniqueOrThrow
   */
  export type DocumentFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Document
     */
    select?: DocumentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Document
     */
    omit?: DocumentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DocumentInclude<ExtArgs> | null
    /**
     * Filter, which Document to fetch.
     */
    where: DocumentWhereUniqueInput
  }

  /**
   * Document findFirst
   */
  export type DocumentFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Document
     */
    select?: DocumentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Document
     */
    omit?: DocumentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DocumentInclude<ExtArgs> | null
    /**
     * Filter, which Document to fetch.
     */
    where?: DocumentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Documents to fetch.
     */
    orderBy?: DocumentOrderByWithRelationInput | DocumentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Documents.
     */
    cursor?: DocumentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Documents from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Documents.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Documents.
     */
    distinct?: DocumentScalarFieldEnum | DocumentScalarFieldEnum[]
  }

  /**
   * Document findFirstOrThrow
   */
  export type DocumentFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Document
     */
    select?: DocumentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Document
     */
    omit?: DocumentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DocumentInclude<ExtArgs> | null
    /**
     * Filter, which Document to fetch.
     */
    where?: DocumentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Documents to fetch.
     */
    orderBy?: DocumentOrderByWithRelationInput | DocumentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Documents.
     */
    cursor?: DocumentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Documents from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Documents.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Documents.
     */
    distinct?: DocumentScalarFieldEnum | DocumentScalarFieldEnum[]
  }

  /**
   * Document findMany
   */
  export type DocumentFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Document
     */
    select?: DocumentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Document
     */
    omit?: DocumentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DocumentInclude<ExtArgs> | null
    /**
     * Filter, which Documents to fetch.
     */
    where?: DocumentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Documents to fetch.
     */
    orderBy?: DocumentOrderByWithRelationInput | DocumentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Documents.
     */
    cursor?: DocumentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Documents from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Documents.
     */
    skip?: number
    distinct?: DocumentScalarFieldEnum | DocumentScalarFieldEnum[]
  }

  /**
   * Document create
   */
  export type DocumentCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Document
     */
    select?: DocumentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Document
     */
    omit?: DocumentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DocumentInclude<ExtArgs> | null
    /**
     * The data needed to create a Document.
     */
    data: XOR<DocumentCreateInput, DocumentUncheckedCreateInput>
  }

  /**
   * Document createMany
   */
  export type DocumentCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Documents.
     */
    data: DocumentCreateManyInput | DocumentCreateManyInput[]
  }

  /**
   * Document createManyAndReturn
   */
  export type DocumentCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Document
     */
    select?: DocumentSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Document
     */
    omit?: DocumentOmit<ExtArgs> | null
    /**
     * The data used to create many Documents.
     */
    data: DocumentCreateManyInput | DocumentCreateManyInput[]
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DocumentIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Document update
   */
  export type DocumentUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Document
     */
    select?: DocumentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Document
     */
    omit?: DocumentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DocumentInclude<ExtArgs> | null
    /**
     * The data needed to update a Document.
     */
    data: XOR<DocumentUpdateInput, DocumentUncheckedUpdateInput>
    /**
     * Choose, which Document to update.
     */
    where: DocumentWhereUniqueInput
  }

  /**
   * Document updateMany
   */
  export type DocumentUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Documents.
     */
    data: XOR<DocumentUpdateManyMutationInput, DocumentUncheckedUpdateManyInput>
    /**
     * Filter which Documents to update
     */
    where?: DocumentWhereInput
    /**
     * Limit how many Documents to update.
     */
    limit?: number
  }

  /**
   * Document updateManyAndReturn
   */
  export type DocumentUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Document
     */
    select?: DocumentSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Document
     */
    omit?: DocumentOmit<ExtArgs> | null
    /**
     * The data used to update Documents.
     */
    data: XOR<DocumentUpdateManyMutationInput, DocumentUncheckedUpdateManyInput>
    /**
     * Filter which Documents to update
     */
    where?: DocumentWhereInput
    /**
     * Limit how many Documents to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DocumentIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Document upsert
   */
  export type DocumentUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Document
     */
    select?: DocumentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Document
     */
    omit?: DocumentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DocumentInclude<ExtArgs> | null
    /**
     * The filter to search for the Document to update in case it exists.
     */
    where: DocumentWhereUniqueInput
    /**
     * In case the Document found by the `where` argument doesn't exist, create a new Document with this data.
     */
    create: XOR<DocumentCreateInput, DocumentUncheckedCreateInput>
    /**
     * In case the Document was found with the provided `where` argument, update it with this data.
     */
    update: XOR<DocumentUpdateInput, DocumentUncheckedUpdateInput>
  }

  /**
   * Document delete
   */
  export type DocumentDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Document
     */
    select?: DocumentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Document
     */
    omit?: DocumentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DocumentInclude<ExtArgs> | null
    /**
     * Filter which Document to delete.
     */
    where: DocumentWhereUniqueInput
  }

  /**
   * Document deleteMany
   */
  export type DocumentDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Documents to delete
     */
    where?: DocumentWhereInput
    /**
     * Limit how many Documents to delete.
     */
    limit?: number
  }

  /**
   * Document without action
   */
  export type DocumentDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Document
     */
    select?: DocumentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Document
     */
    omit?: DocumentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: DocumentInclude<ExtArgs> | null
  }


  /**
   * Model Payment
   */

  export type AggregatePayment = {
    _count: PaymentCountAggregateOutputType | null
    _avg: PaymentAvgAggregateOutputType | null
    _sum: PaymentSumAggregateOutputType | null
    _min: PaymentMinAggregateOutputType | null
    _max: PaymentMaxAggregateOutputType | null
  }

  export type PaymentAvgAggregateOutputType = {
    amount: number | null
  }

  export type PaymentSumAggregateOutputType = {
    amount: number | null
  }

  export type PaymentMinAggregateOutputType = {
    id: string | null
    amount: number | null
    currency: string | null
    status: $Enums.PaymentStatus | null
    description: string | null
    invoiceNumber: string | null
    caseId: string | null
  }

  export type PaymentMaxAggregateOutputType = {
    id: string | null
    amount: number | null
    currency: string | null
    status: $Enums.PaymentStatus | null
    description: string | null
    invoiceNumber: string | null
    caseId: string | null
  }

  export type PaymentCountAggregateOutputType = {
    id: number
    amount: number
    currency: number
    status: number
    description: number
    invoiceNumber: number
    caseId: number
    _all: number
  }


  export type PaymentAvgAggregateInputType = {
    amount?: true
  }

  export type PaymentSumAggregateInputType = {
    amount?: true
  }

  export type PaymentMinAggregateInputType = {
    id?: true
    amount?: true
    currency?: true
    status?: true
    description?: true
    invoiceNumber?: true
    caseId?: true
  }

  export type PaymentMaxAggregateInputType = {
    id?: true
    amount?: true
    currency?: true
    status?: true
    description?: true
    invoiceNumber?: true
    caseId?: true
  }

  export type PaymentCountAggregateInputType = {
    id?: true
    amount?: true
    currency?: true
    status?: true
    description?: true
    invoiceNumber?: true
    caseId?: true
    _all?: true
  }

  export type PaymentAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Payment to aggregate.
     */
    where?: PaymentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Payments to fetch.
     */
    orderBy?: PaymentOrderByWithRelationInput | PaymentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: PaymentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Payments from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Payments.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Payments
    **/
    _count?: true | PaymentCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: PaymentAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: PaymentSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: PaymentMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: PaymentMaxAggregateInputType
  }

  export type GetPaymentAggregateType<T extends PaymentAggregateArgs> = {
        [P in keyof T & keyof AggregatePayment]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePayment[P]>
      : GetScalarType<T[P], AggregatePayment[P]>
  }




  export type PaymentGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PaymentWhereInput
    orderBy?: PaymentOrderByWithAggregationInput | PaymentOrderByWithAggregationInput[]
    by: PaymentScalarFieldEnum[] | PaymentScalarFieldEnum
    having?: PaymentScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: PaymentCountAggregateInputType | true
    _avg?: PaymentAvgAggregateInputType
    _sum?: PaymentSumAggregateInputType
    _min?: PaymentMinAggregateInputType
    _max?: PaymentMaxAggregateInputType
  }

  export type PaymentGroupByOutputType = {
    id: string
    amount: number
    currency: string
    status: $Enums.PaymentStatus
    description: string
    invoiceNumber: string
    caseId: string
    _count: PaymentCountAggregateOutputType | null
    _avg: PaymentAvgAggregateOutputType | null
    _sum: PaymentSumAggregateOutputType | null
    _min: PaymentMinAggregateOutputType | null
    _max: PaymentMaxAggregateOutputType | null
  }

  type GetPaymentGroupByPayload<T extends PaymentGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<PaymentGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof PaymentGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], PaymentGroupByOutputType[P]>
            : GetScalarType<T[P], PaymentGroupByOutputType[P]>
        }
      >
    >


  export type PaymentSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    amount?: boolean
    currency?: boolean
    status?: boolean
    description?: boolean
    invoiceNumber?: boolean
    caseId?: boolean
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["payment"]>

  export type PaymentSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    amount?: boolean
    currency?: boolean
    status?: boolean
    description?: boolean
    invoiceNumber?: boolean
    caseId?: boolean
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["payment"]>

  export type PaymentSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    amount?: boolean
    currency?: boolean
    status?: boolean
    description?: boolean
    invoiceNumber?: boolean
    caseId?: boolean
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["payment"]>

  export type PaymentSelectScalar = {
    id?: boolean
    amount?: boolean
    currency?: boolean
    status?: boolean
    description?: boolean
    invoiceNumber?: boolean
    caseId?: boolean
  }

  export type PaymentOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "amount" | "currency" | "status" | "description" | "invoiceNumber" | "caseId", ExtArgs["result"]["payment"]>
  export type PaymentInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }
  export type PaymentIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }
  export type PaymentIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }

  export type $PaymentPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Payment"
    objects: {
      case: Prisma.$CasePayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      amount: number
      currency: string
      status: $Enums.PaymentStatus
      description: string
      invoiceNumber: string
      caseId: string
    }, ExtArgs["result"]["payment"]>
    composites: {}
  }

  type PaymentGetPayload<S extends boolean | null | undefined | PaymentDefaultArgs> = $Result.GetResult<Prisma.$PaymentPayload, S>

  type PaymentCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<PaymentFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: PaymentCountAggregateInputType | true
    }

  export interface PaymentDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Payment'], meta: { name: 'Payment' } }
    /**
     * Find zero or one Payment that matches the filter.
     * @param {PaymentFindUniqueArgs} args - Arguments to find a Payment
     * @example
     * // Get one Payment
     * const payment = await prisma.payment.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends PaymentFindUniqueArgs>(args: SelectSubset<T, PaymentFindUniqueArgs<ExtArgs>>): Prisma__PaymentClient<$Result.GetResult<Prisma.$PaymentPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Payment that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {PaymentFindUniqueOrThrowArgs} args - Arguments to find a Payment
     * @example
     * // Get one Payment
     * const payment = await prisma.payment.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends PaymentFindUniqueOrThrowArgs>(args: SelectSubset<T, PaymentFindUniqueOrThrowArgs<ExtArgs>>): Prisma__PaymentClient<$Result.GetResult<Prisma.$PaymentPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Payment that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentFindFirstArgs} args - Arguments to find a Payment
     * @example
     * // Get one Payment
     * const payment = await prisma.payment.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends PaymentFindFirstArgs>(args?: SelectSubset<T, PaymentFindFirstArgs<ExtArgs>>): Prisma__PaymentClient<$Result.GetResult<Prisma.$PaymentPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Payment that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentFindFirstOrThrowArgs} args - Arguments to find a Payment
     * @example
     * // Get one Payment
     * const payment = await prisma.payment.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends PaymentFindFirstOrThrowArgs>(args?: SelectSubset<T, PaymentFindFirstOrThrowArgs<ExtArgs>>): Prisma__PaymentClient<$Result.GetResult<Prisma.$PaymentPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Payments that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Payments
     * const payments = await prisma.payment.findMany()
     * 
     * // Get first 10 Payments
     * const payments = await prisma.payment.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const paymentWithIdOnly = await prisma.payment.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends PaymentFindManyArgs>(args?: SelectSubset<T, PaymentFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PaymentPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Payment.
     * @param {PaymentCreateArgs} args - Arguments to create a Payment.
     * @example
     * // Create one Payment
     * const Payment = await prisma.payment.create({
     *   data: {
     *     // ... data to create a Payment
     *   }
     * })
     * 
     */
    create<T extends PaymentCreateArgs>(args: SelectSubset<T, PaymentCreateArgs<ExtArgs>>): Prisma__PaymentClient<$Result.GetResult<Prisma.$PaymentPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Payments.
     * @param {PaymentCreateManyArgs} args - Arguments to create many Payments.
     * @example
     * // Create many Payments
     * const payment = await prisma.payment.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends PaymentCreateManyArgs>(args?: SelectSubset<T, PaymentCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Payments and returns the data saved in the database.
     * @param {PaymentCreateManyAndReturnArgs} args - Arguments to create many Payments.
     * @example
     * // Create many Payments
     * const payment = await prisma.payment.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Payments and only return the `id`
     * const paymentWithIdOnly = await prisma.payment.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends PaymentCreateManyAndReturnArgs>(args?: SelectSubset<T, PaymentCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PaymentPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Payment.
     * @param {PaymentDeleteArgs} args - Arguments to delete one Payment.
     * @example
     * // Delete one Payment
     * const Payment = await prisma.payment.delete({
     *   where: {
     *     // ... filter to delete one Payment
     *   }
     * })
     * 
     */
    delete<T extends PaymentDeleteArgs>(args: SelectSubset<T, PaymentDeleteArgs<ExtArgs>>): Prisma__PaymentClient<$Result.GetResult<Prisma.$PaymentPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Payment.
     * @param {PaymentUpdateArgs} args - Arguments to update one Payment.
     * @example
     * // Update one Payment
     * const payment = await prisma.payment.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends PaymentUpdateArgs>(args: SelectSubset<T, PaymentUpdateArgs<ExtArgs>>): Prisma__PaymentClient<$Result.GetResult<Prisma.$PaymentPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Payments.
     * @param {PaymentDeleteManyArgs} args - Arguments to filter Payments to delete.
     * @example
     * // Delete a few Payments
     * const { count } = await prisma.payment.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends PaymentDeleteManyArgs>(args?: SelectSubset<T, PaymentDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Payments.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Payments
     * const payment = await prisma.payment.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends PaymentUpdateManyArgs>(args: SelectSubset<T, PaymentUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Payments and returns the data updated in the database.
     * @param {PaymentUpdateManyAndReturnArgs} args - Arguments to update many Payments.
     * @example
     * // Update many Payments
     * const payment = await prisma.payment.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Payments and only return the `id`
     * const paymentWithIdOnly = await prisma.payment.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends PaymentUpdateManyAndReturnArgs>(args: SelectSubset<T, PaymentUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PaymentPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Payment.
     * @param {PaymentUpsertArgs} args - Arguments to update or create a Payment.
     * @example
     * // Update or create a Payment
     * const payment = await prisma.payment.upsert({
     *   create: {
     *     // ... data to create a Payment
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Payment we want to update
     *   }
     * })
     */
    upsert<T extends PaymentUpsertArgs>(args: SelectSubset<T, PaymentUpsertArgs<ExtArgs>>): Prisma__PaymentClient<$Result.GetResult<Prisma.$PaymentPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Payments.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentCountArgs} args - Arguments to filter Payments to count.
     * @example
     * // Count the number of Payments
     * const count = await prisma.payment.count({
     *   where: {
     *     // ... the filter for the Payments we want to count
     *   }
     * })
    **/
    count<T extends PaymentCountArgs>(
      args?: Subset<T, PaymentCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], PaymentCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Payment.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PaymentAggregateArgs>(args: Subset<T, PaymentAggregateArgs>): Prisma.PrismaPromise<GetPaymentAggregateType<T>>

    /**
     * Group by Payment.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends PaymentGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: PaymentGroupByArgs['orderBy'] }
        : { orderBy?: PaymentGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, PaymentGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPaymentGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Payment model
   */
  readonly fields: PaymentFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Payment.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__PaymentClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    case<T extends CaseDefaultArgs<ExtArgs> = {}>(args?: Subset<T, CaseDefaultArgs<ExtArgs>>): Prisma__CaseClient<$Result.GetResult<Prisma.$CasePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Payment model
   */
  interface PaymentFieldRefs {
    readonly id: FieldRef<"Payment", 'String'>
    readonly amount: FieldRef<"Payment", 'Int'>
    readonly currency: FieldRef<"Payment", 'String'>
    readonly status: FieldRef<"Payment", 'PaymentStatus'>
    readonly description: FieldRef<"Payment", 'String'>
    readonly invoiceNumber: FieldRef<"Payment", 'String'>
    readonly caseId: FieldRef<"Payment", 'String'>
  }
    

  // Custom InputTypes
  /**
   * Payment findUnique
   */
  export type PaymentFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Payment
     */
    select?: PaymentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Payment
     */
    omit?: PaymentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentInclude<ExtArgs> | null
    /**
     * Filter, which Payment to fetch.
     */
    where: PaymentWhereUniqueInput
  }

  /**
   * Payment findUniqueOrThrow
   */
  export type PaymentFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Payment
     */
    select?: PaymentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Payment
     */
    omit?: PaymentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentInclude<ExtArgs> | null
    /**
     * Filter, which Payment to fetch.
     */
    where: PaymentWhereUniqueInput
  }

  /**
   * Payment findFirst
   */
  export type PaymentFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Payment
     */
    select?: PaymentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Payment
     */
    omit?: PaymentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentInclude<ExtArgs> | null
    /**
     * Filter, which Payment to fetch.
     */
    where?: PaymentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Payments to fetch.
     */
    orderBy?: PaymentOrderByWithRelationInput | PaymentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Payments.
     */
    cursor?: PaymentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Payments from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Payments.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Payments.
     */
    distinct?: PaymentScalarFieldEnum | PaymentScalarFieldEnum[]
  }

  /**
   * Payment findFirstOrThrow
   */
  export type PaymentFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Payment
     */
    select?: PaymentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Payment
     */
    omit?: PaymentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentInclude<ExtArgs> | null
    /**
     * Filter, which Payment to fetch.
     */
    where?: PaymentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Payments to fetch.
     */
    orderBy?: PaymentOrderByWithRelationInput | PaymentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Payments.
     */
    cursor?: PaymentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Payments from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Payments.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Payments.
     */
    distinct?: PaymentScalarFieldEnum | PaymentScalarFieldEnum[]
  }

  /**
   * Payment findMany
   */
  export type PaymentFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Payment
     */
    select?: PaymentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Payment
     */
    omit?: PaymentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentInclude<ExtArgs> | null
    /**
     * Filter, which Payments to fetch.
     */
    where?: PaymentWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Payments to fetch.
     */
    orderBy?: PaymentOrderByWithRelationInput | PaymentOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Payments.
     */
    cursor?: PaymentWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Payments from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Payments.
     */
    skip?: number
    distinct?: PaymentScalarFieldEnum | PaymentScalarFieldEnum[]
  }

  /**
   * Payment create
   */
  export type PaymentCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Payment
     */
    select?: PaymentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Payment
     */
    omit?: PaymentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentInclude<ExtArgs> | null
    /**
     * The data needed to create a Payment.
     */
    data: XOR<PaymentCreateInput, PaymentUncheckedCreateInput>
  }

  /**
   * Payment createMany
   */
  export type PaymentCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Payments.
     */
    data: PaymentCreateManyInput | PaymentCreateManyInput[]
  }

  /**
   * Payment createManyAndReturn
   */
  export type PaymentCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Payment
     */
    select?: PaymentSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Payment
     */
    omit?: PaymentOmit<ExtArgs> | null
    /**
     * The data used to create many Payments.
     */
    data: PaymentCreateManyInput | PaymentCreateManyInput[]
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Payment update
   */
  export type PaymentUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Payment
     */
    select?: PaymentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Payment
     */
    omit?: PaymentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentInclude<ExtArgs> | null
    /**
     * The data needed to update a Payment.
     */
    data: XOR<PaymentUpdateInput, PaymentUncheckedUpdateInput>
    /**
     * Choose, which Payment to update.
     */
    where: PaymentWhereUniqueInput
  }

  /**
   * Payment updateMany
   */
  export type PaymentUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Payments.
     */
    data: XOR<PaymentUpdateManyMutationInput, PaymentUncheckedUpdateManyInput>
    /**
     * Filter which Payments to update
     */
    where?: PaymentWhereInput
    /**
     * Limit how many Payments to update.
     */
    limit?: number
  }

  /**
   * Payment updateManyAndReturn
   */
  export type PaymentUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Payment
     */
    select?: PaymentSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Payment
     */
    omit?: PaymentOmit<ExtArgs> | null
    /**
     * The data used to update Payments.
     */
    data: XOR<PaymentUpdateManyMutationInput, PaymentUncheckedUpdateManyInput>
    /**
     * Filter which Payments to update
     */
    where?: PaymentWhereInput
    /**
     * Limit how many Payments to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Payment upsert
   */
  export type PaymentUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Payment
     */
    select?: PaymentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Payment
     */
    omit?: PaymentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentInclude<ExtArgs> | null
    /**
     * The filter to search for the Payment to update in case it exists.
     */
    where: PaymentWhereUniqueInput
    /**
     * In case the Payment found by the `where` argument doesn't exist, create a new Payment with this data.
     */
    create: XOR<PaymentCreateInput, PaymentUncheckedCreateInput>
    /**
     * In case the Payment was found with the provided `where` argument, update it with this data.
     */
    update: XOR<PaymentUpdateInput, PaymentUncheckedUpdateInput>
  }

  /**
   * Payment delete
   */
  export type PaymentDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Payment
     */
    select?: PaymentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Payment
     */
    omit?: PaymentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentInclude<ExtArgs> | null
    /**
     * Filter which Payment to delete.
     */
    where: PaymentWhereUniqueInput
  }

  /**
   * Payment deleteMany
   */
  export type PaymentDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Payments to delete
     */
    where?: PaymentWhereInput
    /**
     * Limit how many Payments to delete.
     */
    limit?: number
  }

  /**
   * Payment without action
   */
  export type PaymentDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Payment
     */
    select?: PaymentSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Payment
     */
    omit?: PaymentOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PaymentInclude<ExtArgs> | null
  }


  /**
   * Model TimelineEvent
   */

  export type AggregateTimelineEvent = {
    _count: TimelineEventCountAggregateOutputType | null
    _min: TimelineEventMinAggregateOutputType | null
    _max: TimelineEventMaxAggregateOutputType | null
  }

  export type TimelineEventMinAggregateOutputType = {
    id: string | null
    createdAt: Date | null
    details: string | null
    caseId: string | null
  }

  export type TimelineEventMaxAggregateOutputType = {
    id: string | null
    createdAt: Date | null
    details: string | null
    caseId: string | null
  }

  export type TimelineEventCountAggregateOutputType = {
    id: number
    createdAt: number
    details: number
    caseId: number
    _all: number
  }


  export type TimelineEventMinAggregateInputType = {
    id?: true
    createdAt?: true
    details?: true
    caseId?: true
  }

  export type TimelineEventMaxAggregateInputType = {
    id?: true
    createdAt?: true
    details?: true
    caseId?: true
  }

  export type TimelineEventCountAggregateInputType = {
    id?: true
    createdAt?: true
    details?: true
    caseId?: true
    _all?: true
  }

  export type TimelineEventAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which TimelineEvent to aggregate.
     */
    where?: TimelineEventWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TimelineEvents to fetch.
     */
    orderBy?: TimelineEventOrderByWithRelationInput | TimelineEventOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: TimelineEventWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TimelineEvents from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TimelineEvents.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned TimelineEvents
    **/
    _count?: true | TimelineEventCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: TimelineEventMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: TimelineEventMaxAggregateInputType
  }

  export type GetTimelineEventAggregateType<T extends TimelineEventAggregateArgs> = {
        [P in keyof T & keyof AggregateTimelineEvent]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateTimelineEvent[P]>
      : GetScalarType<T[P], AggregateTimelineEvent[P]>
  }




  export type TimelineEventGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TimelineEventWhereInput
    orderBy?: TimelineEventOrderByWithAggregationInput | TimelineEventOrderByWithAggregationInput[]
    by: TimelineEventScalarFieldEnum[] | TimelineEventScalarFieldEnum
    having?: TimelineEventScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: TimelineEventCountAggregateInputType | true
    _min?: TimelineEventMinAggregateInputType
    _max?: TimelineEventMaxAggregateInputType
  }

  export type TimelineEventGroupByOutputType = {
    id: string
    createdAt: Date
    details: string
    caseId: string
    _count: TimelineEventCountAggregateOutputType | null
    _min: TimelineEventMinAggregateOutputType | null
    _max: TimelineEventMaxAggregateOutputType | null
  }

  type GetTimelineEventGroupByPayload<T extends TimelineEventGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<TimelineEventGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof TimelineEventGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], TimelineEventGroupByOutputType[P]>
            : GetScalarType<T[P], TimelineEventGroupByOutputType[P]>
        }
      >
    >


  export type TimelineEventSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    createdAt?: boolean
    details?: boolean
    caseId?: boolean
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["timelineEvent"]>

  export type TimelineEventSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    createdAt?: boolean
    details?: boolean
    caseId?: boolean
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["timelineEvent"]>

  export type TimelineEventSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    createdAt?: boolean
    details?: boolean
    caseId?: boolean
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["timelineEvent"]>

  export type TimelineEventSelectScalar = {
    id?: boolean
    createdAt?: boolean
    details?: boolean
    caseId?: boolean
  }

  export type TimelineEventOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "createdAt" | "details" | "caseId", ExtArgs["result"]["timelineEvent"]>
  export type TimelineEventInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }
  export type TimelineEventIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }
  export type TimelineEventIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }

  export type $TimelineEventPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "TimelineEvent"
    objects: {
      case: Prisma.$CasePayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      createdAt: Date
      details: string
      caseId: string
    }, ExtArgs["result"]["timelineEvent"]>
    composites: {}
  }

  type TimelineEventGetPayload<S extends boolean | null | undefined | TimelineEventDefaultArgs> = $Result.GetResult<Prisma.$TimelineEventPayload, S>

  type TimelineEventCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<TimelineEventFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: TimelineEventCountAggregateInputType | true
    }

  export interface TimelineEventDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['TimelineEvent'], meta: { name: 'TimelineEvent' } }
    /**
     * Find zero or one TimelineEvent that matches the filter.
     * @param {TimelineEventFindUniqueArgs} args - Arguments to find a TimelineEvent
     * @example
     * // Get one TimelineEvent
     * const timelineEvent = await prisma.timelineEvent.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends TimelineEventFindUniqueArgs>(args: SelectSubset<T, TimelineEventFindUniqueArgs<ExtArgs>>): Prisma__TimelineEventClient<$Result.GetResult<Prisma.$TimelineEventPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one TimelineEvent that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {TimelineEventFindUniqueOrThrowArgs} args - Arguments to find a TimelineEvent
     * @example
     * // Get one TimelineEvent
     * const timelineEvent = await prisma.timelineEvent.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends TimelineEventFindUniqueOrThrowArgs>(args: SelectSubset<T, TimelineEventFindUniqueOrThrowArgs<ExtArgs>>): Prisma__TimelineEventClient<$Result.GetResult<Prisma.$TimelineEventPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first TimelineEvent that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TimelineEventFindFirstArgs} args - Arguments to find a TimelineEvent
     * @example
     * // Get one TimelineEvent
     * const timelineEvent = await prisma.timelineEvent.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends TimelineEventFindFirstArgs>(args?: SelectSubset<T, TimelineEventFindFirstArgs<ExtArgs>>): Prisma__TimelineEventClient<$Result.GetResult<Prisma.$TimelineEventPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first TimelineEvent that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TimelineEventFindFirstOrThrowArgs} args - Arguments to find a TimelineEvent
     * @example
     * // Get one TimelineEvent
     * const timelineEvent = await prisma.timelineEvent.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends TimelineEventFindFirstOrThrowArgs>(args?: SelectSubset<T, TimelineEventFindFirstOrThrowArgs<ExtArgs>>): Prisma__TimelineEventClient<$Result.GetResult<Prisma.$TimelineEventPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more TimelineEvents that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TimelineEventFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all TimelineEvents
     * const timelineEvents = await prisma.timelineEvent.findMany()
     * 
     * // Get first 10 TimelineEvents
     * const timelineEvents = await prisma.timelineEvent.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const timelineEventWithIdOnly = await prisma.timelineEvent.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends TimelineEventFindManyArgs>(args?: SelectSubset<T, TimelineEventFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TimelineEventPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a TimelineEvent.
     * @param {TimelineEventCreateArgs} args - Arguments to create a TimelineEvent.
     * @example
     * // Create one TimelineEvent
     * const TimelineEvent = await prisma.timelineEvent.create({
     *   data: {
     *     // ... data to create a TimelineEvent
     *   }
     * })
     * 
     */
    create<T extends TimelineEventCreateArgs>(args: SelectSubset<T, TimelineEventCreateArgs<ExtArgs>>): Prisma__TimelineEventClient<$Result.GetResult<Prisma.$TimelineEventPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many TimelineEvents.
     * @param {TimelineEventCreateManyArgs} args - Arguments to create many TimelineEvents.
     * @example
     * // Create many TimelineEvents
     * const timelineEvent = await prisma.timelineEvent.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends TimelineEventCreateManyArgs>(args?: SelectSubset<T, TimelineEventCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many TimelineEvents and returns the data saved in the database.
     * @param {TimelineEventCreateManyAndReturnArgs} args - Arguments to create many TimelineEvents.
     * @example
     * // Create many TimelineEvents
     * const timelineEvent = await prisma.timelineEvent.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many TimelineEvents and only return the `id`
     * const timelineEventWithIdOnly = await prisma.timelineEvent.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends TimelineEventCreateManyAndReturnArgs>(args?: SelectSubset<T, TimelineEventCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TimelineEventPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a TimelineEvent.
     * @param {TimelineEventDeleteArgs} args - Arguments to delete one TimelineEvent.
     * @example
     * // Delete one TimelineEvent
     * const TimelineEvent = await prisma.timelineEvent.delete({
     *   where: {
     *     // ... filter to delete one TimelineEvent
     *   }
     * })
     * 
     */
    delete<T extends TimelineEventDeleteArgs>(args: SelectSubset<T, TimelineEventDeleteArgs<ExtArgs>>): Prisma__TimelineEventClient<$Result.GetResult<Prisma.$TimelineEventPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one TimelineEvent.
     * @param {TimelineEventUpdateArgs} args - Arguments to update one TimelineEvent.
     * @example
     * // Update one TimelineEvent
     * const timelineEvent = await prisma.timelineEvent.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends TimelineEventUpdateArgs>(args: SelectSubset<T, TimelineEventUpdateArgs<ExtArgs>>): Prisma__TimelineEventClient<$Result.GetResult<Prisma.$TimelineEventPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more TimelineEvents.
     * @param {TimelineEventDeleteManyArgs} args - Arguments to filter TimelineEvents to delete.
     * @example
     * // Delete a few TimelineEvents
     * const { count } = await prisma.timelineEvent.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends TimelineEventDeleteManyArgs>(args?: SelectSubset<T, TimelineEventDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more TimelineEvents.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TimelineEventUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many TimelineEvents
     * const timelineEvent = await prisma.timelineEvent.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends TimelineEventUpdateManyArgs>(args: SelectSubset<T, TimelineEventUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more TimelineEvents and returns the data updated in the database.
     * @param {TimelineEventUpdateManyAndReturnArgs} args - Arguments to update many TimelineEvents.
     * @example
     * // Update many TimelineEvents
     * const timelineEvent = await prisma.timelineEvent.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more TimelineEvents and only return the `id`
     * const timelineEventWithIdOnly = await prisma.timelineEvent.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends TimelineEventUpdateManyAndReturnArgs>(args: SelectSubset<T, TimelineEventUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TimelineEventPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one TimelineEvent.
     * @param {TimelineEventUpsertArgs} args - Arguments to update or create a TimelineEvent.
     * @example
     * // Update or create a TimelineEvent
     * const timelineEvent = await prisma.timelineEvent.upsert({
     *   create: {
     *     // ... data to create a TimelineEvent
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the TimelineEvent we want to update
     *   }
     * })
     */
    upsert<T extends TimelineEventUpsertArgs>(args: SelectSubset<T, TimelineEventUpsertArgs<ExtArgs>>): Prisma__TimelineEventClient<$Result.GetResult<Prisma.$TimelineEventPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of TimelineEvents.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TimelineEventCountArgs} args - Arguments to filter TimelineEvents to count.
     * @example
     * // Count the number of TimelineEvents
     * const count = await prisma.timelineEvent.count({
     *   where: {
     *     // ... the filter for the TimelineEvents we want to count
     *   }
     * })
    **/
    count<T extends TimelineEventCountArgs>(
      args?: Subset<T, TimelineEventCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], TimelineEventCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a TimelineEvent.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TimelineEventAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends TimelineEventAggregateArgs>(args: Subset<T, TimelineEventAggregateArgs>): Prisma.PrismaPromise<GetTimelineEventAggregateType<T>>

    /**
     * Group by TimelineEvent.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TimelineEventGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends TimelineEventGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: TimelineEventGroupByArgs['orderBy'] }
        : { orderBy?: TimelineEventGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, TimelineEventGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetTimelineEventGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the TimelineEvent model
   */
  readonly fields: TimelineEventFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for TimelineEvent.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__TimelineEventClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    case<T extends CaseDefaultArgs<ExtArgs> = {}>(args?: Subset<T, CaseDefaultArgs<ExtArgs>>): Prisma__CaseClient<$Result.GetResult<Prisma.$CasePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the TimelineEvent model
   */
  interface TimelineEventFieldRefs {
    readonly id: FieldRef<"TimelineEvent", 'String'>
    readonly createdAt: FieldRef<"TimelineEvent", 'DateTime'>
    readonly details: FieldRef<"TimelineEvent", 'String'>
    readonly caseId: FieldRef<"TimelineEvent", 'String'>
  }
    

  // Custom InputTypes
  /**
   * TimelineEvent findUnique
   */
  export type TimelineEventFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineEvent
     */
    select?: TimelineEventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineEvent
     */
    omit?: TimelineEventOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineEventInclude<ExtArgs> | null
    /**
     * Filter, which TimelineEvent to fetch.
     */
    where: TimelineEventWhereUniqueInput
  }

  /**
   * TimelineEvent findUniqueOrThrow
   */
  export type TimelineEventFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineEvent
     */
    select?: TimelineEventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineEvent
     */
    omit?: TimelineEventOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineEventInclude<ExtArgs> | null
    /**
     * Filter, which TimelineEvent to fetch.
     */
    where: TimelineEventWhereUniqueInput
  }

  /**
   * TimelineEvent findFirst
   */
  export type TimelineEventFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineEvent
     */
    select?: TimelineEventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineEvent
     */
    omit?: TimelineEventOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineEventInclude<ExtArgs> | null
    /**
     * Filter, which TimelineEvent to fetch.
     */
    where?: TimelineEventWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TimelineEvents to fetch.
     */
    orderBy?: TimelineEventOrderByWithRelationInput | TimelineEventOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for TimelineEvents.
     */
    cursor?: TimelineEventWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TimelineEvents from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TimelineEvents.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of TimelineEvents.
     */
    distinct?: TimelineEventScalarFieldEnum | TimelineEventScalarFieldEnum[]
  }

  /**
   * TimelineEvent findFirstOrThrow
   */
  export type TimelineEventFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineEvent
     */
    select?: TimelineEventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineEvent
     */
    omit?: TimelineEventOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineEventInclude<ExtArgs> | null
    /**
     * Filter, which TimelineEvent to fetch.
     */
    where?: TimelineEventWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TimelineEvents to fetch.
     */
    orderBy?: TimelineEventOrderByWithRelationInput | TimelineEventOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for TimelineEvents.
     */
    cursor?: TimelineEventWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TimelineEvents from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TimelineEvents.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of TimelineEvents.
     */
    distinct?: TimelineEventScalarFieldEnum | TimelineEventScalarFieldEnum[]
  }

  /**
   * TimelineEvent findMany
   */
  export type TimelineEventFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineEvent
     */
    select?: TimelineEventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineEvent
     */
    omit?: TimelineEventOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineEventInclude<ExtArgs> | null
    /**
     * Filter, which TimelineEvents to fetch.
     */
    where?: TimelineEventWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TimelineEvents to fetch.
     */
    orderBy?: TimelineEventOrderByWithRelationInput | TimelineEventOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing TimelineEvents.
     */
    cursor?: TimelineEventWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TimelineEvents from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TimelineEvents.
     */
    skip?: number
    distinct?: TimelineEventScalarFieldEnum | TimelineEventScalarFieldEnum[]
  }

  /**
   * TimelineEvent create
   */
  export type TimelineEventCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineEvent
     */
    select?: TimelineEventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineEvent
     */
    omit?: TimelineEventOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineEventInclude<ExtArgs> | null
    /**
     * The data needed to create a TimelineEvent.
     */
    data: XOR<TimelineEventCreateInput, TimelineEventUncheckedCreateInput>
  }

  /**
   * TimelineEvent createMany
   */
  export type TimelineEventCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many TimelineEvents.
     */
    data: TimelineEventCreateManyInput | TimelineEventCreateManyInput[]
  }

  /**
   * TimelineEvent createManyAndReturn
   */
  export type TimelineEventCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineEvent
     */
    select?: TimelineEventSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineEvent
     */
    omit?: TimelineEventOmit<ExtArgs> | null
    /**
     * The data used to create many TimelineEvents.
     */
    data: TimelineEventCreateManyInput | TimelineEventCreateManyInput[]
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineEventIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * TimelineEvent update
   */
  export type TimelineEventUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineEvent
     */
    select?: TimelineEventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineEvent
     */
    omit?: TimelineEventOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineEventInclude<ExtArgs> | null
    /**
     * The data needed to update a TimelineEvent.
     */
    data: XOR<TimelineEventUpdateInput, TimelineEventUncheckedUpdateInput>
    /**
     * Choose, which TimelineEvent to update.
     */
    where: TimelineEventWhereUniqueInput
  }

  /**
   * TimelineEvent updateMany
   */
  export type TimelineEventUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update TimelineEvents.
     */
    data: XOR<TimelineEventUpdateManyMutationInput, TimelineEventUncheckedUpdateManyInput>
    /**
     * Filter which TimelineEvents to update
     */
    where?: TimelineEventWhereInput
    /**
     * Limit how many TimelineEvents to update.
     */
    limit?: number
  }

  /**
   * TimelineEvent updateManyAndReturn
   */
  export type TimelineEventUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineEvent
     */
    select?: TimelineEventSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineEvent
     */
    omit?: TimelineEventOmit<ExtArgs> | null
    /**
     * The data used to update TimelineEvents.
     */
    data: XOR<TimelineEventUpdateManyMutationInput, TimelineEventUncheckedUpdateManyInput>
    /**
     * Filter which TimelineEvents to update
     */
    where?: TimelineEventWhereInput
    /**
     * Limit how many TimelineEvents to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineEventIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * TimelineEvent upsert
   */
  export type TimelineEventUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineEvent
     */
    select?: TimelineEventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineEvent
     */
    omit?: TimelineEventOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineEventInclude<ExtArgs> | null
    /**
     * The filter to search for the TimelineEvent to update in case it exists.
     */
    where: TimelineEventWhereUniqueInput
    /**
     * In case the TimelineEvent found by the `where` argument doesn't exist, create a new TimelineEvent with this data.
     */
    create: XOR<TimelineEventCreateInput, TimelineEventUncheckedCreateInput>
    /**
     * In case the TimelineEvent was found with the provided `where` argument, update it with this data.
     */
    update: XOR<TimelineEventUpdateInput, TimelineEventUncheckedUpdateInput>
  }

  /**
   * TimelineEvent delete
   */
  export type TimelineEventDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineEvent
     */
    select?: TimelineEventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineEvent
     */
    omit?: TimelineEventOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineEventInclude<ExtArgs> | null
    /**
     * Filter which TimelineEvent to delete.
     */
    where: TimelineEventWhereUniqueInput
  }

  /**
   * TimelineEvent deleteMany
   */
  export type TimelineEventDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which TimelineEvents to delete
     */
    where?: TimelineEventWhereInput
    /**
     * Limit how many TimelineEvents to delete.
     */
    limit?: number
  }

  /**
   * TimelineEvent without action
   */
  export type TimelineEventDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineEvent
     */
    select?: TimelineEventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineEvent
     */
    omit?: TimelineEventOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineEventInclude<ExtArgs> | null
  }


  /**
   * Model Message
   */

  export type AggregateMessage = {
    _count: MessageCountAggregateOutputType | null
    _min: MessageMinAggregateOutputType | null
    _max: MessageMaxAggregateOutputType | null
  }

  export type MessageMinAggregateOutputType = {
    id: string | null
    createdAt: Date | null
    body: string | null
    caseId: string | null
  }

  export type MessageMaxAggregateOutputType = {
    id: string | null
    createdAt: Date | null
    body: string | null
    caseId: string | null
  }

  export type MessageCountAggregateOutputType = {
    id: number
    createdAt: number
    body: number
    caseId: number
    _all: number
  }


  export type MessageMinAggregateInputType = {
    id?: true
    createdAt?: true
    body?: true
    caseId?: true
  }

  export type MessageMaxAggregateInputType = {
    id?: true
    createdAt?: true
    body?: true
    caseId?: true
  }

  export type MessageCountAggregateInputType = {
    id?: true
    createdAt?: true
    body?: true
    caseId?: true
    _all?: true
  }

  export type MessageAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Message to aggregate.
     */
    where?: MessageWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Messages to fetch.
     */
    orderBy?: MessageOrderByWithRelationInput | MessageOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: MessageWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Messages from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Messages.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Messages
    **/
    _count?: true | MessageCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: MessageMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: MessageMaxAggregateInputType
  }

  export type GetMessageAggregateType<T extends MessageAggregateArgs> = {
        [P in keyof T & keyof AggregateMessage]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateMessage[P]>
      : GetScalarType<T[P], AggregateMessage[P]>
  }




  export type MessageGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MessageWhereInput
    orderBy?: MessageOrderByWithAggregationInput | MessageOrderByWithAggregationInput[]
    by: MessageScalarFieldEnum[] | MessageScalarFieldEnum
    having?: MessageScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: MessageCountAggregateInputType | true
    _min?: MessageMinAggregateInputType
    _max?: MessageMaxAggregateInputType
  }

  export type MessageGroupByOutputType = {
    id: string
    createdAt: Date
    body: string
    caseId: string
    _count: MessageCountAggregateOutputType | null
    _min: MessageMinAggregateOutputType | null
    _max: MessageMaxAggregateOutputType | null
  }

  type GetMessageGroupByPayload<T extends MessageGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<MessageGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof MessageGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], MessageGroupByOutputType[P]>
            : GetScalarType<T[P], MessageGroupByOutputType[P]>
        }
      >
    >


  export type MessageSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    createdAt?: boolean
    body?: boolean
    caseId?: boolean
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["message"]>

  export type MessageSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    createdAt?: boolean
    body?: boolean
    caseId?: boolean
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["message"]>

  export type MessageSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    createdAt?: boolean
    body?: boolean
    caseId?: boolean
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["message"]>

  export type MessageSelectScalar = {
    id?: boolean
    createdAt?: boolean
    body?: boolean
    caseId?: boolean
  }

  export type MessageOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "createdAt" | "body" | "caseId", ExtArgs["result"]["message"]>
  export type MessageInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }
  export type MessageIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }
  export type MessageIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    case?: boolean | CaseDefaultArgs<ExtArgs>
  }

  export type $MessagePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Message"
    objects: {
      case: Prisma.$CasePayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      createdAt: Date
      body: string
      caseId: string
    }, ExtArgs["result"]["message"]>
    composites: {}
  }

  type MessageGetPayload<S extends boolean | null | undefined | MessageDefaultArgs> = $Result.GetResult<Prisma.$MessagePayload, S>

  type MessageCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<MessageFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: MessageCountAggregateInputType | true
    }

  export interface MessageDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Message'], meta: { name: 'Message' } }
    /**
     * Find zero or one Message that matches the filter.
     * @param {MessageFindUniqueArgs} args - Arguments to find a Message
     * @example
     * // Get one Message
     * const message = await prisma.message.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends MessageFindUniqueArgs>(args: SelectSubset<T, MessageFindUniqueArgs<ExtArgs>>): Prisma__MessageClient<$Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Message that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {MessageFindUniqueOrThrowArgs} args - Arguments to find a Message
     * @example
     * // Get one Message
     * const message = await prisma.message.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends MessageFindUniqueOrThrowArgs>(args: SelectSubset<T, MessageFindUniqueOrThrowArgs<ExtArgs>>): Prisma__MessageClient<$Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Message that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MessageFindFirstArgs} args - Arguments to find a Message
     * @example
     * // Get one Message
     * const message = await prisma.message.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends MessageFindFirstArgs>(args?: SelectSubset<T, MessageFindFirstArgs<ExtArgs>>): Prisma__MessageClient<$Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Message that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MessageFindFirstOrThrowArgs} args - Arguments to find a Message
     * @example
     * // Get one Message
     * const message = await prisma.message.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends MessageFindFirstOrThrowArgs>(args?: SelectSubset<T, MessageFindFirstOrThrowArgs<ExtArgs>>): Prisma__MessageClient<$Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Messages that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MessageFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Messages
     * const messages = await prisma.message.findMany()
     * 
     * // Get first 10 Messages
     * const messages = await prisma.message.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const messageWithIdOnly = await prisma.message.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends MessageFindManyArgs>(args?: SelectSubset<T, MessageFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Message.
     * @param {MessageCreateArgs} args - Arguments to create a Message.
     * @example
     * // Create one Message
     * const Message = await prisma.message.create({
     *   data: {
     *     // ... data to create a Message
     *   }
     * })
     * 
     */
    create<T extends MessageCreateArgs>(args: SelectSubset<T, MessageCreateArgs<ExtArgs>>): Prisma__MessageClient<$Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Messages.
     * @param {MessageCreateManyArgs} args - Arguments to create many Messages.
     * @example
     * // Create many Messages
     * const message = await prisma.message.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends MessageCreateManyArgs>(args?: SelectSubset<T, MessageCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Messages and returns the data saved in the database.
     * @param {MessageCreateManyAndReturnArgs} args - Arguments to create many Messages.
     * @example
     * // Create many Messages
     * const message = await prisma.message.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Messages and only return the `id`
     * const messageWithIdOnly = await prisma.message.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends MessageCreateManyAndReturnArgs>(args?: SelectSubset<T, MessageCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Message.
     * @param {MessageDeleteArgs} args - Arguments to delete one Message.
     * @example
     * // Delete one Message
     * const Message = await prisma.message.delete({
     *   where: {
     *     // ... filter to delete one Message
     *   }
     * })
     * 
     */
    delete<T extends MessageDeleteArgs>(args: SelectSubset<T, MessageDeleteArgs<ExtArgs>>): Prisma__MessageClient<$Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Message.
     * @param {MessageUpdateArgs} args - Arguments to update one Message.
     * @example
     * // Update one Message
     * const message = await prisma.message.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends MessageUpdateArgs>(args: SelectSubset<T, MessageUpdateArgs<ExtArgs>>): Prisma__MessageClient<$Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Messages.
     * @param {MessageDeleteManyArgs} args - Arguments to filter Messages to delete.
     * @example
     * // Delete a few Messages
     * const { count } = await prisma.message.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends MessageDeleteManyArgs>(args?: SelectSubset<T, MessageDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Messages.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MessageUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Messages
     * const message = await prisma.message.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends MessageUpdateManyArgs>(args: SelectSubset<T, MessageUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Messages and returns the data updated in the database.
     * @param {MessageUpdateManyAndReturnArgs} args - Arguments to update many Messages.
     * @example
     * // Update many Messages
     * const message = await prisma.message.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Messages and only return the `id`
     * const messageWithIdOnly = await prisma.message.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends MessageUpdateManyAndReturnArgs>(args: SelectSubset<T, MessageUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Message.
     * @param {MessageUpsertArgs} args - Arguments to update or create a Message.
     * @example
     * // Update or create a Message
     * const message = await prisma.message.upsert({
     *   create: {
     *     // ... data to create a Message
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Message we want to update
     *   }
     * })
     */
    upsert<T extends MessageUpsertArgs>(args: SelectSubset<T, MessageUpsertArgs<ExtArgs>>): Prisma__MessageClient<$Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Messages.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MessageCountArgs} args - Arguments to filter Messages to count.
     * @example
     * // Count the number of Messages
     * const count = await prisma.message.count({
     *   where: {
     *     // ... the filter for the Messages we want to count
     *   }
     * })
    **/
    count<T extends MessageCountArgs>(
      args?: Subset<T, MessageCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], MessageCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Message.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MessageAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends MessageAggregateArgs>(args: Subset<T, MessageAggregateArgs>): Prisma.PrismaPromise<GetMessageAggregateType<T>>

    /**
     * Group by Message.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MessageGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends MessageGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: MessageGroupByArgs['orderBy'] }
        : { orderBy?: MessageGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, MessageGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetMessageGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Message model
   */
  readonly fields: MessageFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Message.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__MessageClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    case<T extends CaseDefaultArgs<ExtArgs> = {}>(args?: Subset<T, CaseDefaultArgs<ExtArgs>>): Prisma__CaseClient<$Result.GetResult<Prisma.$CasePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Message model
   */
  interface MessageFieldRefs {
    readonly id: FieldRef<"Message", 'String'>
    readonly createdAt: FieldRef<"Message", 'DateTime'>
    readonly body: FieldRef<"Message", 'String'>
    readonly caseId: FieldRef<"Message", 'String'>
  }
    

  // Custom InputTypes
  /**
   * Message findUnique
   */
  export type MessageFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInclude<ExtArgs> | null
    /**
     * Filter, which Message to fetch.
     */
    where: MessageWhereUniqueInput
  }

  /**
   * Message findUniqueOrThrow
   */
  export type MessageFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInclude<ExtArgs> | null
    /**
     * Filter, which Message to fetch.
     */
    where: MessageWhereUniqueInput
  }

  /**
   * Message findFirst
   */
  export type MessageFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInclude<ExtArgs> | null
    /**
     * Filter, which Message to fetch.
     */
    where?: MessageWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Messages to fetch.
     */
    orderBy?: MessageOrderByWithRelationInput | MessageOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Messages.
     */
    cursor?: MessageWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Messages from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Messages.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Messages.
     */
    distinct?: MessageScalarFieldEnum | MessageScalarFieldEnum[]
  }

  /**
   * Message findFirstOrThrow
   */
  export type MessageFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInclude<ExtArgs> | null
    /**
     * Filter, which Message to fetch.
     */
    where?: MessageWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Messages to fetch.
     */
    orderBy?: MessageOrderByWithRelationInput | MessageOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Messages.
     */
    cursor?: MessageWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Messages from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Messages.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Messages.
     */
    distinct?: MessageScalarFieldEnum | MessageScalarFieldEnum[]
  }

  /**
   * Message findMany
   */
  export type MessageFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInclude<ExtArgs> | null
    /**
     * Filter, which Messages to fetch.
     */
    where?: MessageWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Messages to fetch.
     */
    orderBy?: MessageOrderByWithRelationInput | MessageOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Messages.
     */
    cursor?: MessageWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Messages from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Messages.
     */
    skip?: number
    distinct?: MessageScalarFieldEnum | MessageScalarFieldEnum[]
  }

  /**
   * Message create
   */
  export type MessageCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInclude<ExtArgs> | null
    /**
     * The data needed to create a Message.
     */
    data: XOR<MessageCreateInput, MessageUncheckedCreateInput>
  }

  /**
   * Message createMany
   */
  export type MessageCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Messages.
     */
    data: MessageCreateManyInput | MessageCreateManyInput[]
  }

  /**
   * Message createManyAndReturn
   */
  export type MessageCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * The data used to create many Messages.
     */
    data: MessageCreateManyInput | MessageCreateManyInput[]
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Message update
   */
  export type MessageUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInclude<ExtArgs> | null
    /**
     * The data needed to update a Message.
     */
    data: XOR<MessageUpdateInput, MessageUncheckedUpdateInput>
    /**
     * Choose, which Message to update.
     */
    where: MessageWhereUniqueInput
  }

  /**
   * Message updateMany
   */
  export type MessageUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Messages.
     */
    data: XOR<MessageUpdateManyMutationInput, MessageUncheckedUpdateManyInput>
    /**
     * Filter which Messages to update
     */
    where?: MessageWhereInput
    /**
     * Limit how many Messages to update.
     */
    limit?: number
  }

  /**
   * Message updateManyAndReturn
   */
  export type MessageUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * The data used to update Messages.
     */
    data: XOR<MessageUpdateManyMutationInput, MessageUncheckedUpdateManyInput>
    /**
     * Filter which Messages to update
     */
    where?: MessageWhereInput
    /**
     * Limit how many Messages to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Message upsert
   */
  export type MessageUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInclude<ExtArgs> | null
    /**
     * The filter to search for the Message to update in case it exists.
     */
    where: MessageWhereUniqueInput
    /**
     * In case the Message found by the `where` argument doesn't exist, create a new Message with this data.
     */
    create: XOR<MessageCreateInput, MessageUncheckedCreateInput>
    /**
     * In case the Message was found with the provided `where` argument, update it with this data.
     */
    update: XOR<MessageUpdateInput, MessageUncheckedUpdateInput>
  }

  /**
   * Message delete
   */
  export type MessageDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInclude<ExtArgs> | null
    /**
     * Filter which Message to delete.
     */
    where: MessageWhereUniqueInput
  }

  /**
   * Message deleteMany
   */
  export type MessageDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Messages to delete
     */
    where?: MessageWhereInput
    /**
     * Limit how many Messages to delete.
     */
    limit?: number
  }

  /**
   * Message without action
   */
  export type MessageDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInclude<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const UserScalarFieldEnum: {
    id: 'id',
    email: 'email',
    name: 'name',
    role: 'role',
    password: 'password'
  };

  export type UserScalarFieldEnum = (typeof UserScalarFieldEnum)[keyof typeof UserScalarFieldEnum]


  export const CaseScalarFieldEnum: {
    id: 'id',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt',
    title: 'title',
    caseNumber: 'caseNumber',
    totalFee: 'totalFee',
    currency: 'currency',
    applicantName: 'applicantName',
    applicantEmail: 'applicantEmail',
    overallStatus: 'overallStatus',
    stage: 'stage',
    urgencyLevel: 'urgencyLevel',
    completionPercentage: 'completionPercentage',
    clientId: 'clientId',
    caseManagerId: 'caseManagerId',
    lawyerId: 'lawyerId'
  };

  export type CaseScalarFieldEnum = (typeof CaseScalarFieldEnum)[keyof typeof CaseScalarFieldEnum]


  export const PartnerRoleScalarFieldEnum: {
    id: 'id',
    name: 'name'
  };

  export type PartnerRoleScalarFieldEnum = (typeof PartnerRoleScalarFieldEnum)[keyof typeof PartnerRoleScalarFieldEnum]


  export const ExternalPartnerScalarFieldEnum: {
    id: 'id',
    name: 'name',
    email: 'email',
    type: 'type',
    caseId: 'caseId',
    roleId: 'roleId'
  };

  export type ExternalPartnerScalarFieldEnum = (typeof ExternalPartnerScalarFieldEnum)[keyof typeof ExternalPartnerScalarFieldEnum]


  export const ExternalCommunicationScalarFieldEnum: {
    id: 'id',
    createdAt: 'createdAt',
    direction: 'direction',
    body: 'body',
    sender: 'sender',
    caseId: 'caseId'
  };

  export type ExternalCommunicationScalarFieldEnum = (typeof ExternalCommunicationScalarFieldEnum)[keyof typeof ExternalCommunicationScalarFieldEnum]


  export const DocumentScalarFieldEnum: {
    id: 'id',
    name: 'name',
    state: 'state',
    caseId: 'caseId'
  };

  export type DocumentScalarFieldEnum = (typeof DocumentScalarFieldEnum)[keyof typeof DocumentScalarFieldEnum]


  export const PaymentScalarFieldEnum: {
    id: 'id',
    amount: 'amount',
    currency: 'currency',
    status: 'status',
    description: 'description',
    invoiceNumber: 'invoiceNumber',
    caseId: 'caseId'
  };

  export type PaymentScalarFieldEnum = (typeof PaymentScalarFieldEnum)[keyof typeof PaymentScalarFieldEnum]


  export const TimelineEventScalarFieldEnum: {
    id: 'id',
    createdAt: 'createdAt',
    details: 'details',
    caseId: 'caseId'
  };

  export type TimelineEventScalarFieldEnum = (typeof TimelineEventScalarFieldEnum)[keyof typeof TimelineEventScalarFieldEnum]


  export const MessageScalarFieldEnum: {
    id: 'id',
    createdAt: 'createdAt',
    body: 'body',
    caseId: 'caseId'
  };

  export type MessageScalarFieldEnum = (typeof MessageScalarFieldEnum)[keyof typeof MessageScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'Role'
   */
  export type EnumRoleFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Role'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'CaseStatus'
   */
  export type EnumCaseStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'CaseStatus'>
    


  /**
   * Reference to a field of type 'Direction'
   */
  export type EnumDirectionFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Direction'>
    


  /**
   * Reference to a field of type 'DocState'
   */
  export type EnumDocStateFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DocState'>
    


  /**
   * Reference to a field of type 'PaymentStatus'
   */
  export type EnumPaymentStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'PaymentStatus'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    
  /**
   * Deep Input Types
   */


  export type UserWhereInput = {
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    id?: StringFilter<"User"> | string
    email?: StringFilter<"User"> | string
    name?: StringNullableFilter<"User"> | string | null
    role?: EnumRoleFilter<"User"> | $Enums.Role
    password?: StringNullableFilter<"User"> | string | null
    casesAsClient?: CaseListRelationFilter
    casesAsManager?: CaseListRelationFilter
    casesAsLawyer?: CaseListRelationFilter
  }

  export type UserOrderByWithRelationInput = {
    id?: SortOrder
    email?: SortOrder
    name?: SortOrderInput | SortOrder
    role?: SortOrder
    password?: SortOrderInput | SortOrder
    casesAsClient?: CaseOrderByRelationAggregateInput
    casesAsManager?: CaseOrderByRelationAggregateInput
    casesAsLawyer?: CaseOrderByRelationAggregateInput
  }

  export type UserWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    email?: string
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    name?: StringNullableFilter<"User"> | string | null
    role?: EnumRoleFilter<"User"> | $Enums.Role
    password?: StringNullableFilter<"User"> | string | null
    casesAsClient?: CaseListRelationFilter
    casesAsManager?: CaseListRelationFilter
    casesAsLawyer?: CaseListRelationFilter
  }, "id" | "email">

  export type UserOrderByWithAggregationInput = {
    id?: SortOrder
    email?: SortOrder
    name?: SortOrderInput | SortOrder
    role?: SortOrder
    password?: SortOrderInput | SortOrder
    _count?: UserCountOrderByAggregateInput
    _max?: UserMaxOrderByAggregateInput
    _min?: UserMinOrderByAggregateInput
  }

  export type UserScalarWhereWithAggregatesInput = {
    AND?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    OR?: UserScalarWhereWithAggregatesInput[]
    NOT?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"User"> | string
    email?: StringWithAggregatesFilter<"User"> | string
    name?: StringNullableWithAggregatesFilter<"User"> | string | null
    role?: EnumRoleWithAggregatesFilter<"User"> | $Enums.Role
    password?: StringNullableWithAggregatesFilter<"User"> | string | null
  }

  export type CaseWhereInput = {
    AND?: CaseWhereInput | CaseWhereInput[]
    OR?: CaseWhereInput[]
    NOT?: CaseWhereInput | CaseWhereInput[]
    id?: StringFilter<"Case"> | string
    createdAt?: DateTimeFilter<"Case"> | Date | string
    updatedAt?: DateTimeFilter<"Case"> | Date | string
    title?: StringFilter<"Case"> | string
    caseNumber?: StringFilter<"Case"> | string
    totalFee?: IntFilter<"Case"> | number
    currency?: StringFilter<"Case"> | string
    applicantName?: StringFilter<"Case"> | string
    applicantEmail?: StringFilter<"Case"> | string
    overallStatus?: EnumCaseStatusFilter<"Case"> | $Enums.CaseStatus
    stage?: StringFilter<"Case"> | string
    urgencyLevel?: StringFilter<"Case"> | string
    completionPercentage?: IntFilter<"Case"> | number
    clientId?: StringNullableFilter<"Case"> | string | null
    caseManagerId?: StringNullableFilter<"Case"> | string | null
    lawyerId?: StringNullableFilter<"Case"> | string | null
    client?: XOR<UserNullableScalarRelationFilter, UserWhereInput> | null
    caseManager?: XOR<UserNullableScalarRelationFilter, UserWhereInput> | null
    lawyer?: XOR<UserNullableScalarRelationFilter, UserWhereInput> | null
    documents?: DocumentListRelationFilter
    payments?: PaymentListRelationFilter
    timelineEvents?: TimelineEventListRelationFilter
    internalMessages?: MessageListRelationFilter
    externalPartners?: ExternalPartnerListRelationFilter
    externalComms?: ExternalCommunicationListRelationFilter
  }

  export type CaseOrderByWithRelationInput = {
    id?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    title?: SortOrder
    caseNumber?: SortOrder
    totalFee?: SortOrder
    currency?: SortOrder
    applicantName?: SortOrder
    applicantEmail?: SortOrder
    overallStatus?: SortOrder
    stage?: SortOrder
    urgencyLevel?: SortOrder
    completionPercentage?: SortOrder
    clientId?: SortOrderInput | SortOrder
    caseManagerId?: SortOrderInput | SortOrder
    lawyerId?: SortOrderInput | SortOrder
    client?: UserOrderByWithRelationInput
    caseManager?: UserOrderByWithRelationInput
    lawyer?: UserOrderByWithRelationInput
    documents?: DocumentOrderByRelationAggregateInput
    payments?: PaymentOrderByRelationAggregateInput
    timelineEvents?: TimelineEventOrderByRelationAggregateInput
    internalMessages?: MessageOrderByRelationAggregateInput
    externalPartners?: ExternalPartnerOrderByRelationAggregateInput
    externalComms?: ExternalCommunicationOrderByRelationAggregateInput
  }

  export type CaseWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    caseNumber?: string
    AND?: CaseWhereInput | CaseWhereInput[]
    OR?: CaseWhereInput[]
    NOT?: CaseWhereInput | CaseWhereInput[]
    createdAt?: DateTimeFilter<"Case"> | Date | string
    updatedAt?: DateTimeFilter<"Case"> | Date | string
    title?: StringFilter<"Case"> | string
    totalFee?: IntFilter<"Case"> | number
    currency?: StringFilter<"Case"> | string
    applicantName?: StringFilter<"Case"> | string
    applicantEmail?: StringFilter<"Case"> | string
    overallStatus?: EnumCaseStatusFilter<"Case"> | $Enums.CaseStatus
    stage?: StringFilter<"Case"> | string
    urgencyLevel?: StringFilter<"Case"> | string
    completionPercentage?: IntFilter<"Case"> | number
    clientId?: StringNullableFilter<"Case"> | string | null
    caseManagerId?: StringNullableFilter<"Case"> | string | null
    lawyerId?: StringNullableFilter<"Case"> | string | null
    client?: XOR<UserNullableScalarRelationFilter, UserWhereInput> | null
    caseManager?: XOR<UserNullableScalarRelationFilter, UserWhereInput> | null
    lawyer?: XOR<UserNullableScalarRelationFilter, UserWhereInput> | null
    documents?: DocumentListRelationFilter
    payments?: PaymentListRelationFilter
    timelineEvents?: TimelineEventListRelationFilter
    internalMessages?: MessageListRelationFilter
    externalPartners?: ExternalPartnerListRelationFilter
    externalComms?: ExternalCommunicationListRelationFilter
  }, "id" | "caseNumber">

  export type CaseOrderByWithAggregationInput = {
    id?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    title?: SortOrder
    caseNumber?: SortOrder
    totalFee?: SortOrder
    currency?: SortOrder
    applicantName?: SortOrder
    applicantEmail?: SortOrder
    overallStatus?: SortOrder
    stage?: SortOrder
    urgencyLevel?: SortOrder
    completionPercentage?: SortOrder
    clientId?: SortOrderInput | SortOrder
    caseManagerId?: SortOrderInput | SortOrder
    lawyerId?: SortOrderInput | SortOrder
    _count?: CaseCountOrderByAggregateInput
    _avg?: CaseAvgOrderByAggregateInput
    _max?: CaseMaxOrderByAggregateInput
    _min?: CaseMinOrderByAggregateInput
    _sum?: CaseSumOrderByAggregateInput
  }

  export type CaseScalarWhereWithAggregatesInput = {
    AND?: CaseScalarWhereWithAggregatesInput | CaseScalarWhereWithAggregatesInput[]
    OR?: CaseScalarWhereWithAggregatesInput[]
    NOT?: CaseScalarWhereWithAggregatesInput | CaseScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Case"> | string
    createdAt?: DateTimeWithAggregatesFilter<"Case"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Case"> | Date | string
    title?: StringWithAggregatesFilter<"Case"> | string
    caseNumber?: StringWithAggregatesFilter<"Case"> | string
    totalFee?: IntWithAggregatesFilter<"Case"> | number
    currency?: StringWithAggregatesFilter<"Case"> | string
    applicantName?: StringWithAggregatesFilter<"Case"> | string
    applicantEmail?: StringWithAggregatesFilter<"Case"> | string
    overallStatus?: EnumCaseStatusWithAggregatesFilter<"Case"> | $Enums.CaseStatus
    stage?: StringWithAggregatesFilter<"Case"> | string
    urgencyLevel?: StringWithAggregatesFilter<"Case"> | string
    completionPercentage?: IntWithAggregatesFilter<"Case"> | number
    clientId?: StringNullableWithAggregatesFilter<"Case"> | string | null
    caseManagerId?: StringNullableWithAggregatesFilter<"Case"> | string | null
    lawyerId?: StringNullableWithAggregatesFilter<"Case"> | string | null
  }

  export type PartnerRoleWhereInput = {
    AND?: PartnerRoleWhereInput | PartnerRoleWhereInput[]
    OR?: PartnerRoleWhereInput[]
    NOT?: PartnerRoleWhereInput | PartnerRoleWhereInput[]
    id?: StringFilter<"PartnerRole"> | string
    name?: StringFilter<"PartnerRole"> | string
    partners?: ExternalPartnerListRelationFilter
  }

  export type PartnerRoleOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    partners?: ExternalPartnerOrderByRelationAggregateInput
  }

  export type PartnerRoleWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    name?: string
    AND?: PartnerRoleWhereInput | PartnerRoleWhereInput[]
    OR?: PartnerRoleWhereInput[]
    NOT?: PartnerRoleWhereInput | PartnerRoleWhereInput[]
    partners?: ExternalPartnerListRelationFilter
  }, "id" | "name">

  export type PartnerRoleOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    _count?: PartnerRoleCountOrderByAggregateInput
    _max?: PartnerRoleMaxOrderByAggregateInput
    _min?: PartnerRoleMinOrderByAggregateInput
  }

  export type PartnerRoleScalarWhereWithAggregatesInput = {
    AND?: PartnerRoleScalarWhereWithAggregatesInput | PartnerRoleScalarWhereWithAggregatesInput[]
    OR?: PartnerRoleScalarWhereWithAggregatesInput[]
    NOT?: PartnerRoleScalarWhereWithAggregatesInput | PartnerRoleScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"PartnerRole"> | string
    name?: StringWithAggregatesFilter<"PartnerRole"> | string
  }

  export type ExternalPartnerWhereInput = {
    AND?: ExternalPartnerWhereInput | ExternalPartnerWhereInput[]
    OR?: ExternalPartnerWhereInput[]
    NOT?: ExternalPartnerWhereInput | ExternalPartnerWhereInput[]
    id?: StringFilter<"ExternalPartner"> | string
    name?: StringFilter<"ExternalPartner"> | string
    email?: StringNullableFilter<"ExternalPartner"> | string | null
    type?: StringFilter<"ExternalPartner"> | string
    caseId?: StringFilter<"ExternalPartner"> | string
    roleId?: StringFilter<"ExternalPartner"> | string
    case?: XOR<CaseScalarRelationFilter, CaseWhereInput>
    role?: XOR<PartnerRoleScalarRelationFilter, PartnerRoleWhereInput>
  }

  export type ExternalPartnerOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrderInput | SortOrder
    type?: SortOrder
    caseId?: SortOrder
    roleId?: SortOrder
    case?: CaseOrderByWithRelationInput
    role?: PartnerRoleOrderByWithRelationInput
  }

  export type ExternalPartnerWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: ExternalPartnerWhereInput | ExternalPartnerWhereInput[]
    OR?: ExternalPartnerWhereInput[]
    NOT?: ExternalPartnerWhereInput | ExternalPartnerWhereInput[]
    name?: StringFilter<"ExternalPartner"> | string
    email?: StringNullableFilter<"ExternalPartner"> | string | null
    type?: StringFilter<"ExternalPartner"> | string
    caseId?: StringFilter<"ExternalPartner"> | string
    roleId?: StringFilter<"ExternalPartner"> | string
    case?: XOR<CaseScalarRelationFilter, CaseWhereInput>
    role?: XOR<PartnerRoleScalarRelationFilter, PartnerRoleWhereInput>
  }, "id">

  export type ExternalPartnerOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrderInput | SortOrder
    type?: SortOrder
    caseId?: SortOrder
    roleId?: SortOrder
    _count?: ExternalPartnerCountOrderByAggregateInput
    _max?: ExternalPartnerMaxOrderByAggregateInput
    _min?: ExternalPartnerMinOrderByAggregateInput
  }

  export type ExternalPartnerScalarWhereWithAggregatesInput = {
    AND?: ExternalPartnerScalarWhereWithAggregatesInput | ExternalPartnerScalarWhereWithAggregatesInput[]
    OR?: ExternalPartnerScalarWhereWithAggregatesInput[]
    NOT?: ExternalPartnerScalarWhereWithAggregatesInput | ExternalPartnerScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"ExternalPartner"> | string
    name?: StringWithAggregatesFilter<"ExternalPartner"> | string
    email?: StringNullableWithAggregatesFilter<"ExternalPartner"> | string | null
    type?: StringWithAggregatesFilter<"ExternalPartner"> | string
    caseId?: StringWithAggregatesFilter<"ExternalPartner"> | string
    roleId?: StringWithAggregatesFilter<"ExternalPartner"> | string
  }

  export type ExternalCommunicationWhereInput = {
    AND?: ExternalCommunicationWhereInput | ExternalCommunicationWhereInput[]
    OR?: ExternalCommunicationWhereInput[]
    NOT?: ExternalCommunicationWhereInput | ExternalCommunicationWhereInput[]
    id?: StringFilter<"ExternalCommunication"> | string
    createdAt?: DateTimeFilter<"ExternalCommunication"> | Date | string
    direction?: EnumDirectionFilter<"ExternalCommunication"> | $Enums.Direction
    body?: StringFilter<"ExternalCommunication"> | string
    sender?: StringFilter<"ExternalCommunication"> | string
    caseId?: StringFilter<"ExternalCommunication"> | string
    case?: XOR<CaseScalarRelationFilter, CaseWhereInput>
  }

  export type ExternalCommunicationOrderByWithRelationInput = {
    id?: SortOrder
    createdAt?: SortOrder
    direction?: SortOrder
    body?: SortOrder
    sender?: SortOrder
    caseId?: SortOrder
    case?: CaseOrderByWithRelationInput
  }

  export type ExternalCommunicationWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: ExternalCommunicationWhereInput | ExternalCommunicationWhereInput[]
    OR?: ExternalCommunicationWhereInput[]
    NOT?: ExternalCommunicationWhereInput | ExternalCommunicationWhereInput[]
    createdAt?: DateTimeFilter<"ExternalCommunication"> | Date | string
    direction?: EnumDirectionFilter<"ExternalCommunication"> | $Enums.Direction
    body?: StringFilter<"ExternalCommunication"> | string
    sender?: StringFilter<"ExternalCommunication"> | string
    caseId?: StringFilter<"ExternalCommunication"> | string
    case?: XOR<CaseScalarRelationFilter, CaseWhereInput>
  }, "id">

  export type ExternalCommunicationOrderByWithAggregationInput = {
    id?: SortOrder
    createdAt?: SortOrder
    direction?: SortOrder
    body?: SortOrder
    sender?: SortOrder
    caseId?: SortOrder
    _count?: ExternalCommunicationCountOrderByAggregateInput
    _max?: ExternalCommunicationMaxOrderByAggregateInput
    _min?: ExternalCommunicationMinOrderByAggregateInput
  }

  export type ExternalCommunicationScalarWhereWithAggregatesInput = {
    AND?: ExternalCommunicationScalarWhereWithAggregatesInput | ExternalCommunicationScalarWhereWithAggregatesInput[]
    OR?: ExternalCommunicationScalarWhereWithAggregatesInput[]
    NOT?: ExternalCommunicationScalarWhereWithAggregatesInput | ExternalCommunicationScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"ExternalCommunication"> | string
    createdAt?: DateTimeWithAggregatesFilter<"ExternalCommunication"> | Date | string
    direction?: EnumDirectionWithAggregatesFilter<"ExternalCommunication"> | $Enums.Direction
    body?: StringWithAggregatesFilter<"ExternalCommunication"> | string
    sender?: StringWithAggregatesFilter<"ExternalCommunication"> | string
    caseId?: StringWithAggregatesFilter<"ExternalCommunication"> | string
  }

  export type DocumentWhereInput = {
    AND?: DocumentWhereInput | DocumentWhereInput[]
    OR?: DocumentWhereInput[]
    NOT?: DocumentWhereInput | DocumentWhereInput[]
    id?: StringFilter<"Document"> | string
    name?: StringFilter<"Document"> | string
    state?: EnumDocStateFilter<"Document"> | $Enums.DocState
    caseId?: StringFilter<"Document"> | string
    case?: XOR<CaseScalarRelationFilter, CaseWhereInput>
  }

  export type DocumentOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    state?: SortOrder
    caseId?: SortOrder
    case?: CaseOrderByWithRelationInput
  }

  export type DocumentWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: DocumentWhereInput | DocumentWhereInput[]
    OR?: DocumentWhereInput[]
    NOT?: DocumentWhereInput | DocumentWhereInput[]
    name?: StringFilter<"Document"> | string
    state?: EnumDocStateFilter<"Document"> | $Enums.DocState
    caseId?: StringFilter<"Document"> | string
    case?: XOR<CaseScalarRelationFilter, CaseWhereInput>
  }, "id">

  export type DocumentOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    state?: SortOrder
    caseId?: SortOrder
    _count?: DocumentCountOrderByAggregateInput
    _max?: DocumentMaxOrderByAggregateInput
    _min?: DocumentMinOrderByAggregateInput
  }

  export type DocumentScalarWhereWithAggregatesInput = {
    AND?: DocumentScalarWhereWithAggregatesInput | DocumentScalarWhereWithAggregatesInput[]
    OR?: DocumentScalarWhereWithAggregatesInput[]
    NOT?: DocumentScalarWhereWithAggregatesInput | DocumentScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Document"> | string
    name?: StringWithAggregatesFilter<"Document"> | string
    state?: EnumDocStateWithAggregatesFilter<"Document"> | $Enums.DocState
    caseId?: StringWithAggregatesFilter<"Document"> | string
  }

  export type PaymentWhereInput = {
    AND?: PaymentWhereInput | PaymentWhereInput[]
    OR?: PaymentWhereInput[]
    NOT?: PaymentWhereInput | PaymentWhereInput[]
    id?: StringFilter<"Payment"> | string
    amount?: IntFilter<"Payment"> | number
    currency?: StringFilter<"Payment"> | string
    status?: EnumPaymentStatusFilter<"Payment"> | $Enums.PaymentStatus
    description?: StringFilter<"Payment"> | string
    invoiceNumber?: StringFilter<"Payment"> | string
    caseId?: StringFilter<"Payment"> | string
    case?: XOR<CaseScalarRelationFilter, CaseWhereInput>
  }

  export type PaymentOrderByWithRelationInput = {
    id?: SortOrder
    amount?: SortOrder
    currency?: SortOrder
    status?: SortOrder
    description?: SortOrder
    invoiceNumber?: SortOrder
    caseId?: SortOrder
    case?: CaseOrderByWithRelationInput
  }

  export type PaymentWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: PaymentWhereInput | PaymentWhereInput[]
    OR?: PaymentWhereInput[]
    NOT?: PaymentWhereInput | PaymentWhereInput[]
    amount?: IntFilter<"Payment"> | number
    currency?: StringFilter<"Payment"> | string
    status?: EnumPaymentStatusFilter<"Payment"> | $Enums.PaymentStatus
    description?: StringFilter<"Payment"> | string
    invoiceNumber?: StringFilter<"Payment"> | string
    caseId?: StringFilter<"Payment"> | string
    case?: XOR<CaseScalarRelationFilter, CaseWhereInput>
  }, "id">

  export type PaymentOrderByWithAggregationInput = {
    id?: SortOrder
    amount?: SortOrder
    currency?: SortOrder
    status?: SortOrder
    description?: SortOrder
    invoiceNumber?: SortOrder
    caseId?: SortOrder
    _count?: PaymentCountOrderByAggregateInput
    _avg?: PaymentAvgOrderByAggregateInput
    _max?: PaymentMaxOrderByAggregateInput
    _min?: PaymentMinOrderByAggregateInput
    _sum?: PaymentSumOrderByAggregateInput
  }

  export type PaymentScalarWhereWithAggregatesInput = {
    AND?: PaymentScalarWhereWithAggregatesInput | PaymentScalarWhereWithAggregatesInput[]
    OR?: PaymentScalarWhereWithAggregatesInput[]
    NOT?: PaymentScalarWhereWithAggregatesInput | PaymentScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Payment"> | string
    amount?: IntWithAggregatesFilter<"Payment"> | number
    currency?: StringWithAggregatesFilter<"Payment"> | string
    status?: EnumPaymentStatusWithAggregatesFilter<"Payment"> | $Enums.PaymentStatus
    description?: StringWithAggregatesFilter<"Payment"> | string
    invoiceNumber?: StringWithAggregatesFilter<"Payment"> | string
    caseId?: StringWithAggregatesFilter<"Payment"> | string
  }

  export type TimelineEventWhereInput = {
    AND?: TimelineEventWhereInput | TimelineEventWhereInput[]
    OR?: TimelineEventWhereInput[]
    NOT?: TimelineEventWhereInput | TimelineEventWhereInput[]
    id?: StringFilter<"TimelineEvent"> | string
    createdAt?: DateTimeFilter<"TimelineEvent"> | Date | string
    details?: StringFilter<"TimelineEvent"> | string
    caseId?: StringFilter<"TimelineEvent"> | string
    case?: XOR<CaseScalarRelationFilter, CaseWhereInput>
  }

  export type TimelineEventOrderByWithRelationInput = {
    id?: SortOrder
    createdAt?: SortOrder
    details?: SortOrder
    caseId?: SortOrder
    case?: CaseOrderByWithRelationInput
  }

  export type TimelineEventWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: TimelineEventWhereInput | TimelineEventWhereInput[]
    OR?: TimelineEventWhereInput[]
    NOT?: TimelineEventWhereInput | TimelineEventWhereInput[]
    createdAt?: DateTimeFilter<"TimelineEvent"> | Date | string
    details?: StringFilter<"TimelineEvent"> | string
    caseId?: StringFilter<"TimelineEvent"> | string
    case?: XOR<CaseScalarRelationFilter, CaseWhereInput>
  }, "id">

  export type TimelineEventOrderByWithAggregationInput = {
    id?: SortOrder
    createdAt?: SortOrder
    details?: SortOrder
    caseId?: SortOrder
    _count?: TimelineEventCountOrderByAggregateInput
    _max?: TimelineEventMaxOrderByAggregateInput
    _min?: TimelineEventMinOrderByAggregateInput
  }

  export type TimelineEventScalarWhereWithAggregatesInput = {
    AND?: TimelineEventScalarWhereWithAggregatesInput | TimelineEventScalarWhereWithAggregatesInput[]
    OR?: TimelineEventScalarWhereWithAggregatesInput[]
    NOT?: TimelineEventScalarWhereWithAggregatesInput | TimelineEventScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"TimelineEvent"> | string
    createdAt?: DateTimeWithAggregatesFilter<"TimelineEvent"> | Date | string
    details?: StringWithAggregatesFilter<"TimelineEvent"> | string
    caseId?: StringWithAggregatesFilter<"TimelineEvent"> | string
  }

  export type MessageWhereInput = {
    AND?: MessageWhereInput | MessageWhereInput[]
    OR?: MessageWhereInput[]
    NOT?: MessageWhereInput | MessageWhereInput[]
    id?: StringFilter<"Message"> | string
    createdAt?: DateTimeFilter<"Message"> | Date | string
    body?: StringFilter<"Message"> | string
    caseId?: StringFilter<"Message"> | string
    case?: XOR<CaseScalarRelationFilter, CaseWhereInput>
  }

  export type MessageOrderByWithRelationInput = {
    id?: SortOrder
    createdAt?: SortOrder
    body?: SortOrder
    caseId?: SortOrder
    case?: CaseOrderByWithRelationInput
  }

  export type MessageWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: MessageWhereInput | MessageWhereInput[]
    OR?: MessageWhereInput[]
    NOT?: MessageWhereInput | MessageWhereInput[]
    createdAt?: DateTimeFilter<"Message"> | Date | string
    body?: StringFilter<"Message"> | string
    caseId?: StringFilter<"Message"> | string
    case?: XOR<CaseScalarRelationFilter, CaseWhereInput>
  }, "id">

  export type MessageOrderByWithAggregationInput = {
    id?: SortOrder
    createdAt?: SortOrder
    body?: SortOrder
    caseId?: SortOrder
    _count?: MessageCountOrderByAggregateInput
    _max?: MessageMaxOrderByAggregateInput
    _min?: MessageMinOrderByAggregateInput
  }

  export type MessageScalarWhereWithAggregatesInput = {
    AND?: MessageScalarWhereWithAggregatesInput | MessageScalarWhereWithAggregatesInput[]
    OR?: MessageScalarWhereWithAggregatesInput[]
    NOT?: MessageScalarWhereWithAggregatesInput | MessageScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Message"> | string
    createdAt?: DateTimeWithAggregatesFilter<"Message"> | Date | string
    body?: StringWithAggregatesFilter<"Message"> | string
    caseId?: StringWithAggregatesFilter<"Message"> | string
  }

  export type UserCreateInput = {
    id?: string
    email: string
    name?: string | null
    role?: $Enums.Role
    password?: string | null
    casesAsClient?: CaseCreateNestedManyWithoutClientInput
    casesAsManager?: CaseCreateNestedManyWithoutCaseManagerInput
    casesAsLawyer?: CaseCreateNestedManyWithoutLawyerInput
  }

  export type UserUncheckedCreateInput = {
    id?: string
    email: string
    name?: string | null
    role?: $Enums.Role
    password?: string | null
    casesAsClient?: CaseUncheckedCreateNestedManyWithoutClientInput
    casesAsManager?: CaseUncheckedCreateNestedManyWithoutCaseManagerInput
    casesAsLawyer?: CaseUncheckedCreateNestedManyWithoutLawyerInput
  }

  export type UserUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    password?: NullableStringFieldUpdateOperationsInput | string | null
    casesAsClient?: CaseUpdateManyWithoutClientNestedInput
    casesAsManager?: CaseUpdateManyWithoutCaseManagerNestedInput
    casesAsLawyer?: CaseUpdateManyWithoutLawyerNestedInput
  }

  export type UserUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    password?: NullableStringFieldUpdateOperationsInput | string | null
    casesAsClient?: CaseUncheckedUpdateManyWithoutClientNestedInput
    casesAsManager?: CaseUncheckedUpdateManyWithoutCaseManagerNestedInput
    casesAsLawyer?: CaseUncheckedUpdateManyWithoutLawyerNestedInput
  }

  export type UserCreateManyInput = {
    id?: string
    email: string
    name?: string | null
    role?: $Enums.Role
    password?: string | null
  }

  export type UserUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    password?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type UserUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    password?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type CaseCreateInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    client?: UserCreateNestedOneWithoutCasesAsClientInput
    caseManager?: UserCreateNestedOneWithoutCasesAsManagerInput
    lawyer?: UserCreateNestedOneWithoutCasesAsLawyerInput
    documents?: DocumentCreateNestedManyWithoutCaseInput
    payments?: PaymentCreateNestedManyWithoutCaseInput
    timelineEvents?: TimelineEventCreateNestedManyWithoutCaseInput
    internalMessages?: MessageCreateNestedManyWithoutCaseInput
    externalPartners?: ExternalPartnerCreateNestedManyWithoutCaseInput
    externalComms?: ExternalCommunicationCreateNestedManyWithoutCaseInput
  }

  export type CaseUncheckedCreateInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    clientId?: string | null
    caseManagerId?: string | null
    lawyerId?: string | null
    documents?: DocumentUncheckedCreateNestedManyWithoutCaseInput
    payments?: PaymentUncheckedCreateNestedManyWithoutCaseInput
    timelineEvents?: TimelineEventUncheckedCreateNestedManyWithoutCaseInput
    internalMessages?: MessageUncheckedCreateNestedManyWithoutCaseInput
    externalPartners?: ExternalPartnerUncheckedCreateNestedManyWithoutCaseInput
    externalComms?: ExternalCommunicationUncheckedCreateNestedManyWithoutCaseInput
  }

  export type CaseUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
    client?: UserUpdateOneWithoutCasesAsClientNestedInput
    caseManager?: UserUpdateOneWithoutCasesAsManagerNestedInput
    lawyer?: UserUpdateOneWithoutCasesAsLawyerNestedInput
    documents?: DocumentUpdateManyWithoutCaseNestedInput
    payments?: PaymentUpdateManyWithoutCaseNestedInput
    timelineEvents?: TimelineEventUpdateManyWithoutCaseNestedInput
    internalMessages?: MessageUpdateManyWithoutCaseNestedInput
    externalPartners?: ExternalPartnerUpdateManyWithoutCaseNestedInput
    externalComms?: ExternalCommunicationUpdateManyWithoutCaseNestedInput
  }

  export type CaseUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
    clientId?: NullableStringFieldUpdateOperationsInput | string | null
    caseManagerId?: NullableStringFieldUpdateOperationsInput | string | null
    lawyerId?: NullableStringFieldUpdateOperationsInput | string | null
    documents?: DocumentUncheckedUpdateManyWithoutCaseNestedInput
    payments?: PaymentUncheckedUpdateManyWithoutCaseNestedInput
    timelineEvents?: TimelineEventUncheckedUpdateManyWithoutCaseNestedInput
    internalMessages?: MessageUncheckedUpdateManyWithoutCaseNestedInput
    externalPartners?: ExternalPartnerUncheckedUpdateManyWithoutCaseNestedInput
    externalComms?: ExternalCommunicationUncheckedUpdateManyWithoutCaseNestedInput
  }

  export type CaseCreateManyInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    clientId?: string | null
    caseManagerId?: string | null
    lawyerId?: string | null
  }

  export type CaseUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
  }

  export type CaseUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
    clientId?: NullableStringFieldUpdateOperationsInput | string | null
    caseManagerId?: NullableStringFieldUpdateOperationsInput | string | null
    lawyerId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type PartnerRoleCreateInput = {
    id?: string
    name: string
    partners?: ExternalPartnerCreateNestedManyWithoutRoleInput
  }

  export type PartnerRoleUncheckedCreateInput = {
    id?: string
    name: string
    partners?: ExternalPartnerUncheckedCreateNestedManyWithoutRoleInput
  }

  export type PartnerRoleUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    partners?: ExternalPartnerUpdateManyWithoutRoleNestedInput
  }

  export type PartnerRoleUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    partners?: ExternalPartnerUncheckedUpdateManyWithoutRoleNestedInput
  }

  export type PartnerRoleCreateManyInput = {
    id?: string
    name: string
  }

  export type PartnerRoleUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
  }

  export type PartnerRoleUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
  }

  export type ExternalPartnerCreateInput = {
    id?: string
    name: string
    email?: string | null
    type: string
    case: CaseCreateNestedOneWithoutExternalPartnersInput
    role: PartnerRoleCreateNestedOneWithoutPartnersInput
  }

  export type ExternalPartnerUncheckedCreateInput = {
    id?: string
    name: string
    email?: string | null
    type: string
    caseId: string
    roleId: string
  }

  export type ExternalPartnerUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    case?: CaseUpdateOneRequiredWithoutExternalPartnersNestedInput
    role?: PartnerRoleUpdateOneRequiredWithoutPartnersNestedInput
  }

  export type ExternalPartnerUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    caseId?: StringFieldUpdateOperationsInput | string
    roleId?: StringFieldUpdateOperationsInput | string
  }

  export type ExternalPartnerCreateManyInput = {
    id?: string
    name: string
    email?: string | null
    type: string
    caseId: string
    roleId: string
  }

  export type ExternalPartnerUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
  }

  export type ExternalPartnerUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    caseId?: StringFieldUpdateOperationsInput | string
    roleId?: StringFieldUpdateOperationsInput | string
  }

  export type ExternalCommunicationCreateInput = {
    id?: string
    createdAt?: Date | string
    direction: $Enums.Direction
    body: string
    sender: string
    case: CaseCreateNestedOneWithoutExternalCommsInput
  }

  export type ExternalCommunicationUncheckedCreateInput = {
    id?: string
    createdAt?: Date | string
    direction: $Enums.Direction
    body: string
    sender: string
    caseId: string
  }

  export type ExternalCommunicationUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    direction?: EnumDirectionFieldUpdateOperationsInput | $Enums.Direction
    body?: StringFieldUpdateOperationsInput | string
    sender?: StringFieldUpdateOperationsInput | string
    case?: CaseUpdateOneRequiredWithoutExternalCommsNestedInput
  }

  export type ExternalCommunicationUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    direction?: EnumDirectionFieldUpdateOperationsInput | $Enums.Direction
    body?: StringFieldUpdateOperationsInput | string
    sender?: StringFieldUpdateOperationsInput | string
    caseId?: StringFieldUpdateOperationsInput | string
  }

  export type ExternalCommunicationCreateManyInput = {
    id?: string
    createdAt?: Date | string
    direction: $Enums.Direction
    body: string
    sender: string
    caseId: string
  }

  export type ExternalCommunicationUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    direction?: EnumDirectionFieldUpdateOperationsInput | $Enums.Direction
    body?: StringFieldUpdateOperationsInput | string
    sender?: StringFieldUpdateOperationsInput | string
  }

  export type ExternalCommunicationUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    direction?: EnumDirectionFieldUpdateOperationsInput | $Enums.Direction
    body?: StringFieldUpdateOperationsInput | string
    sender?: StringFieldUpdateOperationsInput | string
    caseId?: StringFieldUpdateOperationsInput | string
  }

  export type DocumentCreateInput = {
    id?: string
    name: string
    state: $Enums.DocState
    case: CaseCreateNestedOneWithoutDocumentsInput
  }

  export type DocumentUncheckedCreateInput = {
    id?: string
    name: string
    state: $Enums.DocState
    caseId: string
  }

  export type DocumentUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    state?: EnumDocStateFieldUpdateOperationsInput | $Enums.DocState
    case?: CaseUpdateOneRequiredWithoutDocumentsNestedInput
  }

  export type DocumentUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    state?: EnumDocStateFieldUpdateOperationsInput | $Enums.DocState
    caseId?: StringFieldUpdateOperationsInput | string
  }

  export type DocumentCreateManyInput = {
    id?: string
    name: string
    state: $Enums.DocState
    caseId: string
  }

  export type DocumentUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    state?: EnumDocStateFieldUpdateOperationsInput | $Enums.DocState
  }

  export type DocumentUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    state?: EnumDocStateFieldUpdateOperationsInput | $Enums.DocState
    caseId?: StringFieldUpdateOperationsInput | string
  }

  export type PaymentCreateInput = {
    id?: string
    amount: number
    currency: string
    status: $Enums.PaymentStatus
    description: string
    invoiceNumber: string
    case: CaseCreateNestedOneWithoutPaymentsInput
  }

  export type PaymentUncheckedCreateInput = {
    id?: string
    amount: number
    currency: string
    status: $Enums.PaymentStatus
    description: string
    invoiceNumber: string
    caseId: string
  }

  export type PaymentUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    amount?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    status?: EnumPaymentStatusFieldUpdateOperationsInput | $Enums.PaymentStatus
    description?: StringFieldUpdateOperationsInput | string
    invoiceNumber?: StringFieldUpdateOperationsInput | string
    case?: CaseUpdateOneRequiredWithoutPaymentsNestedInput
  }

  export type PaymentUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    amount?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    status?: EnumPaymentStatusFieldUpdateOperationsInput | $Enums.PaymentStatus
    description?: StringFieldUpdateOperationsInput | string
    invoiceNumber?: StringFieldUpdateOperationsInput | string
    caseId?: StringFieldUpdateOperationsInput | string
  }

  export type PaymentCreateManyInput = {
    id?: string
    amount: number
    currency: string
    status: $Enums.PaymentStatus
    description: string
    invoiceNumber: string
    caseId: string
  }

  export type PaymentUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    amount?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    status?: EnumPaymentStatusFieldUpdateOperationsInput | $Enums.PaymentStatus
    description?: StringFieldUpdateOperationsInput | string
    invoiceNumber?: StringFieldUpdateOperationsInput | string
  }

  export type PaymentUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    amount?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    status?: EnumPaymentStatusFieldUpdateOperationsInput | $Enums.PaymentStatus
    description?: StringFieldUpdateOperationsInput | string
    invoiceNumber?: StringFieldUpdateOperationsInput | string
    caseId?: StringFieldUpdateOperationsInput | string
  }

  export type TimelineEventCreateInput = {
    id?: string
    createdAt?: Date | string
    details: string
    case: CaseCreateNestedOneWithoutTimelineEventsInput
  }

  export type TimelineEventUncheckedCreateInput = {
    id?: string
    createdAt?: Date | string
    details: string
    caseId: string
  }

  export type TimelineEventUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    details?: StringFieldUpdateOperationsInput | string
    case?: CaseUpdateOneRequiredWithoutTimelineEventsNestedInput
  }

  export type TimelineEventUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    details?: StringFieldUpdateOperationsInput | string
    caseId?: StringFieldUpdateOperationsInput | string
  }

  export type TimelineEventCreateManyInput = {
    id?: string
    createdAt?: Date | string
    details: string
    caseId: string
  }

  export type TimelineEventUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    details?: StringFieldUpdateOperationsInput | string
  }

  export type TimelineEventUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    details?: StringFieldUpdateOperationsInput | string
    caseId?: StringFieldUpdateOperationsInput | string
  }

  export type MessageCreateInput = {
    id?: string
    createdAt?: Date | string
    body: string
    case: CaseCreateNestedOneWithoutInternalMessagesInput
  }

  export type MessageUncheckedCreateInput = {
    id?: string
    createdAt?: Date | string
    body: string
    caseId: string
  }

  export type MessageUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    body?: StringFieldUpdateOperationsInput | string
    case?: CaseUpdateOneRequiredWithoutInternalMessagesNestedInput
  }

  export type MessageUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    body?: StringFieldUpdateOperationsInput | string
    caseId?: StringFieldUpdateOperationsInput | string
  }

  export type MessageCreateManyInput = {
    id?: string
    createdAt?: Date | string
    body: string
    caseId: string
  }

  export type MessageUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    body?: StringFieldUpdateOperationsInput | string
  }

  export type MessageUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    body?: StringFieldUpdateOperationsInput | string
    caseId?: StringFieldUpdateOperationsInput | string
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type EnumRoleFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[]
    notIn?: $Enums.Role[]
    not?: NestedEnumRoleFilter<$PrismaModel> | $Enums.Role
  }

  export type CaseListRelationFilter = {
    every?: CaseWhereInput
    some?: CaseWhereInput
    none?: CaseWhereInput
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type CaseOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type UserCountOrderByAggregateInput = {
    id?: SortOrder
    email?: SortOrder
    name?: SortOrder
    role?: SortOrder
    password?: SortOrder
  }

  export type UserMaxOrderByAggregateInput = {
    id?: SortOrder
    email?: SortOrder
    name?: SortOrder
    role?: SortOrder
    password?: SortOrder
  }

  export type UserMinOrderByAggregateInput = {
    id?: SortOrder
    email?: SortOrder
    name?: SortOrder
    role?: SortOrder
    password?: SortOrder
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type EnumRoleWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[]
    notIn?: $Enums.Role[]
    not?: NestedEnumRoleWithAggregatesFilter<$PrismaModel> | $Enums.Role
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumRoleFilter<$PrismaModel>
    _max?: NestedEnumRoleFilter<$PrismaModel>
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type EnumCaseStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.CaseStatus | EnumCaseStatusFieldRefInput<$PrismaModel>
    in?: $Enums.CaseStatus[]
    notIn?: $Enums.CaseStatus[]
    not?: NestedEnumCaseStatusFilter<$PrismaModel> | $Enums.CaseStatus
  }

  export type UserNullableScalarRelationFilter = {
    is?: UserWhereInput | null
    isNot?: UserWhereInput | null
  }

  export type DocumentListRelationFilter = {
    every?: DocumentWhereInput
    some?: DocumentWhereInput
    none?: DocumentWhereInput
  }

  export type PaymentListRelationFilter = {
    every?: PaymentWhereInput
    some?: PaymentWhereInput
    none?: PaymentWhereInput
  }

  export type TimelineEventListRelationFilter = {
    every?: TimelineEventWhereInput
    some?: TimelineEventWhereInput
    none?: TimelineEventWhereInput
  }

  export type MessageListRelationFilter = {
    every?: MessageWhereInput
    some?: MessageWhereInput
    none?: MessageWhereInput
  }

  export type ExternalPartnerListRelationFilter = {
    every?: ExternalPartnerWhereInput
    some?: ExternalPartnerWhereInput
    none?: ExternalPartnerWhereInput
  }

  export type ExternalCommunicationListRelationFilter = {
    every?: ExternalCommunicationWhereInput
    some?: ExternalCommunicationWhereInput
    none?: ExternalCommunicationWhereInput
  }

  export type DocumentOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type PaymentOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type TimelineEventOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type MessageOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type ExternalPartnerOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type ExternalCommunicationOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type CaseCountOrderByAggregateInput = {
    id?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    title?: SortOrder
    caseNumber?: SortOrder
    totalFee?: SortOrder
    currency?: SortOrder
    applicantName?: SortOrder
    applicantEmail?: SortOrder
    overallStatus?: SortOrder
    stage?: SortOrder
    urgencyLevel?: SortOrder
    completionPercentage?: SortOrder
    clientId?: SortOrder
    caseManagerId?: SortOrder
    lawyerId?: SortOrder
  }

  export type CaseAvgOrderByAggregateInput = {
    totalFee?: SortOrder
    completionPercentage?: SortOrder
  }

  export type CaseMaxOrderByAggregateInput = {
    id?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    title?: SortOrder
    caseNumber?: SortOrder
    totalFee?: SortOrder
    currency?: SortOrder
    applicantName?: SortOrder
    applicantEmail?: SortOrder
    overallStatus?: SortOrder
    stage?: SortOrder
    urgencyLevel?: SortOrder
    completionPercentage?: SortOrder
    clientId?: SortOrder
    caseManagerId?: SortOrder
    lawyerId?: SortOrder
  }

  export type CaseMinOrderByAggregateInput = {
    id?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    title?: SortOrder
    caseNumber?: SortOrder
    totalFee?: SortOrder
    currency?: SortOrder
    applicantName?: SortOrder
    applicantEmail?: SortOrder
    overallStatus?: SortOrder
    stage?: SortOrder
    urgencyLevel?: SortOrder
    completionPercentage?: SortOrder
    clientId?: SortOrder
    caseManagerId?: SortOrder
    lawyerId?: SortOrder
  }

  export type CaseSumOrderByAggregateInput = {
    totalFee?: SortOrder
    completionPercentage?: SortOrder
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type EnumCaseStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.CaseStatus | EnumCaseStatusFieldRefInput<$PrismaModel>
    in?: $Enums.CaseStatus[]
    notIn?: $Enums.CaseStatus[]
    not?: NestedEnumCaseStatusWithAggregatesFilter<$PrismaModel> | $Enums.CaseStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumCaseStatusFilter<$PrismaModel>
    _max?: NestedEnumCaseStatusFilter<$PrismaModel>
  }

  export type PartnerRoleCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
  }

  export type PartnerRoleMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
  }

  export type PartnerRoleMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
  }

  export type CaseScalarRelationFilter = {
    is?: CaseWhereInput
    isNot?: CaseWhereInput
  }

  export type PartnerRoleScalarRelationFilter = {
    is?: PartnerRoleWhereInput
    isNot?: PartnerRoleWhereInput
  }

  export type ExternalPartnerCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    type?: SortOrder
    caseId?: SortOrder
    roleId?: SortOrder
  }

  export type ExternalPartnerMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    type?: SortOrder
    caseId?: SortOrder
    roleId?: SortOrder
  }

  export type ExternalPartnerMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    type?: SortOrder
    caseId?: SortOrder
    roleId?: SortOrder
  }

  export type EnumDirectionFilter<$PrismaModel = never> = {
    equals?: $Enums.Direction | EnumDirectionFieldRefInput<$PrismaModel>
    in?: $Enums.Direction[]
    notIn?: $Enums.Direction[]
    not?: NestedEnumDirectionFilter<$PrismaModel> | $Enums.Direction
  }

  export type ExternalCommunicationCountOrderByAggregateInput = {
    id?: SortOrder
    createdAt?: SortOrder
    direction?: SortOrder
    body?: SortOrder
    sender?: SortOrder
    caseId?: SortOrder
  }

  export type ExternalCommunicationMaxOrderByAggregateInput = {
    id?: SortOrder
    createdAt?: SortOrder
    direction?: SortOrder
    body?: SortOrder
    sender?: SortOrder
    caseId?: SortOrder
  }

  export type ExternalCommunicationMinOrderByAggregateInput = {
    id?: SortOrder
    createdAt?: SortOrder
    direction?: SortOrder
    body?: SortOrder
    sender?: SortOrder
    caseId?: SortOrder
  }

  export type EnumDirectionWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Direction | EnumDirectionFieldRefInput<$PrismaModel>
    in?: $Enums.Direction[]
    notIn?: $Enums.Direction[]
    not?: NestedEnumDirectionWithAggregatesFilter<$PrismaModel> | $Enums.Direction
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumDirectionFilter<$PrismaModel>
    _max?: NestedEnumDirectionFilter<$PrismaModel>
  }

  export type EnumDocStateFilter<$PrismaModel = never> = {
    equals?: $Enums.DocState | EnumDocStateFieldRefInput<$PrismaModel>
    in?: $Enums.DocState[]
    notIn?: $Enums.DocState[]
    not?: NestedEnumDocStateFilter<$PrismaModel> | $Enums.DocState
  }

  export type DocumentCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    state?: SortOrder
    caseId?: SortOrder
  }

  export type DocumentMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    state?: SortOrder
    caseId?: SortOrder
  }

  export type DocumentMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    state?: SortOrder
    caseId?: SortOrder
  }

  export type EnumDocStateWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.DocState | EnumDocStateFieldRefInput<$PrismaModel>
    in?: $Enums.DocState[]
    notIn?: $Enums.DocState[]
    not?: NestedEnumDocStateWithAggregatesFilter<$PrismaModel> | $Enums.DocState
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumDocStateFilter<$PrismaModel>
    _max?: NestedEnumDocStateFilter<$PrismaModel>
  }

  export type EnumPaymentStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.PaymentStatus | EnumPaymentStatusFieldRefInput<$PrismaModel>
    in?: $Enums.PaymentStatus[]
    notIn?: $Enums.PaymentStatus[]
    not?: NestedEnumPaymentStatusFilter<$PrismaModel> | $Enums.PaymentStatus
  }

  export type PaymentCountOrderByAggregateInput = {
    id?: SortOrder
    amount?: SortOrder
    currency?: SortOrder
    status?: SortOrder
    description?: SortOrder
    invoiceNumber?: SortOrder
    caseId?: SortOrder
  }

  export type PaymentAvgOrderByAggregateInput = {
    amount?: SortOrder
  }

  export type PaymentMaxOrderByAggregateInput = {
    id?: SortOrder
    amount?: SortOrder
    currency?: SortOrder
    status?: SortOrder
    description?: SortOrder
    invoiceNumber?: SortOrder
    caseId?: SortOrder
  }

  export type PaymentMinOrderByAggregateInput = {
    id?: SortOrder
    amount?: SortOrder
    currency?: SortOrder
    status?: SortOrder
    description?: SortOrder
    invoiceNumber?: SortOrder
    caseId?: SortOrder
  }

  export type PaymentSumOrderByAggregateInput = {
    amount?: SortOrder
  }

  export type EnumPaymentStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.PaymentStatus | EnumPaymentStatusFieldRefInput<$PrismaModel>
    in?: $Enums.PaymentStatus[]
    notIn?: $Enums.PaymentStatus[]
    not?: NestedEnumPaymentStatusWithAggregatesFilter<$PrismaModel> | $Enums.PaymentStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumPaymentStatusFilter<$PrismaModel>
    _max?: NestedEnumPaymentStatusFilter<$PrismaModel>
  }

  export type TimelineEventCountOrderByAggregateInput = {
    id?: SortOrder
    createdAt?: SortOrder
    details?: SortOrder
    caseId?: SortOrder
  }

  export type TimelineEventMaxOrderByAggregateInput = {
    id?: SortOrder
    createdAt?: SortOrder
    details?: SortOrder
    caseId?: SortOrder
  }

  export type TimelineEventMinOrderByAggregateInput = {
    id?: SortOrder
    createdAt?: SortOrder
    details?: SortOrder
    caseId?: SortOrder
  }

  export type MessageCountOrderByAggregateInput = {
    id?: SortOrder
    createdAt?: SortOrder
    body?: SortOrder
    caseId?: SortOrder
  }

  export type MessageMaxOrderByAggregateInput = {
    id?: SortOrder
    createdAt?: SortOrder
    body?: SortOrder
    caseId?: SortOrder
  }

  export type MessageMinOrderByAggregateInput = {
    id?: SortOrder
    createdAt?: SortOrder
    body?: SortOrder
    caseId?: SortOrder
  }

  export type CaseCreateNestedManyWithoutClientInput = {
    create?: XOR<CaseCreateWithoutClientInput, CaseUncheckedCreateWithoutClientInput> | CaseCreateWithoutClientInput[] | CaseUncheckedCreateWithoutClientInput[]
    connectOrCreate?: CaseCreateOrConnectWithoutClientInput | CaseCreateOrConnectWithoutClientInput[]
    createMany?: CaseCreateManyClientInputEnvelope
    connect?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
  }

  export type CaseCreateNestedManyWithoutCaseManagerInput = {
    create?: XOR<CaseCreateWithoutCaseManagerInput, CaseUncheckedCreateWithoutCaseManagerInput> | CaseCreateWithoutCaseManagerInput[] | CaseUncheckedCreateWithoutCaseManagerInput[]
    connectOrCreate?: CaseCreateOrConnectWithoutCaseManagerInput | CaseCreateOrConnectWithoutCaseManagerInput[]
    createMany?: CaseCreateManyCaseManagerInputEnvelope
    connect?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
  }

  export type CaseCreateNestedManyWithoutLawyerInput = {
    create?: XOR<CaseCreateWithoutLawyerInput, CaseUncheckedCreateWithoutLawyerInput> | CaseCreateWithoutLawyerInput[] | CaseUncheckedCreateWithoutLawyerInput[]
    connectOrCreate?: CaseCreateOrConnectWithoutLawyerInput | CaseCreateOrConnectWithoutLawyerInput[]
    createMany?: CaseCreateManyLawyerInputEnvelope
    connect?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
  }

  export type CaseUncheckedCreateNestedManyWithoutClientInput = {
    create?: XOR<CaseCreateWithoutClientInput, CaseUncheckedCreateWithoutClientInput> | CaseCreateWithoutClientInput[] | CaseUncheckedCreateWithoutClientInput[]
    connectOrCreate?: CaseCreateOrConnectWithoutClientInput | CaseCreateOrConnectWithoutClientInput[]
    createMany?: CaseCreateManyClientInputEnvelope
    connect?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
  }

  export type CaseUncheckedCreateNestedManyWithoutCaseManagerInput = {
    create?: XOR<CaseCreateWithoutCaseManagerInput, CaseUncheckedCreateWithoutCaseManagerInput> | CaseCreateWithoutCaseManagerInput[] | CaseUncheckedCreateWithoutCaseManagerInput[]
    connectOrCreate?: CaseCreateOrConnectWithoutCaseManagerInput | CaseCreateOrConnectWithoutCaseManagerInput[]
    createMany?: CaseCreateManyCaseManagerInputEnvelope
    connect?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
  }

  export type CaseUncheckedCreateNestedManyWithoutLawyerInput = {
    create?: XOR<CaseCreateWithoutLawyerInput, CaseUncheckedCreateWithoutLawyerInput> | CaseCreateWithoutLawyerInput[] | CaseUncheckedCreateWithoutLawyerInput[]
    connectOrCreate?: CaseCreateOrConnectWithoutLawyerInput | CaseCreateOrConnectWithoutLawyerInput[]
    createMany?: CaseCreateManyLawyerInputEnvelope
    connect?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type EnumRoleFieldUpdateOperationsInput = {
    set?: $Enums.Role
  }

  export type CaseUpdateManyWithoutClientNestedInput = {
    create?: XOR<CaseCreateWithoutClientInput, CaseUncheckedCreateWithoutClientInput> | CaseCreateWithoutClientInput[] | CaseUncheckedCreateWithoutClientInput[]
    connectOrCreate?: CaseCreateOrConnectWithoutClientInput | CaseCreateOrConnectWithoutClientInput[]
    upsert?: CaseUpsertWithWhereUniqueWithoutClientInput | CaseUpsertWithWhereUniqueWithoutClientInput[]
    createMany?: CaseCreateManyClientInputEnvelope
    set?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
    disconnect?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
    delete?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
    connect?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
    update?: CaseUpdateWithWhereUniqueWithoutClientInput | CaseUpdateWithWhereUniqueWithoutClientInput[]
    updateMany?: CaseUpdateManyWithWhereWithoutClientInput | CaseUpdateManyWithWhereWithoutClientInput[]
    deleteMany?: CaseScalarWhereInput | CaseScalarWhereInput[]
  }

  export type CaseUpdateManyWithoutCaseManagerNestedInput = {
    create?: XOR<CaseCreateWithoutCaseManagerInput, CaseUncheckedCreateWithoutCaseManagerInput> | CaseCreateWithoutCaseManagerInput[] | CaseUncheckedCreateWithoutCaseManagerInput[]
    connectOrCreate?: CaseCreateOrConnectWithoutCaseManagerInput | CaseCreateOrConnectWithoutCaseManagerInput[]
    upsert?: CaseUpsertWithWhereUniqueWithoutCaseManagerInput | CaseUpsertWithWhereUniqueWithoutCaseManagerInput[]
    createMany?: CaseCreateManyCaseManagerInputEnvelope
    set?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
    disconnect?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
    delete?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
    connect?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
    update?: CaseUpdateWithWhereUniqueWithoutCaseManagerInput | CaseUpdateWithWhereUniqueWithoutCaseManagerInput[]
    updateMany?: CaseUpdateManyWithWhereWithoutCaseManagerInput | CaseUpdateManyWithWhereWithoutCaseManagerInput[]
    deleteMany?: CaseScalarWhereInput | CaseScalarWhereInput[]
  }

  export type CaseUpdateManyWithoutLawyerNestedInput = {
    create?: XOR<CaseCreateWithoutLawyerInput, CaseUncheckedCreateWithoutLawyerInput> | CaseCreateWithoutLawyerInput[] | CaseUncheckedCreateWithoutLawyerInput[]
    connectOrCreate?: CaseCreateOrConnectWithoutLawyerInput | CaseCreateOrConnectWithoutLawyerInput[]
    upsert?: CaseUpsertWithWhereUniqueWithoutLawyerInput | CaseUpsertWithWhereUniqueWithoutLawyerInput[]
    createMany?: CaseCreateManyLawyerInputEnvelope
    set?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
    disconnect?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
    delete?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
    connect?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
    update?: CaseUpdateWithWhereUniqueWithoutLawyerInput | CaseUpdateWithWhereUniqueWithoutLawyerInput[]
    updateMany?: CaseUpdateManyWithWhereWithoutLawyerInput | CaseUpdateManyWithWhereWithoutLawyerInput[]
    deleteMany?: CaseScalarWhereInput | CaseScalarWhereInput[]
  }

  export type CaseUncheckedUpdateManyWithoutClientNestedInput = {
    create?: XOR<CaseCreateWithoutClientInput, CaseUncheckedCreateWithoutClientInput> | CaseCreateWithoutClientInput[] | CaseUncheckedCreateWithoutClientInput[]
    connectOrCreate?: CaseCreateOrConnectWithoutClientInput | CaseCreateOrConnectWithoutClientInput[]
    upsert?: CaseUpsertWithWhereUniqueWithoutClientInput | CaseUpsertWithWhereUniqueWithoutClientInput[]
    createMany?: CaseCreateManyClientInputEnvelope
    set?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
    disconnect?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
    delete?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
    connect?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
    update?: CaseUpdateWithWhereUniqueWithoutClientInput | CaseUpdateWithWhereUniqueWithoutClientInput[]
    updateMany?: CaseUpdateManyWithWhereWithoutClientInput | CaseUpdateManyWithWhereWithoutClientInput[]
    deleteMany?: CaseScalarWhereInput | CaseScalarWhereInput[]
  }

  export type CaseUncheckedUpdateManyWithoutCaseManagerNestedInput = {
    create?: XOR<CaseCreateWithoutCaseManagerInput, CaseUncheckedCreateWithoutCaseManagerInput> | CaseCreateWithoutCaseManagerInput[] | CaseUncheckedCreateWithoutCaseManagerInput[]
    connectOrCreate?: CaseCreateOrConnectWithoutCaseManagerInput | CaseCreateOrConnectWithoutCaseManagerInput[]
    upsert?: CaseUpsertWithWhereUniqueWithoutCaseManagerInput | CaseUpsertWithWhereUniqueWithoutCaseManagerInput[]
    createMany?: CaseCreateManyCaseManagerInputEnvelope
    set?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
    disconnect?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
    delete?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
    connect?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
    update?: CaseUpdateWithWhereUniqueWithoutCaseManagerInput | CaseUpdateWithWhereUniqueWithoutCaseManagerInput[]
    updateMany?: CaseUpdateManyWithWhereWithoutCaseManagerInput | CaseUpdateManyWithWhereWithoutCaseManagerInput[]
    deleteMany?: CaseScalarWhereInput | CaseScalarWhereInput[]
  }

  export type CaseUncheckedUpdateManyWithoutLawyerNestedInput = {
    create?: XOR<CaseCreateWithoutLawyerInput, CaseUncheckedCreateWithoutLawyerInput> | CaseCreateWithoutLawyerInput[] | CaseUncheckedCreateWithoutLawyerInput[]
    connectOrCreate?: CaseCreateOrConnectWithoutLawyerInput | CaseCreateOrConnectWithoutLawyerInput[]
    upsert?: CaseUpsertWithWhereUniqueWithoutLawyerInput | CaseUpsertWithWhereUniqueWithoutLawyerInput[]
    createMany?: CaseCreateManyLawyerInputEnvelope
    set?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
    disconnect?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
    delete?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
    connect?: CaseWhereUniqueInput | CaseWhereUniqueInput[]
    update?: CaseUpdateWithWhereUniqueWithoutLawyerInput | CaseUpdateWithWhereUniqueWithoutLawyerInput[]
    updateMany?: CaseUpdateManyWithWhereWithoutLawyerInput | CaseUpdateManyWithWhereWithoutLawyerInput[]
    deleteMany?: CaseScalarWhereInput | CaseScalarWhereInput[]
  }

  export type UserCreateNestedOneWithoutCasesAsClientInput = {
    create?: XOR<UserCreateWithoutCasesAsClientInput, UserUncheckedCreateWithoutCasesAsClientInput>
    connectOrCreate?: UserCreateOrConnectWithoutCasesAsClientInput
    connect?: UserWhereUniqueInput
  }

  export type UserCreateNestedOneWithoutCasesAsManagerInput = {
    create?: XOR<UserCreateWithoutCasesAsManagerInput, UserUncheckedCreateWithoutCasesAsManagerInput>
    connectOrCreate?: UserCreateOrConnectWithoutCasesAsManagerInput
    connect?: UserWhereUniqueInput
  }

  export type UserCreateNestedOneWithoutCasesAsLawyerInput = {
    create?: XOR<UserCreateWithoutCasesAsLawyerInput, UserUncheckedCreateWithoutCasesAsLawyerInput>
    connectOrCreate?: UserCreateOrConnectWithoutCasesAsLawyerInput
    connect?: UserWhereUniqueInput
  }

  export type DocumentCreateNestedManyWithoutCaseInput = {
    create?: XOR<DocumentCreateWithoutCaseInput, DocumentUncheckedCreateWithoutCaseInput> | DocumentCreateWithoutCaseInput[] | DocumentUncheckedCreateWithoutCaseInput[]
    connectOrCreate?: DocumentCreateOrConnectWithoutCaseInput | DocumentCreateOrConnectWithoutCaseInput[]
    createMany?: DocumentCreateManyCaseInputEnvelope
    connect?: DocumentWhereUniqueInput | DocumentWhereUniqueInput[]
  }

  export type PaymentCreateNestedManyWithoutCaseInput = {
    create?: XOR<PaymentCreateWithoutCaseInput, PaymentUncheckedCreateWithoutCaseInput> | PaymentCreateWithoutCaseInput[] | PaymentUncheckedCreateWithoutCaseInput[]
    connectOrCreate?: PaymentCreateOrConnectWithoutCaseInput | PaymentCreateOrConnectWithoutCaseInput[]
    createMany?: PaymentCreateManyCaseInputEnvelope
    connect?: PaymentWhereUniqueInput | PaymentWhereUniqueInput[]
  }

  export type TimelineEventCreateNestedManyWithoutCaseInput = {
    create?: XOR<TimelineEventCreateWithoutCaseInput, TimelineEventUncheckedCreateWithoutCaseInput> | TimelineEventCreateWithoutCaseInput[] | TimelineEventUncheckedCreateWithoutCaseInput[]
    connectOrCreate?: TimelineEventCreateOrConnectWithoutCaseInput | TimelineEventCreateOrConnectWithoutCaseInput[]
    createMany?: TimelineEventCreateManyCaseInputEnvelope
    connect?: TimelineEventWhereUniqueInput | TimelineEventWhereUniqueInput[]
  }

  export type MessageCreateNestedManyWithoutCaseInput = {
    create?: XOR<MessageCreateWithoutCaseInput, MessageUncheckedCreateWithoutCaseInput> | MessageCreateWithoutCaseInput[] | MessageUncheckedCreateWithoutCaseInput[]
    connectOrCreate?: MessageCreateOrConnectWithoutCaseInput | MessageCreateOrConnectWithoutCaseInput[]
    createMany?: MessageCreateManyCaseInputEnvelope
    connect?: MessageWhereUniqueInput | MessageWhereUniqueInput[]
  }

  export type ExternalPartnerCreateNestedManyWithoutCaseInput = {
    create?: XOR<ExternalPartnerCreateWithoutCaseInput, ExternalPartnerUncheckedCreateWithoutCaseInput> | ExternalPartnerCreateWithoutCaseInput[] | ExternalPartnerUncheckedCreateWithoutCaseInput[]
    connectOrCreate?: ExternalPartnerCreateOrConnectWithoutCaseInput | ExternalPartnerCreateOrConnectWithoutCaseInput[]
    createMany?: ExternalPartnerCreateManyCaseInputEnvelope
    connect?: ExternalPartnerWhereUniqueInput | ExternalPartnerWhereUniqueInput[]
  }

  export type ExternalCommunicationCreateNestedManyWithoutCaseInput = {
    create?: XOR<ExternalCommunicationCreateWithoutCaseInput, ExternalCommunicationUncheckedCreateWithoutCaseInput> | ExternalCommunicationCreateWithoutCaseInput[] | ExternalCommunicationUncheckedCreateWithoutCaseInput[]
    connectOrCreate?: ExternalCommunicationCreateOrConnectWithoutCaseInput | ExternalCommunicationCreateOrConnectWithoutCaseInput[]
    createMany?: ExternalCommunicationCreateManyCaseInputEnvelope
    connect?: ExternalCommunicationWhereUniqueInput | ExternalCommunicationWhereUniqueInput[]
  }

  export type DocumentUncheckedCreateNestedManyWithoutCaseInput = {
    create?: XOR<DocumentCreateWithoutCaseInput, DocumentUncheckedCreateWithoutCaseInput> | DocumentCreateWithoutCaseInput[] | DocumentUncheckedCreateWithoutCaseInput[]
    connectOrCreate?: DocumentCreateOrConnectWithoutCaseInput | DocumentCreateOrConnectWithoutCaseInput[]
    createMany?: DocumentCreateManyCaseInputEnvelope
    connect?: DocumentWhereUniqueInput | DocumentWhereUniqueInput[]
  }

  export type PaymentUncheckedCreateNestedManyWithoutCaseInput = {
    create?: XOR<PaymentCreateWithoutCaseInput, PaymentUncheckedCreateWithoutCaseInput> | PaymentCreateWithoutCaseInput[] | PaymentUncheckedCreateWithoutCaseInput[]
    connectOrCreate?: PaymentCreateOrConnectWithoutCaseInput | PaymentCreateOrConnectWithoutCaseInput[]
    createMany?: PaymentCreateManyCaseInputEnvelope
    connect?: PaymentWhereUniqueInput | PaymentWhereUniqueInput[]
  }

  export type TimelineEventUncheckedCreateNestedManyWithoutCaseInput = {
    create?: XOR<TimelineEventCreateWithoutCaseInput, TimelineEventUncheckedCreateWithoutCaseInput> | TimelineEventCreateWithoutCaseInput[] | TimelineEventUncheckedCreateWithoutCaseInput[]
    connectOrCreate?: TimelineEventCreateOrConnectWithoutCaseInput | TimelineEventCreateOrConnectWithoutCaseInput[]
    createMany?: TimelineEventCreateManyCaseInputEnvelope
    connect?: TimelineEventWhereUniqueInput | TimelineEventWhereUniqueInput[]
  }

  export type MessageUncheckedCreateNestedManyWithoutCaseInput = {
    create?: XOR<MessageCreateWithoutCaseInput, MessageUncheckedCreateWithoutCaseInput> | MessageCreateWithoutCaseInput[] | MessageUncheckedCreateWithoutCaseInput[]
    connectOrCreate?: MessageCreateOrConnectWithoutCaseInput | MessageCreateOrConnectWithoutCaseInput[]
    createMany?: MessageCreateManyCaseInputEnvelope
    connect?: MessageWhereUniqueInput | MessageWhereUniqueInput[]
  }

  export type ExternalPartnerUncheckedCreateNestedManyWithoutCaseInput = {
    create?: XOR<ExternalPartnerCreateWithoutCaseInput, ExternalPartnerUncheckedCreateWithoutCaseInput> | ExternalPartnerCreateWithoutCaseInput[] | ExternalPartnerUncheckedCreateWithoutCaseInput[]
    connectOrCreate?: ExternalPartnerCreateOrConnectWithoutCaseInput | ExternalPartnerCreateOrConnectWithoutCaseInput[]
    createMany?: ExternalPartnerCreateManyCaseInputEnvelope
    connect?: ExternalPartnerWhereUniqueInput | ExternalPartnerWhereUniqueInput[]
  }

  export type ExternalCommunicationUncheckedCreateNestedManyWithoutCaseInput = {
    create?: XOR<ExternalCommunicationCreateWithoutCaseInput, ExternalCommunicationUncheckedCreateWithoutCaseInput> | ExternalCommunicationCreateWithoutCaseInput[] | ExternalCommunicationUncheckedCreateWithoutCaseInput[]
    connectOrCreate?: ExternalCommunicationCreateOrConnectWithoutCaseInput | ExternalCommunicationCreateOrConnectWithoutCaseInput[]
    createMany?: ExternalCommunicationCreateManyCaseInputEnvelope
    connect?: ExternalCommunicationWhereUniqueInput | ExternalCommunicationWhereUniqueInput[]
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type EnumCaseStatusFieldUpdateOperationsInput = {
    set?: $Enums.CaseStatus
  }

  export type UserUpdateOneWithoutCasesAsClientNestedInput = {
    create?: XOR<UserCreateWithoutCasesAsClientInput, UserUncheckedCreateWithoutCasesAsClientInput>
    connectOrCreate?: UserCreateOrConnectWithoutCasesAsClientInput
    upsert?: UserUpsertWithoutCasesAsClientInput
    disconnect?: UserWhereInput | boolean
    delete?: UserWhereInput | boolean
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutCasesAsClientInput, UserUpdateWithoutCasesAsClientInput>, UserUncheckedUpdateWithoutCasesAsClientInput>
  }

  export type UserUpdateOneWithoutCasesAsManagerNestedInput = {
    create?: XOR<UserCreateWithoutCasesAsManagerInput, UserUncheckedCreateWithoutCasesAsManagerInput>
    connectOrCreate?: UserCreateOrConnectWithoutCasesAsManagerInput
    upsert?: UserUpsertWithoutCasesAsManagerInput
    disconnect?: UserWhereInput | boolean
    delete?: UserWhereInput | boolean
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutCasesAsManagerInput, UserUpdateWithoutCasesAsManagerInput>, UserUncheckedUpdateWithoutCasesAsManagerInput>
  }

  export type UserUpdateOneWithoutCasesAsLawyerNestedInput = {
    create?: XOR<UserCreateWithoutCasesAsLawyerInput, UserUncheckedCreateWithoutCasesAsLawyerInput>
    connectOrCreate?: UserCreateOrConnectWithoutCasesAsLawyerInput
    upsert?: UserUpsertWithoutCasesAsLawyerInput
    disconnect?: UserWhereInput | boolean
    delete?: UserWhereInput | boolean
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutCasesAsLawyerInput, UserUpdateWithoutCasesAsLawyerInput>, UserUncheckedUpdateWithoutCasesAsLawyerInput>
  }

  export type DocumentUpdateManyWithoutCaseNestedInput = {
    create?: XOR<DocumentCreateWithoutCaseInput, DocumentUncheckedCreateWithoutCaseInput> | DocumentCreateWithoutCaseInput[] | DocumentUncheckedCreateWithoutCaseInput[]
    connectOrCreate?: DocumentCreateOrConnectWithoutCaseInput | DocumentCreateOrConnectWithoutCaseInput[]
    upsert?: DocumentUpsertWithWhereUniqueWithoutCaseInput | DocumentUpsertWithWhereUniqueWithoutCaseInput[]
    createMany?: DocumentCreateManyCaseInputEnvelope
    set?: DocumentWhereUniqueInput | DocumentWhereUniqueInput[]
    disconnect?: DocumentWhereUniqueInput | DocumentWhereUniqueInput[]
    delete?: DocumentWhereUniqueInput | DocumentWhereUniqueInput[]
    connect?: DocumentWhereUniqueInput | DocumentWhereUniqueInput[]
    update?: DocumentUpdateWithWhereUniqueWithoutCaseInput | DocumentUpdateWithWhereUniqueWithoutCaseInput[]
    updateMany?: DocumentUpdateManyWithWhereWithoutCaseInput | DocumentUpdateManyWithWhereWithoutCaseInput[]
    deleteMany?: DocumentScalarWhereInput | DocumentScalarWhereInput[]
  }

  export type PaymentUpdateManyWithoutCaseNestedInput = {
    create?: XOR<PaymentCreateWithoutCaseInput, PaymentUncheckedCreateWithoutCaseInput> | PaymentCreateWithoutCaseInput[] | PaymentUncheckedCreateWithoutCaseInput[]
    connectOrCreate?: PaymentCreateOrConnectWithoutCaseInput | PaymentCreateOrConnectWithoutCaseInput[]
    upsert?: PaymentUpsertWithWhereUniqueWithoutCaseInput | PaymentUpsertWithWhereUniqueWithoutCaseInput[]
    createMany?: PaymentCreateManyCaseInputEnvelope
    set?: PaymentWhereUniqueInput | PaymentWhereUniqueInput[]
    disconnect?: PaymentWhereUniqueInput | PaymentWhereUniqueInput[]
    delete?: PaymentWhereUniqueInput | PaymentWhereUniqueInput[]
    connect?: PaymentWhereUniqueInput | PaymentWhereUniqueInput[]
    update?: PaymentUpdateWithWhereUniqueWithoutCaseInput | PaymentUpdateWithWhereUniqueWithoutCaseInput[]
    updateMany?: PaymentUpdateManyWithWhereWithoutCaseInput | PaymentUpdateManyWithWhereWithoutCaseInput[]
    deleteMany?: PaymentScalarWhereInput | PaymentScalarWhereInput[]
  }

  export type TimelineEventUpdateManyWithoutCaseNestedInput = {
    create?: XOR<TimelineEventCreateWithoutCaseInput, TimelineEventUncheckedCreateWithoutCaseInput> | TimelineEventCreateWithoutCaseInput[] | TimelineEventUncheckedCreateWithoutCaseInput[]
    connectOrCreate?: TimelineEventCreateOrConnectWithoutCaseInput | TimelineEventCreateOrConnectWithoutCaseInput[]
    upsert?: TimelineEventUpsertWithWhereUniqueWithoutCaseInput | TimelineEventUpsertWithWhereUniqueWithoutCaseInput[]
    createMany?: TimelineEventCreateManyCaseInputEnvelope
    set?: TimelineEventWhereUniqueInput | TimelineEventWhereUniqueInput[]
    disconnect?: TimelineEventWhereUniqueInput | TimelineEventWhereUniqueInput[]
    delete?: TimelineEventWhereUniqueInput | TimelineEventWhereUniqueInput[]
    connect?: TimelineEventWhereUniqueInput | TimelineEventWhereUniqueInput[]
    update?: TimelineEventUpdateWithWhereUniqueWithoutCaseInput | TimelineEventUpdateWithWhereUniqueWithoutCaseInput[]
    updateMany?: TimelineEventUpdateManyWithWhereWithoutCaseInput | TimelineEventUpdateManyWithWhereWithoutCaseInput[]
    deleteMany?: TimelineEventScalarWhereInput | TimelineEventScalarWhereInput[]
  }

  export type MessageUpdateManyWithoutCaseNestedInput = {
    create?: XOR<MessageCreateWithoutCaseInput, MessageUncheckedCreateWithoutCaseInput> | MessageCreateWithoutCaseInput[] | MessageUncheckedCreateWithoutCaseInput[]
    connectOrCreate?: MessageCreateOrConnectWithoutCaseInput | MessageCreateOrConnectWithoutCaseInput[]
    upsert?: MessageUpsertWithWhereUniqueWithoutCaseInput | MessageUpsertWithWhereUniqueWithoutCaseInput[]
    createMany?: MessageCreateManyCaseInputEnvelope
    set?: MessageWhereUniqueInput | MessageWhereUniqueInput[]
    disconnect?: MessageWhereUniqueInput | MessageWhereUniqueInput[]
    delete?: MessageWhereUniqueInput | MessageWhereUniqueInput[]
    connect?: MessageWhereUniqueInput | MessageWhereUniqueInput[]
    update?: MessageUpdateWithWhereUniqueWithoutCaseInput | MessageUpdateWithWhereUniqueWithoutCaseInput[]
    updateMany?: MessageUpdateManyWithWhereWithoutCaseInput | MessageUpdateManyWithWhereWithoutCaseInput[]
    deleteMany?: MessageScalarWhereInput | MessageScalarWhereInput[]
  }

  export type ExternalPartnerUpdateManyWithoutCaseNestedInput = {
    create?: XOR<ExternalPartnerCreateWithoutCaseInput, ExternalPartnerUncheckedCreateWithoutCaseInput> | ExternalPartnerCreateWithoutCaseInput[] | ExternalPartnerUncheckedCreateWithoutCaseInput[]
    connectOrCreate?: ExternalPartnerCreateOrConnectWithoutCaseInput | ExternalPartnerCreateOrConnectWithoutCaseInput[]
    upsert?: ExternalPartnerUpsertWithWhereUniqueWithoutCaseInput | ExternalPartnerUpsertWithWhereUniqueWithoutCaseInput[]
    createMany?: ExternalPartnerCreateManyCaseInputEnvelope
    set?: ExternalPartnerWhereUniqueInput | ExternalPartnerWhereUniqueInput[]
    disconnect?: ExternalPartnerWhereUniqueInput | ExternalPartnerWhereUniqueInput[]
    delete?: ExternalPartnerWhereUniqueInput | ExternalPartnerWhereUniqueInput[]
    connect?: ExternalPartnerWhereUniqueInput | ExternalPartnerWhereUniqueInput[]
    update?: ExternalPartnerUpdateWithWhereUniqueWithoutCaseInput | ExternalPartnerUpdateWithWhereUniqueWithoutCaseInput[]
    updateMany?: ExternalPartnerUpdateManyWithWhereWithoutCaseInput | ExternalPartnerUpdateManyWithWhereWithoutCaseInput[]
    deleteMany?: ExternalPartnerScalarWhereInput | ExternalPartnerScalarWhereInput[]
  }

  export type ExternalCommunicationUpdateManyWithoutCaseNestedInput = {
    create?: XOR<ExternalCommunicationCreateWithoutCaseInput, ExternalCommunicationUncheckedCreateWithoutCaseInput> | ExternalCommunicationCreateWithoutCaseInput[] | ExternalCommunicationUncheckedCreateWithoutCaseInput[]
    connectOrCreate?: ExternalCommunicationCreateOrConnectWithoutCaseInput | ExternalCommunicationCreateOrConnectWithoutCaseInput[]
    upsert?: ExternalCommunicationUpsertWithWhereUniqueWithoutCaseInput | ExternalCommunicationUpsertWithWhereUniqueWithoutCaseInput[]
    createMany?: ExternalCommunicationCreateManyCaseInputEnvelope
    set?: ExternalCommunicationWhereUniqueInput | ExternalCommunicationWhereUniqueInput[]
    disconnect?: ExternalCommunicationWhereUniqueInput | ExternalCommunicationWhereUniqueInput[]
    delete?: ExternalCommunicationWhereUniqueInput | ExternalCommunicationWhereUniqueInput[]
    connect?: ExternalCommunicationWhereUniqueInput | ExternalCommunicationWhereUniqueInput[]
    update?: ExternalCommunicationUpdateWithWhereUniqueWithoutCaseInput | ExternalCommunicationUpdateWithWhereUniqueWithoutCaseInput[]
    updateMany?: ExternalCommunicationUpdateManyWithWhereWithoutCaseInput | ExternalCommunicationUpdateManyWithWhereWithoutCaseInput[]
    deleteMany?: ExternalCommunicationScalarWhereInput | ExternalCommunicationScalarWhereInput[]
  }

  export type DocumentUncheckedUpdateManyWithoutCaseNestedInput = {
    create?: XOR<DocumentCreateWithoutCaseInput, DocumentUncheckedCreateWithoutCaseInput> | DocumentCreateWithoutCaseInput[] | DocumentUncheckedCreateWithoutCaseInput[]
    connectOrCreate?: DocumentCreateOrConnectWithoutCaseInput | DocumentCreateOrConnectWithoutCaseInput[]
    upsert?: DocumentUpsertWithWhereUniqueWithoutCaseInput | DocumentUpsertWithWhereUniqueWithoutCaseInput[]
    createMany?: DocumentCreateManyCaseInputEnvelope
    set?: DocumentWhereUniqueInput | DocumentWhereUniqueInput[]
    disconnect?: DocumentWhereUniqueInput | DocumentWhereUniqueInput[]
    delete?: DocumentWhereUniqueInput | DocumentWhereUniqueInput[]
    connect?: DocumentWhereUniqueInput | DocumentWhereUniqueInput[]
    update?: DocumentUpdateWithWhereUniqueWithoutCaseInput | DocumentUpdateWithWhereUniqueWithoutCaseInput[]
    updateMany?: DocumentUpdateManyWithWhereWithoutCaseInput | DocumentUpdateManyWithWhereWithoutCaseInput[]
    deleteMany?: DocumentScalarWhereInput | DocumentScalarWhereInput[]
  }

  export type PaymentUncheckedUpdateManyWithoutCaseNestedInput = {
    create?: XOR<PaymentCreateWithoutCaseInput, PaymentUncheckedCreateWithoutCaseInput> | PaymentCreateWithoutCaseInput[] | PaymentUncheckedCreateWithoutCaseInput[]
    connectOrCreate?: PaymentCreateOrConnectWithoutCaseInput | PaymentCreateOrConnectWithoutCaseInput[]
    upsert?: PaymentUpsertWithWhereUniqueWithoutCaseInput | PaymentUpsertWithWhereUniqueWithoutCaseInput[]
    createMany?: PaymentCreateManyCaseInputEnvelope
    set?: PaymentWhereUniqueInput | PaymentWhereUniqueInput[]
    disconnect?: PaymentWhereUniqueInput | PaymentWhereUniqueInput[]
    delete?: PaymentWhereUniqueInput | PaymentWhereUniqueInput[]
    connect?: PaymentWhereUniqueInput | PaymentWhereUniqueInput[]
    update?: PaymentUpdateWithWhereUniqueWithoutCaseInput | PaymentUpdateWithWhereUniqueWithoutCaseInput[]
    updateMany?: PaymentUpdateManyWithWhereWithoutCaseInput | PaymentUpdateManyWithWhereWithoutCaseInput[]
    deleteMany?: PaymentScalarWhereInput | PaymentScalarWhereInput[]
  }

  export type TimelineEventUncheckedUpdateManyWithoutCaseNestedInput = {
    create?: XOR<TimelineEventCreateWithoutCaseInput, TimelineEventUncheckedCreateWithoutCaseInput> | TimelineEventCreateWithoutCaseInput[] | TimelineEventUncheckedCreateWithoutCaseInput[]
    connectOrCreate?: TimelineEventCreateOrConnectWithoutCaseInput | TimelineEventCreateOrConnectWithoutCaseInput[]
    upsert?: TimelineEventUpsertWithWhereUniqueWithoutCaseInput | TimelineEventUpsertWithWhereUniqueWithoutCaseInput[]
    createMany?: TimelineEventCreateManyCaseInputEnvelope
    set?: TimelineEventWhereUniqueInput | TimelineEventWhereUniqueInput[]
    disconnect?: TimelineEventWhereUniqueInput | TimelineEventWhereUniqueInput[]
    delete?: TimelineEventWhereUniqueInput | TimelineEventWhereUniqueInput[]
    connect?: TimelineEventWhereUniqueInput | TimelineEventWhereUniqueInput[]
    update?: TimelineEventUpdateWithWhereUniqueWithoutCaseInput | TimelineEventUpdateWithWhereUniqueWithoutCaseInput[]
    updateMany?: TimelineEventUpdateManyWithWhereWithoutCaseInput | TimelineEventUpdateManyWithWhereWithoutCaseInput[]
    deleteMany?: TimelineEventScalarWhereInput | TimelineEventScalarWhereInput[]
  }

  export type MessageUncheckedUpdateManyWithoutCaseNestedInput = {
    create?: XOR<MessageCreateWithoutCaseInput, MessageUncheckedCreateWithoutCaseInput> | MessageCreateWithoutCaseInput[] | MessageUncheckedCreateWithoutCaseInput[]
    connectOrCreate?: MessageCreateOrConnectWithoutCaseInput | MessageCreateOrConnectWithoutCaseInput[]
    upsert?: MessageUpsertWithWhereUniqueWithoutCaseInput | MessageUpsertWithWhereUniqueWithoutCaseInput[]
    createMany?: MessageCreateManyCaseInputEnvelope
    set?: MessageWhereUniqueInput | MessageWhereUniqueInput[]
    disconnect?: MessageWhereUniqueInput | MessageWhereUniqueInput[]
    delete?: MessageWhereUniqueInput | MessageWhereUniqueInput[]
    connect?: MessageWhereUniqueInput | MessageWhereUniqueInput[]
    update?: MessageUpdateWithWhereUniqueWithoutCaseInput | MessageUpdateWithWhereUniqueWithoutCaseInput[]
    updateMany?: MessageUpdateManyWithWhereWithoutCaseInput | MessageUpdateManyWithWhereWithoutCaseInput[]
    deleteMany?: MessageScalarWhereInput | MessageScalarWhereInput[]
  }

  export type ExternalPartnerUncheckedUpdateManyWithoutCaseNestedInput = {
    create?: XOR<ExternalPartnerCreateWithoutCaseInput, ExternalPartnerUncheckedCreateWithoutCaseInput> | ExternalPartnerCreateWithoutCaseInput[] | ExternalPartnerUncheckedCreateWithoutCaseInput[]
    connectOrCreate?: ExternalPartnerCreateOrConnectWithoutCaseInput | ExternalPartnerCreateOrConnectWithoutCaseInput[]
    upsert?: ExternalPartnerUpsertWithWhereUniqueWithoutCaseInput | ExternalPartnerUpsertWithWhereUniqueWithoutCaseInput[]
    createMany?: ExternalPartnerCreateManyCaseInputEnvelope
    set?: ExternalPartnerWhereUniqueInput | ExternalPartnerWhereUniqueInput[]
    disconnect?: ExternalPartnerWhereUniqueInput | ExternalPartnerWhereUniqueInput[]
    delete?: ExternalPartnerWhereUniqueInput | ExternalPartnerWhereUniqueInput[]
    connect?: ExternalPartnerWhereUniqueInput | ExternalPartnerWhereUniqueInput[]
    update?: ExternalPartnerUpdateWithWhereUniqueWithoutCaseInput | ExternalPartnerUpdateWithWhereUniqueWithoutCaseInput[]
    updateMany?: ExternalPartnerUpdateManyWithWhereWithoutCaseInput | ExternalPartnerUpdateManyWithWhereWithoutCaseInput[]
    deleteMany?: ExternalPartnerScalarWhereInput | ExternalPartnerScalarWhereInput[]
  }

  export type ExternalCommunicationUncheckedUpdateManyWithoutCaseNestedInput = {
    create?: XOR<ExternalCommunicationCreateWithoutCaseInput, ExternalCommunicationUncheckedCreateWithoutCaseInput> | ExternalCommunicationCreateWithoutCaseInput[] | ExternalCommunicationUncheckedCreateWithoutCaseInput[]
    connectOrCreate?: ExternalCommunicationCreateOrConnectWithoutCaseInput | ExternalCommunicationCreateOrConnectWithoutCaseInput[]
    upsert?: ExternalCommunicationUpsertWithWhereUniqueWithoutCaseInput | ExternalCommunicationUpsertWithWhereUniqueWithoutCaseInput[]
    createMany?: ExternalCommunicationCreateManyCaseInputEnvelope
    set?: ExternalCommunicationWhereUniqueInput | ExternalCommunicationWhereUniqueInput[]
    disconnect?: ExternalCommunicationWhereUniqueInput | ExternalCommunicationWhereUniqueInput[]
    delete?: ExternalCommunicationWhereUniqueInput | ExternalCommunicationWhereUniqueInput[]
    connect?: ExternalCommunicationWhereUniqueInput | ExternalCommunicationWhereUniqueInput[]
    update?: ExternalCommunicationUpdateWithWhereUniqueWithoutCaseInput | ExternalCommunicationUpdateWithWhereUniqueWithoutCaseInput[]
    updateMany?: ExternalCommunicationUpdateManyWithWhereWithoutCaseInput | ExternalCommunicationUpdateManyWithWhereWithoutCaseInput[]
    deleteMany?: ExternalCommunicationScalarWhereInput | ExternalCommunicationScalarWhereInput[]
  }

  export type ExternalPartnerCreateNestedManyWithoutRoleInput = {
    create?: XOR<ExternalPartnerCreateWithoutRoleInput, ExternalPartnerUncheckedCreateWithoutRoleInput> | ExternalPartnerCreateWithoutRoleInput[] | ExternalPartnerUncheckedCreateWithoutRoleInput[]
    connectOrCreate?: ExternalPartnerCreateOrConnectWithoutRoleInput | ExternalPartnerCreateOrConnectWithoutRoleInput[]
    createMany?: ExternalPartnerCreateManyRoleInputEnvelope
    connect?: ExternalPartnerWhereUniqueInput | ExternalPartnerWhereUniqueInput[]
  }

  export type ExternalPartnerUncheckedCreateNestedManyWithoutRoleInput = {
    create?: XOR<ExternalPartnerCreateWithoutRoleInput, ExternalPartnerUncheckedCreateWithoutRoleInput> | ExternalPartnerCreateWithoutRoleInput[] | ExternalPartnerUncheckedCreateWithoutRoleInput[]
    connectOrCreate?: ExternalPartnerCreateOrConnectWithoutRoleInput | ExternalPartnerCreateOrConnectWithoutRoleInput[]
    createMany?: ExternalPartnerCreateManyRoleInputEnvelope
    connect?: ExternalPartnerWhereUniqueInput | ExternalPartnerWhereUniqueInput[]
  }

  export type ExternalPartnerUpdateManyWithoutRoleNestedInput = {
    create?: XOR<ExternalPartnerCreateWithoutRoleInput, ExternalPartnerUncheckedCreateWithoutRoleInput> | ExternalPartnerCreateWithoutRoleInput[] | ExternalPartnerUncheckedCreateWithoutRoleInput[]
    connectOrCreate?: ExternalPartnerCreateOrConnectWithoutRoleInput | ExternalPartnerCreateOrConnectWithoutRoleInput[]
    upsert?: ExternalPartnerUpsertWithWhereUniqueWithoutRoleInput | ExternalPartnerUpsertWithWhereUniqueWithoutRoleInput[]
    createMany?: ExternalPartnerCreateManyRoleInputEnvelope
    set?: ExternalPartnerWhereUniqueInput | ExternalPartnerWhereUniqueInput[]
    disconnect?: ExternalPartnerWhereUniqueInput | ExternalPartnerWhereUniqueInput[]
    delete?: ExternalPartnerWhereUniqueInput | ExternalPartnerWhereUniqueInput[]
    connect?: ExternalPartnerWhereUniqueInput | ExternalPartnerWhereUniqueInput[]
    update?: ExternalPartnerUpdateWithWhereUniqueWithoutRoleInput | ExternalPartnerUpdateWithWhereUniqueWithoutRoleInput[]
    updateMany?: ExternalPartnerUpdateManyWithWhereWithoutRoleInput | ExternalPartnerUpdateManyWithWhereWithoutRoleInput[]
    deleteMany?: ExternalPartnerScalarWhereInput | ExternalPartnerScalarWhereInput[]
  }

  export type ExternalPartnerUncheckedUpdateManyWithoutRoleNestedInput = {
    create?: XOR<ExternalPartnerCreateWithoutRoleInput, ExternalPartnerUncheckedCreateWithoutRoleInput> | ExternalPartnerCreateWithoutRoleInput[] | ExternalPartnerUncheckedCreateWithoutRoleInput[]
    connectOrCreate?: ExternalPartnerCreateOrConnectWithoutRoleInput | ExternalPartnerCreateOrConnectWithoutRoleInput[]
    upsert?: ExternalPartnerUpsertWithWhereUniqueWithoutRoleInput | ExternalPartnerUpsertWithWhereUniqueWithoutRoleInput[]
    createMany?: ExternalPartnerCreateManyRoleInputEnvelope
    set?: ExternalPartnerWhereUniqueInput | ExternalPartnerWhereUniqueInput[]
    disconnect?: ExternalPartnerWhereUniqueInput | ExternalPartnerWhereUniqueInput[]
    delete?: ExternalPartnerWhereUniqueInput | ExternalPartnerWhereUniqueInput[]
    connect?: ExternalPartnerWhereUniqueInput | ExternalPartnerWhereUniqueInput[]
    update?: ExternalPartnerUpdateWithWhereUniqueWithoutRoleInput | ExternalPartnerUpdateWithWhereUniqueWithoutRoleInput[]
    updateMany?: ExternalPartnerUpdateManyWithWhereWithoutRoleInput | ExternalPartnerUpdateManyWithWhereWithoutRoleInput[]
    deleteMany?: ExternalPartnerScalarWhereInput | ExternalPartnerScalarWhereInput[]
  }

  export type CaseCreateNestedOneWithoutExternalPartnersInput = {
    create?: XOR<CaseCreateWithoutExternalPartnersInput, CaseUncheckedCreateWithoutExternalPartnersInput>
    connectOrCreate?: CaseCreateOrConnectWithoutExternalPartnersInput
    connect?: CaseWhereUniqueInput
  }

  export type PartnerRoleCreateNestedOneWithoutPartnersInput = {
    create?: XOR<PartnerRoleCreateWithoutPartnersInput, PartnerRoleUncheckedCreateWithoutPartnersInput>
    connectOrCreate?: PartnerRoleCreateOrConnectWithoutPartnersInput
    connect?: PartnerRoleWhereUniqueInput
  }

  export type CaseUpdateOneRequiredWithoutExternalPartnersNestedInput = {
    create?: XOR<CaseCreateWithoutExternalPartnersInput, CaseUncheckedCreateWithoutExternalPartnersInput>
    connectOrCreate?: CaseCreateOrConnectWithoutExternalPartnersInput
    upsert?: CaseUpsertWithoutExternalPartnersInput
    connect?: CaseWhereUniqueInput
    update?: XOR<XOR<CaseUpdateToOneWithWhereWithoutExternalPartnersInput, CaseUpdateWithoutExternalPartnersInput>, CaseUncheckedUpdateWithoutExternalPartnersInput>
  }

  export type PartnerRoleUpdateOneRequiredWithoutPartnersNestedInput = {
    create?: XOR<PartnerRoleCreateWithoutPartnersInput, PartnerRoleUncheckedCreateWithoutPartnersInput>
    connectOrCreate?: PartnerRoleCreateOrConnectWithoutPartnersInput
    upsert?: PartnerRoleUpsertWithoutPartnersInput
    connect?: PartnerRoleWhereUniqueInput
    update?: XOR<XOR<PartnerRoleUpdateToOneWithWhereWithoutPartnersInput, PartnerRoleUpdateWithoutPartnersInput>, PartnerRoleUncheckedUpdateWithoutPartnersInput>
  }

  export type CaseCreateNestedOneWithoutExternalCommsInput = {
    create?: XOR<CaseCreateWithoutExternalCommsInput, CaseUncheckedCreateWithoutExternalCommsInput>
    connectOrCreate?: CaseCreateOrConnectWithoutExternalCommsInput
    connect?: CaseWhereUniqueInput
  }

  export type EnumDirectionFieldUpdateOperationsInput = {
    set?: $Enums.Direction
  }

  export type CaseUpdateOneRequiredWithoutExternalCommsNestedInput = {
    create?: XOR<CaseCreateWithoutExternalCommsInput, CaseUncheckedCreateWithoutExternalCommsInput>
    connectOrCreate?: CaseCreateOrConnectWithoutExternalCommsInput
    upsert?: CaseUpsertWithoutExternalCommsInput
    connect?: CaseWhereUniqueInput
    update?: XOR<XOR<CaseUpdateToOneWithWhereWithoutExternalCommsInput, CaseUpdateWithoutExternalCommsInput>, CaseUncheckedUpdateWithoutExternalCommsInput>
  }

  export type CaseCreateNestedOneWithoutDocumentsInput = {
    create?: XOR<CaseCreateWithoutDocumentsInput, CaseUncheckedCreateWithoutDocumentsInput>
    connectOrCreate?: CaseCreateOrConnectWithoutDocumentsInput
    connect?: CaseWhereUniqueInput
  }

  export type EnumDocStateFieldUpdateOperationsInput = {
    set?: $Enums.DocState
  }

  export type CaseUpdateOneRequiredWithoutDocumentsNestedInput = {
    create?: XOR<CaseCreateWithoutDocumentsInput, CaseUncheckedCreateWithoutDocumentsInput>
    connectOrCreate?: CaseCreateOrConnectWithoutDocumentsInput
    upsert?: CaseUpsertWithoutDocumentsInput
    connect?: CaseWhereUniqueInput
    update?: XOR<XOR<CaseUpdateToOneWithWhereWithoutDocumentsInput, CaseUpdateWithoutDocumentsInput>, CaseUncheckedUpdateWithoutDocumentsInput>
  }

  export type CaseCreateNestedOneWithoutPaymentsInput = {
    create?: XOR<CaseCreateWithoutPaymentsInput, CaseUncheckedCreateWithoutPaymentsInput>
    connectOrCreate?: CaseCreateOrConnectWithoutPaymentsInput
    connect?: CaseWhereUniqueInput
  }

  export type EnumPaymentStatusFieldUpdateOperationsInput = {
    set?: $Enums.PaymentStatus
  }

  export type CaseUpdateOneRequiredWithoutPaymentsNestedInput = {
    create?: XOR<CaseCreateWithoutPaymentsInput, CaseUncheckedCreateWithoutPaymentsInput>
    connectOrCreate?: CaseCreateOrConnectWithoutPaymentsInput
    upsert?: CaseUpsertWithoutPaymentsInput
    connect?: CaseWhereUniqueInput
    update?: XOR<XOR<CaseUpdateToOneWithWhereWithoutPaymentsInput, CaseUpdateWithoutPaymentsInput>, CaseUncheckedUpdateWithoutPaymentsInput>
  }

  export type CaseCreateNestedOneWithoutTimelineEventsInput = {
    create?: XOR<CaseCreateWithoutTimelineEventsInput, CaseUncheckedCreateWithoutTimelineEventsInput>
    connectOrCreate?: CaseCreateOrConnectWithoutTimelineEventsInput
    connect?: CaseWhereUniqueInput
  }

  export type CaseUpdateOneRequiredWithoutTimelineEventsNestedInput = {
    create?: XOR<CaseCreateWithoutTimelineEventsInput, CaseUncheckedCreateWithoutTimelineEventsInput>
    connectOrCreate?: CaseCreateOrConnectWithoutTimelineEventsInput
    upsert?: CaseUpsertWithoutTimelineEventsInput
    connect?: CaseWhereUniqueInput
    update?: XOR<XOR<CaseUpdateToOneWithWhereWithoutTimelineEventsInput, CaseUpdateWithoutTimelineEventsInput>, CaseUncheckedUpdateWithoutTimelineEventsInput>
  }

  export type CaseCreateNestedOneWithoutInternalMessagesInput = {
    create?: XOR<CaseCreateWithoutInternalMessagesInput, CaseUncheckedCreateWithoutInternalMessagesInput>
    connectOrCreate?: CaseCreateOrConnectWithoutInternalMessagesInput
    connect?: CaseWhereUniqueInput
  }

  export type CaseUpdateOneRequiredWithoutInternalMessagesNestedInput = {
    create?: XOR<CaseCreateWithoutInternalMessagesInput, CaseUncheckedCreateWithoutInternalMessagesInput>
    connectOrCreate?: CaseCreateOrConnectWithoutInternalMessagesInput
    upsert?: CaseUpsertWithoutInternalMessagesInput
    connect?: CaseWhereUniqueInput
    update?: XOR<XOR<CaseUpdateToOneWithWhereWithoutInternalMessagesInput, CaseUpdateWithoutInternalMessagesInput>, CaseUncheckedUpdateWithoutInternalMessagesInput>
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedEnumRoleFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[]
    notIn?: $Enums.Role[]
    not?: NestedEnumRoleFilter<$PrismaModel> | $Enums.Role
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedEnumRoleWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[]
    notIn?: $Enums.Role[]
    not?: NestedEnumRoleWithAggregatesFilter<$PrismaModel> | $Enums.Role
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumRoleFilter<$PrismaModel>
    _max?: NestedEnumRoleFilter<$PrismaModel>
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedEnumCaseStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.CaseStatus | EnumCaseStatusFieldRefInput<$PrismaModel>
    in?: $Enums.CaseStatus[]
    notIn?: $Enums.CaseStatus[]
    not?: NestedEnumCaseStatusFilter<$PrismaModel> | $Enums.CaseStatus
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedEnumCaseStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.CaseStatus | EnumCaseStatusFieldRefInput<$PrismaModel>
    in?: $Enums.CaseStatus[]
    notIn?: $Enums.CaseStatus[]
    not?: NestedEnumCaseStatusWithAggregatesFilter<$PrismaModel> | $Enums.CaseStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumCaseStatusFilter<$PrismaModel>
    _max?: NestedEnumCaseStatusFilter<$PrismaModel>
  }

  export type NestedEnumDirectionFilter<$PrismaModel = never> = {
    equals?: $Enums.Direction | EnumDirectionFieldRefInput<$PrismaModel>
    in?: $Enums.Direction[]
    notIn?: $Enums.Direction[]
    not?: NestedEnumDirectionFilter<$PrismaModel> | $Enums.Direction
  }

  export type NestedEnumDirectionWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Direction | EnumDirectionFieldRefInput<$PrismaModel>
    in?: $Enums.Direction[]
    notIn?: $Enums.Direction[]
    not?: NestedEnumDirectionWithAggregatesFilter<$PrismaModel> | $Enums.Direction
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumDirectionFilter<$PrismaModel>
    _max?: NestedEnumDirectionFilter<$PrismaModel>
  }

  export type NestedEnumDocStateFilter<$PrismaModel = never> = {
    equals?: $Enums.DocState | EnumDocStateFieldRefInput<$PrismaModel>
    in?: $Enums.DocState[]
    notIn?: $Enums.DocState[]
    not?: NestedEnumDocStateFilter<$PrismaModel> | $Enums.DocState
  }

  export type NestedEnumDocStateWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.DocState | EnumDocStateFieldRefInput<$PrismaModel>
    in?: $Enums.DocState[]
    notIn?: $Enums.DocState[]
    not?: NestedEnumDocStateWithAggregatesFilter<$PrismaModel> | $Enums.DocState
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumDocStateFilter<$PrismaModel>
    _max?: NestedEnumDocStateFilter<$PrismaModel>
  }

  export type NestedEnumPaymentStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.PaymentStatus | EnumPaymentStatusFieldRefInput<$PrismaModel>
    in?: $Enums.PaymentStatus[]
    notIn?: $Enums.PaymentStatus[]
    not?: NestedEnumPaymentStatusFilter<$PrismaModel> | $Enums.PaymentStatus
  }

  export type NestedEnumPaymentStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.PaymentStatus | EnumPaymentStatusFieldRefInput<$PrismaModel>
    in?: $Enums.PaymentStatus[]
    notIn?: $Enums.PaymentStatus[]
    not?: NestedEnumPaymentStatusWithAggregatesFilter<$PrismaModel> | $Enums.PaymentStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumPaymentStatusFilter<$PrismaModel>
    _max?: NestedEnumPaymentStatusFilter<$PrismaModel>
  }

  export type CaseCreateWithoutClientInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    caseManager?: UserCreateNestedOneWithoutCasesAsManagerInput
    lawyer?: UserCreateNestedOneWithoutCasesAsLawyerInput
    documents?: DocumentCreateNestedManyWithoutCaseInput
    payments?: PaymentCreateNestedManyWithoutCaseInput
    timelineEvents?: TimelineEventCreateNestedManyWithoutCaseInput
    internalMessages?: MessageCreateNestedManyWithoutCaseInput
    externalPartners?: ExternalPartnerCreateNestedManyWithoutCaseInput
    externalComms?: ExternalCommunicationCreateNestedManyWithoutCaseInput
  }

  export type CaseUncheckedCreateWithoutClientInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    caseManagerId?: string | null
    lawyerId?: string | null
    documents?: DocumentUncheckedCreateNestedManyWithoutCaseInput
    payments?: PaymentUncheckedCreateNestedManyWithoutCaseInput
    timelineEvents?: TimelineEventUncheckedCreateNestedManyWithoutCaseInput
    internalMessages?: MessageUncheckedCreateNestedManyWithoutCaseInput
    externalPartners?: ExternalPartnerUncheckedCreateNestedManyWithoutCaseInput
    externalComms?: ExternalCommunicationUncheckedCreateNestedManyWithoutCaseInput
  }

  export type CaseCreateOrConnectWithoutClientInput = {
    where: CaseWhereUniqueInput
    create: XOR<CaseCreateWithoutClientInput, CaseUncheckedCreateWithoutClientInput>
  }

  export type CaseCreateManyClientInputEnvelope = {
    data: CaseCreateManyClientInput | CaseCreateManyClientInput[]
  }

  export type CaseCreateWithoutCaseManagerInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    client?: UserCreateNestedOneWithoutCasesAsClientInput
    lawyer?: UserCreateNestedOneWithoutCasesAsLawyerInput
    documents?: DocumentCreateNestedManyWithoutCaseInput
    payments?: PaymentCreateNestedManyWithoutCaseInput
    timelineEvents?: TimelineEventCreateNestedManyWithoutCaseInput
    internalMessages?: MessageCreateNestedManyWithoutCaseInput
    externalPartners?: ExternalPartnerCreateNestedManyWithoutCaseInput
    externalComms?: ExternalCommunicationCreateNestedManyWithoutCaseInput
  }

  export type CaseUncheckedCreateWithoutCaseManagerInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    clientId?: string | null
    lawyerId?: string | null
    documents?: DocumentUncheckedCreateNestedManyWithoutCaseInput
    payments?: PaymentUncheckedCreateNestedManyWithoutCaseInput
    timelineEvents?: TimelineEventUncheckedCreateNestedManyWithoutCaseInput
    internalMessages?: MessageUncheckedCreateNestedManyWithoutCaseInput
    externalPartners?: ExternalPartnerUncheckedCreateNestedManyWithoutCaseInput
    externalComms?: ExternalCommunicationUncheckedCreateNestedManyWithoutCaseInput
  }

  export type CaseCreateOrConnectWithoutCaseManagerInput = {
    where: CaseWhereUniqueInput
    create: XOR<CaseCreateWithoutCaseManagerInput, CaseUncheckedCreateWithoutCaseManagerInput>
  }

  export type CaseCreateManyCaseManagerInputEnvelope = {
    data: CaseCreateManyCaseManagerInput | CaseCreateManyCaseManagerInput[]
  }

  export type CaseCreateWithoutLawyerInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    client?: UserCreateNestedOneWithoutCasesAsClientInput
    caseManager?: UserCreateNestedOneWithoutCasesAsManagerInput
    documents?: DocumentCreateNestedManyWithoutCaseInput
    payments?: PaymentCreateNestedManyWithoutCaseInput
    timelineEvents?: TimelineEventCreateNestedManyWithoutCaseInput
    internalMessages?: MessageCreateNestedManyWithoutCaseInput
    externalPartners?: ExternalPartnerCreateNestedManyWithoutCaseInput
    externalComms?: ExternalCommunicationCreateNestedManyWithoutCaseInput
  }

  export type CaseUncheckedCreateWithoutLawyerInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    clientId?: string | null
    caseManagerId?: string | null
    documents?: DocumentUncheckedCreateNestedManyWithoutCaseInput
    payments?: PaymentUncheckedCreateNestedManyWithoutCaseInput
    timelineEvents?: TimelineEventUncheckedCreateNestedManyWithoutCaseInput
    internalMessages?: MessageUncheckedCreateNestedManyWithoutCaseInput
    externalPartners?: ExternalPartnerUncheckedCreateNestedManyWithoutCaseInput
    externalComms?: ExternalCommunicationUncheckedCreateNestedManyWithoutCaseInput
  }

  export type CaseCreateOrConnectWithoutLawyerInput = {
    where: CaseWhereUniqueInput
    create: XOR<CaseCreateWithoutLawyerInput, CaseUncheckedCreateWithoutLawyerInput>
  }

  export type CaseCreateManyLawyerInputEnvelope = {
    data: CaseCreateManyLawyerInput | CaseCreateManyLawyerInput[]
  }

  export type CaseUpsertWithWhereUniqueWithoutClientInput = {
    where: CaseWhereUniqueInput
    update: XOR<CaseUpdateWithoutClientInput, CaseUncheckedUpdateWithoutClientInput>
    create: XOR<CaseCreateWithoutClientInput, CaseUncheckedCreateWithoutClientInput>
  }

  export type CaseUpdateWithWhereUniqueWithoutClientInput = {
    where: CaseWhereUniqueInput
    data: XOR<CaseUpdateWithoutClientInput, CaseUncheckedUpdateWithoutClientInput>
  }

  export type CaseUpdateManyWithWhereWithoutClientInput = {
    where: CaseScalarWhereInput
    data: XOR<CaseUpdateManyMutationInput, CaseUncheckedUpdateManyWithoutClientInput>
  }

  export type CaseScalarWhereInput = {
    AND?: CaseScalarWhereInput | CaseScalarWhereInput[]
    OR?: CaseScalarWhereInput[]
    NOT?: CaseScalarWhereInput | CaseScalarWhereInput[]
    id?: StringFilter<"Case"> | string
    createdAt?: DateTimeFilter<"Case"> | Date | string
    updatedAt?: DateTimeFilter<"Case"> | Date | string
    title?: StringFilter<"Case"> | string
    caseNumber?: StringFilter<"Case"> | string
    totalFee?: IntFilter<"Case"> | number
    currency?: StringFilter<"Case"> | string
    applicantName?: StringFilter<"Case"> | string
    applicantEmail?: StringFilter<"Case"> | string
    overallStatus?: EnumCaseStatusFilter<"Case"> | $Enums.CaseStatus
    stage?: StringFilter<"Case"> | string
    urgencyLevel?: StringFilter<"Case"> | string
    completionPercentage?: IntFilter<"Case"> | number
    clientId?: StringNullableFilter<"Case"> | string | null
    caseManagerId?: StringNullableFilter<"Case"> | string | null
    lawyerId?: StringNullableFilter<"Case"> | string | null
  }

  export type CaseUpsertWithWhereUniqueWithoutCaseManagerInput = {
    where: CaseWhereUniqueInput
    update: XOR<CaseUpdateWithoutCaseManagerInput, CaseUncheckedUpdateWithoutCaseManagerInput>
    create: XOR<CaseCreateWithoutCaseManagerInput, CaseUncheckedCreateWithoutCaseManagerInput>
  }

  export type CaseUpdateWithWhereUniqueWithoutCaseManagerInput = {
    where: CaseWhereUniqueInput
    data: XOR<CaseUpdateWithoutCaseManagerInput, CaseUncheckedUpdateWithoutCaseManagerInput>
  }

  export type CaseUpdateManyWithWhereWithoutCaseManagerInput = {
    where: CaseScalarWhereInput
    data: XOR<CaseUpdateManyMutationInput, CaseUncheckedUpdateManyWithoutCaseManagerInput>
  }

  export type CaseUpsertWithWhereUniqueWithoutLawyerInput = {
    where: CaseWhereUniqueInput
    update: XOR<CaseUpdateWithoutLawyerInput, CaseUncheckedUpdateWithoutLawyerInput>
    create: XOR<CaseCreateWithoutLawyerInput, CaseUncheckedCreateWithoutLawyerInput>
  }

  export type CaseUpdateWithWhereUniqueWithoutLawyerInput = {
    where: CaseWhereUniqueInput
    data: XOR<CaseUpdateWithoutLawyerInput, CaseUncheckedUpdateWithoutLawyerInput>
  }

  export type CaseUpdateManyWithWhereWithoutLawyerInput = {
    where: CaseScalarWhereInput
    data: XOR<CaseUpdateManyMutationInput, CaseUncheckedUpdateManyWithoutLawyerInput>
  }

  export type UserCreateWithoutCasesAsClientInput = {
    id?: string
    email: string
    name?: string | null
    role?: $Enums.Role
    password?: string | null
    casesAsManager?: CaseCreateNestedManyWithoutCaseManagerInput
    casesAsLawyer?: CaseCreateNestedManyWithoutLawyerInput
  }

  export type UserUncheckedCreateWithoutCasesAsClientInput = {
    id?: string
    email: string
    name?: string | null
    role?: $Enums.Role
    password?: string | null
    casesAsManager?: CaseUncheckedCreateNestedManyWithoutCaseManagerInput
    casesAsLawyer?: CaseUncheckedCreateNestedManyWithoutLawyerInput
  }

  export type UserCreateOrConnectWithoutCasesAsClientInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutCasesAsClientInput, UserUncheckedCreateWithoutCasesAsClientInput>
  }

  export type UserCreateWithoutCasesAsManagerInput = {
    id?: string
    email: string
    name?: string | null
    role?: $Enums.Role
    password?: string | null
    casesAsClient?: CaseCreateNestedManyWithoutClientInput
    casesAsLawyer?: CaseCreateNestedManyWithoutLawyerInput
  }

  export type UserUncheckedCreateWithoutCasesAsManagerInput = {
    id?: string
    email: string
    name?: string | null
    role?: $Enums.Role
    password?: string | null
    casesAsClient?: CaseUncheckedCreateNestedManyWithoutClientInput
    casesAsLawyer?: CaseUncheckedCreateNestedManyWithoutLawyerInput
  }

  export type UserCreateOrConnectWithoutCasesAsManagerInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutCasesAsManagerInput, UserUncheckedCreateWithoutCasesAsManagerInput>
  }

  export type UserCreateWithoutCasesAsLawyerInput = {
    id?: string
    email: string
    name?: string | null
    role?: $Enums.Role
    password?: string | null
    casesAsClient?: CaseCreateNestedManyWithoutClientInput
    casesAsManager?: CaseCreateNestedManyWithoutCaseManagerInput
  }

  export type UserUncheckedCreateWithoutCasesAsLawyerInput = {
    id?: string
    email: string
    name?: string | null
    role?: $Enums.Role
    password?: string | null
    casesAsClient?: CaseUncheckedCreateNestedManyWithoutClientInput
    casesAsManager?: CaseUncheckedCreateNestedManyWithoutCaseManagerInput
  }

  export type UserCreateOrConnectWithoutCasesAsLawyerInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutCasesAsLawyerInput, UserUncheckedCreateWithoutCasesAsLawyerInput>
  }

  export type DocumentCreateWithoutCaseInput = {
    id?: string
    name: string
    state: $Enums.DocState
  }

  export type DocumentUncheckedCreateWithoutCaseInput = {
    id?: string
    name: string
    state: $Enums.DocState
  }

  export type DocumentCreateOrConnectWithoutCaseInput = {
    where: DocumentWhereUniqueInput
    create: XOR<DocumentCreateWithoutCaseInput, DocumentUncheckedCreateWithoutCaseInput>
  }

  export type DocumentCreateManyCaseInputEnvelope = {
    data: DocumentCreateManyCaseInput | DocumentCreateManyCaseInput[]
  }

  export type PaymentCreateWithoutCaseInput = {
    id?: string
    amount: number
    currency: string
    status: $Enums.PaymentStatus
    description: string
    invoiceNumber: string
  }

  export type PaymentUncheckedCreateWithoutCaseInput = {
    id?: string
    amount: number
    currency: string
    status: $Enums.PaymentStatus
    description: string
    invoiceNumber: string
  }

  export type PaymentCreateOrConnectWithoutCaseInput = {
    where: PaymentWhereUniqueInput
    create: XOR<PaymentCreateWithoutCaseInput, PaymentUncheckedCreateWithoutCaseInput>
  }

  export type PaymentCreateManyCaseInputEnvelope = {
    data: PaymentCreateManyCaseInput | PaymentCreateManyCaseInput[]
  }

  export type TimelineEventCreateWithoutCaseInput = {
    id?: string
    createdAt?: Date | string
    details: string
  }

  export type TimelineEventUncheckedCreateWithoutCaseInput = {
    id?: string
    createdAt?: Date | string
    details: string
  }

  export type TimelineEventCreateOrConnectWithoutCaseInput = {
    where: TimelineEventWhereUniqueInput
    create: XOR<TimelineEventCreateWithoutCaseInput, TimelineEventUncheckedCreateWithoutCaseInput>
  }

  export type TimelineEventCreateManyCaseInputEnvelope = {
    data: TimelineEventCreateManyCaseInput | TimelineEventCreateManyCaseInput[]
  }

  export type MessageCreateWithoutCaseInput = {
    id?: string
    createdAt?: Date | string
    body: string
  }

  export type MessageUncheckedCreateWithoutCaseInput = {
    id?: string
    createdAt?: Date | string
    body: string
  }

  export type MessageCreateOrConnectWithoutCaseInput = {
    where: MessageWhereUniqueInput
    create: XOR<MessageCreateWithoutCaseInput, MessageUncheckedCreateWithoutCaseInput>
  }

  export type MessageCreateManyCaseInputEnvelope = {
    data: MessageCreateManyCaseInput | MessageCreateManyCaseInput[]
  }

  export type ExternalPartnerCreateWithoutCaseInput = {
    id?: string
    name: string
    email?: string | null
    type: string
    role: PartnerRoleCreateNestedOneWithoutPartnersInput
  }

  export type ExternalPartnerUncheckedCreateWithoutCaseInput = {
    id?: string
    name: string
    email?: string | null
    type: string
    roleId: string
  }

  export type ExternalPartnerCreateOrConnectWithoutCaseInput = {
    where: ExternalPartnerWhereUniqueInput
    create: XOR<ExternalPartnerCreateWithoutCaseInput, ExternalPartnerUncheckedCreateWithoutCaseInput>
  }

  export type ExternalPartnerCreateManyCaseInputEnvelope = {
    data: ExternalPartnerCreateManyCaseInput | ExternalPartnerCreateManyCaseInput[]
  }

  export type ExternalCommunicationCreateWithoutCaseInput = {
    id?: string
    createdAt?: Date | string
    direction: $Enums.Direction
    body: string
    sender: string
  }

  export type ExternalCommunicationUncheckedCreateWithoutCaseInput = {
    id?: string
    createdAt?: Date | string
    direction: $Enums.Direction
    body: string
    sender: string
  }

  export type ExternalCommunicationCreateOrConnectWithoutCaseInput = {
    where: ExternalCommunicationWhereUniqueInput
    create: XOR<ExternalCommunicationCreateWithoutCaseInput, ExternalCommunicationUncheckedCreateWithoutCaseInput>
  }

  export type ExternalCommunicationCreateManyCaseInputEnvelope = {
    data: ExternalCommunicationCreateManyCaseInput | ExternalCommunicationCreateManyCaseInput[]
  }

  export type UserUpsertWithoutCasesAsClientInput = {
    update: XOR<UserUpdateWithoutCasesAsClientInput, UserUncheckedUpdateWithoutCasesAsClientInput>
    create: XOR<UserCreateWithoutCasesAsClientInput, UserUncheckedCreateWithoutCasesAsClientInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutCasesAsClientInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutCasesAsClientInput, UserUncheckedUpdateWithoutCasesAsClientInput>
  }

  export type UserUpdateWithoutCasesAsClientInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    password?: NullableStringFieldUpdateOperationsInput | string | null
    casesAsManager?: CaseUpdateManyWithoutCaseManagerNestedInput
    casesAsLawyer?: CaseUpdateManyWithoutLawyerNestedInput
  }

  export type UserUncheckedUpdateWithoutCasesAsClientInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    password?: NullableStringFieldUpdateOperationsInput | string | null
    casesAsManager?: CaseUncheckedUpdateManyWithoutCaseManagerNestedInput
    casesAsLawyer?: CaseUncheckedUpdateManyWithoutLawyerNestedInput
  }

  export type UserUpsertWithoutCasesAsManagerInput = {
    update: XOR<UserUpdateWithoutCasesAsManagerInput, UserUncheckedUpdateWithoutCasesAsManagerInput>
    create: XOR<UserCreateWithoutCasesAsManagerInput, UserUncheckedCreateWithoutCasesAsManagerInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutCasesAsManagerInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutCasesAsManagerInput, UserUncheckedUpdateWithoutCasesAsManagerInput>
  }

  export type UserUpdateWithoutCasesAsManagerInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    password?: NullableStringFieldUpdateOperationsInput | string | null
    casesAsClient?: CaseUpdateManyWithoutClientNestedInput
    casesAsLawyer?: CaseUpdateManyWithoutLawyerNestedInput
  }

  export type UserUncheckedUpdateWithoutCasesAsManagerInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    password?: NullableStringFieldUpdateOperationsInput | string | null
    casesAsClient?: CaseUncheckedUpdateManyWithoutClientNestedInput
    casesAsLawyer?: CaseUncheckedUpdateManyWithoutLawyerNestedInput
  }

  export type UserUpsertWithoutCasesAsLawyerInput = {
    update: XOR<UserUpdateWithoutCasesAsLawyerInput, UserUncheckedUpdateWithoutCasesAsLawyerInput>
    create: XOR<UserCreateWithoutCasesAsLawyerInput, UserUncheckedCreateWithoutCasesAsLawyerInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutCasesAsLawyerInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutCasesAsLawyerInput, UserUncheckedUpdateWithoutCasesAsLawyerInput>
  }

  export type UserUpdateWithoutCasesAsLawyerInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    password?: NullableStringFieldUpdateOperationsInput | string | null
    casesAsClient?: CaseUpdateManyWithoutClientNestedInput
    casesAsManager?: CaseUpdateManyWithoutCaseManagerNestedInput
  }

  export type UserUncheckedUpdateWithoutCasesAsLawyerInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    password?: NullableStringFieldUpdateOperationsInput | string | null
    casesAsClient?: CaseUncheckedUpdateManyWithoutClientNestedInput
    casesAsManager?: CaseUncheckedUpdateManyWithoutCaseManagerNestedInput
  }

  export type DocumentUpsertWithWhereUniqueWithoutCaseInput = {
    where: DocumentWhereUniqueInput
    update: XOR<DocumentUpdateWithoutCaseInput, DocumentUncheckedUpdateWithoutCaseInput>
    create: XOR<DocumentCreateWithoutCaseInput, DocumentUncheckedCreateWithoutCaseInput>
  }

  export type DocumentUpdateWithWhereUniqueWithoutCaseInput = {
    where: DocumentWhereUniqueInput
    data: XOR<DocumentUpdateWithoutCaseInput, DocumentUncheckedUpdateWithoutCaseInput>
  }

  export type DocumentUpdateManyWithWhereWithoutCaseInput = {
    where: DocumentScalarWhereInput
    data: XOR<DocumentUpdateManyMutationInput, DocumentUncheckedUpdateManyWithoutCaseInput>
  }

  export type DocumentScalarWhereInput = {
    AND?: DocumentScalarWhereInput | DocumentScalarWhereInput[]
    OR?: DocumentScalarWhereInput[]
    NOT?: DocumentScalarWhereInput | DocumentScalarWhereInput[]
    id?: StringFilter<"Document"> | string
    name?: StringFilter<"Document"> | string
    state?: EnumDocStateFilter<"Document"> | $Enums.DocState
    caseId?: StringFilter<"Document"> | string
  }

  export type PaymentUpsertWithWhereUniqueWithoutCaseInput = {
    where: PaymentWhereUniqueInput
    update: XOR<PaymentUpdateWithoutCaseInput, PaymentUncheckedUpdateWithoutCaseInput>
    create: XOR<PaymentCreateWithoutCaseInput, PaymentUncheckedCreateWithoutCaseInput>
  }

  export type PaymentUpdateWithWhereUniqueWithoutCaseInput = {
    where: PaymentWhereUniqueInput
    data: XOR<PaymentUpdateWithoutCaseInput, PaymentUncheckedUpdateWithoutCaseInput>
  }

  export type PaymentUpdateManyWithWhereWithoutCaseInput = {
    where: PaymentScalarWhereInput
    data: XOR<PaymentUpdateManyMutationInput, PaymentUncheckedUpdateManyWithoutCaseInput>
  }

  export type PaymentScalarWhereInput = {
    AND?: PaymentScalarWhereInput | PaymentScalarWhereInput[]
    OR?: PaymentScalarWhereInput[]
    NOT?: PaymentScalarWhereInput | PaymentScalarWhereInput[]
    id?: StringFilter<"Payment"> | string
    amount?: IntFilter<"Payment"> | number
    currency?: StringFilter<"Payment"> | string
    status?: EnumPaymentStatusFilter<"Payment"> | $Enums.PaymentStatus
    description?: StringFilter<"Payment"> | string
    invoiceNumber?: StringFilter<"Payment"> | string
    caseId?: StringFilter<"Payment"> | string
  }

  export type TimelineEventUpsertWithWhereUniqueWithoutCaseInput = {
    where: TimelineEventWhereUniqueInput
    update: XOR<TimelineEventUpdateWithoutCaseInput, TimelineEventUncheckedUpdateWithoutCaseInput>
    create: XOR<TimelineEventCreateWithoutCaseInput, TimelineEventUncheckedCreateWithoutCaseInput>
  }

  export type TimelineEventUpdateWithWhereUniqueWithoutCaseInput = {
    where: TimelineEventWhereUniqueInput
    data: XOR<TimelineEventUpdateWithoutCaseInput, TimelineEventUncheckedUpdateWithoutCaseInput>
  }

  export type TimelineEventUpdateManyWithWhereWithoutCaseInput = {
    where: TimelineEventScalarWhereInput
    data: XOR<TimelineEventUpdateManyMutationInput, TimelineEventUncheckedUpdateManyWithoutCaseInput>
  }

  export type TimelineEventScalarWhereInput = {
    AND?: TimelineEventScalarWhereInput | TimelineEventScalarWhereInput[]
    OR?: TimelineEventScalarWhereInput[]
    NOT?: TimelineEventScalarWhereInput | TimelineEventScalarWhereInput[]
    id?: StringFilter<"TimelineEvent"> | string
    createdAt?: DateTimeFilter<"TimelineEvent"> | Date | string
    details?: StringFilter<"TimelineEvent"> | string
    caseId?: StringFilter<"TimelineEvent"> | string
  }

  export type MessageUpsertWithWhereUniqueWithoutCaseInput = {
    where: MessageWhereUniqueInput
    update: XOR<MessageUpdateWithoutCaseInput, MessageUncheckedUpdateWithoutCaseInput>
    create: XOR<MessageCreateWithoutCaseInput, MessageUncheckedCreateWithoutCaseInput>
  }

  export type MessageUpdateWithWhereUniqueWithoutCaseInput = {
    where: MessageWhereUniqueInput
    data: XOR<MessageUpdateWithoutCaseInput, MessageUncheckedUpdateWithoutCaseInput>
  }

  export type MessageUpdateManyWithWhereWithoutCaseInput = {
    where: MessageScalarWhereInput
    data: XOR<MessageUpdateManyMutationInput, MessageUncheckedUpdateManyWithoutCaseInput>
  }

  export type MessageScalarWhereInput = {
    AND?: MessageScalarWhereInput | MessageScalarWhereInput[]
    OR?: MessageScalarWhereInput[]
    NOT?: MessageScalarWhereInput | MessageScalarWhereInput[]
    id?: StringFilter<"Message"> | string
    createdAt?: DateTimeFilter<"Message"> | Date | string
    body?: StringFilter<"Message"> | string
    caseId?: StringFilter<"Message"> | string
  }

  export type ExternalPartnerUpsertWithWhereUniqueWithoutCaseInput = {
    where: ExternalPartnerWhereUniqueInput
    update: XOR<ExternalPartnerUpdateWithoutCaseInput, ExternalPartnerUncheckedUpdateWithoutCaseInput>
    create: XOR<ExternalPartnerCreateWithoutCaseInput, ExternalPartnerUncheckedCreateWithoutCaseInput>
  }

  export type ExternalPartnerUpdateWithWhereUniqueWithoutCaseInput = {
    where: ExternalPartnerWhereUniqueInput
    data: XOR<ExternalPartnerUpdateWithoutCaseInput, ExternalPartnerUncheckedUpdateWithoutCaseInput>
  }

  export type ExternalPartnerUpdateManyWithWhereWithoutCaseInput = {
    where: ExternalPartnerScalarWhereInput
    data: XOR<ExternalPartnerUpdateManyMutationInput, ExternalPartnerUncheckedUpdateManyWithoutCaseInput>
  }

  export type ExternalPartnerScalarWhereInput = {
    AND?: ExternalPartnerScalarWhereInput | ExternalPartnerScalarWhereInput[]
    OR?: ExternalPartnerScalarWhereInput[]
    NOT?: ExternalPartnerScalarWhereInput | ExternalPartnerScalarWhereInput[]
    id?: StringFilter<"ExternalPartner"> | string
    name?: StringFilter<"ExternalPartner"> | string
    email?: StringNullableFilter<"ExternalPartner"> | string | null
    type?: StringFilter<"ExternalPartner"> | string
    caseId?: StringFilter<"ExternalPartner"> | string
    roleId?: StringFilter<"ExternalPartner"> | string
  }

  export type ExternalCommunicationUpsertWithWhereUniqueWithoutCaseInput = {
    where: ExternalCommunicationWhereUniqueInput
    update: XOR<ExternalCommunicationUpdateWithoutCaseInput, ExternalCommunicationUncheckedUpdateWithoutCaseInput>
    create: XOR<ExternalCommunicationCreateWithoutCaseInput, ExternalCommunicationUncheckedCreateWithoutCaseInput>
  }

  export type ExternalCommunicationUpdateWithWhereUniqueWithoutCaseInput = {
    where: ExternalCommunicationWhereUniqueInput
    data: XOR<ExternalCommunicationUpdateWithoutCaseInput, ExternalCommunicationUncheckedUpdateWithoutCaseInput>
  }

  export type ExternalCommunicationUpdateManyWithWhereWithoutCaseInput = {
    where: ExternalCommunicationScalarWhereInput
    data: XOR<ExternalCommunicationUpdateManyMutationInput, ExternalCommunicationUncheckedUpdateManyWithoutCaseInput>
  }

  export type ExternalCommunicationScalarWhereInput = {
    AND?: ExternalCommunicationScalarWhereInput | ExternalCommunicationScalarWhereInput[]
    OR?: ExternalCommunicationScalarWhereInput[]
    NOT?: ExternalCommunicationScalarWhereInput | ExternalCommunicationScalarWhereInput[]
    id?: StringFilter<"ExternalCommunication"> | string
    createdAt?: DateTimeFilter<"ExternalCommunication"> | Date | string
    direction?: EnumDirectionFilter<"ExternalCommunication"> | $Enums.Direction
    body?: StringFilter<"ExternalCommunication"> | string
    sender?: StringFilter<"ExternalCommunication"> | string
    caseId?: StringFilter<"ExternalCommunication"> | string
  }

  export type ExternalPartnerCreateWithoutRoleInput = {
    id?: string
    name: string
    email?: string | null
    type: string
    case: CaseCreateNestedOneWithoutExternalPartnersInput
  }

  export type ExternalPartnerUncheckedCreateWithoutRoleInput = {
    id?: string
    name: string
    email?: string | null
    type: string
    caseId: string
  }

  export type ExternalPartnerCreateOrConnectWithoutRoleInput = {
    where: ExternalPartnerWhereUniqueInput
    create: XOR<ExternalPartnerCreateWithoutRoleInput, ExternalPartnerUncheckedCreateWithoutRoleInput>
  }

  export type ExternalPartnerCreateManyRoleInputEnvelope = {
    data: ExternalPartnerCreateManyRoleInput | ExternalPartnerCreateManyRoleInput[]
  }

  export type ExternalPartnerUpsertWithWhereUniqueWithoutRoleInput = {
    where: ExternalPartnerWhereUniqueInput
    update: XOR<ExternalPartnerUpdateWithoutRoleInput, ExternalPartnerUncheckedUpdateWithoutRoleInput>
    create: XOR<ExternalPartnerCreateWithoutRoleInput, ExternalPartnerUncheckedCreateWithoutRoleInput>
  }

  export type ExternalPartnerUpdateWithWhereUniqueWithoutRoleInput = {
    where: ExternalPartnerWhereUniqueInput
    data: XOR<ExternalPartnerUpdateWithoutRoleInput, ExternalPartnerUncheckedUpdateWithoutRoleInput>
  }

  export type ExternalPartnerUpdateManyWithWhereWithoutRoleInput = {
    where: ExternalPartnerScalarWhereInput
    data: XOR<ExternalPartnerUpdateManyMutationInput, ExternalPartnerUncheckedUpdateManyWithoutRoleInput>
  }

  export type CaseCreateWithoutExternalPartnersInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    client?: UserCreateNestedOneWithoutCasesAsClientInput
    caseManager?: UserCreateNestedOneWithoutCasesAsManagerInput
    lawyer?: UserCreateNestedOneWithoutCasesAsLawyerInput
    documents?: DocumentCreateNestedManyWithoutCaseInput
    payments?: PaymentCreateNestedManyWithoutCaseInput
    timelineEvents?: TimelineEventCreateNestedManyWithoutCaseInput
    internalMessages?: MessageCreateNestedManyWithoutCaseInput
    externalComms?: ExternalCommunicationCreateNestedManyWithoutCaseInput
  }

  export type CaseUncheckedCreateWithoutExternalPartnersInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    clientId?: string | null
    caseManagerId?: string | null
    lawyerId?: string | null
    documents?: DocumentUncheckedCreateNestedManyWithoutCaseInput
    payments?: PaymentUncheckedCreateNestedManyWithoutCaseInput
    timelineEvents?: TimelineEventUncheckedCreateNestedManyWithoutCaseInput
    internalMessages?: MessageUncheckedCreateNestedManyWithoutCaseInput
    externalComms?: ExternalCommunicationUncheckedCreateNestedManyWithoutCaseInput
  }

  export type CaseCreateOrConnectWithoutExternalPartnersInput = {
    where: CaseWhereUniqueInput
    create: XOR<CaseCreateWithoutExternalPartnersInput, CaseUncheckedCreateWithoutExternalPartnersInput>
  }

  export type PartnerRoleCreateWithoutPartnersInput = {
    id?: string
    name: string
  }

  export type PartnerRoleUncheckedCreateWithoutPartnersInput = {
    id?: string
    name: string
  }

  export type PartnerRoleCreateOrConnectWithoutPartnersInput = {
    where: PartnerRoleWhereUniqueInput
    create: XOR<PartnerRoleCreateWithoutPartnersInput, PartnerRoleUncheckedCreateWithoutPartnersInput>
  }

  export type CaseUpsertWithoutExternalPartnersInput = {
    update: XOR<CaseUpdateWithoutExternalPartnersInput, CaseUncheckedUpdateWithoutExternalPartnersInput>
    create: XOR<CaseCreateWithoutExternalPartnersInput, CaseUncheckedCreateWithoutExternalPartnersInput>
    where?: CaseWhereInput
  }

  export type CaseUpdateToOneWithWhereWithoutExternalPartnersInput = {
    where?: CaseWhereInput
    data: XOR<CaseUpdateWithoutExternalPartnersInput, CaseUncheckedUpdateWithoutExternalPartnersInput>
  }

  export type CaseUpdateWithoutExternalPartnersInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
    client?: UserUpdateOneWithoutCasesAsClientNestedInput
    caseManager?: UserUpdateOneWithoutCasesAsManagerNestedInput
    lawyer?: UserUpdateOneWithoutCasesAsLawyerNestedInput
    documents?: DocumentUpdateManyWithoutCaseNestedInput
    payments?: PaymentUpdateManyWithoutCaseNestedInput
    timelineEvents?: TimelineEventUpdateManyWithoutCaseNestedInput
    internalMessages?: MessageUpdateManyWithoutCaseNestedInput
    externalComms?: ExternalCommunicationUpdateManyWithoutCaseNestedInput
  }

  export type CaseUncheckedUpdateWithoutExternalPartnersInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
    clientId?: NullableStringFieldUpdateOperationsInput | string | null
    caseManagerId?: NullableStringFieldUpdateOperationsInput | string | null
    lawyerId?: NullableStringFieldUpdateOperationsInput | string | null
    documents?: DocumentUncheckedUpdateManyWithoutCaseNestedInput
    payments?: PaymentUncheckedUpdateManyWithoutCaseNestedInput
    timelineEvents?: TimelineEventUncheckedUpdateManyWithoutCaseNestedInput
    internalMessages?: MessageUncheckedUpdateManyWithoutCaseNestedInput
    externalComms?: ExternalCommunicationUncheckedUpdateManyWithoutCaseNestedInput
  }

  export type PartnerRoleUpsertWithoutPartnersInput = {
    update: XOR<PartnerRoleUpdateWithoutPartnersInput, PartnerRoleUncheckedUpdateWithoutPartnersInput>
    create: XOR<PartnerRoleCreateWithoutPartnersInput, PartnerRoleUncheckedCreateWithoutPartnersInput>
    where?: PartnerRoleWhereInput
  }

  export type PartnerRoleUpdateToOneWithWhereWithoutPartnersInput = {
    where?: PartnerRoleWhereInput
    data: XOR<PartnerRoleUpdateWithoutPartnersInput, PartnerRoleUncheckedUpdateWithoutPartnersInput>
  }

  export type PartnerRoleUpdateWithoutPartnersInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
  }

  export type PartnerRoleUncheckedUpdateWithoutPartnersInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
  }

  export type CaseCreateWithoutExternalCommsInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    client?: UserCreateNestedOneWithoutCasesAsClientInput
    caseManager?: UserCreateNestedOneWithoutCasesAsManagerInput
    lawyer?: UserCreateNestedOneWithoutCasesAsLawyerInput
    documents?: DocumentCreateNestedManyWithoutCaseInput
    payments?: PaymentCreateNestedManyWithoutCaseInput
    timelineEvents?: TimelineEventCreateNestedManyWithoutCaseInput
    internalMessages?: MessageCreateNestedManyWithoutCaseInput
    externalPartners?: ExternalPartnerCreateNestedManyWithoutCaseInput
  }

  export type CaseUncheckedCreateWithoutExternalCommsInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    clientId?: string | null
    caseManagerId?: string | null
    lawyerId?: string | null
    documents?: DocumentUncheckedCreateNestedManyWithoutCaseInput
    payments?: PaymentUncheckedCreateNestedManyWithoutCaseInput
    timelineEvents?: TimelineEventUncheckedCreateNestedManyWithoutCaseInput
    internalMessages?: MessageUncheckedCreateNestedManyWithoutCaseInput
    externalPartners?: ExternalPartnerUncheckedCreateNestedManyWithoutCaseInput
  }

  export type CaseCreateOrConnectWithoutExternalCommsInput = {
    where: CaseWhereUniqueInput
    create: XOR<CaseCreateWithoutExternalCommsInput, CaseUncheckedCreateWithoutExternalCommsInput>
  }

  export type CaseUpsertWithoutExternalCommsInput = {
    update: XOR<CaseUpdateWithoutExternalCommsInput, CaseUncheckedUpdateWithoutExternalCommsInput>
    create: XOR<CaseCreateWithoutExternalCommsInput, CaseUncheckedCreateWithoutExternalCommsInput>
    where?: CaseWhereInput
  }

  export type CaseUpdateToOneWithWhereWithoutExternalCommsInput = {
    where?: CaseWhereInput
    data: XOR<CaseUpdateWithoutExternalCommsInput, CaseUncheckedUpdateWithoutExternalCommsInput>
  }

  export type CaseUpdateWithoutExternalCommsInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
    client?: UserUpdateOneWithoutCasesAsClientNestedInput
    caseManager?: UserUpdateOneWithoutCasesAsManagerNestedInput
    lawyer?: UserUpdateOneWithoutCasesAsLawyerNestedInput
    documents?: DocumentUpdateManyWithoutCaseNestedInput
    payments?: PaymentUpdateManyWithoutCaseNestedInput
    timelineEvents?: TimelineEventUpdateManyWithoutCaseNestedInput
    internalMessages?: MessageUpdateManyWithoutCaseNestedInput
    externalPartners?: ExternalPartnerUpdateManyWithoutCaseNestedInput
  }

  export type CaseUncheckedUpdateWithoutExternalCommsInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
    clientId?: NullableStringFieldUpdateOperationsInput | string | null
    caseManagerId?: NullableStringFieldUpdateOperationsInput | string | null
    lawyerId?: NullableStringFieldUpdateOperationsInput | string | null
    documents?: DocumentUncheckedUpdateManyWithoutCaseNestedInput
    payments?: PaymentUncheckedUpdateManyWithoutCaseNestedInput
    timelineEvents?: TimelineEventUncheckedUpdateManyWithoutCaseNestedInput
    internalMessages?: MessageUncheckedUpdateManyWithoutCaseNestedInput
    externalPartners?: ExternalPartnerUncheckedUpdateManyWithoutCaseNestedInput
  }

  export type CaseCreateWithoutDocumentsInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    client?: UserCreateNestedOneWithoutCasesAsClientInput
    caseManager?: UserCreateNestedOneWithoutCasesAsManagerInput
    lawyer?: UserCreateNestedOneWithoutCasesAsLawyerInput
    payments?: PaymentCreateNestedManyWithoutCaseInput
    timelineEvents?: TimelineEventCreateNestedManyWithoutCaseInput
    internalMessages?: MessageCreateNestedManyWithoutCaseInput
    externalPartners?: ExternalPartnerCreateNestedManyWithoutCaseInput
    externalComms?: ExternalCommunicationCreateNestedManyWithoutCaseInput
  }

  export type CaseUncheckedCreateWithoutDocumentsInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    clientId?: string | null
    caseManagerId?: string | null
    lawyerId?: string | null
    payments?: PaymentUncheckedCreateNestedManyWithoutCaseInput
    timelineEvents?: TimelineEventUncheckedCreateNestedManyWithoutCaseInput
    internalMessages?: MessageUncheckedCreateNestedManyWithoutCaseInput
    externalPartners?: ExternalPartnerUncheckedCreateNestedManyWithoutCaseInput
    externalComms?: ExternalCommunicationUncheckedCreateNestedManyWithoutCaseInput
  }

  export type CaseCreateOrConnectWithoutDocumentsInput = {
    where: CaseWhereUniqueInput
    create: XOR<CaseCreateWithoutDocumentsInput, CaseUncheckedCreateWithoutDocumentsInput>
  }

  export type CaseUpsertWithoutDocumentsInput = {
    update: XOR<CaseUpdateWithoutDocumentsInput, CaseUncheckedUpdateWithoutDocumentsInput>
    create: XOR<CaseCreateWithoutDocumentsInput, CaseUncheckedCreateWithoutDocumentsInput>
    where?: CaseWhereInput
  }

  export type CaseUpdateToOneWithWhereWithoutDocumentsInput = {
    where?: CaseWhereInput
    data: XOR<CaseUpdateWithoutDocumentsInput, CaseUncheckedUpdateWithoutDocumentsInput>
  }

  export type CaseUpdateWithoutDocumentsInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
    client?: UserUpdateOneWithoutCasesAsClientNestedInput
    caseManager?: UserUpdateOneWithoutCasesAsManagerNestedInput
    lawyer?: UserUpdateOneWithoutCasesAsLawyerNestedInput
    payments?: PaymentUpdateManyWithoutCaseNestedInput
    timelineEvents?: TimelineEventUpdateManyWithoutCaseNestedInput
    internalMessages?: MessageUpdateManyWithoutCaseNestedInput
    externalPartners?: ExternalPartnerUpdateManyWithoutCaseNestedInput
    externalComms?: ExternalCommunicationUpdateManyWithoutCaseNestedInput
  }

  export type CaseUncheckedUpdateWithoutDocumentsInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
    clientId?: NullableStringFieldUpdateOperationsInput | string | null
    caseManagerId?: NullableStringFieldUpdateOperationsInput | string | null
    lawyerId?: NullableStringFieldUpdateOperationsInput | string | null
    payments?: PaymentUncheckedUpdateManyWithoutCaseNestedInput
    timelineEvents?: TimelineEventUncheckedUpdateManyWithoutCaseNestedInput
    internalMessages?: MessageUncheckedUpdateManyWithoutCaseNestedInput
    externalPartners?: ExternalPartnerUncheckedUpdateManyWithoutCaseNestedInput
    externalComms?: ExternalCommunicationUncheckedUpdateManyWithoutCaseNestedInput
  }

  export type CaseCreateWithoutPaymentsInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    client?: UserCreateNestedOneWithoutCasesAsClientInput
    caseManager?: UserCreateNestedOneWithoutCasesAsManagerInput
    lawyer?: UserCreateNestedOneWithoutCasesAsLawyerInput
    documents?: DocumentCreateNestedManyWithoutCaseInput
    timelineEvents?: TimelineEventCreateNestedManyWithoutCaseInput
    internalMessages?: MessageCreateNestedManyWithoutCaseInput
    externalPartners?: ExternalPartnerCreateNestedManyWithoutCaseInput
    externalComms?: ExternalCommunicationCreateNestedManyWithoutCaseInput
  }

  export type CaseUncheckedCreateWithoutPaymentsInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    clientId?: string | null
    caseManagerId?: string | null
    lawyerId?: string | null
    documents?: DocumentUncheckedCreateNestedManyWithoutCaseInput
    timelineEvents?: TimelineEventUncheckedCreateNestedManyWithoutCaseInput
    internalMessages?: MessageUncheckedCreateNestedManyWithoutCaseInput
    externalPartners?: ExternalPartnerUncheckedCreateNestedManyWithoutCaseInput
    externalComms?: ExternalCommunicationUncheckedCreateNestedManyWithoutCaseInput
  }

  export type CaseCreateOrConnectWithoutPaymentsInput = {
    where: CaseWhereUniqueInput
    create: XOR<CaseCreateWithoutPaymentsInput, CaseUncheckedCreateWithoutPaymentsInput>
  }

  export type CaseUpsertWithoutPaymentsInput = {
    update: XOR<CaseUpdateWithoutPaymentsInput, CaseUncheckedUpdateWithoutPaymentsInput>
    create: XOR<CaseCreateWithoutPaymentsInput, CaseUncheckedCreateWithoutPaymentsInput>
    where?: CaseWhereInput
  }

  export type CaseUpdateToOneWithWhereWithoutPaymentsInput = {
    where?: CaseWhereInput
    data: XOR<CaseUpdateWithoutPaymentsInput, CaseUncheckedUpdateWithoutPaymentsInput>
  }

  export type CaseUpdateWithoutPaymentsInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
    client?: UserUpdateOneWithoutCasesAsClientNestedInput
    caseManager?: UserUpdateOneWithoutCasesAsManagerNestedInput
    lawyer?: UserUpdateOneWithoutCasesAsLawyerNestedInput
    documents?: DocumentUpdateManyWithoutCaseNestedInput
    timelineEvents?: TimelineEventUpdateManyWithoutCaseNestedInput
    internalMessages?: MessageUpdateManyWithoutCaseNestedInput
    externalPartners?: ExternalPartnerUpdateManyWithoutCaseNestedInput
    externalComms?: ExternalCommunicationUpdateManyWithoutCaseNestedInput
  }

  export type CaseUncheckedUpdateWithoutPaymentsInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
    clientId?: NullableStringFieldUpdateOperationsInput | string | null
    caseManagerId?: NullableStringFieldUpdateOperationsInput | string | null
    lawyerId?: NullableStringFieldUpdateOperationsInput | string | null
    documents?: DocumentUncheckedUpdateManyWithoutCaseNestedInput
    timelineEvents?: TimelineEventUncheckedUpdateManyWithoutCaseNestedInput
    internalMessages?: MessageUncheckedUpdateManyWithoutCaseNestedInput
    externalPartners?: ExternalPartnerUncheckedUpdateManyWithoutCaseNestedInput
    externalComms?: ExternalCommunicationUncheckedUpdateManyWithoutCaseNestedInput
  }

  export type CaseCreateWithoutTimelineEventsInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    client?: UserCreateNestedOneWithoutCasesAsClientInput
    caseManager?: UserCreateNestedOneWithoutCasesAsManagerInput
    lawyer?: UserCreateNestedOneWithoutCasesAsLawyerInput
    documents?: DocumentCreateNestedManyWithoutCaseInput
    payments?: PaymentCreateNestedManyWithoutCaseInput
    internalMessages?: MessageCreateNestedManyWithoutCaseInput
    externalPartners?: ExternalPartnerCreateNestedManyWithoutCaseInput
    externalComms?: ExternalCommunicationCreateNestedManyWithoutCaseInput
  }

  export type CaseUncheckedCreateWithoutTimelineEventsInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    clientId?: string | null
    caseManagerId?: string | null
    lawyerId?: string | null
    documents?: DocumentUncheckedCreateNestedManyWithoutCaseInput
    payments?: PaymentUncheckedCreateNestedManyWithoutCaseInput
    internalMessages?: MessageUncheckedCreateNestedManyWithoutCaseInput
    externalPartners?: ExternalPartnerUncheckedCreateNestedManyWithoutCaseInput
    externalComms?: ExternalCommunicationUncheckedCreateNestedManyWithoutCaseInput
  }

  export type CaseCreateOrConnectWithoutTimelineEventsInput = {
    where: CaseWhereUniqueInput
    create: XOR<CaseCreateWithoutTimelineEventsInput, CaseUncheckedCreateWithoutTimelineEventsInput>
  }

  export type CaseUpsertWithoutTimelineEventsInput = {
    update: XOR<CaseUpdateWithoutTimelineEventsInput, CaseUncheckedUpdateWithoutTimelineEventsInput>
    create: XOR<CaseCreateWithoutTimelineEventsInput, CaseUncheckedCreateWithoutTimelineEventsInput>
    where?: CaseWhereInput
  }

  export type CaseUpdateToOneWithWhereWithoutTimelineEventsInput = {
    where?: CaseWhereInput
    data: XOR<CaseUpdateWithoutTimelineEventsInput, CaseUncheckedUpdateWithoutTimelineEventsInput>
  }

  export type CaseUpdateWithoutTimelineEventsInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
    client?: UserUpdateOneWithoutCasesAsClientNestedInput
    caseManager?: UserUpdateOneWithoutCasesAsManagerNestedInput
    lawyer?: UserUpdateOneWithoutCasesAsLawyerNestedInput
    documents?: DocumentUpdateManyWithoutCaseNestedInput
    payments?: PaymentUpdateManyWithoutCaseNestedInput
    internalMessages?: MessageUpdateManyWithoutCaseNestedInput
    externalPartners?: ExternalPartnerUpdateManyWithoutCaseNestedInput
    externalComms?: ExternalCommunicationUpdateManyWithoutCaseNestedInput
  }

  export type CaseUncheckedUpdateWithoutTimelineEventsInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
    clientId?: NullableStringFieldUpdateOperationsInput | string | null
    caseManagerId?: NullableStringFieldUpdateOperationsInput | string | null
    lawyerId?: NullableStringFieldUpdateOperationsInput | string | null
    documents?: DocumentUncheckedUpdateManyWithoutCaseNestedInput
    payments?: PaymentUncheckedUpdateManyWithoutCaseNestedInput
    internalMessages?: MessageUncheckedUpdateManyWithoutCaseNestedInput
    externalPartners?: ExternalPartnerUncheckedUpdateManyWithoutCaseNestedInput
    externalComms?: ExternalCommunicationUncheckedUpdateManyWithoutCaseNestedInput
  }

  export type CaseCreateWithoutInternalMessagesInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    client?: UserCreateNestedOneWithoutCasesAsClientInput
    caseManager?: UserCreateNestedOneWithoutCasesAsManagerInput
    lawyer?: UserCreateNestedOneWithoutCasesAsLawyerInput
    documents?: DocumentCreateNestedManyWithoutCaseInput
    payments?: PaymentCreateNestedManyWithoutCaseInput
    timelineEvents?: TimelineEventCreateNestedManyWithoutCaseInput
    externalPartners?: ExternalPartnerCreateNestedManyWithoutCaseInput
    externalComms?: ExternalCommunicationCreateNestedManyWithoutCaseInput
  }

  export type CaseUncheckedCreateWithoutInternalMessagesInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    clientId?: string | null
    caseManagerId?: string | null
    lawyerId?: string | null
    documents?: DocumentUncheckedCreateNestedManyWithoutCaseInput
    payments?: PaymentUncheckedCreateNestedManyWithoutCaseInput
    timelineEvents?: TimelineEventUncheckedCreateNestedManyWithoutCaseInput
    externalPartners?: ExternalPartnerUncheckedCreateNestedManyWithoutCaseInput
    externalComms?: ExternalCommunicationUncheckedCreateNestedManyWithoutCaseInput
  }

  export type CaseCreateOrConnectWithoutInternalMessagesInput = {
    where: CaseWhereUniqueInput
    create: XOR<CaseCreateWithoutInternalMessagesInput, CaseUncheckedCreateWithoutInternalMessagesInput>
  }

  export type CaseUpsertWithoutInternalMessagesInput = {
    update: XOR<CaseUpdateWithoutInternalMessagesInput, CaseUncheckedUpdateWithoutInternalMessagesInput>
    create: XOR<CaseCreateWithoutInternalMessagesInput, CaseUncheckedCreateWithoutInternalMessagesInput>
    where?: CaseWhereInput
  }

  export type CaseUpdateToOneWithWhereWithoutInternalMessagesInput = {
    where?: CaseWhereInput
    data: XOR<CaseUpdateWithoutInternalMessagesInput, CaseUncheckedUpdateWithoutInternalMessagesInput>
  }

  export type CaseUpdateWithoutInternalMessagesInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
    client?: UserUpdateOneWithoutCasesAsClientNestedInput
    caseManager?: UserUpdateOneWithoutCasesAsManagerNestedInput
    lawyer?: UserUpdateOneWithoutCasesAsLawyerNestedInput
    documents?: DocumentUpdateManyWithoutCaseNestedInput
    payments?: PaymentUpdateManyWithoutCaseNestedInput
    timelineEvents?: TimelineEventUpdateManyWithoutCaseNestedInput
    externalPartners?: ExternalPartnerUpdateManyWithoutCaseNestedInput
    externalComms?: ExternalCommunicationUpdateManyWithoutCaseNestedInput
  }

  export type CaseUncheckedUpdateWithoutInternalMessagesInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
    clientId?: NullableStringFieldUpdateOperationsInput | string | null
    caseManagerId?: NullableStringFieldUpdateOperationsInput | string | null
    lawyerId?: NullableStringFieldUpdateOperationsInput | string | null
    documents?: DocumentUncheckedUpdateManyWithoutCaseNestedInput
    payments?: PaymentUncheckedUpdateManyWithoutCaseNestedInput
    timelineEvents?: TimelineEventUncheckedUpdateManyWithoutCaseNestedInput
    externalPartners?: ExternalPartnerUncheckedUpdateManyWithoutCaseNestedInput
    externalComms?: ExternalCommunicationUncheckedUpdateManyWithoutCaseNestedInput
  }

  export type CaseCreateManyClientInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    caseManagerId?: string | null
    lawyerId?: string | null
  }

  export type CaseCreateManyCaseManagerInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    clientId?: string | null
    lawyerId?: string | null
  }

  export type CaseCreateManyLawyerInput = {
    id?: string
    createdAt?: Date | string
    updatedAt?: Date | string
    title: string
    caseNumber: string
    totalFee: number
    currency: string
    applicantName: string
    applicantEmail: string
    overallStatus: $Enums.CaseStatus
    stage: string
    urgencyLevel: string
    completionPercentage: number
    clientId?: string | null
    caseManagerId?: string | null
  }

  export type CaseUpdateWithoutClientInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
    caseManager?: UserUpdateOneWithoutCasesAsManagerNestedInput
    lawyer?: UserUpdateOneWithoutCasesAsLawyerNestedInput
    documents?: DocumentUpdateManyWithoutCaseNestedInput
    payments?: PaymentUpdateManyWithoutCaseNestedInput
    timelineEvents?: TimelineEventUpdateManyWithoutCaseNestedInput
    internalMessages?: MessageUpdateManyWithoutCaseNestedInput
    externalPartners?: ExternalPartnerUpdateManyWithoutCaseNestedInput
    externalComms?: ExternalCommunicationUpdateManyWithoutCaseNestedInput
  }

  export type CaseUncheckedUpdateWithoutClientInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
    caseManagerId?: NullableStringFieldUpdateOperationsInput | string | null
    lawyerId?: NullableStringFieldUpdateOperationsInput | string | null
    documents?: DocumentUncheckedUpdateManyWithoutCaseNestedInput
    payments?: PaymentUncheckedUpdateManyWithoutCaseNestedInput
    timelineEvents?: TimelineEventUncheckedUpdateManyWithoutCaseNestedInput
    internalMessages?: MessageUncheckedUpdateManyWithoutCaseNestedInput
    externalPartners?: ExternalPartnerUncheckedUpdateManyWithoutCaseNestedInput
    externalComms?: ExternalCommunicationUncheckedUpdateManyWithoutCaseNestedInput
  }

  export type CaseUncheckedUpdateManyWithoutClientInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
    caseManagerId?: NullableStringFieldUpdateOperationsInput | string | null
    lawyerId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type CaseUpdateWithoutCaseManagerInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
    client?: UserUpdateOneWithoutCasesAsClientNestedInput
    lawyer?: UserUpdateOneWithoutCasesAsLawyerNestedInput
    documents?: DocumentUpdateManyWithoutCaseNestedInput
    payments?: PaymentUpdateManyWithoutCaseNestedInput
    timelineEvents?: TimelineEventUpdateManyWithoutCaseNestedInput
    internalMessages?: MessageUpdateManyWithoutCaseNestedInput
    externalPartners?: ExternalPartnerUpdateManyWithoutCaseNestedInput
    externalComms?: ExternalCommunicationUpdateManyWithoutCaseNestedInput
  }

  export type CaseUncheckedUpdateWithoutCaseManagerInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
    clientId?: NullableStringFieldUpdateOperationsInput | string | null
    lawyerId?: NullableStringFieldUpdateOperationsInput | string | null
    documents?: DocumentUncheckedUpdateManyWithoutCaseNestedInput
    payments?: PaymentUncheckedUpdateManyWithoutCaseNestedInput
    timelineEvents?: TimelineEventUncheckedUpdateManyWithoutCaseNestedInput
    internalMessages?: MessageUncheckedUpdateManyWithoutCaseNestedInput
    externalPartners?: ExternalPartnerUncheckedUpdateManyWithoutCaseNestedInput
    externalComms?: ExternalCommunicationUncheckedUpdateManyWithoutCaseNestedInput
  }

  export type CaseUncheckedUpdateManyWithoutCaseManagerInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
    clientId?: NullableStringFieldUpdateOperationsInput | string | null
    lawyerId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type CaseUpdateWithoutLawyerInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
    client?: UserUpdateOneWithoutCasesAsClientNestedInput
    caseManager?: UserUpdateOneWithoutCasesAsManagerNestedInput
    documents?: DocumentUpdateManyWithoutCaseNestedInput
    payments?: PaymentUpdateManyWithoutCaseNestedInput
    timelineEvents?: TimelineEventUpdateManyWithoutCaseNestedInput
    internalMessages?: MessageUpdateManyWithoutCaseNestedInput
    externalPartners?: ExternalPartnerUpdateManyWithoutCaseNestedInput
    externalComms?: ExternalCommunicationUpdateManyWithoutCaseNestedInput
  }

  export type CaseUncheckedUpdateWithoutLawyerInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
    clientId?: NullableStringFieldUpdateOperationsInput | string | null
    caseManagerId?: NullableStringFieldUpdateOperationsInput | string | null
    documents?: DocumentUncheckedUpdateManyWithoutCaseNestedInput
    payments?: PaymentUncheckedUpdateManyWithoutCaseNestedInput
    timelineEvents?: TimelineEventUncheckedUpdateManyWithoutCaseNestedInput
    internalMessages?: MessageUncheckedUpdateManyWithoutCaseNestedInput
    externalPartners?: ExternalPartnerUncheckedUpdateManyWithoutCaseNestedInput
    externalComms?: ExternalCommunicationUncheckedUpdateManyWithoutCaseNestedInput
  }

  export type CaseUncheckedUpdateManyWithoutLawyerInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    caseNumber?: StringFieldUpdateOperationsInput | string
    totalFee?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    applicantName?: StringFieldUpdateOperationsInput | string
    applicantEmail?: StringFieldUpdateOperationsInput | string
    overallStatus?: EnumCaseStatusFieldUpdateOperationsInput | $Enums.CaseStatus
    stage?: StringFieldUpdateOperationsInput | string
    urgencyLevel?: StringFieldUpdateOperationsInput | string
    completionPercentage?: IntFieldUpdateOperationsInput | number
    clientId?: NullableStringFieldUpdateOperationsInput | string | null
    caseManagerId?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type DocumentCreateManyCaseInput = {
    id?: string
    name: string
    state: $Enums.DocState
  }

  export type PaymentCreateManyCaseInput = {
    id?: string
    amount: number
    currency: string
    status: $Enums.PaymentStatus
    description: string
    invoiceNumber: string
  }

  export type TimelineEventCreateManyCaseInput = {
    id?: string
    createdAt?: Date | string
    details: string
  }

  export type MessageCreateManyCaseInput = {
    id?: string
    createdAt?: Date | string
    body: string
  }

  export type ExternalPartnerCreateManyCaseInput = {
    id?: string
    name: string
    email?: string | null
    type: string
    roleId: string
  }

  export type ExternalCommunicationCreateManyCaseInput = {
    id?: string
    createdAt?: Date | string
    direction: $Enums.Direction
    body: string
    sender: string
  }

  export type DocumentUpdateWithoutCaseInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    state?: EnumDocStateFieldUpdateOperationsInput | $Enums.DocState
  }

  export type DocumentUncheckedUpdateWithoutCaseInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    state?: EnumDocStateFieldUpdateOperationsInput | $Enums.DocState
  }

  export type DocumentUncheckedUpdateManyWithoutCaseInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    state?: EnumDocStateFieldUpdateOperationsInput | $Enums.DocState
  }

  export type PaymentUpdateWithoutCaseInput = {
    id?: StringFieldUpdateOperationsInput | string
    amount?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    status?: EnumPaymentStatusFieldUpdateOperationsInput | $Enums.PaymentStatus
    description?: StringFieldUpdateOperationsInput | string
    invoiceNumber?: StringFieldUpdateOperationsInput | string
  }

  export type PaymentUncheckedUpdateWithoutCaseInput = {
    id?: StringFieldUpdateOperationsInput | string
    amount?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    status?: EnumPaymentStatusFieldUpdateOperationsInput | $Enums.PaymentStatus
    description?: StringFieldUpdateOperationsInput | string
    invoiceNumber?: StringFieldUpdateOperationsInput | string
  }

  export type PaymentUncheckedUpdateManyWithoutCaseInput = {
    id?: StringFieldUpdateOperationsInput | string
    amount?: IntFieldUpdateOperationsInput | number
    currency?: StringFieldUpdateOperationsInput | string
    status?: EnumPaymentStatusFieldUpdateOperationsInput | $Enums.PaymentStatus
    description?: StringFieldUpdateOperationsInput | string
    invoiceNumber?: StringFieldUpdateOperationsInput | string
  }

  export type TimelineEventUpdateWithoutCaseInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    details?: StringFieldUpdateOperationsInput | string
  }

  export type TimelineEventUncheckedUpdateWithoutCaseInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    details?: StringFieldUpdateOperationsInput | string
  }

  export type TimelineEventUncheckedUpdateManyWithoutCaseInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    details?: StringFieldUpdateOperationsInput | string
  }

  export type MessageUpdateWithoutCaseInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    body?: StringFieldUpdateOperationsInput | string
  }

  export type MessageUncheckedUpdateWithoutCaseInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    body?: StringFieldUpdateOperationsInput | string
  }

  export type MessageUncheckedUpdateManyWithoutCaseInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    body?: StringFieldUpdateOperationsInput | string
  }

  export type ExternalPartnerUpdateWithoutCaseInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    role?: PartnerRoleUpdateOneRequiredWithoutPartnersNestedInput
  }

  export type ExternalPartnerUncheckedUpdateWithoutCaseInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    roleId?: StringFieldUpdateOperationsInput | string
  }

  export type ExternalPartnerUncheckedUpdateManyWithoutCaseInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    roleId?: StringFieldUpdateOperationsInput | string
  }

  export type ExternalCommunicationUpdateWithoutCaseInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    direction?: EnumDirectionFieldUpdateOperationsInput | $Enums.Direction
    body?: StringFieldUpdateOperationsInput | string
    sender?: StringFieldUpdateOperationsInput | string
  }

  export type ExternalCommunicationUncheckedUpdateWithoutCaseInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    direction?: EnumDirectionFieldUpdateOperationsInput | $Enums.Direction
    body?: StringFieldUpdateOperationsInput | string
    sender?: StringFieldUpdateOperationsInput | string
  }

  export type ExternalCommunicationUncheckedUpdateManyWithoutCaseInput = {
    id?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    direction?: EnumDirectionFieldUpdateOperationsInput | $Enums.Direction
    body?: StringFieldUpdateOperationsInput | string
    sender?: StringFieldUpdateOperationsInput | string
  }

  export type ExternalPartnerCreateManyRoleInput = {
    id?: string
    name: string
    email?: string | null
    type: string
    caseId: string
  }

  export type ExternalPartnerUpdateWithoutRoleInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    case?: CaseUpdateOneRequiredWithoutExternalPartnersNestedInput
  }

  export type ExternalPartnerUncheckedUpdateWithoutRoleInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    caseId?: StringFieldUpdateOperationsInput | string
  }

  export type ExternalPartnerUncheckedUpdateManyWithoutRoleInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    caseId?: StringFieldUpdateOperationsInput | string
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}